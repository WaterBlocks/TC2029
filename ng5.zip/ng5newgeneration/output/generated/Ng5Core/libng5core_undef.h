//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBNG5CORE) && !defined(IPLIB)
#   error IPLIB or LIBNG5CORE is not defined
#endif

#undef NG5CORE_API
#undef NG5COREEXPORT
#undef NG5COREGLOBAL
#undef NG5COREPRIVATE