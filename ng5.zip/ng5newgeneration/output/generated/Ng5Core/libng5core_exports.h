//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/** 
    @file 

    This file contains the declaration for the Dispatch Library  Ng5Core

*/

#include <common/library_indicators.h>

#ifdef EXPORTLIBRARY
#define EXPORTLIBRARY something else
#error ExportLibrary was already defined
#endif

#define EXPORTLIBRARY            libNg5Core

#if !defined(LIBNG5CORE) && !defined(IPLIB)
#   error IPLIB or LIBNG5CORE is not defined
#endif

/* Handwritten code should use NG5CORE_API, not NG5COREEXPORT */

#define NG5CORE_API NG5COREEXPORT

#if IPLIB==libNg5Core || defined(LIBNG5CORE)
#   if defined(__lint)
#       define NG5COREEXPORT       __export(Ng5Core)
#       define NG5COREGLOBAL       extern __global(Ng5Core)
#       define NG5COREPRIVATE      extern __private(Ng5Core)
#   elif defined(_WIN32)
#       define NG5COREEXPORT       __declspec(dllexport)
#       define NG5COREGLOBAL       extern __declspec(dllexport)
#       define NG5COREPRIVATE      extern
#   else
#       define NG5COREEXPORT
#       define NG5COREGLOBAL       extern
#       define NG5COREPRIVATE      extern
#   endif
#else
#   if defined(__lint)
#       define NG5COREEXPORT       __export(Ng5Core)
#       define NG5COREGLOBAL       extern __global(Ng5Core)
#   elif defined(_WIN32) && !defined(WNT_STATIC_LINK)
#       define NG5COREEXPORT      __declspec(dllimport)
#       define NG5COREGLOBAL       extern __declspec(dllimport)
#   else
#       define NG5COREEXPORT
#       define NG5COREGLOBAL       extern
#   endif
#endif