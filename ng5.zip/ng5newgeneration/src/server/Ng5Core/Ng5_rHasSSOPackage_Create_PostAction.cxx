//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasSSOPackage_Create_PostAction
 *
 */
#include <Ng5Core/Ng5_rHasSSOPackage_Create_PostAction.hxx>

int Ng5_rHasSSOPackage_Create_PostAction( METHOD_message_t * msg, va_list args)
{
	int ifail = ITK_ok;
	TC_write_syslog("\n\n Entered extension on rHasSSOPackage GRM Create\n\n");
	va_list uargs;
	va_copy(uargs,args);

	tag_t launch_tag = va_arg(uargs, tag_t);
	tag_t ssopkgrev_tag = va_arg(uargs, tag_t);
	va_end(uargs);

	char* ssopkg_name =NULL;
	tag_t masterform_relation = NULLTAG;
	int launchmaster_count =0;
	tag_t* launch_master_tags = NULL;
	char* launch_master_name= NULL;
	tag_t ssopkg_item = NULL;
	int ssopkg_master_count = 0;
	tag_t* ssopkg_master_tags =NULL;
	char* ssopkg_master_name = NULL;
	char ssopkg_custom_id[128];

	TC_write_syslog("\n\n Launch Tag :%d\n\n",launch_tag);
	TC_write_syslog("\n\n SSO PKG Rev Tag :%d\n\n",ssopkgrev_tag);

	ifail = GRM_find_relation_type(IMAN_master_form, &masterform_relation);
	TC_write_syslog("\n\n IMAN_master_form relation tag:%d\n\n",masterform_relation);

	ifail= GRM_list_secondary_objects_only(launch_tag, masterform_relation, &launchmaster_count, &launch_master_tags);
	TC_write_syslog("\n\n Launch->GRM list secondary ifail: %d, count:%d\n\n", ifail, launchmaster_count);

	ifail = AOM_ask_value_string(launch_master_tags[0],object_name, &launch_master_name);
	TC_write_syslog("\n\n Launch Master Name: %s\n\n",launch_master_name);
	MEM_free(launch_master_tags);

	ifail = AOM_ask_value_tag(ssopkgrev_tag, items_tag, &ssopkg_item);
	TC_write_syslog("\n\n SSO Pkg Item Tag: %d\n\n", ssopkg_item);

	ifail = GRM_list_secondary_objects_only(ssopkg_item, masterform_relation, &ssopkg_master_count, &ssopkg_master_tags);
	TC_write_syslog("\n\n SSOPKG->GRM list secondary ifail: %d, count:%d\n\n", ifail, ssopkg_master_count);

	ifail = AOM_ask_value_string(ssopkg_master_tags[0], object_name, &ssopkg_master_name);
	TC_write_syslog("\n\n SSOPKG Master Name:%s\n\n", ssopkg_master_name);
	MEM_free(ssopkg_master_tags);


	strcpy(ssopkg_custom_id, launch_master_name);
	strcat(ssopkg_custom_id, "-");
	strcat(ssopkg_custom_id, ssopkg_master_name);
	TC_write_syslog("\n\n SSOPkg_custom_id: %s\n\n", ssopkg_custom_id);

	AOM_lock(ssopkg_item);
	ifail = ITEM_set_id(ssopkg_item,ssopkg_custom_id);
	TC_write_syslog("\n\n Set SSOPKG ID ifail:%d\n\n",ifail);
	AOM_save_with_extensions(ssopkg_item); //TC 12 Upgrade
	AOM_unlock(ssopkg_item);

	ifail = AOM_ask_value_string(ssopkgrev_tag, object_name, &ssopkg_name);
	TC_write_syslog("\n\n SSOpkg name: %s\n\n", ssopkg_name);

	if(tc_strcmp(ssopkg_name,SSOPkg_Name_value2)==0 || tc_strcmp(ssopkg_name,SSOPkg_Name_value3)==0 ||
			tc_strcmp(ssopkg_name,SSOPkg_Name_value4)==0 ||	tc_strcmp(ssopkg_name,SSOPkg_Name_value5)==0 ||
					tc_strcmp(ssopkg_name,SSOPkg_Name_value6)==0||
					tc_strcmp(ssopkg_name,SSOPkg_Name_value7)==0){

		tag_t masterprg_tag = NULLTAG;
		char* masterPrg_id = NULL;
		tag_t project_tag = NULLTAG;

		ifail = AOM_ask_value_tag(launch_tag, Ng5_launchprg_masterprg, &masterprg_tag);
		TC_write_syslog("\n\n Master Prg Tag: %d\n\n",masterprg_tag);

		AOM_ask_value_string(masterprg_tag, item_id, &masterPrg_id);
		TC_write_syslog("\n\n Master Prg ID: %s\n\n",masterPrg_id);

		PROJ_find(masterPrg_id, &project_tag);
		TC_write_syslog("\n\n Project Tag: %d\n\n", project_tag);

		ifail= PROJ_assign_objects(1, &project_tag, 1, &ssopkgrev_tag);
		TC_write_syslog("\n\n proj assign ifail: %d\n\n", ifail);

	}
	else{
		TC_write_syslog("\n\n Name is Development Start, So no need of this postaction\n\n");
	}
 
 return 0;

}
