 
 /*********************************************************************************************
** File Name:         Ng5_SetUgmasterOEM.cxx
**
** File Description:
*   This file contains the implementation for the Extension Ng5_SetUgmasterOEM
**
** History:
**   mm/dd/yyyy  Name                   Comments
**   ----------  -------------          -------------------------
**   08/29/2018  Manjula Tirunagari     Initial Version
                                        Added implementation for use case 6220.
                                        During checkin of ugmaster if we have oem environment value in UGpartattributes form,
                                        populate it to Item Revision and Item Name display constants
**  05/07/2021   Balaji                 TC12 Upgrade
*********************************************************************************************/
#include <Ng5Core/Ng5_SetUgmasterOEM.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_SetUgmasterOEM( METHOD_message_t * msg, va_list args )
{



    int        retCode            = ITK_ok;

    /*  TC_write_syslog("\n Entering Ng5_SetUgmasterOEM");

    //Get the dataset tag from arguments
    tag_t     tDataset         = NULLTAG;

    va_list largs;
    va_copy(largs,args);
    tDataset = va_arg(largs, tag_t);

    if (NULLTAG != tDataset)    
    {
        
        int    iNamedRefs      = 0;
        tag_t  *tpNamedRefs    = NULL;
        tag_t  tObjType        = NULLTAG;
        char   *chTypeName     = NULL;


        TCTYPE_ask_object_type(tDataset,&tObjType);
        //TC12 Upgrade
        TCTYPE_ask_name2 (tObjType,&chTypeName);


        if (tc_strcmp(chTypeName,DATASET_UGMASTER) !=0 )
        {        
            TC_write_syslog("Exiting method Ng5_SetUgmasterOEM as dataset is not a UGMASTER.\n");
            return retCode;
        }

        //Get all the named references of the Dataset
        ITK (AE_ask_dataset_named_refs (tDataset, &iNamedRefs, &tpNamedRefs) );

        if( (iNamedRefs > 0) && (tpNamedRefs != NULL) )
        {
            //Scan through each Named Reference
            for(int iNr=0; iNr<iNamedRefs; iNr++)
            {
                if(NULLTAG != tpNamedRefs[iNr])
                {
                    //Check the Type Name of the Named Reference
                    tag_t    tNrType    =    NULLTAG;
                    ITK( TCTYPE_ask_object_type(tpNamedRefs[iNr], &tNrType) );
                    if (NULLTAG != tNrType)
                    {
                        char    *cpNRClassName    = NULL;
                        ITK( TCTYPE_ask_name2( tNrType, &cpNRClassName ) ) ;
                        
                        if(NULL != cpNRClassName)
                        {
                            //If the type is ugpartattributesForm
                            if (tc_strcmp (cpNRClassName, UGPART_ATTR_FORM) == 0)
                            {
                                char *cpOEMName = NULL;
                                tag_t pom_instance = NULLTAG;
                                FORM_ask_pom_instance(tpNamedRefs[iNr], &pom_instance);
                                AOM_ask_value_string(pom_instance,NX_ENV,&cpOEMName);
                                TC_write_syslog("OEM environment value from UGPartAttributes Form is %s \n",cpOEMName);
                                
                                tag_t tRelTypeTag = NULLTAG;
                                ITK(GRM_find_relation_type(REL_SPECIFICATION, &tRelTypeTag));
                                //find the primary objects
                                if(tRelTypeTag != NULLTAG &&  (cpOEMName != NULL))
                                {
                                    int iPartRevs = 0;
                                    tag_t *tPartRevs = NULL;
                                    ITK(GRM_list_primary_objects_only(tDataset, tRelTypeTag, &iPartRevs, &tPartRevs));
                                    

                                    if(iPartRevs > 0 && tPartRevs != NULL)
                                    {
                                        char *cpItemRevOEMValue =  NULL;
                                        ITK(AOM_ask_value_string(tPartRevs[0],OEM_ENV ,&cpItemRevOEMValue));
					//US 153988     
                                       // if ( cpItemRevOEMValue ==  NULL || tc_strlen(cpItemRevOEMValue)==0 )
                                        {
                                            TC_write_syslog("Setting OEM_env as %s \n",cpOEMName);
                                            ITK(AOM_refresh(tPartRevs[0], POM_modify_lock));
                                            ITK(AOM_set_value_string(tPartRevs[0],OEM_ENV ,cpOEMName));
                                            ITK(AOM_save_with_extensions(tPartRevs[0]));//TC12 Upgrade
                                            ITK(AOM_refresh(tPartRevs[0], POM_no_lock));
                                            NG5_MEM_TCFREE( cpOEMName );
                                        }
                                        NG5_MEM_TCFREE( cpItemRevOEMValue );

                                    }
                                }
                            }
                        }
                    }
                }

            }
        }
		MEM_TCFREE(chTypeName);
    }

     TC_write_syslog("Exiting method Ng5_SetUgmasterOEM.\n");*/
 
 return retCode;

}
