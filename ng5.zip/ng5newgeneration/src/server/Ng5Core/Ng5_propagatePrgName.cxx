//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_propagatePrgName
 *
 */
#include <Ng5Core/Ng5_propagatePrgName.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_propagatePrgName( METHOD_message_t * msg, va_list args )
{
 
    int   iFail = ITK_ok;
    char  secondary_type[WSO_name_size_c+1] = "";
    char  primary_type[WSO_name_size_c+1]   = "";
	char* sObject_name                      = NULL;
	char *       sProgramConcatAttr         = NULL;

    va_list largs;
    va_copy( largs, args );

    tag_t  primary_object      = va_arg(largs, tag_t);
    tag_t  secondary_object    = va_arg(largs, tag_t);

	NG5_ITK_CALL( PREF_ask_char_value( NG5_PROGRAM_CONCAT_PROPERTY,0,&sProgramConcatAttr));

    NG5_ITK_CALL( AOM_ask_value_string( primary_object,sProgramConcatAttr,&sObject_name ));

    TC_write_syslog("\n Ng5_propagatePrgName : Value of preference attribute is --%s--- \n", sObject_name);

    NG5_ITK_CALL( AOM_refresh( secondary_object, POM_modify_lock ));
    NG5_ITK_CALL( AOM_set_value_string( secondary_object, sProgramConcatAttr, sObject_name ));
    NG5_ITK_CALL( AOM_save( secondary_object ));
    NG5_ITK_CALL( AOM_unlock( secondary_object ));


	MEM_free( sProgramConcatAttr );

    return iFail;
}
