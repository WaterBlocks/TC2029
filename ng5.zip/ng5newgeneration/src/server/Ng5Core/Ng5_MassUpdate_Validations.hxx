//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_MassUpdate_Validations
 *
 */
 
#ifndef NG5_MASSUPDATE_VALIDATIONS_HXX
#define NG5_MASSUPDATE_VALIDATIONS_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_MassUpdate_Validations(METHOD_message_t* msg, va_list args);

#define NG5_MASS_UPDATE_TYPE            "ng5_Mass_Update_Type"
#define NG5_START_EFFECTIVITY           "ng5_Start_Effectivity"
#define NG5_END_EFFECTIVITY           "ng5_End_Effectivity"
#define NG5_REPLACE           				"Replace"
#define NG5_ADD           				"Add"
#define NG5_ADD_WITH_SIBLING           				"Add with Sibling"
#define NG5_REMOVE           				"Effect Out"
#define NG5_REMOVE_WITH_SIBLING           	"Effect Out Part2 where Part1 Exist"
#define NG5_MODIFY           				"Modify"
#define CUSTOM_ERRORBASE                         919000
#define NG5_START_END_EFFECTIVITY				CUSTOM_ERRORBASE +3009
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_MASSUPDATE_VALIDATIONS_HXX
