//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_SetImportedStatusOnCheckin
 *	 Created Date	:	15-May-2016
 * 	 Created By		:	Siva Sundararaj
 * 	 Functionality	:	This function sets Imported Status on Item Rev and its secondary 
 *						objects with Specification, Rendering, Manifestation and BVR
 *
 */
#include <Ng5Core/Ng5_SetImportedStatusOnCheckin.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

/******************************************************************************
 * **
 * Created By	:	Sachin Rampure
 * Created Date	:	15-Dec-2016
 * Modified Date:	15-May-2017 (Added comments and freed unwanted memory)
 * Functionality:	This function sets Imported Status on Item Rev and
 *  its secindary objects with Specification, Rendering, Manifestation and BVR
 ******************************************************************************/
/*int Ng5_setImportStatus( tag_t tDesignRevTag )
{
	int		retCode			= ITK_ok;

	TC_write_syslog("\n Entering Ng5_setImportStatus");

	tag_t    tReleseStatus   = NULLTAG;
	tag_t* 	tpCATDS 		 = NULL;
	//tag_t* 	tpSecAuxDS 		 = NULL;
	tag_t* 	tpManDS 		 = NULL;
	tag_t* 	tpBOMView 		 = NULL;
	tag_t 	tSpecRel 		 = NULLTAG;
	//tag_t 	tRendRel 		 = NULLTAG;
	tag_t 	tManifRel 		 = NULLTAG;
	int 	iDesCount 		 = 0;
	//int 	iCount 		 	 = 0;
	int		iManifCount		 = 0;
	int 	iBOM 		 	 = 0;
	//int 	iNum 			 = 0;
	int		iMan			 = 0;
	int 	iBum 			 = 0;
	int 	iDst 			 = 0;
	int	iStatusCount         = 0 ;
	tag_t   *tpstatusList    = NULL;

	//Get the release status list of the Item Revision
	ITK( WSOM_ask_release_status_list(tDesignRevTag,&iStatusCount,&tpstatusList));

	//Proceed only if there is no Release Status
	if((NULL == tpstatusList) && (iStatusCount == 0))
	{
		//Create the Imported Release Status
		ITK( RELSTAT_create_release_status(Ng5_IMPORTED,&tReleseStatus));

		if (NULLTAG != tReleseStatus)
		{
			//Add the Release Status on Item Revision
			ITK( RELSTAT_add_release_status(tReleseStatus,1,&tDesignRevTag,true));

			//Get the secondary objects of Item Revision with Specification relation and add release status to them
			ITK(GRM_find_relation_type (REL_SPECIFICATION,&tSpecRel));
			ITK(GRM_list_secondary_objects_only  (tDesignRevTag, tSpecRel, &iDesCount, &tpCATDS));

			if ((iDesCount > 0) && (NULL != tpCATDS))
			{
				for (iDst = 0; iDst < iDesCount; iDst++)
				{
					ITK( RELSTAT_add_release_status(tReleseStatus,1,&tpCATDS[iDst],true));
				}
			}

			//Get the secondary objects of Item Revision with Rendering relation and add release status to them
			//ITK(GRM_find_relation_type (REL_RENDERING,&tRendRel));
			//ITK(GRM_list_secondary_objects_only  (tDesignRevTag, tRendRel, &iCount, &tpSecAuxDS));

			//if ((iCount > 0) && (NULL != tpSecAuxDS))
			//{
				//for (iNum = 0; iNum < iCount; iNum++)
				//{
					//ITK( RELSTAT_add_release_status(tReleseStatus,1,&tpSecAuxDS[iNum],true));
				//}
			//}

			//Get the secondary objects of Item Revision with Manifestation relation and add release status to them
			ITK(GRM_find_relation_type (REL_MANIFESTATION,&tManifRel));
			ITK(GRM_list_secondary_objects_only  (tDesignRevTag, tManifRel, &iManifCount, &tpManDS));

			if ((iManifCount > 0) && (NULL != tpManDS))
			{
				for (iMan = 0; iMan < iManifCount; iMan++)
				{
					ITK( RELSTAT_add_release_status(tReleseStatus,1,&tpManDS[iMan],true));
				}
			}

			//Get the secondary objects of Item Revision with Structure Revision relation and add release status to them
			ITK(AOM_ask_value_tags(tDesignRevTag, STRUCTURE_REVISION, &iBOM, &tpBOMView));

			if(( iBOM > 0 ) && (NULL != tpBOMView))
			{
				for (iBum = 0; iBum < iBOM; iBum++)
				{
					ITK( RELSTAT_add_release_status(tReleseStatus,1,&tpBOMView[iBum],true));
				}
			}
			if(NULL != tpCATDS)
			{
				MEM_free(tpCATDS);
			}
			//if(NULL != tpSecAuxDS)
			//{
				//MEM_free(tpSecAuxDS);
			//}
			if(NULL != tpManDS)
			{
				MEM_free(tpManDS);
			}
			if(NULL != tpBOMView)
			{
				MEM_free(tpBOMView);
			}
		}
	}
	if(NULL != tpstatusList)
	{
		MEM_free(tpstatusList);
	}

	TC_write_syslog("\n Exiting Ng5_setImportStatus");

	return retCode;
}*/

/******************************************************************************
 * **
 * Created By	:	Siva Sundararaj
 * Created Date	:	15-May-2017
 *
 * Functionality:	This function sets Imported Status on Item Rev and
 *  its secondary objects with Specification, Rendering, Manifestation and BVR
 ******************************************************************************/
int Ng5_SetImportedStatusOnCheckin( METHOD_message_t * msg, va_list args )
{
	int		retCode			= ITK_ok;

	/*TC_write_syslog("\n Entering Ng5_SetImportedStatusOnCheckin");

	//Get the dataset tag from arguments
	tag_t 	tDataset 		= NULLTAG;

	va_list largs;
	va_copy(largs,args);
	tDataset = va_arg(largs, tag_t);

	if (NULLTAG != tDataset)
	{
		//Allow only if the logged in user has WRITE access to the Dataset
		logical		lSecVerdict	=	false;
		ITK( AM_check_privilege (tDataset, ACCESS_WRITE, &lSecVerdict) );

		if(true == lSecVerdict)
		{
			int		iStatusCount	=	0;
			tag_t	*tpstatusList	=	NULL;

			//Get the Release Status list of the Dataset
			ITK( WSOM_ask_release_status_list(tDataset, &iStatusCount, &tpstatusList));

			//Proceed only if there is no Release Status
			if((NULL == tpstatusList) && (iStatusCount == 0))
			{
				tag_t	tSecType	=	NULLTAG;
				ITK( TCTYPE_ask_object_type(tDataset, &tSecType) );

				if(NULLTAG != tSecType)
				{
					//Get the Dataset's Type Name
					char	*cpSecObjClassName	= NULL;
					ITK( TCTYPE_ask_name2 ( tSecType, &cpSecObjClassName) );

					if(NULL != cpSecObjClassName)
					{
						//Proceed only if the Dataset Type matches with UGMASTER.
						if(
								//(tc_strcmp (cpSecObjClassName, DATASET_CATPART ) == 0) ||
								//(tc_strcmp (cpSecObjClassName, DATASET_CATPRODUCT ) == 0) ||
								//(tc_strcmp (cpSecObjClassName, DATASET_CATDRAWING ) == 0) ||
								(tc_strcmp (cpSecObjClassName, DATASET_UGMASTER ) == 0)
						)
						{
							int		iNamedRefs		=	0;
							tag_t	*tpNamedRefs	=	NULL;

							//Get all the named references of the Dataset
							ITK (AE_ask_dataset_named_refs (tDataset, &iNamedRefs, &tpNamedRefs) );

							if( (iNamedRefs > 0) && (tpNamedRefs != NULL) )
							{
								//Scan through each Named Reference
								for(int iNr=0; iNr<iNamedRefs; iNr++)
								{
									if(NULLTAG != tpNamedRefs[iNr])
									{
										//Check the Type Name of the Named Reference
										tag_t	tNrType	=	NULLTAG;
										ITK( TCTYPE_ask_object_type(tpNamedRefs[iNr], &tNrType) );

										if(NULLTAG != tNrType)
										{
											char	*cpNrTypeClassName	= NULL;
											ITK( TCTYPE_ask_class_name2 ( tNrType, &cpNrTypeClassName) );

											if(NULL != cpNrTypeClassName)
											{
												//Proceed only if the Type Name matches with ImanFile since we need to check only for presence of physical CAD file
												if(tc_strcmp (cpNrTypeClassName, NAMEDREF_IMANFILE ) == 0)
												{
													//Get the Original File Name of the Named Reference
													tag_t	tFileName	=	NULLTAG;
													ITK(POM_attr_id_of_attr(ATTR_ORIG_FILE_NAME, NAMEDREF_IMANFILE, &tFileName));

													char		*cpFileName	=	NULL;
													logical		lFnNull		=	false;
													logical		lFnEmpty	=	false;
													ITK(POM_ask_attr_string(tpNamedRefs[iNr], tFileName, &cpFileName, &lFnNull, &lFnEmpty));

													if(NULL != cpFileName)
													{
														//Proceed only if the Original File Name contains .prt
														if(
																//(tc_strstr (cpFileName, FILE_CATPART )) ||
																//(tc_strstr (cpFileName, FILE_CATPRODUCT )) ||
																//(tc_strstr (cpFileName, FILE_CATDRAWING )) ||
																(tc_strstr (cpFileName, FILE_UGMASTER ))
														)
														{
															//Find the Item Revision to which this Dataset is attached to
															tag_t tSpecRel 			= NULLTAG;
															ITK (GRM_find_relation_type (REL_SPECIFICATION, &tSpecRel));

															if(NULLTAG != tSpecRel)
															{
																int		iPrimary		=	0;
																tag_t	*tpPrimaryObjs	=	NULL;

																ITK (GRM_list_primary_objects_only (tDataset, tSpecRel, &iPrimary, &tpPrimaryObjs ));

																if (( NULL != tpPrimaryObjs) && ( iPrimary > 0 ))
																{
																	if(NULLTAG != tpPrimaryObjs[0])
																	{
																		//Allow only if the logged in user has WRITE access to the Item Revision
																		logical		lPriVerdict	=	false;
																		ITK( AM_check_privilege (tpPrimaryObjs[0], ACCESS_WRITE, &lPriVerdict) );

																		if(true == lPriVerdict)
																		{
																			//Find the Object Type of Item Revision
																			tag_t	tPriType	=	NULLTAG;
																			ITK( TCTYPE_ask_object_type(tpPrimaryObjs[0], &tPriType) );

																			if(NULLTAG != tPriType)
																			{
																				char	*cpPriObjClassName	= NULL;
																				ITK( TCTYPE_ask_class_name2 ( tPriType, &cpPriObjClassName) ); // Get Primary object class name

																				if(NULL != cpPriObjClassName)
																				{
																					//Proceed only if the type is External Part Revision or External Support Part Revision
																					if(
																							(tc_strcmp (cpPriObjClassName, ITEM_EXTERNAL_PART_REVISION ) == 0) ||
																							(tc_strcmp (cpPriObjClassName, ITEM_EXTERNAL_SUPPORT_DESIGN_REVISION ) == 0)
																					)
																					{
																						//Call the function which sets the Release Status
																						Ng5_setImportStatus(tpPrimaryObjs[0]);
																						//Break out from the loop to avoid the function being called again
																						break;
																					}
																					MEM_free(cpPriObjClassName);
																				}
																			}
																		}
																	}
																	MEM_free(tpPrimaryObjs);
																}
															}
														}
														MEM_free(cpFileName);
													}
												}
												MEM_free(cpNrTypeClassName);
											}
										}
									}
								}
								MEM_free(tpNamedRefs);
							}
						}
						MEM_free(cpSecObjClassName);
					}
				}
				MEM_free(tpstatusList);
			}
		}
	}

	TC_write_syslog("\n Exiting Ng5_SetImportedStatusOnCheckin");*/

	return retCode;
}
