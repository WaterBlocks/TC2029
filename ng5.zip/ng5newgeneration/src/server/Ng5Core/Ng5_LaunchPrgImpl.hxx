//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_LaunchPrgImpl
//

#ifndef NG5NEWGENERATION__NG5_LAUNCHPRGIMPL_HXX
#define NG5NEWGENERATION__NG5_LAUNCHPRGIMPL_HXX

#include <Ng5Core/Ng5_LaunchPrgGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_LaunchPrgImpl; 
    class Ng5_LaunchPrgDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_LaunchPrgImpl
    : public ng5newgeneration::Ng5_LaunchPrgGenImpl
{
public:

    ///
    /// Getter for a Tag Property
    /// @param value - Parameter value
    /// @param isNull - Returns true if the Parameter value is null
    /// @return - Status. 0 if successful
    ///
    int  getNg5_launchprg_masterprgBase( tag_t &value, bool &isNull ) const;


protected:
    ///
    /// Constructor for a Ng5_LaunchPrg
    explicit Ng5_LaunchPrgImpl( Ng5_LaunchPrg& busObj );

    ///
    /// Destructor
    virtual ~Ng5_LaunchPrgImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_LaunchPrgImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_LaunchPrgImpl( const Ng5_LaunchPrgImpl& );

    ///
    /// Copy constructor
    Ng5_LaunchPrgImpl& operator=( const Ng5_LaunchPrgImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_LaunchPrgDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_LAUNCHPRGIMPL_HXX
