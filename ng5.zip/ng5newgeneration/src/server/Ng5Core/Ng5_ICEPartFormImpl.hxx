//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_ICEPartFormImpl
//

#ifndef NG5NEWGENERATION__NG5_ICEPARTFORMIMPL_HXX
#define NG5NEWGENERATION__NG5_ICEPARTFORMIMPL_HXX

#include <Ng5Core/Ng5_ICEPartFormGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_ICEPartFormImpl; 
    class Ng5_ICEPartFormDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_ICEPartFormImpl
    : public ng5newgeneration::Ng5_ICEPartFormGenImpl
{
public:

    ///
    /// Setter for a Boolean Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_adr_dangerous_goodBase( bool value, bool isNull );

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_mfg_descBase( const std::string &value, bool isNull );

    ///
    /// Setter for a Double Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_sap_net_weightBase( double value, bool isNull );

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_sap_weight_uomBase( const std::string &value, bool isNull );

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_material_typeBase( const std::string &value, bool isNull );

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_material_groupBase( const std::string &value, bool isNull );

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_ent_sourc_decBase( const std::string &value, bool isNull );

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_prod_attrBase( const std::string &value, bool isNull );

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_prod_codeBase( const std::string &value, bool isNull );

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_prod_hierarchyBase( const std::string &value, bool isNull );

protected:
    ///
    /// Constructor for a Ng5_ICEPartForm
    explicit Ng5_ICEPartFormImpl( Ng5_ICEPartForm& busObj );

    ///
    /// Destructor
    virtual ~Ng5_ICEPartFormImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_ICEPartFormImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_ICEPartFormImpl( const Ng5_ICEPartFormImpl& );

    ///
    /// Copy constructor
    Ng5_ICEPartFormImpl& operator=( const Ng5_ICEPartFormImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_ICEPartFormDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_ICEPARTFORMIMPL_HXX