//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_linkEBOMToPlantMBOM
 *
 */
 
#ifndef NG5_LINKEBOMTOPLANTMBOM_HXX
#define NG5_LINKEBOMTOPLANTMBOM_HXX
#include <tccore/method.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <Ng5Core/Ng5_BMF_ITEM_create_or_ref_id.hxx>
#include <Ng5Core/libng5core_exports.h>
#include <sstream>
#include <string>

#ifdef __cplusplus
         extern "C"{
#endif
//extern date_t startTraversalTime;
extern NG5CORE_API int Ng5_linkEBOMToPlantMBOM(METHOD_message_t* msg, va_list args);
int Ng5_createPlantMBOMfromEBOM2 (tag_t tEbomRevision, tag_t tMfgPartRevision, tag_t* tPlantMbomRevision );
int Ng5_linkEBOMViewToPlantMBOMView2(tag_t tEbomRevision, tag_t tPlantMbomRevision );
int Ng5_RenameMfgNodes(tag_t item_revision, char *plant_code);
void Ng5_TraverseMfgNodes(tag_t line,char *plant_code,char *cpOEMName);
tag_t Ng5_findItemRevisionFromBOMLine(tag_t bom_line);
int Ng5_find_rev(char *item_id, char *rev_id, tag_t *rev);
int Ng5_setMfgItemIDWithPlantCode(tag_t item_revision, char *plant_code);
int Ng5_setMfgItemIDWithPlantCode2(tag_t item_revision, char *plant_code,char* OEMName);
int Ng5_current_get_time_stamp(char* format, char** timestamp);
int Ng5_getMfgCustomPartNum(tag_t tERevision, char * OEMName,char **CustomerPartNo);
int Ng5_createRelation(tag_t tprimary, tag_t tSecondary, char* szRelation);
int Ng5_LinkMfgNodesandENodes(tag_t tEBOMItemRev,tag_t item_revision,char *plant_code);
void Ng5_TraverseMfgNodesforLinking(tag_t tEBOMItemRev,tag_t line,char *plant_code,int isPackCutReq);//Pack lines
tag_t Ng5_UpdatedPackedLines(tag_t line);
int Ng5_setSourType(tag_t item_revision,tag_t tERevision);
int Ng5_CopyProps(tag_t item_revision,tag_t tERevision);
int Ng5_CopyRevProps(tag_t item_revision,tag_t tERevision);
int Ng5_linkICEPartForm(tag_t tMBOMRev, tag_t tEBOMrev);
int Ng5_TransferOwnership(tag_t tEbomRevision,tag_t tMBOMLine);
int Ng5_setBVRName(tag_t item,tag_t item_revision); //function to set BVR Name

#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_LINKEBOMTOPLANTMBOM_HXX
