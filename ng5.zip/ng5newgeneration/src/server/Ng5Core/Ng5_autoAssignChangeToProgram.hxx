//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_autoAssignChangeToProgram
 *
 */
 
#ifndef NG5_AUTOASSIGNCHANGETOPROGRAM_HXX
#define NG5_AUTOASSIGNCHANGETOPROGRAM_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_autoAssignChangeToProgram(METHOD_message_t* msg, va_list args);
int associate_change_to_program(tag_t tMasterPrgItem , tag_t tChangeItemRev);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_AUTOASSIGNCHANGETOPROGRAM_HXX
