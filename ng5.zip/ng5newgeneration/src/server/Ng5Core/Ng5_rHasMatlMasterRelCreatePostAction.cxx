//@<COPYRIGHT>@
//==================================================
//Copyright $2019.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasMatlMasterRelCreatePostAction
 *
 */

#include <Ng5Core/Ng5_rHasMatlMasterRelCreatePostAction.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <math.h>
#include <iomanip>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <sa/sa_errors.h>
#include <ug_va_copy.h>
#include <ce/ce.h>
#include <constants/constants.h>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdarg.h>
#include <string>
#include <sstream>
#include <fclasses/tc_string.h>

#include "Ng5_CommonUtils.hxx"

int  Ng5_TCTYPE_Create_Object(char *pcTCTypename, char *pcObjName, tag_t *tCreatedObjTag);

using namespace std;
using namespace ng5newgeneration;

/**********************************************************************************
 **  Function Name: Ng5_rHasMatlMasterRelCreatePostAction
 **  Parameters:
 **     METHOD_message_t*  msg (I)
 **     va_list  args         (I)
 **
 **  Description:
 **    Post Action to create ICE Part form and attach to the parent Object.
 **    If there is existing  ICE Part Form then it will not create, if it doesnt
 **    exists, then creates ICE Part Form and attach it to the Parent Object.
 **
 **
***********************************************************************************/

int Ng5_rHasMatlMasterRelCreatePostAction( METHOD_message_t *msg, va_list args )
{

    int iFail           = ITK_ok;
    int nForms          = 0;

    tag_t tEngPart      = NULLTAG;
    tag_t tMatlMaster   = NULLTAG;
    tag_t tRelationType = NULLTAG;
    tag_t* ttForms      = NULLTAG;

    tEngPart            = va_arg(args, tag_t);
    tMatlMaster         = va_arg(args, tag_t);
    tRelationType       = va_arg(args, tag_t);

    TC_write_syslog("\n Entering Ng5_rHasMatlMstrCreatePostAction\n");

    if (NULLTAG != tEngPart && NULLTAG != tMatlMaster && NULLTAG != tRelationType)
    {

        char* cObjectType    = NULL;
        char*  cItemID		 = NULL;
        tag_t  tICEform      = NULLTAG;
        tag_t  tPlantform    = NULLTAG;
        tag_t  tRelICEtype   = NULLTAG;
        tag_t  tRelPlanttype = NULLTAG;
        tag_t  trelation     = NULLTAG;
        double value		 = 0.0;


        NG5_ITK_CALL (AOM_ask_value_string (tEngPart,ATTR_OBJECT_TYPE, &cObjectType));
        //TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction:object_type %s\n", cObjectType);

        NG5_ITK_CALL (AOM_ask_value_string (tEngPart,ATTR_ITEM_ID, &cItemID));
        //TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction:cItemID %s\n", cItemID);

        //Ng5_rHasMatlMaster relationship can be created for
        //Ng5_EngPart,Ng5_NonEngPart,Ng5_RawMaterial,Ng5_PhantomPart for all these part types
        //we need to create ICE Part Form. In way we dont need to check for Part Types as relationship
        //is creation is allowed only for these types.

        //get the relation type for the ICEPartForm
        NG5_ITK_CALL (GRM_find_relation_type(REL_ICEPARTFORM, &tRelICEtype));

        //check if EngPart already has relation with ICEPartForm
        NG5_ITK_CALL (GRM_list_secondary_objects_only (tEngPart, tRelICEtype, &nForms, &ttForms));
        //TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction:Number of Forms %d\n", nForms);

        //If relation exists, then do not create the form
        //else create the ICEpart form and attach it to EngPart.
        if (nForms == 0)
        {
            //TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction:Before Create Object\n");

            //create ICE part form and attach them to Eng Part respectively.
            iFail = Ng5_TCTYPE_Create_Object (ICEPART_FORM, cItemID, &tICEform);

            if(iFail == ITK_ok && tICEform != NULLTAG)
            {

                NG5_ITK_CALL (GRM_find_relation_type (REL_ICEPARTFORM, &tRelICEtype));
                NG5_ITK_CALL (GRM_create_relation (tEngPart, tICEform, tRelICEtype, NULLTAG, &trelation));
                NG5_ITK_CALL (GRM_save_relation(trelation));
                //NG5_ITK_CALL(AOM_unlock(trelation));
                NG5_ITK_CALL (AOM_save_with_extensions(tICEform));//TC 12 Upgrade

            }
            nForms = 0;
            ttForms = NULLTAG;

            NG5_ITK_CALL (GRM_list_secondary_objects_only (tEngPart, tRelICEtype, &nForms, &ttForms));

            //TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction:After Create Number of Forms %d\n", nForms);
            //TC_write_syslog("\n *Ng5_rHasMatlMstrCreatePostAction: set SAP Weight as 0.0\n");
/*
            NG5_ITK_CALL (AOM_refresh(ttForms[0], TRUE));
            NG5_ITK_CALL (AOM_set_value_double (ttForms[0], "ng5_sap_net_weight", value));
            NG5_ITK_CALL (AOM_save_with_extensions(ttForms[0])); //TC 12 Upgrade
            NG5_ITK_CALL (AOM_refresh(ttForms[0], FALSE));
*/
            //TC_write_syslog("\n *Ng5_rHasMatlMstrCreatePostAction: After AOM_save_with_extensions\n");
        }
        else
        {
            //TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction: ICE Part Form else: Find Plant form \n");
            tag_t 	trelPFType = NULLTAG;
			int 	iPFCnt 	= 0;
			tag_t 	*tPrimPF 	= NULL;

			//get the relation type for the ICE Part form and Eng Part
			NG5_ITK_CALL (GRM_find_relation_type(REL_PLANTFORM, &trelPFType));
			//Get ICE Part Form of Eng Part
			NG5_ITK_CALL(GRM_list_secondary_objects_only(tMatlMaster, trelPFType, &iPFCnt, &tPrimPF));
			//TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction:iPFCnt %d\n", iPFCnt);
			if(iPFCnt > 0 && tPrimPF != NULL)
			{
				char *cObjPFType = NULL;
				AOM_ask_value_string(tPrimPF[0], ATTR_OBJECT_TYPE, &cObjPFType);
				//TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction:Plant form Object Type = %s \n",cObjPFType);

				//Get SAP Net Weight
				double 	dSAPwt 		= 0.0;
				char*	cSAPUom 	= NULL;
				char*	cPlantUOM 	= NULL;

				AOM_ask_value_string(ttForms[0], ATTR_SAP_UOM, &cSAPUom);
				//TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction:cSAPUom=%s \n",cSAPUom);
				AOM_ask_value_double(ttForms[0], ATTR_SAP_WT, &dSAPwt);
				//TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction: SAP Net Weight=%f\n",dSAPwt);

				//Get Plant Weight UOM
				AOM_ask_value_string(tPrimPF[0], ATTR_PLANT_UOM, &cPlantUOM);
				//TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction:cPlantUOM=%s \n",cPlantUOM);

				double	dPlantWt = 0.0;
				NG5_ITK_CALL (Ng5_CommonUtils::getConvertedWeight (cSAPUom, cPlantUOM, dSAPwt, &dPlantWt));

				TC_write_syslog("\n Ng5_rHasMatlMstrCreatePostAction : ConvertedWeight: Plant Weight=%f\n",dPlantWt);
				NG5_ITK_CALL (AOM_refresh(tPrimPF[0], TRUE));
				NG5_ITK_CALL (AOM_set_value_double (tPrimPF[0], ATTR_PLANT_WT, dPlantWt));
				NG5_ITK_CALL (AOM_save_with_extensions(tPrimPF[0])); //TC 12 Upgrade
				NG5_ITK_CALL (AOM_refresh(tPrimPF[0], FALSE));
					
				NG5_MEM_TCFREE (cSAPUom);
				NG5_MEM_TCFREE (cPlantUOM);
			}
			NG5_MEM_TCFREE (cObjectType);
			NG5_MEM_TCFREE (cItemID);
			NG5_MEM_TCFREE (tPrimPF);
        }
    }
    // Cleanup and exit the function.
    TC_write_syslog("\n Leaving Ng5_rHasMatlMstrCreatePostAction exited \n");
    NG5_MEM_TCFREE (ttForms);
    return iFail;
}
/**********************************************************************************
 **  Function Name: Ng5_TCTYPE_Create_Object
 **  Parameters:
 **     char*  pcTCTypename (I)
 **     char*  pcObjName    (I)
 **     tag_t* tCreateObjTag(O)
 **
 **  Description:
 **   Based on input type name and object_name provided, it creates the object.
 **   and set the value of object_name with provided input pcObjName.
***********************************************************************************/

int  Ng5_TCTYPE_Create_Object(char * pcTCTypename, char *pcObjName, tag_t *tCreatedObjTag)
{

    int    iFail           = ITK_ok;
    tag_t  tTypeTag        = NULLTAG;
    tag_t  tCreateInputTag = NULLTAG;
    //tag_t tCreatedObjTag = NULLTAG;

    TC_write_syslog("\n Entering Ng5_TCTYPE_Create_Object\n");

    //Find type tag to construct create input
    NG5_ITK_CALL(TCTYPE_find_type ( pcTCTypename, NULL, &tTypeTag )) ;
    NG5_ITK_CALL(TCTYPE_construct_create_input ( tTypeTag, &tCreateInputTag)) ;


    if ( iFail == ITK_ok && tCreateInputTag != NULLTAG )
    {
        //TC_write_syslog("\n Entering Ng5_TCTYPE_Create_Object: Creating Form\n");

        NG5_ITK_CALL(AOM_set_value_string ( tCreateInputTag, OBJECT_NAME, pcObjName )) ;
        NG5_ITK_CALL(TCTYPE_create_object ( tCreateInputTag, tCreatedObjTag )) ;

        if ( *tCreatedObjTag != NULLTAG )
        {
        //TC_write_syslog("\n Entering Ng5_TCTYPE_Create_Object: Saving Form\n");
        AOM_save_with_extensions ( *tCreatedObjTag ) ;//TC 12 Upgrade
        //AOM_unlock ( tCreatedObjTag ) ;
        }
    }
    TC_write_syslog("\n Exiting Ng5_TCTYPE_Create_Object\n");
    return iFail;
}
