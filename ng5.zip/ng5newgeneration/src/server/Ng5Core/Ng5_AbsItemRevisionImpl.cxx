/*********************************************************************************************
** File Name:         Ng5_AbsItemRevisionImpl.cxx
**
** File Description:
	This file contains the declaration for the Ng5_AbsItemRevisionImpl class and the setter methods for design_weight and tooling maturity.
	The Design weight setter converts the weight to gms and the tooling Maturity method validates whether user is entering proper tooling maturity value
	.
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   8/1/2018   Shibabrata Jena		 Added Comments
**   05/07/2021 Balaji             TC12 Upgrade
*********************************************************************************************/

#include <Ng5Core/Ng5_AbsItemRevisionImpl.hxx>

#include <fclasses/tc_string.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <tc/tc.h>
#include "Ng5_CommonUtils.hxx"

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_AbsItemRevisionImpl::Ng5_AbsItemRevisionImpl(Ng5_AbsItemRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_AbsItemRevisionImpl::Ng5_AbsItemRevisionImpl( Ng5_AbsItemRevision& busObj )
   : Ng5_AbsItemRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_AbsItemRevisionImpl::~Ng5_AbsItemRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_AbsItemRevisionImpl::~Ng5_AbsItemRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_AbsItemRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_AbsItemRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_AbsItemRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}
/// Setter for a Double Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_AbsItemRevisionImpl::setNg5_design_weightBase( double value, bool  isNull)
{
    int ifail = ITK_ok;
    tag_t   tAbsItemRev 		= 	NULLTAG;

    Ng5_AbsItemRevision *bo = getNg5_AbsItemRevision();
    tAbsItemRev = ((Teamcenter::BusinessObject*)bo)->getTag();

    if( tAbsItemRev != NULLTAG)
    {
    	int iSecObjCount = 0;
    	tag_t *ptSecObjets = NULL;
    	Ng5_CommonUtils::Find_All_Secondary_Objects(tAbsItemRev,REL_SPECIFICATION,&iSecObjCount,&ptSecObjets);

    	for(int i = 0; i< iSecObjCount ;i++)
    	{

    		tag_t tObjType = NULLTAG;
    		char  *chTypeName = NULL;


			TCTYPE_ask_object_type(ptSecObjets[i],&tObjType);
			//TC12 Upgrade, need to cleanup the variable.
			TCTYPE_ask_name2 (tObjType,&chTypeName);


			if (tc_strcmp(chTypeName,"UGMASTER")==0)
			{

				TC_write_syslog("\n Found UGMASTER , converting weight in Grams..");
				value = value *1000;

			}
			MEM_TCFREE(chTypeName) //tc12 upgrade
    	}
    }


    if (ifail == ITK_ok)
    {
    	Ng5_AbsItemRevisionGenImpl::setNg5_design_weightBase(  value,   isNull );
    }
    return ifail;
}

/*
 * **
 * Created By	:	Anil Kumar G
 * Created Date	:	22-Feb-2017
 *
 * Functionality:	Setter for a string Property
 * 					@param value - Value to be set for the parameter
 * 					@param isNull - If true, set the parameter value to null
 * 					@return - Status. 0 if successful
 *					This Method is to set the tool maturity of Engineered Part Revision & Raw Material Revision
 *	  Pradnya      Initial Baseline
 *	  Anil 	       Moved to Abstract Item Revision
 *	  Pradnya      Bypass mechanism Admin & DBA Group

 */

///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_AbsItemRevisionImpl::setNg5_tool_maturityBase( const std::string & value, bool  isNull )
{
    	int ifail = ITK_ok;

    	int iRevCount 				= 0;
        tag_t tPartRev 				= NULLTAG;
    	tag_t tItemTag 				= NULLTAG;
    	tag_t tPreviousRev			= NULLTAG;
    	tag_t tCurrRevTag 			= NULLTAG;
    	tag_t *ptRevList 			= NULL;
    	logical isFirstRevision		= false;
    	char *cpItemType            = NULL;



    	Ng5_AbsItemRevision *bo = getNg5_AbsItemRevision();
    	tPartRev = ((Teamcenter::BusinessObject*)bo)->getTag();

    	if(Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_ADMIN)||Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_DBA)||Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_MIGRATION))
    	{
    		TC_write_syslog("\n Skipping Check..as the current Role is Data Migration");
    		ifail = Ng5_AbsItemRevisionGenImpl::setNg5_tool_maturityBase( value, isNull );
    		return ifail;

    	}
    	ITK(ITEM_ask_item_of_rev(tPartRev ,&tItemTag));
    	ITK(ITEM_ask_type2(tItemTag ,&cpItemType));



    	if ( tc_strcmp ( cpItemType, ENG_PART ) == 0 ||  tc_strcmp ( cpItemType,RAW_MATERIAL )== 0 ) {


    		/*ITK(ITEM_list_all_revs(tItemTag,&iRevCount,&ptRevList));

    			for (int iRevCounter = 0; iRevCounter < iRevCount; iRevCounter++)
    			{

    				tCurrRevTag			=	ptRevList[iRevCounter];


    				if (tCurrRevTag != tPartRev ) //if current revision is not the revision in context then traverse to next revision
    				{

    					continue;
    				}
    				else
    				{
    					/*If current revision is not first revision then find out previous revision,
    					any Baselined revision should be skipped while retrieving the previous revison*/

    					/*if (iRevCounter>0 )
    					{

    						int j = 1;
    						do
    						{
    							tPreviousRev = ptRevList[iRevCounter-j];
    							j++;

    						}while (Ng5_CommonUtils::isStatused(tPreviousRev, BASELINE_STATUS) );
    					}
    					else if (iRevCounter == 0) //if current revision is first revision
    					{

    						isFirstRevision = true;
    					}
    					break;
    				}

    			}
    			if (isFirstRevision == false)//if revision is not first revision then perform validations based on value of tooling maturity of previous revision
    			{
    				char* szToolingMaturity = NULL;

    				ITK(AOM_ask_value_string(tPreviousRev , ATTR_TOOL_MATURITY , &szToolingMaturity));
    				if(tc_strcmp(szToolingMaturity,CONST_PROTOTYPE)== 0)
    				{

    					if(value==CONST_DEVELOPMENT)
    					{
    						EMH_store_initial_error_s1(EMH_severity_error, ErrorCodeForToolingMaturity , "" ) ;
    						return ErrorCodeForToolingMaturity;
    					}

    				}

    				else if((tc_strcmp(szToolingMaturity,CONST_PRODUCTION)== 0 ))
    				{
    					if((value==CONST_DEVELOPMENT) || (value==CONST_PROTOTYPE))
    					{
    						EMH_store_initial_error_s1(EMH_severity_error, ErrorCodeForToolingMaturity , "" ) ;
    						return ErrorCodeForToolingMaturity;
    					}

    				}
    				MEM_TCFREE(ptRevList);
    				MEM_TCFREE(szToolingMaturity);
    				MEM_TCFREE(cpItemType);

    			}*/


    			if(ifail == ITK_ok)//if the value if tooling maturity is as per the business validations then set the value
    			{
    				ifail = Ng5_AbsItemRevisionGenImpl::setNg5_tool_maturityBase( value, isNull );

    			}
    			return ifail;
    	} else {



    			ifail = Ng5_AbsItemRevisionGenImpl::setNg5_tool_maturityBase( value, isNull );


    		MEM_TCFREE(cpItemType);
    		return ifail;
    	}
}

