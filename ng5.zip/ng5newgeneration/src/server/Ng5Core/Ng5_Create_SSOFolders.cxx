//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_Create_SSOFolders
 *
 */
#include <Ng5Core/Ng5_Create_SSOFolders.hxx>

int create_relation(tag_t ssopkg_revtag, tag_t folder_created, tag_t rHasSSOFolders_tag);

int Ng5_Create_SSOFolders( METHOD_message_t * msg, va_list args)
{
	int ifail =ITK_ok;
	TC_write_syslog("\n\n Ng5_Create SSO Folders extension entered\n\n");

	tag_t ssopkg_tag = va_arg(args,tag_t);
	char   *rev_id = va_arg(args, char*);
	tag_t *ssopkg_revtag = va_arg(args, tag_t*);
	tag_t lov_tag = NULLTAG;
	int lov_value_count= NULL;
	char** values=NULL;
	int count=NULL;
	char** pref_values =NULL;
	char* pkg_name = NULLTAG;
	tag_t ssofolder_type = NULLTAG;
	tag_t rHasSSOFolders_tag = NULLTAG;



	AOM_ask_value_string(ssopkg_tag,object_name, &pkg_name);

	const char* type_name=Ng5_SSOPkg;


	LOV_find_attached_prop(type_name, object_name, &lov_tag);
	TC_write_syslog("\n\n LOV tag: %d\n\n", lov_tag);
	LOV_ask_values_string(lov_tag, &lov_value_count, &values);

	if(tc_strcmp(pkg_name,values[0])==0){
		PREF_ask_char_values(Ng5_Gate_DV_Start_Folders, &count, &pref_values);
		AOM_set_value_string(*ssopkg_revtag, ng5_retn_date, retn_date1);
	}
	else if(tc_strcmp(pkg_name,values[1])==0){
		PREF_ask_char_values(Ng5_Gate_DV_Release_Folders, &count, &pref_values);
		AOM_set_value_string(*ssopkg_revtag, ng5_retn_date, retn_date1);
	}
	else if(tc_strcmp(pkg_name,values[2])==0){
		PREF_ask_char_values(Ng5_Gate_Final_Prod_Release_Folders, &count, &pref_values);
		AOM_set_value_string(*ssopkg_revtag, ng5_retn_date, retn_date1);
	}
	else if(tc_strcmp(pkg_name,values[3])==0){
		PREF_ask_char_values(Ng5_Gate_Customer_Part_Approval_Folders, &count, &pref_values);
		AOM_set_value_string(*ssopkg_revtag, ng5_retn_date, retn_date2);
	}
	else if(tc_strcmp(pkg_name,values[4])==0){
		PREF_ask_char_values(Ng5_Gate_Post_Launch, &count, &pref_values);
		AOM_set_value_string(*ssopkg_revtag, ng5_retn_date, retn_date2);
	}
	else if(tc_strcmp(pkg_name,values[5])==0){
		PREF_ask_char_values(Ng5_Gate_Production, &count, &pref_values);
		AOM_set_value_string(*ssopkg_revtag, ng5_retn_date, retn_date2);
	}
	else if(tc_strcmp(pkg_name,values[6])==0){
		PREF_ask_char_values(Ng5_Gate_End_of_Production, &count, &pref_values);
		AOM_set_value_string(*ssopkg_revtag, ng5_retn_date, retn_date2);
	}
	

	for(int i=0; i < lov_value_count; i++){
		MEM_free(values[i]);
	}

	ifail= TCTYPE_find_type(Ng5_SSOFolders, Ng5_SSOFolders, &ssofolder_type);
	TC_write_syslog("\n\n SSO Folders Type Tag: %d\n\n", ssofolder_type);

	ifail= GRM_find_relation_type(Ng5_rHasSSOFolders, &rHasSSOFolders_tag);
	TC_write_syslog("\n\n SSO Folders Rel Tag: %d\n\n", rHasSSOFolders_tag);

	for(int i = 0; i <count; i++){
			tag_t folder_createtag = NULLTAG;
			tag_t folder_created = NULLTAG;



			ifail= TCTYPE_construct_create_input(ssofolder_type, &folder_createtag);
			ifail= AOM_set_value_string(folder_createtag, object_name, pref_values[i]);
			ifail= TCTYPE_create_object(folder_createtag, &folder_created);
			ifail= AOM_save_with_extensions(folder_created); //TC 12 Upgrade
			ifail= AOM_unlock(folder_created);
			ifail= create_relation(*ssopkg_revtag, folder_created, rHasSSOFolders_tag);

	}

	MEM_free(pref_values);

 
 return 0;

}

int create_relation(tag_t ssopkg_rev, tag_t folder_created, tag_t rHasSSOFolders_tag){
	int ifail =ITK_ok;
	tag_t output_reltag = NULLTAG;

	ifail= GRM_create_relation(ssopkg_rev, folder_created, rHasSSOFolders_tag, NULLTAG, &output_reltag);
	TC_write_syslog("\n\n GRM create relation ifail:%d\n\n", ifail);
	ifail= GRM_save_relation(output_reltag);

	return 0;
}
