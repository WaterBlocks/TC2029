//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_MfgPart_IMAN_Save_PostAction
 *
 */
#include <Ng5Core/Ng5_MfgPart_IMAN_Save_PostAction.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <iostream>
#include <string>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <sa/sa_errors.h>
#include <ug_va_copy.h>
#include <ce/ce.h>
#include <constants/constants.h>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdarg.h>
#include <sstream>
#include <fclasses/tc_string.h>
#include <Ng5Core/Ng5_rHasMatlMasterRelCreatePostAction.hxx>
#include "Ng5_CommonUtils.hxx"

using namespace std;
using namespace ng5newgeneration;

//int  Ng5_TCTYPE_Create_ICEPF(char * pcTCTypename, char *cOrgID, char *cMfgDesc1, tag_t *tCreatedObjTag);

int Ng5_MfgPart_IMAN_Save_PostAction( METHOD_message_t * msg, va_list args )
{
	TC_write_syslog ("\n\t Entering  Ng5_MfgPart_IMAN_Save_PostAction...\n" );

		int		iFail	= ITK_ok;
		tag_t	tObject	= NULLTAG;
		int		nForms  = 0;
		char*   cObjectType    = NULL;
		char*   cOrgID		 = NULL;
		char*   cMfgDesc1	 = NULL;
		char*  bCreateIPF = NULL;
		tag_t   tICEform      = NULLTAG;
		tag_t* ttForms      = NULLTAG;
		tag_t  tRelICEtype   = NULLTAG;
		tag_t  trelation     = NULLTAG;

		tag_t 	mfgPrtTag = msg->object_tag;
/*
		TC_write_syslog("\n\n MfgPart tag from msg: %d\n\n", mfgPrtTag);

		NG5_ITK_CALL (AOM_ask_value_string (mfgPrtTag,ATTR_OBJECT_TYPE, &cObjectType));
		TC_write_syslog("\n Ng5_MfgPart_IMAN_Save_PostAction:object_type %s\n", cObjectType);

		NG5_ITK_CALL (AOM_ask_value_string (mfgPrtTag,ORIGINALID, &cOrgID));
		TC_write_syslog("\n Ng5_MfgPart_IMAN_Save_PostAction:cOrgID %s\n", cOrgID);

		NG5_ITK_CALL (AOM_ask_value_string (mfgPrtTag, ATTR_MFG_DSC, &cMfgDesc1));
		TC_write_syslog("\n Ng5_MfgPart_IMAN_Save_PostAction:cMfgDesc1 %s\n", cMfgDesc1);

		NG5_ITK_CALL (AOM_ask_value_string (mfgPrtTag, ATTR_CREATE_IPF, &bCreateIPF));
		TC_write_syslog("\n Ng5_MfgPart_IMAN_Save_PostAction:bCreateIPF %s\n", bCreateIPF);

		if ( tc_strcmp(bCreateIPF, "Yes") == 0 )
		{
	        //get the relation type for the ICEPartForm
	        NG5_ITK_CALL (GRM_find_relation_type(REL_ICEPARTFORM, &tRelICEtype));

	        //check if MfgPart already has relation with ICEPartForm
	        NG5_ITK_CALL (GRM_list_secondary_objects_only (mfgPrtTag, tRelICEtype, &nForms, &ttForms));
	        TC_write_syslog("\n Ng5_MfgPart_IMAN_Save_PostAction:Number of Forms %d\n", nForms);

	        //If relation exists, then do not create the form
	        //else create the ICEpart form and attach it to MfgPart.
	        if (nForms == 0)
	        {
	            TC_write_syslog("\n Ng5_MfgPart_IMAN_Save_PostAction: ICE Part Form does not exist. So, creating IPF \n");

	            //create ICE part form and attach them to Mfg Part respectively.
	            iFail = Ng5_TCTYPE_Create_ICEPF (ICEPART_FORM, cOrgID, cMfgDesc1, &tICEform);

	            if(iFail == ITK_ok && tICEform != NULLTAG)
	            {
	                NG5_ITK_CALL (GRM_find_relation_type (REL_ICEPARTFORM, &tRelICEtype));
	                NG5_ITK_CALL (GRM_create_relation (mfgPrtTag, tICEform, tRelICEtype, NULLTAG, &trelation));
	                NG5_ITK_CALL (GRM_save_relation(trelation));
	                NG5_ITK_CALL (AOM_save_with_extensions(tICEform));
	            }
	            else
	            {
	            	TC_write_syslog("\n Ng5_MfgPart_IMAN_Save_PostAction: ICEPartForm not created \n");
	            }

	        }
		}
		else if( tc_strcmp(bCreateIPF, "No") == 0 )
		{
			TC_write_syslog("\n Ng5_MfgPart_IMAN_Save_PostAction: MfgPart created in context of Eng Part. ICEPartForm exists on Eng Part. \n");
		}
		else
			TC_write_syslog("\n Ng5_MfgPart_IMAN_Save_PostAction: ICEPartForm tag null \n");
		}
		*/
	NG5_MEM_TCFREE (ttForms);
	NG5_MEM_TCFREE(cObjectType);
	NG5_MEM_TCFREE(cOrgID);
	NG5_MEM_TCFREE(cMfgDesc1);
	NG5_MEM_TCFREE(bCreateIPF);
 return iFail;

}

/**********************************************************************************
 **  Function Name: Ng5_TCTYPE_Create_ICEPF
 **  Parameters:
 **     char*  pcTCTypename (I)
 **     char*  pcObjName    (I)
 **     char*  cMfgDesc1    (I)
 **     tag_t* tCreateObjTag(O)
 **
 **  Description:
 **   Based on input type name, object_name and ng5_mfg_desc provided, it creates the ICE Part Form
 **   and also sets the value of object_name and ng5_mfg_desc with provided input pcObjName.
***********************************************************************************/
/*
int  Ng5_TCTYPE_Create_ICEPF(char * pcTCTypename, char *cOrgID, char *cMfgDesc1, tag_t *tCreatedObjTag)
{

    int    iFail           = ITK_ok;
    tag_t  tTypeTag        = NULLTAG;
    tag_t  tCreateInputTag = NULLTAG;
    //tag_t tCreatedObjTag = NULLTAG;

    TC_write_syslog("\n Entering Ng5_TCTYPE_Create_ICEPF\n");

    //Find type tag to construct create input
    NG5_ITK_CALL(TCTYPE_find_type ( pcTCTypename, NULL, &tTypeTag )) ;
    NG5_ITK_CALL(TCTYPE_construct_create_input ( tTypeTag, &tCreateInputTag)) ;


    if ( iFail == ITK_ok && tCreateInputTag != NULLTAG )
    {
        TC_write_syslog("\n Entering Ng5_TCTYPE_Create_ICEPF: Creating ICE Part Form\n");

        NG5_ITK_CALL(AOM_set_value_string ( tCreateInputTag, OBJECT_NAME, cOrgID )) ;
        NG5_ITK_CALL(AOM_set_value_string ( tCreateInputTag, ATTR_MFG_DSC, cMfgDesc1 )) ;
        NG5_ITK_CALL(TCTYPE_create_object ( tCreateInputTag, tCreatedObjTag )) ;

        if ( *tCreatedObjTag != NULLTAG )
        {
        //TC_write_syslog("\n Entering Ng5_TCTYPE_Create_Object: Saving Form\n");
        AOM_save_with_extensions ( *tCreatedObjTag ) ;//TC 12 Upgrade
        //AOM_unlock ( tCreatedObjTag ) ;
        }
    }
    TC_write_syslog("\n Exiting Ng5_TCTYPE_Create_ICEPF\n");
    return iFail;
}
*/