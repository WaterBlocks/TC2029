/*********************************************************************************************
** File Name:         Ng5_Update_Master_ID.hxx
**
** File Description:
	This file contains the declaration for the extension named Ng5_Update_Master_ID
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   12/09/2016  Shibabrata Jena      Initial Version

*********************************************************************************************/


 
#ifndef NG5_UPDATE_MASTER_ID_HXX
#define NG5_UPDATE_MASTER_ID_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif

//-----------------------------------------------------------------------------------------------------
// int Ng5_Update_Master_ID( METHOD_message_t * msg, va_list args )
// declaration  for the extension on createpost and saveaspost post action of Customer part Form to
// concatenate three values namely customer part number, customer part revision and customer name
//------------------------------------------------------------------------------------------------------

extern NG5CORE_API int Ng5_Update_Master_ID(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>


                
#endif  // NG5_UPDATE_MASTER_ID_HXX
