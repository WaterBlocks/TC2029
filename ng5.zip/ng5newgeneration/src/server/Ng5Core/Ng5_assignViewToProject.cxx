//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_assignViewToProject
 *
 *  FILE DESCRIPTION : Ng5_assignViewToProject Function is created on revise operation of program revision and product Launch Revision BVR is created.
 *
 *  *Shivaji Parade          7th July 2023               Created
 *
 */
#include <Ng5Core/Ng5_assignViewToProject.hxx>
#include <tccore/project.h>
#include <tccore/method.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <tccore/grm.h>
#include <pie/pie.h>
#include <ps/ps.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_stdio.h>
#include <bom/bom.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include<tccore/workspaceobject.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include "Ng5_CommonUtils.hxx"

/* function Description : function program and product launch revisions after revised revision he checking BVR is available or not.
 *                         if available assigned to respective project it's not available it's created and then assign the respective project.
 *
*/

int Ng5_assignViewToProject( METHOD_message_t * msg, va_list args )
{
	TC_write_syslog("\n ------>>>>>> AssigViewToProject <<<<---------\n");
	tag_t    tsrcPrgRev                                      = va_arg(args,tag_t);
	tag_t*   tnPrgRev                                        = va_arg (args, tag_t *);
	tag_t    twindow                                          = NULLTAG;
	tag_t    topLine                                         = NULLTAG;
	tag_t*   tBomViews                                       = NULL;   //OF
	tag_t*   tBomRevs                                        = NULL;   //OF
	tag_t    tPrgBOMView                                     = NULLTAG;
	tag_t    tBVR                                            = NULLTAG;
	tag_t	 tPrglatestrev                                   = NULLTAG;
	tag_t    tPrgIItem                                       = NULLTAG;
	tag_t    tlatestrev                                      = NULLTAG;
	int      iBomCount                                       = 0;
    int      iBomRevCount                                    = 0;
	int      iFail                                           = ITK_ok;
	char*    cprogObjType                                    = NULL;   //OF
	char*    cobject_type                                    = NULL;   //OF
	char*  	 cvalue                                          = NULL;   //OF

	NG5_ITK_CALL( AOM_ask_value_string( tsrcPrgRev, ATTR_OBJECT_TYPE, &cprogObjType ));

//condition is checking object type is masterprg revision

	if(( tc_strcmp( cprogObjType, NG5_MASTER_PRG_REVISION ) == 0 ))
	{
		if (tnPrgRev != NULL )
		{
			if (tnPrgRev[0] != NULLTAG)
			{
					tPrglatestrev = tnPrgRev[0];

					if(tPrglatestrev!=NULLTAG)
					{

						NG5_ITK_CALL(ITEM_ask_item_of_rev (tPrglatestrev,&tPrgIItem));

						NG5_ITK_CALL (AOM_ask_value_string(tsrcPrgRev,REV_ID,&cvalue));

						NG5_ITK_CALL (WSOM_ask_object_type2(tsrcPrgRev,&cobject_type));

						NG5_ITK_CALL (ITEM_ask_item_of_rev	(	tsrcPrgRev,	&tPrgIItem));
						NG5_ITK_CALL(ITEM_ask_latest_rev(tPrgIItem,&tPrglatestrev));
						NG5_ITK_CALL(AOM_ask_value_string(tPrglatestrev,REV_ID,&cvalue));


						if(tPrgIItem!=NULLTAG)
						{

							ITKCALL(ITEM_list_bom_views(tPrgIItem, &iBomCount, &tBomViews));

						}
						ITKCALL(ITEM_rev_list_bom_view_revs(tPrglatestrev, &iBomCount, &tBomViews));
						if(iBomCount == 0 )
						{
							NG5_ITK_CALL(AOM_refresh(tPrgIItem,TRUE));
							ITKCALL(PS_create_bom_view(NULLTAG, NULL, NULL, tPrgIItem, &tPrgBOMView));
							ITKCALL(AOM_save_without_extensions(tPrgBOMView));//TC12 Upgrade
							ITKCALL(AOM_save_without_extensions(tPrgIItem));//TC12 Upgrade
							NG5_ITK_CALL(AOM_refresh(tPrgIItem,FALSE));
							NG5_ITK_CALL(AOM_refresh(tPrgBOMView,FALSE));
							NG5_ITK_CALL(AOM_refresh(tPrglatestrev,TRUE));
							ITKCALL(PS_create_bvr(tPrgBOMView, NULL, NULL, false, tPrglatestrev,&tBVR));
							NG5_ITK_CALL(BOM_create_window(&twindow));
							NG5_ITK_CALL(BOM_set_window_top_line_bvr(twindow,tBVR,&topLine));
							NG5_ITK_CALL(BOM_line_set_precise(topLine,false));
							NG5_ITK_CALL(BOM_save_window(twindow));
							NG5_ITK_CALL(BOM_close_window(twindow));
							NG5_ITK_CALL(AOM_save_without_extensions(tBVR));
							NG5_ITK_CALL(AOM_save_without_extensions(tPrglatestrev));
							NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));
							NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));
						}
						else
						{
							if(tPrgIItem!=NULLTAG)
							{
								int                     num_values = 0;
								tag_t                   tProject   = NULLTAG;
								tag_t               tProgramItem1  = NULLTAG;
								char* 	                cpId       = NULL;  //OF
								char**					cPrgmId    = NULL;  //OF

								ITKCALL(AOM_ask_displayable_values(tPrgIItem,ATTR_ITEM_ID,&num_values,&cPrgmId));
								ITKCALL(PROJ_find(cPrgmId[0],&tProject));
								ITKCALL(PROJ_ask_id2	(	tProject,&cpId ));

								ITKCALL(ITEM_rev_list_all_bom_view_revs(tPrglatestrev, &iBomRevCount, &tBomRevs));
								if(iBomCount > 0)
								{
								tBVR = tBomRevs[iBomCount-1];
								}

								if(tProject != NULLTAG)
								{
									ITKCALL ( PROJ_assign_objects( 1, &tProject , 1 , &tBVR));
									ITKCALL(AOM_save_without_extensions(tBVR));
									NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));
								}
								NG5_MEM_TCFREE(cPrgmId);
								NG5_MEM_TCFREE(cpId);
							}
						}

						NG5_MEM_TCFREE(cvalue);
						NG5_MEM_TCFREE(cobject_type);
						NG5_MEM_TCFREE(tBomViews);
						NG5_MEM_TCFREE(tBomRevs);

					}
			}
		}

}
/*Condition is check object type is Product launch revision
 * */

if(( tc_strcmp( cprogObjType, NG5_LAUNCH_PRG_REVISION ) == 0 ))
	{
		if (tnPrgRev != NULL )
		{
			if (tnPrgRev[0] != NULLTAG)
			{
				tPrglatestrev = tnPrgRev[0];

				if(tPrglatestrev!=NULLTAG)
				{
					char * 	cvalue =NULL;

					NG5_ITK_CALL(ITEM_ask_item_of_rev (tPrglatestrev,&tPrgIItem));

					NG5_ITK_CALL(AOM_ask_value_string(tsrcPrgRev,REV_ID,&cvalue));

					NG5_ITK_CALL (WSOM_ask_object_type2(tsrcPrgRev,&cobject_type));

					NG5_ITK_CALL (ITEM_ask_item_of_rev	(tsrcPrgRev,	&tPrgIItem));
					NG5_ITK_CALL(ITEM_ask_latest_rev(tPrgIItem,&tPrglatestrev));
					NG5_ITK_CALL(AOM_ask_value_string(tPrglatestrev,REV_ID,	&cvalue));
					if(tPrgIItem!=NULLTAG)
					{
						ITKCALL(ITEM_list_bom_views(tPrgIItem, &iBomCount, &tBomViews));
					}
					ITKCALL(ITEM_rev_list_bom_view_revs(tPrglatestrev, &iBomCount, &tBomViews));
					if(iBomCount == 0 )
					{
						NG5_ITK_CALL(AOM_refresh(tPrgIItem,TRUE));
						ITKCALL(PS_create_bom_view(NULLTAG, NULL, NULL, tPrgIItem, &tPrgBOMView));
						ITKCALL(AOM_save_without_extensions(tPrgBOMView));
						ITKCALL(AOM_save_without_extensions(tPrgIItem));
						NG5_ITK_CALL(AOM_refresh(tPrgIItem,FALSE));
						NG5_ITK_CALL(AOM_refresh(tPrgBOMView,FALSE));
						NG5_ITK_CALL(AOM_refresh(tPrglatestrev,TRUE));
						ITKCALL(PS_create_bvr(tPrgBOMView, NULL, NULL, false, tPrglatestrev,&tBVR));
						NG5_ITK_CALL(BOM_create_window(&twindow));
						NG5_ITK_CALL(BOM_set_window_top_line_bvr(twindow,tBVR,&topLine));
						NG5_ITK_CALL(BOM_line_set_precise(topLine,false));
						NG5_ITK_CALL(BOM_save_window(twindow));
						NG5_ITK_CALL(BOM_close_window(twindow));
						NG5_ITK_CALL(AOM_save_without_extensions(tBVR));
						NG5_ITK_CALL(AOM_save_without_extensions(tPrglatestrev));
						NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));
						NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));
					}
					else
					{
						if(tPrgIItem!=NULLTAG)
						{
							int                     num_values = 0;
							tag_t                   tProject   = NULLTAG;
							tag_t               tProgramItem1  = NULLTAG;
							char* 	                cpId       = NULL;  //OF
							char**					cPrgmId    = NULL;  //OF

							iFail=AOM_ask_value_tag	(tPrgIItem,PROGRAM,&tProgramItem1);

							ITKCALL(AOM_ask_displayable_values(tProgramItem1,ATTR_ITEM_ID,&num_values,&cPrgmId));
							ITKCALL(PROJ_find(cPrgmId[0],&tProject));
							ITKCALL(PROJ_ask_id2	(	tProject,&cpId ));

							ITKCALL(ITEM_rev_list_all_bom_view_revs(tPrglatestrev, &iBomRevCount, &tBomRevs));

							if(iBomCount > 0)
							{
								tBVR = tBomRevs[iBomCount-1];
							}
							if(tProject != NULLTAG)
							{
								ITKCALL ( PROJ_assign_objects( 1, &tProject , 1 , &tBVR));
								ITKCALL(AOM_save_without_extensions(tBVR));
								NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));

							}
							NG5_MEM_TCFREE(cPrgmId);
							NG5_MEM_TCFREE(cpId);
						}
						NG5_MEM_TCFREE(cvalue);
					}
					NG5_MEM_TCFREE(cvalue);
					NG5_MEM_TCFREE(cobject_type);
					NG5_MEM_TCFREE(tBomViews);
					NG5_MEM_TCFREE(tBomRevs);

				}
			}
		}

}
NG5_MEM_TCFREE(cprogObjType);
return iFail;
}

