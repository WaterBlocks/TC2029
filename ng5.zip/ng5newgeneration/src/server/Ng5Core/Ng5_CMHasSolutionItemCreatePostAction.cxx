//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
 * @file
 *
 *   This file contains the implementation for the Extension Ng5_CMHasSolutionItemCreatePostAction
 *   Function will get called whenever Eng Part Rev & Raw Material Rev are attached to Solutions folder present under Design Freeze Change Object.
 *   It checks for the  Eng Part Rev & Raw Material Rev attached to Solutions folder present under Design Freeze Change Object & the property
 *   ng5_DesignFreeze on Eng Part Rev & Raw Material Rev gets updated.
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   10/05/2018  Meenakshi Shenoy  Initial Version
 *   07/05/2021  Balaji            TC12 Upgrade
 */
#include <Ng5Core/Ng5_CMHasSolutionItemCreatePostAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_associatePartRevtoDFRev(tag_t tPartRev, tag_t tDsgnFrzRev);
int Ng5_setDFPropertyValue(tag_t tPartRev, int numofdsgnfrzrevs,tag_t tDsgnFrzRev);

/****************************************************************************************************
*Function Name : Ng5_CMHasSolutionItemCreatePostAction
*Description   : This function Pastes the first Revision of an Mfg ITEM when trying to paste ITEM or other revision object on Mass Update Revsion with relation Solutions
*****************************************************************************************************/
int Ng5_CMHasSolutionItemCreatePostAction(METHOD_message_t *msg,
		va_list args) 
{
	TC_write_syslog("\n Entering Ng5_CMHasSolutionItemCreatePostAction\n");
	int iFail 		    = ITK_ok;
	tag_t tDsgnFrzRev   = NULLTAG;
	tag_t tPartRev      = NULLTAG;
	tag_t tRelationType = NULLTAG;
	tag_t tRelation 	= NULLTAG;
	tag_t tHasEngRel 	= NULLTAG;
	tag_t tTargetRev 	= NULLTAG;
	tag_t tItem 		= NULLTAG;
	char* cObjectType 	= NULL;
	char* cObjectType1 	= NULL;
	char* cRevID		= NULL;
	char* cItemID		= NULL;
	tDsgnFrzRev   = va_arg(args, tag_t);
	tPartRev      = va_arg(args, tag_t);
	tRelationType = va_arg(args, tag_t);
	if (NULLTAG != tDsgnFrzRev && NULLTAG != tPartRev && NULLTAG != tRelationType) 
	{
		/*	Added check to verify object type = Eng Part rev or Raw Material rev only.
		For rest of the types, code will skip the execution.*/
		NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));
		NG5_ITK_CALL(AOM_ask_value_string(tDsgnFrzRev,ATTR_OBJECT_TYPE, &cObjectType1));
		if(tc_strcmp(cObjectType, ENG_PART_REVISION) == 0 ||tc_strcmp(cObjectType, RAW_MATERIAL_REVISION) == 0 )
		{
			iFail = Ng5_associatePartRevtoDFRev(tPartRev,tDsgnFrzRev);
		}
		if(tc_strcmp(cObjectType1, MASSUPDATERev) == 0)
			{
				//iFail = Ng5_associatePartRevtoDARev(tPartRev,tDsgnFrzRev);
				if(tc_strcmp(cObjectType, MFGPART) == 0 )
				{
					iFail = Ng5_DeleteRelation11(tDsgnFrzRev,tPartRev,rSOLUTIONS);
					tTargetRev = Ng5_Find_First_Revision12(tPartRev);
					iFail = GRM_find_relation_type(rSOLUTIONS, &tRelationType);
					iFail = GRM_find_relation(tDsgnFrzRev, tTargetRev, tRelationType, &tRelation);
					if (iFail == ITK_ok && tRelation == NULLTAG)
					{
						iFail = GRM_create_relation(tDsgnFrzRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
						iFail = GRM_save_relation(tHasEngRel);
					}
				}
				if(tc_strcmp(cObjectType, MFGPARTRev) == 0 )
				{
					iFail = AOM_ask_value_string(tPartRev,ITEM_REV_ID, &cRevID);
					if(tc_strcmp(cRevID, "01") == 0 ||tc_strcmp(cRevID, "A") == 0  )
					{
						TC_write_syslog("\n Doing nothing as it is expected revison \n");
						// Do nothing
					} else
					{
						iFail = AOM_ask_value_string(tPartRev,ITEM_ID, &cItemID);
						iFail= Ng5_find_Item(cItemID,MFGPART,&tItem);
						tTargetRev = Ng5_Find_First_Revision12(tItem);
						iFail = Ng5_DeleteRelation11(tDsgnFrzRev,tPartRev,rSOLUTIONS);
						iFail = GRM_find_relation_type(rSOLUTIONS, &tRelationType);
						iFail = GRM_find_relation(tDsgnFrzRev, tTargetRev, tRelationType, &tRelation);
						if (iFail == ITK_ok && tRelation == NULLTAG)
						{
							iFail = GRM_create_relation(tDsgnFrzRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
							iFail = GRM_save_relation(tHasEngRel);
						}
					}

				}
			}
		//}
		MEM_TCFREE(cObjectType);
	}
	TC_write_syslog("\n Leaving Ng5_CMHasSolutionItemCreatePostAction \n");
	return iFail;
}


/**
 * Function Name 	:	Ng5_setPropertyValue
 * Description		:	This function sets the ng5_DesignFreeze property value
 * Parameters		:	tPartRev Tag of Primary (I)
 * 						numofdsgnfrzrevs number of DF's(I)
 * 						tDsgnFrzRev Tag of Secondary
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 * 10/05/2018 	|			|	Meenakshi Shenoy	|	1. Added this function as part of restructuring this extension code
 *
 */

int Ng5_setDFPropertyValue(tag_t tPartRev, int numofdsgnfrzrevs,tag_t tDsgnFrzRev)
{
	int iFail = ITK_ok;
	NG5_ITK_CALL(AOM_refresh(tPartRev,TRUE));
	NG5_ITK_CALL(AOM_set_value_tag_at(tPartRev,DESIGN_FREEZE_PROPERTY,numofdsgnfrzrevs, tDsgnFrzRev));
	TC_write_syslog("\n Setting Property ng5_DesignFreeze \n");
	NG5_ITK_CALL(AOM_save_with_extensions(tPartRev));//TC 12 Upgrade
	NG5_ITK_CALL(AOM_refresh(tPartRev,FALSE));

	return iFail;

}

/**
 * Function Name 	:	Ng5_associatePartRevtoDFRev
 * Description		:	This function checks whether DF rev is attached to Part Rev & also checks for the access on Part Rev.
 * Parameters		:	tPartRev Tag of Secondary (I)
 * 						tDsgnFrzRev Tag of Primary (I)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 * 10/08/2018 	|			|	Meenakshi Shenoy	|	1. Added this function as part of restructuring this extension code
 *
 */

int Ng5_associatePartRevtoDFRev(tag_t tPartRev, tag_t tDsgnFrzRev)
{
	int iFail = ITK_ok;
	int numofdsgnfrzrevs = 0;

	tag_t *tagtDsgnFrzRevs = NULLTAG;

	logical tDsgnFrzRevexist = false;

	logical lPriVerdict = false;


	NG5_ITK_CALL(AOM_ask_value_tags(tPartRev,DESIGN_FREEZE_PROPERTY,&numofdsgnfrzrevs,&tagtDsgnFrzRevs));


	//Checking if the 'Design Freeze' rev count is more than 0
	if (tagtDsgnFrzRevs > 0 && tagtDsgnFrzRevs != NULL) {
		for (int indxDsgnFrzRev = 0; indxDsgnFrzRev < numofdsgnfrzrevs; indxDsgnFrzRev++) {

			//Checking if the 'Design Freeze' rev is already attached to ng5_DesignFreeze Property
			if (tagtDsgnFrzRevs[indxDsgnFrzRev] == tDsgnFrzRev) {
				tDsgnFrzRevexist = true;
				break;

			}


		}
	}

	//Setting the ng5_DesignFreeze Property by adding the 'Design Freeze' rev to it

	NG5_ITK_CALL( AM_check_privilege (tPartRev, ACCESS_WRITE, &lPriVerdict));

	//Allow only if the logged in user has write access to Primary object
	if (true == lPriVerdict) {
		//If the Part Does not exist or Property value count is 0
		if (tDsgnFrzRevexist == false || numofdsgnfrzrevs == 0) {
			iFail = Ng5_setDFPropertyValue(tPartRev,numofdsgnfrzrevs,tDsgnFrzRev);
			if (iFail != ITK_ok) {
				return iFail;
			}
		}
	}
	MEM_TCFREE(tagtDsgnFrzRevs);
	return iFail;
}
