/*********************************************************************************************
** File Name:         Ng5_isOwningGrpMatchesLoginGrp.cxx
**
** File Description:
** This file contains implementation logic for Ng5_isOwningGrpMatchesLoginGrp extension
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   23/02/2017  Arjun      Initial Version
**   25/02/2017  Arjun      Modified code to handle to the extension is added on IMAN_delete of any relation
**	 08/03/2017	 Arjun		if Relation is IMAN_reference and Primary object is not Ng5_EngPartRevision, then skip validation
**   05/07/2021  Balaji     TC12 Upgrade
*********************************************************************************************/
#include <Ng5Core/Ng5_isOwningGrpMatchesLoginGrp.hxx>

#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <base_utils/ResultCheck.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

using namespace std;
using namespace Teamcenter;
using namespace ng5newgeneration;

int Ng5_isOwningGrpMatchesLoginGrp( METHOD_message_t * msg, va_list args)
{
	TC_write_syslog("\n Ng5_isOwningGrpMatchesLoginGrp Entering");
	int ifail 					= ITK_ok;
	int iCount 					= ITK_ok;
	int iCnt 					= 0;
	char* szCurrentGroupName 	= NULL;
	char* szOwningGroupName 	= NULL;
	char* pcRelationTypeName	= NULL;
	char* pcObjectTypeName		= NULL;
	char** szPrefValueList 		= NULL;

	tag_t tOwningGroup 			= NULLTAG;
	tag_t tCurrentGroupmember	= NULLTAG;
	tag_t tCurrentGroup 		= NULLTAG;
	tag_t tSecondary 			= NULLTAG;
	tag_t tPrimary 				= NULLTAG;
	tag_t tRelationType 		= NULLTAG;

	tPrimary   		= va_arg( args, tag_t );
	tSecondary 		= va_arg( args, tag_t );

	if(tPrimary==msg->object_tag) // if tPrimary is same as object_tag, then this extension is attached on IMAN_delete
	{
		// object_tag will be relation tag
		ITK( GRM_ask_primary(msg->object_tag,&tPrimary));
		ITK( GRM_ask_relation_type(msg->object_tag,&tRelationType));
	}
	else
		tRelationType 	= va_arg( args, tag_t );

	ITK( TCTYPE_ask_name2(tRelationType,&pcRelationTypeName));

	if(tPrimary !=NULLTAG)
	{
		ITK( WSOM_ask_object_type2(tPrimary,&pcObjectTypeName));
		if((tc_strcasecmp(pcObjectTypeName,ITEM_ENGINEERED_PART_REVISION)!=0)&&(tc_strcasecmp(pcRelationTypeName,"IMAN_reference")==0))
		{
			TC_write_syslog("\n Relation is Reference and Primary object is %s, so allowing to create/delete relation ",pcObjectTypeName);
			return ITK_ok;
		}
		else
		{
			ITK( AOM_ask_value_tag(tPrimary,ATTR_OWNING_GROUP,&tOwningGroup));

			ITK( SA_ask_current_groupmember  ( &tCurrentGroupmember ) );
			if ( tCurrentGroupmember != NULLTAG )
			{
				ITK( SA_ask_groupmember_group  ( tCurrentGroupmember, &tCurrentGroup ) );
				ITK( SA_ask_group_full_name (tCurrentGroup, &szCurrentGroupName) );
				TC_write_syslog("\n Current login group : %s\n",szCurrentGroupName);
				//TC12 commented the code
				//ITK(PREF_set_search_scope (TC_preference_site));
				ITK(PREF_ask_char_values  (PREF_BYPASSOWNINGGROUP,&iCount,&szPrefValueList));
				for(iCnt = 0;iCnt<iCount;iCnt++)
				{
					if(tc_strcasecmp(szPrefValueList[iCnt],szCurrentGroupName)==0)
					{
						TC_write_syslog("\n Current login group is present in the preference, so allowing to create relation");
						return ITK_ok;
					}
				}
			}
			if (( tCurrentGroup != NULLTAG )&&(tOwningGroup != NULLTAG))
			{
				ITK( SA_ask_group_full_name(tOwningGroup, &szOwningGroupName) );
				if(tc_strcasecmp(szCurrentGroupName,szOwningGroupName)!=0)
				{
					TC_write_syslog("\n Current login group is not matching with owning group of primary object, so restricting to create relation");
					return ErrorCodeMismatchGroup;
				}
			}
		}
	}


	if(pcRelationTypeName != NULL)
		MEM_TCFREE(pcRelationTypeName);
	if(szPrefValueList != NULL)
		MEM_TCFREE(szPrefValueList);
	if(szCurrentGroupName != NULL)
		MEM_TCFREE(szCurrentGroupName);
	if(szOwningGroupName != NULL)
		MEM_TCFREE(szOwningGroupName);
	if(pcObjectTypeName != NULL)
		MEM_TCFREE(pcObjectTypeName);
	TC_write_syslog("\n Ng5_isOwningGrpMatchesLoginGrp Leaving");
	return ITK_ok;
}

