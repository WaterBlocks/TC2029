/*********************************************************************************************
** File Name:         Ng5_rHasMirroredHandedRelImpl.cxx
**
** File Description:
**  This file contains the implementation for the Extension Ng5_rHasMirroredHandedRelImpl. This extension is added as Pre Condition for relation Ng5_rHasMirroredHandedRel
**	It will check if reverse Mirror Handed relation is being made between Engineering Part Revisions, if yes it will Prompt user and restricts creating such relation
**
** History			:
** 		Date	|  	AGM		|	Name          	|	Comments
** ------------------------------------------------------------------------------------------------
**  12/27/2016  |			|	Sachin Rampure 	|	Initial Version
**
**  08/20/2018	|			|Pradnya Hingankar 	|	Added changes for defect 1208 - Don't allow Mirror handed cyclic relation creation
**  07/05/2021  |           |Balaji             |   TC12 Upgrade
**
*********************************************************************************************/

#include <Ng5Core/Ng5_rHasMirroredHandedRelImpl.hxx>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <tc/tc_errors.h>
#include <base_utils/ResultCheck.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_rHasMirroredHandedRelImpl::Ng5_rHasMirroredHandedRelImpl(Ng5_rHasMirroredHandedRel& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_rHasMirroredHandedRelImpl::Ng5_rHasMirroredHandedRelImpl( Ng5_rHasMirroredHandedRel& busObj )
	: Ng5_rHasMirroredHandedRelGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_rHasMirroredHandedRelImpl::~Ng5_rHasMirroredHandedRelImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_rHasMirroredHandedRelImpl::~Ng5_rHasMirroredHandedRelImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_rHasMirroredHandedRelImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_rHasMirroredHandedRelImpl::initializeClass()
{
	int ifail = ITK_ok;
	static bool initialized = false;

	if( !initialized )
	{
		ifail = Ng5_rHasMirroredHandedRelGenImpl::initializeClass( );
		if ( ifail == ITK_ok )
		{
			initialized = true;
		}
	}
	return ifail;
}



/**
* Function Name 	:	validateCreateInputBase
* Description		:	Restrict creation of Mirrored Handed Relationship in opposite direction
* Parameters		:	tPrimaryRevTag	Tag of Primary (I)
* 						tSecondaryRevTag Tag of Secondary (I)
*					:	szRelationName	Name of Relation (I)
* Return Type		: 	int
*
* History			:
* Date			|  	AGM		|	Name          	|	Comments
* ------------------------------------------------------------------------------------------------
*  			|			|	Sachin  		|	Initial Creation
*  20/08/2018 	|			|	Pradnya  		|	1. Modified Function and file header
*				|			|					|	2.Reconstruct code to check and restrict Mirror Handed relation creation in Reverse direction irrespective of CATIA MML Links
*
*/
int  Ng5_rHasMirroredHandedRelImpl::validateCreateInputBase( ::Teamcenter::CreateInput *creInput )
{
	int 	ifail 		= 	ITK_ok;

	tag_t	tPrimary	=	NULLTAG;
	tag_t	tSecondary	=	NULLTAG;

	ResultCheck stat 	= 	ITK_ok;

	bool 		isNull 	= 	false;

	TC_write_syslog("\n in Ng5_rHasMirroredHandedRelImpl validateCreateInputBase");

	stat = creInput->getTag(PRIMARY_OBJECT, tPrimary, isNull);
	stat = creInput->getTag(SECONDARY_OBJECT, tSecondary, isNull);

	if( (NULLTAG != tSecondary) && (NULLTAG != tPrimary) )
	{

		char	*caPriType = NULL;
		//TC12 Upgrade, varialbe need to be cleaned up.
		char	*caSecType = NULL;

		//Checking whether the primary object and secondary object are Engineered Part Revisions
		//TC12 Upgrade.

		ITK( WSOM_ask_object_type2 (tPrimary, &caPriType) );
		//TC12 Upgrade Varialbe need to be cleaned up.

		ITK( WSOM_ask_object_type2 (tSecondary, &caSecType) );

		if ((tc_strcmp (caPriType, ENG_PART_REVISION) == 0) && (tc_strcmp (caSecType, ENG_PART_REVISION) == 0))
		{
			tag_t	tMirroredHandedReln	=	NULLTAG;


			ITK( GRM_find_relation_type(MIRRORED_HANDED, &tMirroredHandedReln) );
			if((NULLTAG != tMirroredHandedReln))
			{
				int		iDst		=	0;
				tag_t		*tpCatDst	=	NULL;
				int		iSecEngPrt	=	0;
				tag_t		*tpSecEngPrt	=	NULL;

				//Getting the secondary (Engineered Part Revision) of above CATPart with relation catiaV5_MML - If exists

				ITK( GRM_list_secondary_objects_only(tSecondary, tMirroredHandedReln, &iSecEngPrt, &tpSecEngPrt) );

				if(NULL != tpSecEngPrt)
				{


					for(int iPrt=0; iPrt<iSecEngPrt; iPrt++)
					{
						//Check if cyclic relationship is getting created for mirrored handed relation

						if(tpSecEngPrt[iPrt] == tPrimary)
						{
							char* szPrimaryItemID = NULL;
							char* szPrimaryRevId= NULL;
							char * szSecItemID = NULL;
							char * szSecItemRevID = NULL;
							char* szPriObjStr= NULL;

							char* szSecObjStr= NULL;
							ITK(AOM_ask_value_string(tPrimary, ATTR_ITEM_ID, &szPrimaryItemID));
							ITK(AOM_ask_value_string(tPrimary, ATTR_ITEM_REV_ID, &szPrimaryRevId));
							szPriObjStr = (char *)MEM_alloc(tc_strlen(szPrimaryItemID) + tc_strlen(szPrimaryRevId) + tc_strlen("/")+ 1);

							tc_strcpy(szPriObjStr,szPrimaryItemID);
							tc_strcat(szPriObjStr,"/");
							tc_strcat(szPriObjStr,szPrimaryRevId);
							ITK(AOM_ask_value_string(tSecondary, ATTR_ITEM_ID, &szSecItemID));
							ITK(AOM_ask_value_string(tSecondary, ATTR_ITEM_REV_ID, &szSecItemRevID));

							szSecObjStr = (char *)MEM_alloc(tc_strlen(szSecItemID) + tc_strlen(szSecItemRevID) + tc_strlen("/")+ 1);

							tc_strcpy(szSecObjStr,szSecItemID);
							tc_strcat(szSecObjStr,"/");
							tc_strcat(szSecObjStr,szSecItemRevID);
							TC_write_syslog("\n Cyclic relation is being created..");
							ifail = ErrorCodeForMHSecondary;
							EMH_store_error_s2(EMH_severity_error, ifail,szSecObjStr,szPriObjStr);
							NG5_MEM_TCFREE(szPriObjStr);
							NG5_MEM_TCFREE(szSecObjStr);
							NG5_MEM_TCFREE(szPrimaryItemID);
							NG5_MEM_TCFREE(szPrimaryRevId);
							NG5_MEM_TCFREE(szSecItemID);
							NG5_MEM_TCFREE(szSecItemRevID);
							return ifail;

						}
					}

					NG5_MEM_TCFREE(tpSecEngPrt);

				}
			}
			//Added changes for defect 1208, AGM 1557 - Don't allow Mirror Handed cyclic relation creation	
			int iNumberOfMirrorHandedPrimary = 0;
			tag_t *ptMirrorHandedPrimaryTags = NULL;
			ITK(AOM_ask_value_tags(tPrimary,ATTR_MIRRORED_HANDED_PRIMARY,&iNumberOfMirrorHandedPrimary,&ptMirrorHandedPrimaryTags));
			TC_write_syslog("\n iNumberOfMirrorHandedPrimary is %d",iNumberOfMirrorHandedPrimary);
			if(ptMirrorHandedPrimaryTags!=NULL)
			{
				for(int ii=0;ii<iNumberOfMirrorHandedPrimary;ii++)
				{
					if(ptMirrorHandedPrimaryTags[ii]==tSecondary)
					{
						char* szPrimaryItemID = NULL;
						char* szPrimaryRevId= NULL;
						char * szSecItemID = NULL;
						char * szSecItemRevID = NULL;
						char* szPriObjStr = NULL;
						char* szSecObjStr = NULL;
						ITK(AOM_ask_value_string(tPrimary, ATTR_ITEM_ID, &szPrimaryItemID));
						ITK(AOM_ask_value_string(tPrimary, ATTR_ITEM_REV_ID, &szPrimaryRevId));

						szPriObjStr = (char *)MEM_alloc(tc_strlen(szPrimaryItemID) + tc_strlen(szPrimaryRevId) + tc_strlen("/")+ 1);

						tc_strcpy(szPriObjStr,szPrimaryItemID);
						tc_strcat(szPriObjStr,"/");
						tc_strcat(szPriObjStr,szPrimaryRevId);

						ITK(AOM_ask_value_string(tSecondary, ATTR_ITEM_ID, &szSecItemID));
						ITK(AOM_ask_value_string(tSecondary, ATTR_ITEM_REV_ID, &szSecItemRevID));
						szSecObjStr = (char *)MEM_alloc(tc_strlen(szSecItemID) + tc_strlen(szSecItemRevID) + tc_strlen("/")+ 1);
						tc_strcpy(szSecObjStr,szSecItemID);
						tc_strcat(szSecObjStr,"/");
						tc_strcat(szSecObjStr,szSecItemRevID);
						
						TC_write_syslog("\n Cyclic relation is being created..");
						ifail = ErrorCodeForMHSecondary;
						EMH_store_error_s2(EMH_severity_error, ifail,szSecObjStr,szPriObjStr);
						
						
						NG5_MEM_TCFREE(szPriObjStr);
						NG5_MEM_TCFREE(szSecObjStr);
						NG5_MEM_TCFREE(szPrimaryItemID);
						NG5_MEM_TCFREE(szPrimaryRevId);
						NG5_MEM_TCFREE(szSecItemID);
						NG5_MEM_TCFREE(szSecItemRevID);
						return ifail;
					}
				}
			}

		}
		NG5_MEM_TCFREE(caPriType);
		NG5_MEM_TCFREE(caSecType);
	}



	// Call the parent Implementation

	if(ITK_ok == ifail)

		Ng5_rHasMirroredHandedRelImpl::super_validateCreateInputBase(  creInput );
	TC_write_syslog("\n Leeaving Ng5_rHasMirroredHandedRelImpl ");


	return ifail;
}
