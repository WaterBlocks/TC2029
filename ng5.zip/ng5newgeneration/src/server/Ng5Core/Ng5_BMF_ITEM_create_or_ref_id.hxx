//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_BMF_ITEM_create_or_ref_id
 *
 */
 
#ifndef NG5_BMF_ITEM_CREATE_OR_REF_ID_HXX
#define NG5_BMF_ITEM_CREATE_OR_REF_ID_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
//#include <stdlib.h>
#include<vector>
#include<set>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_BMF_ITEM_create_or_ref_id(METHOD_message_t* msg, va_list largs);
int Ng5_find_item(const char* cpItemid, char* cpobjtype,tag_t* tItemTag );
int Ng5_find_item_rev(const char* cpItemid, const char* cpRevid, char* cpobjtype,tag_t* tItemRevTag );
int Ng5_build_ebom_traverse_vector(tag_t tEBOMLineNode, std::vector<tag_t> *vectEBOMTraverseNodes );
int Ng5_check_skip_ebom_node(tag_t tEBOMLineNode, char* OEMName, char* cpPlantcode, logical* lIsEBOMSkip);
int Ng5_getRev2CopyFrom(tag_t tItemTag,tag_t* tRevTag);
logical Ng5_validType2Copy(char* cpEBOMNodeType);
logical Ng5_validType2Clone(char* cpEBOMNodeType);
int Ng5_get_bline_attr_tag (
      tag_t bline_t,      /* <I> */
      char  *attr,        /* <I> */
      tag_t *attr_t       /* <O> */
      );
tag_t Ng5_isRawMaterialExists(tag_t tEBOMItem);
tag_t Ng5_isPackagingPartExists(tag_t tEBOMItem);
           
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_BMF_ITEM_CREATE_OR_REF_ID_HXX
