//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
* @file
*
*   This file contains the implementation for the Extension Ng5_LaunchExport
*** 05/07/2021  Balaji           TC12 Upgrade
*/
#include <Ng5Core/Ng5_LaunchExport.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include "Ng5_CommonUtils.hxx"

using namespace ng5newgeneration;

/*
*
* This function is called insided LaunchExport.
* sets the Auto Program name on Launch Prog. reads the required attributes such as OEM model, Year, name from the Launch.
* Input Arguement given is Launch prog object.
*/
int autoPopulateLaungPrgName(tag_t tLaunchPrg)
{
	int iFail = ITK_ok;
	TC_write_syslog("\n Ng5_autoPopulateLaunchPrgName entrance" );
	//char* sModel_Yr                                      = NULL;
	//char* sOEM_Name                                      = NULL;
	char** sModel_YrVals                                   = NULL;
	char** sOEM_NameVals                                   = NULL;
	char* sDisp_OEM_Name                                   = NULL;
	char** sDC_Launchst_Rgn                                = NULL;
	char* sDC_Name                                         = NULL;
	char* sMODEL_Code                                      = NULL;
	char* sVehicle_Name                                    = NULL;
	char** sProduct_LineVals                               = NULL;
	//char* sProduct_Line                                  = NULL;
	char* sKiss_Comment                                    = NULL;
	char *  sProgramConcatAttr                             = NULL;
	char** sProd_AreaVals                                  = NULL;
	//char* sProd_Area                                     = NULL;
	std::string  sAuto_prg_name ("");
	int entry_count                                        = 0;
	int iDC_num                                            = 0;
	int nyr                                                = 0;
	int noem                                               = 0;
	int npline                                             = 0;
	int nparea                                             = 0;

	NG5_ITK_CALL( PREF_ask_char_value( NG5_PROGRAM_CONCAT_PROPERTY,0,&sProgramConcatAttr));
	//Get Launch Program Revision attributes
	/*NG5_ITK_CALL(AOM_UIF_ask_value( tLaunchPrg, MODEL_YR, &sModel_Yr ));
	NG5_ITK_CALL(AOM_UIF_ask_value ( tLaunchPrg, PRODUCT_AREA, &sProd_Area));
	NG5_ITK_CALL(AOM_UIF_ask_value( tLaunchPrg,OEM_NAME,&sOEM_Name ));
	NG5_ITK_CALL(AOM_UIF_ask_values(tLaunchPrg,DC_LAUNCHST_RGN,&iDC_num,&sDC_Launchst_Rgn ));*/
	NG5_ITK_CALL(AOM_ask_displayable_values( tLaunchPrg, MODEL_YR,&nyr, &sModel_YrVals ));//TC12 Upgrade
	NG5_ITK_CALL(AOM_ask_displayable_values ( tLaunchPrg, PRODUCT_AREA, &nparea,&sProd_AreaVals));//TC12 Upgrade

	NG5_ITK_CALL(AOM_ask_displayable_values( tLaunchPrg,OEM_NAME,&noem,&sOEM_NameVals ));//TC12 Upgrade

	NG5_ITK_CALL(AOM_ask_displayable_values(tLaunchPrg,DC_LAUNCHST_RGN,&iDC_num,&sDC_Launchst_Rgn ));//TC12 Upgrade
	NG5_ITK_CALL(AOM_ask_value_string( tLaunchPrg,MODEL_CODE,&sMODEL_Code ));
	NG5_ITK_CALL(AOM_ask_value_string( tLaunchPrg,VEHICLE_NAME,&sVehicle_Name ));
	//NG5_ITK_CALL(AOM_UIF_ask_value( tLaunchPrg,PRODUCT_LINE,&sProduct_Line ));
	NG5_ITK_CALL(AOM_ask_displayable_values( tLaunchPrg,PRODUCT_LINE,&npline,&sProduct_LineVals ));//TC12 Upgrade

	NG5_ITK_CALL(AOM_ask_value_string( tLaunchPrg,KISS_COMMENT,&sKiss_Comment ));
	NG5_ITK_CALL(AOM_ask_value_string ( tLaunchPrg,DC_NAME,&sDC_Name ));


	//print all attribute names
	TC_write_syslog("\n Value of Model year is --%s--- \n", sModel_YrVals[0]);
	TC_write_syslog("\n Value of sOEM_Name is --%s--- \n", sOEM_NameVals[0]);
	TC_write_syslog("\n Value of sMODEL_Code is --%s--- \n", sMODEL_Code);
	TC_write_syslog("\n Value of sVehicle_Name is --%s--- \n", sVehicle_Name);
	TC_write_syslog("\n Value of sProduct_Line is --%s--- \n", sProduct_LineVals[0]);
	TC_write_syslog("\n Value of sKiss_Comment is --%s--- \n", sKiss_Comment);
	TC_write_syslog("\n Value of sDC_Name is --%s--- \n", sDC_Name);
	TC_write_syslog("\n Value of iDC_num is %d \n",iDC_num);
	TC_write_syslog("\n Value of product area is --%s--- \n", sProd_AreaVals[0]);

	/***********logic for setting Direct customer value starts here*****************/
	sAuto_prg_name.assign( "" );

	if( sModel_YrVals[0] != NULL && tc_strcmp( sModel_YrVals[0], "" ) != 0 )
	{
		sAuto_prg_name.append( sModel_YrVals[0] );
	}

	sAuto_prg_name.append( NAME_SEPERATOR );
	//get the value of Direct customer launch site region and concatenate it
	if(iDC_num > 0 && sDC_Launchst_Rgn[0] != NULL )
	{
		TC_write_syslog("\n Entered direct customer values \n");
		sAuto_prg_name.append( sDC_Launchst_Rgn[0]);
	}

	sAuto_prg_name.append( NAME_SEPERATOR );
	if( sOEM_NameVals[0] != NULL && tc_strcmp( sOEM_NameVals[0], "" ) != 0 )
	{
		sAuto_prg_name.append( sOEM_NameVals[0]);
	}
	sAuto_prg_name.append( NAME_SEPERATOR );
	if( sDC_Name != NULL && tc_strcmp( sDC_Name, "" ) != 0 )
	{
		sAuto_prg_name.append( sDC_Name );
	}
	sAuto_prg_name.append( NAME_SEPERATOR );
	if( sMODEL_Code != NULL && tc_strcmp( sMODEL_Code, "" ) != 0 )
	{
		sAuto_prg_name.append( sMODEL_Code );
	}
	sAuto_prg_name.append( NAME_SEPERATOR );
	if( sVehicle_Name != NULL && tc_strcmp( sVehicle_Name, "" ) != 0 )
	{
		sAuto_prg_name.append( sVehicle_Name );
	}
	sAuto_prg_name.append( NAME_SEPERATOR );
	if( sProduct_LineVals[0] != NULL && tc_strcmp( sProduct_LineVals[0], "" ) != 0 )
	{
		sAuto_prg_name.append( sProduct_LineVals[0] );
	}
	sAuto_prg_name.append( NAME_SEPERATOR );
	if( sProd_AreaVals[0] != NULL && tc_strcmp( sProd_AreaVals[0], "" ) != 0 )
	{
		sAuto_prg_name.append( sProd_AreaVals[0] );
	}
	sAuto_prg_name.append( NAME_SEPERATOR );
	if( sKiss_Comment != NULL && tc_strcmp( sKiss_Comment, "" ) != 0 )
	{
		//sAuto_prg_name.append( NAME_SEPERATOR );
		sAuto_prg_name.append( sKiss_Comment );
	}
	TC_write_syslog("\n Value of concatenated sAuto_prg_name is --%s--- \n", sAuto_prg_name.c_str());
	TC_write_syslog("\n after sAuto_prg_name \n");
	TC_write_syslog("\n Entered in setting program name \n");
	NG5_ITK_CALL( AOM_refresh( tLaunchPrg, POM_modify_lock ));
	if ( sAuto_prg_name.length() < 128 )
	{
		NG5_ITK_CALL( AOM_set_value_string( tLaunchPrg, sProgramConcatAttr, sAuto_prg_name.c_str() ));
		TC_write_syslog("\n after AOM_set_value_string for object_name for program \n");
	}
	else
	{
		std::string slocal_prgrev_name("");
		slocal_prgrev_name = sAuto_prg_name.substr( 0, 126 );
		TC_write_syslog("\n value of slocal_prgrev_name ----%s---- \n", slocal_prgrev_name.c_str());
		NG5_ITK_CALL( AOM_set_value_string( tLaunchPrg, sProgramConcatAttr, slocal_prgrev_name.c_str() ));
		TC_write_syslog("\n after AOM_set_value_string for object_name for program \n");
	}
	NG5_ITK_CALL(AOM_save_with_extensions( tLaunchPrg ));//TC12 Upgrade
	TC_write_syslog("\n after AOM_save_with_extensions for program \n");
	NG5_ITK_CALL( AOM_unlock( tLaunchPrg ));
	TC_write_syslog("\n after AOM_unlock of program \n");
	TC_write_syslog("\n Ng5_autoPopulateLaunchPrgName exit" );

	MEM_TCFREE( sModel_YrVals );
	MEM_TCFREE( sOEM_NameVals );
	MEM_TCFREE( sDC_Launchst_Rgn );
	MEM_TCFREE( sProduct_LineVals );
	MEM_TCFREE( sProd_AreaVals );


	return iFail;
}

int Ng5_LaunchExport( METHOD_message_t * msg, va_list args )
{
	int iFail = ITK_ok;
	TC_write_syslog("\n LaunchExport entrance" );
	va_list largs;
	va_copy( largs, args );
	tag_t  tLaunchRel             = va_arg (largs, tag_t);
	int    isNew                  = va_arg (largs, int);

	if(isNew == 1)
	{
		tag_t tMasterPrg 			  = NULLTAG;
		tag_t tLaunchPrg 			  = NULLTAG;

		NG5_ITK_CALL(GRM_ask_primary	(tLaunchRel,&tMasterPrg));
		NG5_ITK_CALL(GRM_ask_secondary	(tLaunchRel,&tLaunchPrg ));

		//calling function to set auto program name on Launch Prog
		iFail = autoPopulateLaungPrgName(tLaunchPrg);

		logical bPLMXML_Export_Check_PrefValue =false;
		tag_t  tlatestrev = NULLTAG;
		//read program export control preference value
		NG5_ITK_CALL(PREF_ask_logical_value(NG5_PROGRAM_PLMXML_EXPORT_CHECK,0,&bPLMXML_Export_Check_PrefValue));
		NG5_ITK_CALL(ITEM_ask_latest_rev ( tLaunchPrg,&tlatestrev));
		//Take decision whether to export or not
		if(bPLMXML_Export_Check_PrefValue)
		{
			TC_write_syslog("\n--->>>>>PLMXML_Export_Check pref vlaue -> True, so exporting program");
			iFail = Ng5_CommonUtils::Ng5_programExport( tlatestrev );
		}
		else
		{
			TC_write_syslog("\n--->>>>>PLMXML_Export_Check pref vlaue -> false, so program export aborted");
		}
	}
	TC_write_syslog("\n LaunchExport exit" );
	return iFail;

}
