//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_LaunchPrgImpl
//

#include <Ng5Core/Ng5_LaunchPrgImpl.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

#include <fclasses/tc_string.h>
#include <tc/tc.h>

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_LaunchPrgImpl::Ng5_LaunchPrgImpl(Ng5_LaunchPrg& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_LaunchPrgImpl::Ng5_LaunchPrgImpl( Ng5_LaunchPrg& busObj )
   : Ng5_LaunchPrgGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_LaunchPrgImpl::~Ng5_LaunchPrgImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_LaunchPrgImpl::~Ng5_LaunchPrgImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_LaunchPrgImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_LaunchPrgImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_LaunchPrgGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


///
/// Getter for a Tag Property
/// @param value - Parameter value
/// @param isNull - Returns true if the Parameter value is null
/// @return - Status. 0 if successful
///
int  Ng5_LaunchPrgImpl::getNg5_launchprg_masterprgBase( tag_t &tMasterPrg /*value*/, bool &isNull /*isNull*/ ) const
{
    int iFail 				= ITK_ok;
    tag_t tgetRelation 		= NULLTAG;
    tag_t tLaunchPrg        = NULLTAG;
    TC_write_syslog("\nGetting value for Runtime Property  Ng5_GetLaunchPrgMasterPrg" );
    Ng5_LaunchPrg *launchPrg =  getNg5_LaunchPrg();
    tLaunchPrg = ((Teamcenter::BusinessObject*)launchPrg)->getTag();
    if (tLaunchPrg!=NULLTAG)
    {
       NG5_ITK_CALL(GRM_find_relation_type("Ng5_rHasLaunch", &tgetRelation));
       if (tgetRelation != NULLTAG)
       {
                      int objCount = 0;
                      tag_t *tPrimaryObjects = NULL;
                      NG5_ITK_CALL(GRM_list_primary_objects_only(tLaunchPrg,tgetRelation,&objCount,&tPrimaryObjects));
                      TC_write_syslog("\n Inside if for Runtime Property  Ng5_GetLaunchPrgMasterPrg = %d",objCount );
                      if (objCount>0)
                      {
                                     tMasterPrg = tPrimaryObjects[0];
                                     isNull = false;
                                     NG5_MEM_TCFREE( tPrimaryObjects );
                      }
       }
    }
    TC_write_syslog("\nSuccseeful got value for Runtime Property  Ng5_GetLaunchPrgMasterPrg" );
    return iFail;
}

