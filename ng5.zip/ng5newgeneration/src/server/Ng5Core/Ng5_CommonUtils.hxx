/*********************************************************************************************
** File Name:         Ng5_CommonUtils.hxx
**
** File Description:
** This file contains declarations for Common functions
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   12/09/2016  Pradnya Hingankar      Initial Version

*********************************************************************************************/

#ifndef Ng5_CommonUtils_HXX_
#define Ng5_CommonUtils_HXX_

#include <Ng5Core/Ng5Core_Std_Defines.h>

#include <base_utils/ScopedSmPtr.hxx>
#include <map>
#include <vector>
#include <iostream>
#include <sstream>
#include <fclasses/tc_stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <sa/am.h>
#include <algorithm>    // std::sort

using namespace std;
using namespace Teamcenter;

namespace ng5newgeneration {
class Ng5_CommonUtils {
public:
	Ng5_CommonUtils();
	virtual ~Ng5_CommonUtils();
	static  logical isStatused(tag_t tItemRevTag, char * chStatusName);
	static logical isMinorRevision(char * cRevId);
	static tag_t getLatestRevisionOverlay(tag_t tNewRevision);
	static int loadAllPreferencesIntoMap( string  szPreferenceName, map<string, string> &MapPreference);
	static  string ZeroPadNumber(int num);
	static logical isMinor(tag_t tItemRevTag);
	static vector<string> splitStringToVector ( string s, string delimiter );
	static int Ng5_isCurrentGroup(char *szGroupName);
	static int Find_All_Primary_Object (
							tag_t Secondary_Object, /**< (I)Primary  Object Tag */
							char *relation_name,  /**< (I) Relation Name */
							int *Primary_Object_Count,   /**< (O)Count of Secondary object */
							tag_t **Primary_Object_Tags); /**< (OF)List of Secondary object tag */

	static int Find_All_Secondary_Objects(tag_t tPrimaryObject, /**< (I)Primary  Object Tag */
													char *relation_name,  /**< (I) Relation Name */
													int *iObjectCount,   /**< (O)Count of Secondary object */
													tag_t **ptSecObjectTags) ;/**< (OF)List of Secondary object tag */
	static int Ng5_programExport(tag_t tPR );
	static int setNg5_ChangeState(tag_t tDARevTag);
	static int setNg5_UpdateDAProperty(tag_t tDARevTag);
	static int getConvertedWeight (char* cSAPUom, char* cPlantUOM, double value, double* newValue);
	static double roundTo5Places(double d);
	static int getAttrIDTag (tag_t tObject, char* sClassName, char* sAttrName, tag_t* tAttrTag);
	static logical is_descendant_of_Form(tag_t object);
	static char* convertSpecialCharacters(char* cpOriginalFileName);
};
}
#endif /* NG5ADIENTCOMMON_HXX_ */
