//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
 * @file
 *
 *   This file contains the implementation for the Extension Ng5_AutoPopulatePrgName
 *
 *##########################################Modification#########################################################################################################
 *
 *		Name:-				Date							Modification										Description
 *		Rukmini R			6th April 				Added Status tag to BVR Revision
 *
 *		Syed Suleman 		12th Dec-2020 			Added Function Ng5_assignTeamAdmintoProject		Add the User To Project as Team Administrator
 **      Balaji             5th Jul 2021            TC12 UpgradeTC12 Upgrade
 **
 **      Shivaji Parade     7th Jul 2023            added function NG5_pouplate_product_launch      create BVR in product launch and assign to respective project
 *###############################################################################################################################################################						 
 */

#include <Ng5Core/Ng5_autoPopulatePrgName.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include "Ng5_CommonUtils.hxx"
#include <stdarg.h>
#include <string>
#include <sstream>
#include <ug_va_copy.h>
#include <tccore/project.h>
#include <tccore/method.h>
#include <tc/preferences.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/item.h>
#include <pie/pie.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>


using namespace std;
using namespace ng5newgeneration;

std::string Ng5_validateProjectName(std::string projectName)
{
	int iproj_name_length=0;
	int isValid=0;
	std::string slcl_prj_name("");

	iproj_name_length = projectName.length();
	while(iproj_name_length>0)
	{
		int cProjectLastChar = (int)projectName[iproj_name_length-1];
		if(!((cProjectLastChar >=65 && cProjectLastChar <=90) || (cProjectLastChar >=97 && cProjectLastChar <=122) || (cProjectLastChar >=48 && cProjectLastChar <=57)))
		{
			iproj_name_length --;

		}
		else
		{
			isValid=1;
			break;
		}
	}
	if(isValid==1)
	{
		slcl_prj_name = projectName.substr(0,iproj_name_length);
	}
	return slcl_prj_name;
}


	/*
     * ng5_oem_model_year          LOV              R
     * ng5_dc_launch_site_rgn      LOV              N
     * ng5_oem_name                LOV              R
     * ng5_dc_name                 LOV              R
     * ng5_oem_model_code          LOV              R
     * ng5_oem_vehicle_name        LOV              R
     * ng5_product_line            LOV              N
     * ng5_product_area            LOV              R
     * ng5_kiss_comment                             N
     */
int Ng5_autoPopulatePrgName( METHOD_message_t * msg, va_list args )
{
    TC_write_syslog ("--->>>>> Entering Ng5_AutoPopulatePrgName>>>>>--- \n");
    tag_t tProgramItem                                    = va_arg (args, tag_t);
    tag_t * tnPrgRev                                        = va_arg (args, tag_t *);
    int iFail                                             = ITK_ok;
    //char* sModel_Yr                                        = NULL;
    //char* sOEM_Name                                        = NULL;
   // char* sDisp_OEM_Name                                   = NULL;
    char** sDC_Launchst_Rgn                                = NULL;
    char* sDC_Name                                         = NULL;
    char* sMODEL_Code                                      = NULL;
    char* sVehicle_Name                                    = NULL;
    //char* sProduct_Line                                    = NULL;
    char* sKiss_Comment                                    = NULL;
    char * sDC_Name_Same                                   = NULL;
	//char* sProd_Area                                       = NULL;
    char* sPrg_Status	                                   = NULL;
	std::string  sAuto_prg_name ("");
    int entry_count                                        = 0;
    int iDC_num                                            = 0;
    char *    item_id                                        = NULL;
    tag_t tlatestrev                                     = NULLTAG;
	char* progObjType                                     = NULL;
	int          qry_entry_count                                                          = 1;
	int          num_found                                                                = 0;
	int          isNew                                                                    = 0;
	int	         iPrefValue				                                                  =	0;
	tag_t tPrgRelationType     	= 	NULLTAG;

	tag_t*       tproject                                                                 = NULL;
	tag_t        tClassID                                                                 = NULLTAG;
	tag_t        MasterPrg                                                                = NULLTAG;
	tag_t        projectTag                                                               = NULLTAG;
	tag_t        tRelType                                                              	  = NULLTAG;
	tag_t        query_tag                                                                = NULLTAG;

	char *       chCheckedOut			                                                  =	NULL;
	char*        cpItemId	                                                              = NULL;
	char*        objName	                                                              = NULL;
	char*        pClassName                                                               = NULL;
	char         query_name[QRY_name_size_c+1]                                            = "Projects...";
	char *       entries [1]                                                              = {"Project ID"};
	char *       values [1]                                                               = {""};
	char *       sProgramConcatAttr                                                       = NULL;
	char** sModel_YrVals                                        						  = NULL;
	char** sOEM_NameVals                                                                  = NULL;
	char** sProduct_LineVals                                                              = NULL;
	char** sProd_AreaVals                                                                 = NULL;
	char** sDisp_OEM_NameVals                                                             = NULL;
	int nyr                                                                               = 0;
	int noem                                                                              = 0;
	int npline                                                                            = 0;
	int nparea                                                                            = 0;
	int nname                                                                             = 0;
	TC_preference_search_scope_t currentScope;

	NG5_ITK_CALL( PREF_ask_char_value( NG5_PROGRAM_CONCAT_PROPERTY,0,&sProgramConcatAttr));


	NG5_ITK_CALL(ITEM_ask_latest_rev (tProgramItem,&tlatestrev));
    NG5_ITK_CALL( AOM_ask_value_string( tlatestrev, "object_type", &progObjType ));

    //Get Program Revision attributes
    /*NG5_ITK_CALL(AOM_UIF_ask_value( tProgramItem, MODEL_YR, &sModel_Yr ));
    NG5_ITK_CALL(AOM_UIF_ask_value ( tProgramItem, PRODUCT_AREA, &sProd_Area));
    NG5_ITK_CALL(AOM_UIF_ask_value( tProgramItem,OEM_NAME,&sOEM_Name ));
    NG5_ITK_CALL(AOM_UIF_ask_values(tProgramItem,DC_LAUNCHST_RGN,&iDC_num,&sDC_Launchst_Rgn ));**********/
    NG5_ITK_CALL(AOM_ask_displayable_values( tProgramItem, MODEL_YR, &nyr, &sModel_YrVals ));//TC12 Upgrade

    NG5_ITK_CALL(AOM_ask_displayable_values ( tProgramItem, PRODUCT_AREA, &nparea,&sProd_AreaVals));//TC12 Upgrade

    NG5_ITK_CALL(AOM_ask_displayable_values( tProgramItem,OEM_NAME,&noem,&sOEM_NameVals ));//TC12 Upgrade

    NG5_ITK_CALL(AOM_ask_displayable_values(tProgramItem,DC_LAUNCHST_RGN,&iDC_num,&sDC_Launchst_Rgn ));
    NG5_ITK_CALL(AOM_ask_value_string( tProgramItem,MODEL_CODE,&sMODEL_Code ));
    NG5_ITK_CALL(AOM_ask_value_string( tProgramItem,VEHICLE_NAME,&sVehicle_Name ));
    //NG5_ITK_CALL(AOM_UIF_ask_value( tProgramItem,PRODUCT_LINE,&sProduct_Line ));
    NG5_ITK_CALL(AOM_ask_displayable_values( tProgramItem,PRODUCT_LINE,&npline,&sProduct_LineVals ));//TC12 Upgrade

    NG5_ITK_CALL(AOM_ask_value_string( tProgramItem,KISS_COMMENT,&sKiss_Comment ));

    /***********logic for setting Direct customer value starts here*****************/


    NG5_ITK_CALL(AOM_ask_value_string ( tProgramItem,DC_NAME,&sDC_Name ));

    //NG5_ITK_CALL(AOM_UIF_ask_value( tProgramItem,OEM_NAME,&sDisp_OEM_Name ));
    NG5_ITK_CALL(AOM_ask_displayable_values( tProgramItem,OEM_NAME,&nname,&sDisp_OEM_NameVals ));//TC 12 upgrade sDisp_OEM_NameVals

    //setting whole auto name by concatenation
	sAuto_prg_name.assign( sModel_YrVals[0] );
	sAuto_prg_name.append( NAME_SEPERATOR );

    //get the value of Direct customer launch site region and concatenate it
	if(iDC_num > 0 && sDC_Launchst_Rgn[0] != NULL )
	{
		sAuto_prg_name.append( sDC_Launchst_Rgn[0]);
		sAuto_prg_name.append( NAME_SEPERATOR );
	}

	sAuto_prg_name.append( sDisp_OEM_NameVals[0] );
	sAuto_prg_name.append( NAME_SEPERATOR );
	//sAuto_prg_name.append( sDC_Name );
	//sAuto_prg_name.append( NAME_SEPERATOR );
	sAuto_prg_name.append( sMODEL_Code );
	sAuto_prg_name.append( NAME_SEPERATOR );
	sAuto_prg_name.append( sVehicle_Name );
	if( sProduct_LineVals[0]!= NULL)
	{
        if( tc_strcmp( sProduct_LineVals[0], "" ) != 0 )
	    {
	    	sAuto_prg_name.append( NAME_SEPERATOR );
	    	sAuto_prg_name.append( sProduct_LineVals[0] );
	    }
	}
	sAuto_prg_name.append( NAME_SEPERATOR );
	sAuto_prg_name.append( sProd_AreaVals[0] );
	if( sKiss_Comment != NULL)
	{
        if( tc_strcmp( sKiss_Comment, "" ) != 0 )
	    {
	    	sAuto_prg_name.append( NAME_SEPERATOR );
	    	sAuto_prg_name.append( sKiss_Comment );
	    }
	}
    
	NG5_ITK_CALL( AOM_refresh( tProgramItem, POM_modify_lock ));
	if ( sAuto_prg_name.length() < 128 )
	{
		NG5_ITK_CALL( AOM_set_value_string( tProgramItem, sProgramConcatAttr, sAuto_prg_name.c_str() ));
	}
	else
	{
		std::string slocal_prgrev_name("");
		slocal_prgrev_name = sAuto_prg_name.substr( 0, 126 );
		NG5_ITK_CALL( AOM_set_value_string( tProgramItem, sProgramConcatAttr, slocal_prgrev_name.c_str() ));
	}
	NG5_ITK_CALL(AOM_save_without_extensions( tProgramItem ));//TC12 Upgrade
	NG5_ITK_CALL( AOM_unlock( tProgramItem ));


	//NG5_ITK_CALL(PREF_ask_search_scope(&currentScope));//TC12 Upgrade obsolete call
	//NG5_ITK_CALL(PREF_set_search_scope(TC_preference_site));//TC12 Upgrade obsolete call
	NG5_ITK_CALL(PREF_ask_int_value(PREF_PROGRAM_SECURITY, 0, &iPrefValue) );

	if(iPrefValue == 1 && ( tc_strcmp( progObjType, NG5_LAUNCH_PRG_REVISION ) == 0 ) )
	{
		iFail=NG5_pouplate_product_launch(tProgramItem);
	}
	else
	{
		TC_write_syslog ("--->>>>> NG5_LAUNCH_PRG_REVISION IS NOT FOUND   >>>>>--- \n");
	}


	if (iPrefValue == 1 && ( tc_strcmp( progObjType, NG5_MASTER_PRG_REVISION ) == 0 ) )
	{

		std::string projectName("");

		NG5_ITK_CALL(AOM_ask_value_string ( tProgramItem, ATTR_ITEM_ID, &cpItemId ));
		NG5_ITK_CALL(AOM_ask_value_string ( tProgramItem, "object_name", &objName ));

		projectName.assign( cpItemId );
		projectName.append( " " );
		projectName.append( objName );

		//Code for removal of "." from project Name for Master Program Creation

		int iprojLen = projectName.length();
		int j = 0;

		for (int i = 0;  i < iprojLen; i++)
		{
			if (projectName[i] == '.')
			{
				continue;
			}
			else
			{
				projectName[j] = projectName[i];
				j++;
			}
		}

		projectName[j] = '\0';

		std::string slcl_prj_name("");

		//if Master Program being created is new then create project
		if(NULL != cpItemId)
		{
			if(tc_strlen(cpItemId) > 0)
			{
				//TC12 updated to QRY_find2.
				NG5_ITK_CALL(QRY_find2( query_name,&query_tag ));

				values[0]=cpItemId;

				NG5_ITK_CALL(QRY_execute ( query_tag,qry_entry_count,entries,values, &num_found,&tproject));

				if (num_found==0)
				{
					if ( projectName.length() < 32 )
					{
						slcl_prj_name = Ng5_validateProjectName(projectName);
						NG5_ITK_CALL(PROJ_create_project(cpItemId,slcl_prj_name.c_str(),slcl_prj_name.c_str(),&projectTag));
					}
					else
					{
						std::string slcl_prj_name_substr("");
						slcl_prj_name_substr = projectName.substr( 0, 30 );
						slcl_prj_name = Ng5_validateProjectName(slcl_prj_name_substr);
						NG5_ITK_CALL(PROJ_create_project(cpItemId,slcl_prj_name.c_str(),slcl_prj_name.c_str(),&projectTag));
					}
					iFail = associate_to_program(projectTag , tProgramItem );

					//Create BOMView for the program.
					tag_t tPrgBOMView = NULLTAG;
					tag_t tBVR = NULLTAG;
					tag_t window =NULLTAG;
					tag_t topLine =NULLTAG;
					tag_t *tBomViews = NULL;
					tag_t * tBomRevs = NULL;
					int iBomCount = 0;
					int iBomRevCount = 0;

					ITKCALL(ITEM_list_bom_views(tProgramItem, &iBomCount, &tBomViews));
					if(iBomCount == 0 )
					{
						NG5_ITK_CALL(AOM_refresh(tProgramItem,TRUE));
						ITKCALL(PS_create_bom_view(NULLTAG, NULL, NULL, tProgramItem, &tPrgBOMView));
						ITKCALL(AOM_save_without_extensions(tPrgBOMView));//TC12 Upgrade
						ITKCALL(AOM_save_without_extensions(tProgramItem));//TC12 Upgrade
						NG5_ITK_CALL(AOM_refresh(tProgramItem,FALSE));
						NG5_ITK_CALL(AOM_refresh(tPrgBOMView,FALSE));

						NG5_ITK_CALL(AOM_refresh(tlatestrev,TRUE));
						ITKCALL(PS_create_bvr(tPrgBOMView, NULL, NULL, false, tlatestrev,&tBVR));
						//TC12 disabled to compile the code, but it has to be fixed with proper API
						// We need to get the BOM line ojbect instead of BVR for new API
						//ITKCALL(PS_set_bvr_imprecise(tBVR));//TC12 Upgrade
						NG5_ITK_CALL(BOM_create_window(&window));
						NG5_ITK_CALL(BOM_set_window_top_line_bvr(window,tBVR,&topLine));
						NG5_ITK_CALL(BOM_line_set_precise(topLine,false));
						NG5_ITK_CALL(BOM_save_window(window));
						NG5_ITK_CALL(BOM_close_window(window));

						NG5_ITK_CALL(AOM_save_without_extensions(tBVR));//TC12 Upgrade
						NG5_ITK_CALL(AOM_save_without_extensions(tlatestrev));//TC12 Upgrade
						NG5_ITK_CALL(AOM_refresh(tlatestrev,FALSE));
						NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));

					}
					else
					{
						tPrgBOMView = tBomViews[iBomCount-1];
						ITEM_rev_list_bom_view_revs(tlatestrev, &iBomRevCount, &tBomRevs);
						if(iBomRevCount > 0)
						{
							tBVR = tBomRevs[iBomRevCount-1];
						}
					}

					if(projectTag != NULLTAG)
					{
						int iObjCount = 0;
						logical lIsAttached = false;
						tag_t *tAssignedObjects = NULL;
						ITKCALL(PROJ_ask_assigned_objects(cpItemId, &iObjCount, &tAssignedObjects));
						for(int iCount =  0 ; iCount < iObjCount ; iCount++)
						{
							if(tAssignedObjects[iCount] == tPrgBOMView)
							{
								lIsAttached = true;
								break;
							}
						}

						
						ITKCALL ( PROJ_assign_objects( 1, &projectTag , 1 , &tBVR));
						ITKCALL(AOM_save_without_extensions(tBVR));//TC12 Upgrade
						NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));
						ITKCALL ( Ng5_assignTeamAdmintoProject(projectTag));

					}
					iFail = Ng5_addStatus(REL_ENDITEMLIST, tlatestrev);		//add status for Program Rev A, End Item List


					//Add Status to BomView Revision also
					if (tBVR != NULLTAG)
					{
							iFail = Ng5_addStatus(REL_ENDITEMLIST, tBVR);
					}//////////

                   NG5_MEM_TCFREE (tBomViews);
                   NG5_MEM_TCFREE (tBomRevs);
				}

			}
		}

		NG5_MEM_TCFREE( cpItemId );
		NG5_MEM_TCFREE( objName );
	}


    if(( tc_strcmp( progObjType, NG5_MASTER_PRG_REVISION ) == 0 )||(( tc_strcmp( progObjType, NG5_LAUNCH_PRG_REVISION ) == 0) && (isNew == 0)))
    {
		logical bPLMXML_Export_Check_PrefValue =false;
		//read program export control preference value
    	NG5_ITK_CALL(PREF_ask_logical_value(NG5_PROGRAM_PLMXML_EXPORT_CHECK,0,&bPLMXML_Export_Check_PrefValue));
    		//Take decision whether to export or not
			if(bPLMXML_Export_Check_PrefValue)
    		{
				TC_write_syslog("\n--->>>>>PLMXML_Export_Check pref vlaue -> True, so exporting program");
    			iFail =  Ng5_CommonUtils::Ng5_programExport( tlatestrev );
    		}
			else
			{
				TC_write_syslog("\n--->>>>>PLMXML_Export_Check pref vlaue -> false, so program export aborted");
			}
    }


	NG5_MEM_TCFREE( sModel_YrVals );
	NG5_MEM_TCFREE( progObjType );
	NG5_MEM_TCFREE( sOEM_NameVals );
	NG5_MEM_TCFREE( sDC_Launchst_Rgn );
	NG5_MEM_TCFREE( sDC_Name );
	NG5_MEM_TCFREE( sDisp_OEM_NameVals );
	NG5_MEM_TCFREE( sMODEL_Code );
	NG5_MEM_TCFREE( sVehicle_Name );
	NG5_MEM_TCFREE( sProduct_LineVals );
	NG5_MEM_TCFREE( sKiss_Comment );
	NG5_MEM_TCFREE( sDC_Name_Same );
	NG5_MEM_TCFREE( sProd_AreaVals );
	NG5_MEM_TCFREE( item_id );
	NG5_MEM_TCFREE( sProgramConcatAttr );

	return iFail;
}



int associate_to_program(tag_t project , tag_t program)
{
	int iFail = ITK_ok;

	tag_t ProgToProjRelation           	= 	NULLTAG;
	tag_t ProgToProjRelationType       	= 	NULLTAG;
	tag_t tlatestrev     =   NULLTAG;
	NG5_ITK_CALL(GRM_find_relation_type(ProgToProj_Relation_Type, &ProgToProjRelationType));
	NG5_ITK_CALL(GRM_create_relation(program,project,ProgToProjRelationType,NULLTAG,&ProgToProjRelation));
	NG5_ITK_CALL(GRM_save_relation(ProgToProjRelation));

	/*
	NG5_ITK_CALL(ITEM_ask_latest_rev (program,&tlatestrev));
	tag_t  objects[2]={NULLTAG,NULLTAG};
	objects[0] = program;
	objects[1] = tlatestrev;
	if ( project != NULLTAG )
	{
		NG5_ITK_CALL ( PROJ_assign_objects( 1, &project , 2 , objects));
	}
	*/

	return iFail;
}


int Ng5_addStatus(char* cStatusName, tag_t tWorkspaceObject)
{

	int iFail = ITK_ok;
	tag_t tStatus = NULLTAG;

	NG5_ITK_CALL(AOM_refresh(tWorkspaceObject,TRUE));
	NG5_ITK_CALL(RELSTAT_create_release_status(cStatusName,&tStatus));
	NG5_ITK_CALL(RELSTAT_add_release_status (tStatus,1,&tWorkspaceObject,true));

	NG5_ITK_CALL(AOM_save_without_extensions(tWorkspaceObject));//TC12 Upgrade

	NG5_ITK_CALL(AOM_refresh(tWorkspaceObject,FALSE));

	return iFail;

}
/******************************************************************************************************************
*Function Name :Ng5_assignTeamAdmintoProject

*Description: Add the User To Project as Team Administrator
*Arguments  : Project Tag         
*Returns    : ITK_ok
			   
*Syed Suleman           12-Dec-2020                    Created
                                            
*******************************************************************************************************************/


int Ng5_assignTeamAdmintoProject(tag_t tProjectTag)
{
    int   iFail		        		= ITK_ok;
	tag_t 		tUserIdTag 			= NULLTAG ;
	tag_t*  	tMember				= NULL;
	tag_t* 		tAdminUsr			= NULL;
	tag_t* 		tPrivUsr			= NULL;
	tag_t*		tGrpMembers			= NULL;

	int iGrpMemberCnt=0;
	int iMemberCnt=0;
	int iAdminUsrCnt=0;
	int iPrivUsrCnt=0;
	
	NG5_ITK_CALL(SA_find_groupmember_by_rolename(TC_PROJ_ADMIN_ROLE, TC_PROJ_ADMIN_GROUP, TC_PROJ_ADMIN_USER, &iGrpMemberCnt,&tGrpMembers));
		
	NG5_ITK_CALL(PROJ_ask_team  ( tProjectTag,  &iMemberCnt,&tMember,&iAdminUsrCnt,&tAdminUsr,&iPrivUsrCnt,&tPrivUsr));
	NG5_ITK_CALL(SA_find_user2 (TC_PROJ_ADMIN_USER, &tUserIdTag));
	if(tUserIdTag!=NULLTAG && iGrpMemberCnt>0)
	{
	NG5_ITK_CALL(Ng5_add_user_to_project(tProjectTag,tGrpMembers[0],tUserIdTag,ADD_USER_AS_ADMIN,false,iMemberCnt,tMember,iAdminUsrCnt,tAdminUsr,iPrivUsrCnt,tPrivUsr ));
	}

	
	MEM_free(tPrivUsr);
	MEM_free(tMember);
	MEM_free(tAdminUsr);
	MEM_free(tPrivUsr);

    TC_write_syslog("\n *****************************End Of Assign SDT Team to Project Function********************** \n");
    return iFail;

}

/******************************************************************************************************************
*Function Name :NG5_pouplate_product_launch

*Description:   create a BVR in product launch
*Description:   Parameter	:	tag_t tProgramItem			    Product Launch tag
*Description:   Return		:	int(ifail value)				ITK_ok on success else corresponding error code

* Shivaji Parade          7th July 2023               Created

*******************************************************************************************************************/
int NG5_pouplate_product_launch(tag_t tProgramItem)
{
	TC_write_syslog ("--->>>>> Entering ng5_populate_product_Launch function >>>>>--- \n");

	int           iBomCount             = 0;
	int           iBomRevCount          = 0;
	int           iFail                 = ITK_ok;
	int           num_values            = 0;
	char**	      cpPrgmId              = NULL; //OF
	char*  	      cpPrjId               = NULL; //OF
	tag_t         tlatestrev            = NULLTAG;
	tag_t         tProgramItem1         = NULLTAG;
    tag_t         tProject              = NULLTAG;
	tag_t         tPrgBOMView           = NULLTAG;
	tag_t         tBVR                  = NULLTAG;
	tag_t         twindow               = NULLTAG;
	tag_t         topLine               = NULLTAG;
	tag_t*        tBomViews             = NULL;  //OF
	tag_t*        tBomRevs              = NULL;  //OF


	NG5_ITK_CALL(ITEM_ask_latest_rev (tProgramItem,&tlatestrev));


	iFail=AOM_ask_value_tag	(tProgramItem,PROGRAM,&tProgramItem1);

    if(tProgramItem1!=NULLTAG)
    {
    	ITKCALL(AOM_ask_displayable_values(tProgramItem1,ATTR_ITEM_ID,&num_values,&cpPrgmId));
 		ITKCALL(PROJ_find(cpPrgmId[0],&tProject));
 		ITKCALL(PROJ_ask_id2(tProject,&cpPrjId ));
    }
    iFail=(ITEM_list_bom_views(tProgramItem, &iBomCount, &tBomViews));
    if(iBomCount == 0 )
    {
    	NG5_ITK_CALL(AOM_refresh(tProgramItem,TRUE));
    	ITKCALL(PS_create_bom_view(NULLTAG, NULL, NULL, tProgramItem, &tPrgBOMView));
    	ITKCALL(AOM_save_without_extensions(tPrgBOMView));
    	ITKCALL(AOM_save_without_extensions(tProgramItem));
    	NG5_ITK_CALL(AOM_refresh(tProgramItem,FALSE));
    	NG5_ITK_CALL(AOM_refresh(tPrgBOMView,FALSE));
    	NG5_ITK_CALL(AOM_refresh(tlatestrev,TRUE));
    	ITKCALL(PS_create_bvr(tPrgBOMView, NULL, NULL, false, tlatestrev,&tBVR));
    	NG5_ITK_CALL(BOM_create_window(&twindow));
    	NG5_ITK_CALL(BOM_set_window_top_line_bvr(twindow,tBVR,&topLine));
    	NG5_ITK_CALL(BOM_line_set_precise(topLine,false));
    	NG5_ITK_CALL(BOM_save_window(twindow));
    	NG5_ITK_CALL(BOM_close_window(twindow));
    	NG5_ITK_CALL(AOM_save_without_extensions(tBVR));
    	NG5_ITK_CALL(AOM_save_without_extensions(tlatestrev));
    	NG5_ITK_CALL(AOM_refresh(tlatestrev,FALSE));
    	NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));
    }
    else
    {
    	tPrgBOMView = tBomViews[iBomCount-1];
    	ITEM_rev_list_all_bom_view_revs(tlatestrev, &iBomRevCount, &tBomRevs);
    	if(iBomRevCount > 0)
    	{
    		tBVR = tBomRevs[iBomRevCount-1];
    	}
    }
    if(tProject != NULLTAG)
    {
    	ITKCALL ( PROJ_assign_objects( 1, &tProject , 1 , &tBVR));
    	ITKCALL(AOM_save_without_extensions(tBVR));
    	NG5_ITK_CALL(AOM_refresh(tBVR,FALSE));
    }
    NG5_MEM_TCFREE(tBomViews);
    NG5_MEM_TCFREE(tBomRevs);
    NG5_MEM_TCFREE(cpPrjId);
    NG5_MEM_TCFREE(cpPrgmId);


    return iFail;
}

/*===========================================================================================================

	Function	:	Ng5_add_user_to_project

	Description	:	It add user in given groupmemeber and project as Team Administrator,Privileged or Non-privileged member.Please use PROJ_ask_team API to get inputs for this function
	Parameter	:	tag_t tProjTag( I )			    Project tag
	Parameter	:   tag_t tGrpMemberTag (I)         Group Members tag
	Parameter	:   tag_t tUserIdTag(I)            user tag
	Parameter	:   string strUserType(I)          user should be addd as Team Administrator
	Parameter	:    bool isForceAssign(I)          modify user for given user type (isForceAssign=true mean change User's priviledge based on strUserType)

													(isForceAssign=false mean change User's priviledge based on strUserType but do not demote privilege level 
													example1 if user is Team Administrator do not demote it to Privileged or Non-privileged member
													example2 if user is Privileged do not demote it to Non-privileged member)													
	Parameter	:   int iMemberCnt(I)              Member count
	Parameter	:  tag_t* tMember(I)               member tags 
	Parameter	:  int iAdminUsrCnt(I)             Admin user count
	Parameter	:  tag_t*tAdminUsr(I)             Admin user tags
	Parameter	:  int iPrivUsrCnt(I)            privileged user count
	Parameter	:  tag_t* tPrivUsr(I)            privileged user tags	
	Return		:	int(ifail value)				ITK_ok on success else corresponding error code
=============================================================================================================*/


int Ng5_add_user_to_project(tag_t tProjTag,tag_t tGrpMemberTag,tag_t tUserIdTag,string strUserType,bool isForceAssign,int iMemberCnt,tag_t* tMember,int iAdminUsrCnt,tag_t* tAdminUsr,int iPrivUsrCnt,tag_t* tPrivUsr )

{

	int ifail = ITK_ok;
	vector<tag_t> vcMember;
	vector<tag_t> vcAdminUser;
	vector<tag_t> vcPrivilegeUser;
	bool isReqUserExist=false;
	bool isAlreadyGrpMember=false;	
	
	for(int iLoop=0;iLoop<iMemberCnt;iLoop++)
	{
		vcMember.push_back(tMember[iLoop]);
	}

	for(int iLoop=0;iLoop<iAdminUsrCnt;iLoop++)
	{
		vcAdminUser.push_back(tAdminUsr[iLoop]);
	}
	
	for(int iLoop=0;iLoop<iPrivUsrCnt;iLoop++)
	{
		vcPrivilegeUser.push_back(tPrivUsr[iLoop]);
	}

	// GroupMember is not found in project group member
	if(std::find(vcMember.begin(),vcMember.end(),tGrpMemberTag)==vcMember.end())
	{
		vcMember.push_back(tGrpMemberTag);
	}

	else
	{
		isAlreadyGrpMember=true;
	}
	
	if(tc_strcasecmp(strUserType.c_str(),ADD_USER_AS_ADMIN)==0)
	{
		// user is not  Team Administrator
		if(find(vcAdminUser.begin(),vcAdminUser.end(),tUserIdTag)==vcAdminUser.end())
		{
			vcAdminUser.push_back(tUserIdTag);
			// user is Privileged
			if(find(vcPrivilegeUser.begin(),vcPrivilegeUser.end(),tUserIdTag)!=vcPrivilegeUser.end())
			{
				// removing user from privileged user vector
				vcPrivilegeUser.erase(remove(vcPrivilegeUser.begin(),vcPrivilegeUser.end(),tUserIdTag),vcPrivilegeUser.end());
			}
		}
		else
		{
			isReqUserExist=true;
		}
	}
	
	if(isAlreadyGrpMember==false || isReqUserExist==false)
	{	
		if (ifail == ITK_ok )
		{
			ifail=AOM_refresh( tProjTag, 1 );
			if (ifail == ITK_ok)
			{
				ifail=PROJ_assign_team_members (tProjTag,vcMember.size(),vcMember.data(),vcAdminUser.size(),vcAdminUser.data(),vcPrivilegeUser.size(),vcPrivilegeUser.data());
				if (ifail == ITK_ok)
				{
					ifail=AOM_save_without_extensions(tProjTag);//TC12 Upgrade

					if (ifail == ITK_ok)
					{
						ifail=AOM_refresh( tProjTag, 0 );
					}
				}
			}
		}
	} 		
	return ifail;
}
