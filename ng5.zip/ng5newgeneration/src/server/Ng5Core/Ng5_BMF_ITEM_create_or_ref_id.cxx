//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_BMF_ITEM_create_or_ref_id .
 *   covers user stories (US#262216,US#262217,US#262218,US#262220)
 *
 *   Sahida Khatun	  		Initial Creation			        July 2022 
 *   Padma Cherukumilli     Setting ng5_create_ipf attribute    Aug 2022
 *
 *
 */
#include <Ng5Core/Ng5_BMF_ITEM_create_or_ref_id.hxx>
#include <Ng5Core/Ng5_linkEBOMToPlantMBOM.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <Ng5Core/Ng5_absItemRevisionCreatePre.hxx>

using namespace std;
using namespace ng5newgeneration;




static char *cpTimeStamp;



/*
* Function Name :Ng5_BMF_ITEM_create_or_ref_id
  Description   : Function to build the create input while 
  cloning from Manufacturing Part to Engineering Part
  
*/
int Ng5_BMF_ITEM_create_or_ref_id( METHOD_message_t * msg, va_list largs )
{
 
	int ifail 						= ITK_ok;
	int iEBOMLevel 					= 0;
	int nForms                      = 0;

	logical lHasChildren 			= false;
	logical lIsEBOMSkip 			= false;

	char  *cpEbomItemId     	 	= NULL; //OF
	char  *cpMfgItemId     		 	= NULL; //OF
	char  *cpObjStr				 	= NULL;  //OF
	char  *cObjDesc                 = NULL; //OF
	char  *makeBuy                  = NULL; //OF
	char  *cpObjStr1			 	= NULL; //OF
	char  *cpObjName			 	= NULL; //OF
	char  *cpEBOMNodeType			= NULL; //OF
	char  *cpEbomItemRevID			= NULL; //OF
	char  *cpPlantcode  			= NULL; //OF
	char  *cpPlantMfgStr            = NULL;
	char  *cpRootMBOMID             = NULL;
	char  *cpRevID                  = NULL;
	char  *cpNewSuffix              = NULL;
    char  *cpUserDataStr            = NULL;
    char  *cpOEMStr                 = NULL;
    char  *cpCustomerPartNo         = NULL;//MEM_Free

	char*  cpMBOM                   = NULL;
	char* cpSourceOEM               = NULL;
	std::string  bCreateIPF("");

	tag_t tEbomItem 				= NULLTAG;
	tag_t tMfgItem 					= NULLTAG;
	tag_t tEbomItemRev 				= NULLTAG;
	tag_t tMfgItemRev 				= NULLTAG;
	tag_t tMfgItemType 			 	= NULLTAG;
	tag_t tMfgItemRevType 		 	= NULLTAG;
	tag_t tMfgItemCreateInput 	 	= NULLTAG;
	tag_t tMfgItemRevCreateInput 	= NULLTAG;
	tag_t tEBOMNodeType 			= NULLTAG;
	tag_t tEBOMNodeCreateInput 	 	= NULLTAG;
	tag_t tRev2CopyFrom           = NULLTAG; //Tag of latest released or Latest  Major WIP
	tag_t* ttForms                 = NULLTAG;
	tag_t tRelICEtype             = NULLTAG;
	tag_t tSourceMBOM             = NULLTAG;
	tag_t tRawMaterial            = NULLTAG;

	std::map<char*,char*> mapOldNewSuffix;


	TC_write_syslog("\n >>>>>  Entering Ng5_BMF_ITEM_create_or_ref_id\n");

    tag_t tEBOMNode 				= va_arg(largs, tag_t); // EBOM
    tag_t tEBOMLineNode 			= va_arg(largs, tag_t); // EBOMLin     
    char *cpUserData 				= va_arg(largs, char*);
    int	*num_mfk_keys 				= va_arg(largs, int*);
    char*** mfk_keys 				= va_arg(largs, char***);
    char*** mfk_values 				= va_arg(largs, char***);
    tag_t* tCreateItemType 			= va_arg(largs, tag_t*);
    tag_t* tCreateInput 			= va_arg(largs, tag_t*);
    va_end( largs );

    //GetLatest Released Revision tag / latest WIP major revsion
    //Ng5_isRawMaterialExists(tEBOMNode);
    ITKCALL(ITEM_ask_type2(tEBOMNode ,&cpEBOMNodeType));
    TC_write_syslog("\n >>>>>  cpEBOMNodeType %s\n",cpEBOMNodeType);
    if(tc_strcmp(cpEBOMNodeType,RAW_MATERIAL)!=0)
    {
    	tRawMaterial = Ng5_isRawMaterialExists(tEBOMNode);

    }
    if(tc_strcmp(cpEBOMNodeType,PKG_PART)!=0)
    {
        	tRawMaterial = Ng5_isPackagingPartExists(tEBOMNode);

    }
    if(tRawMaterial!= NULLTAG)
    {
    	ITKCALL(Ng5_getRev2CopyFrom(tRawMaterial,&tRev2CopyFrom));
    }
    else
    {
	  ITKCALL(Ng5_getRev2CopyFrom(tEBOMNode,&tRev2CopyFrom));
    }
	//cpSourceType = Ng5_getSourType(tRev2CopyFrom);
	ITKCALL(AOM_ask_value_string (tRev2CopyFrom,ATTR_OBJECT_NAME, &cpObjStr));
	ITKCALL(AOM_ask_value_string (tRev2CopyFrom,ATTR_OBJECT_DESC, &cObjDesc));
	ITKCALL(AOM_ask_value_string (tRev2CopyFrom,"ng5_make_buy", &makeBuy));
	
	
    ITKCALL(AOM_ask_value_logical(tEBOMLineNode, BOMLINEHASCHILD, &lHasChildren ));
    ITKCALL(AOM_ask_value_int(tEBOMLineNode, BOMLINELEVEL0, &iEBOMLevel ));
    ITKCALL(ITEM_ask_type2(tEBOMNode ,&cpEBOMNodeType));
    TC_write_syslog("\n >>>>>  cpEBOMNodeType %s\n",cpEBOMNodeType);
    ITKCALL (GRM_find_relation_type(REL_ICEPARTFORM, &tRelICEtype));
    if(tEBOMNode != NULLTAG)
    {
    	ITKCALL (GRM_list_secondary_objects_only (tEBOMNode, tRelICEtype, &nForms, &ttForms));
    	TC_write_syslog("\n Ng5_BMF_ITEM_create_or_ref_id 1: Number of ICE Part Forms %d\n", nForms);
    }
    else
    {
    	TC_write_syslog("\n tEBOMNode is null 1\n");
    }
	
    if(Ng5_validType2Clone(cpEBOMNodeType))
    {
    	cpUserDataStr = (char *)MEM_alloc (((int)tc_strlen(cpUserData)+1)* sizeof(char) );
		tc_strcpy(cpUserDataStr,cpUserData);
		if (tc_strstr(cpUserDataStr,TILT) != NULL)
		{
			char *cpTempPlantcode = NULL;
			char  *cpTempTimeStamp    = NULL;

			cpTempPlantcode  = tc_strtok ( cpUserDataStr , TILT );
            cpPlantcode = (char *)MEM_alloc (((int)tc_strlen(cpTempPlantcode)+1)* sizeof(char) );
            tc_strcpy(cpPlantcode, cpTempPlantcode);
            cpTempPlantcode = tc_strtok(NULL, TILT);

            if(tc_strstr(cpTempPlantcode,PIPE)== NULL)
            {
               if(tc_strstr(cpTempPlantcode,BACKSLASH)==0)
               {
            	cpTimeStamp =(char *)MEM_alloc (((int)tc_strlen(cpTempPlantcode)+1)* sizeof(char) );
            	tc_strcpy (cpTimeStamp, cpTempPlantcode);
			    TC_write_syslog("\n >>>>> TimeStamp: %s\n", cpTimeStamp);
               }
               else
               {
            	   cpTempTimeStamp  = tc_strtok(cpTempPlantcode,BACKSLASH);
            	   cpTimeStamp = (char *)MEM_alloc (((int)tc_strlen(cpTempTimeStamp)+1)* sizeof(char) );
            	   tc_strcpy (cpTimeStamp, cpTempPlantcode);
            	   cpTempTimeStamp  = tc_strtok(NULL,BACKSLASH);
            	   cpOEMStr = (char *)MEM_alloc (((int)tc_strlen(cpTempTimeStamp)+1)* sizeof(char) );
            	   tc_strcpy(cpOEMStr,cpTempTimeStamp);
               }
            }

            else
            {
            	cpTempTimeStamp  = tc_strtok(cpTempPlantcode,PIPE);
            	cpTimeStamp = (char *)MEM_alloc (((int)tc_strlen(cpTempTimeStamp)+1)* sizeof(char) );
            	tc_strcpy (cpTimeStamp, cpTempPlantcode);

                cpTempTimeStamp  = tc_strtok(NULL,PIPE);
                cpPlantMfgStr = (char *)MEM_alloc (((int)tc_strlen(cpTempTimeStamp)+1)* sizeof(char) );
                tc_strcpy(cpPlantMfgStr,cpTempTimeStamp);
                TC_write_syslog("\n >>>>> cpPlantMfgStr: %s\n", cpPlantMfgStr);
                int iSuffixCount =0;
                int iItemCount   = 0;
                char* oldSuffix = NULL;
                char* newSuffix = NULL;
                char*  oldNewSuffixStr = NULL;
                tag_t*  tSourceItem    = NULLTAG;
                tag_t   tSourceRev    = NULLTAG;
                tag_t*  tpColorMapping = NULLTAG;

                int      iRow         = 0;

                ITK__convert_uid_to_tag(cpPlantMfgStr,&tSourceRev);
				ITKCALL(AOM_ask_table_rows(tSourceRev,COLOR_MAPPING_TABLE,&iRow,&tpColorMapping));
                TC_write_syslog("\n >>>>> SRow Count : %d\n", iRow);
				for(int iRx= 0;iRx < iRow ; iRx++)
				{
						  AOM_ask_value_string(tpColorMapping[iRx],NEW_SUFFIX,&newSuffix);
						  AOM_ask_value_string(tpColorMapping[iRx],OLD_SUFFIX,&oldSuffix);
						  mapOldNewSuffix.insert(pair<char*,char*>(oldSuffix,newSuffix));


				}
           }
		}

		else
		{
            cpPlantcode = (char *)MEM_alloc (((int)tc_strlen(cpUserDataStr)+1)* sizeof(char) );
			tc_strcpy(cpPlantcode, cpUserDataStr);


		}
		if (lHasChildren == true )
    	{


			ITKCALL(ITEM_ask_id2(tEBOMNode, &cpEbomItemId));
    		//TC_write_syslog("\n Ng5_BMF_ITEM_create_or_ref_id 1: cpEbomItemId %s\n", cpEbomItemId);

			TC_write_syslog("\n >>>>>  Has Children");
			ifail = TCTYPE_find_type(MFGPART, NULL, &tMfgItemType);
		    ifail = TCTYPE_construct_create_input(tMfgItemType, &tMfgItemCreateInput);
	    	*tCreateItemType = tMfgItemType;
			TC_write_syslog("\n >>>>>  Ng5_BMF_ITEM_create_or_ref_id 539 - cpEBOMNodeType :  MFGPART %s : %s\n",cpEBOMNodeType,MFGPART);
			if(tc_strcmp(cpEBOMNodeType,MFGPART)!=0)
		    {

				 if(tc_strlen(cpOEMStr)>0)
				 {

					 Ng5_getMfgCustomPartNum(tRev2CopyFrom, cpOEMStr,&cpCustomerPartNo);
					
				 }
				 TC_write_syslog("\n Ng5_BMF_ITEM_create_or_ref_id 241: ORIGINALID %s\n", cpEbomItemId);
				 ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ORIGINALID, cpEbomItemId));
				 if(tc_strlen(cpCustomerPartNo)>0)
				 {
					 cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpCustomerPartNo))+1);
					 tc_strcpy(cpMfgItemId, MHYPHEN);
				     tc_strcat(cpMfgItemId, cpPlantcode);
				     tc_strcat(cpMfgItemId, HYPHEN);
				     tc_strcat(cpMfgItemId, cpCustomerPartNo);

				 }
				 else
				 {
			        cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpEbomItemId))+1);
			        tc_strcpy(cpMfgItemId, MHYPHEN);
			        tc_strcat(cpMfgItemId, cpPlantcode);
			        tc_strcat(cpMfgItemId, HYPHEN);
			        tc_strcat(cpMfgItemId, cpEbomItemId);
				 }
			}
			else
			{
			      char* cpOriginalID     = NULL; //Mem_Free
			      char* cpSuffix         = NULL; //Mem Free
			      char* cpSourcePlantID  = NULL;
				   char* cpSourceItemID  = NULL;
			     

			      //logical isSuffixChanged = false;
			      logical   isOldSuffixMatched = false;
				  //Set Source MBOM for childline
				   tSourceMBOM =tRev2CopyFrom ;
				  
			      map<char*, char*>::iterator itMap; //object for forloop
			      ITKCALL(AOM_ask_value_string(tEBOMNode,ORIGINALID,&cpOriginalID));
			      ITKCALL(AOM_ask_value_string(tRev2CopyFrom,SUFFIX,&cpSuffix));
			      ITKCALL(AOM_ask_value_string(tRev2CopyFrom,PLANTS,&cpSourcePlantID));
			      ITKCALL(AOM_ask_value_string(tRev2CopyFrom,CUSTOMER,&cpSourceOEM));
				  ITKCALL(AOM_ask_value_string(tRev2CopyFrom,ATTR_ITEM_ID,&cpSourceItemID));
				  
	
                  if(tc_strncasecmp(cpOriginalID,MHYPHEN,2)!=0)
				  {
				      TC_write_syslog("\n Ng5_BMF_ITEM_create_or_ref_id 281: cpOriginalID %s\n", cpOriginalID);
					  ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ORIGINALID, cpOriginalID));
				  }else
				  {
					 std::string strOrginalId ="";
					 strOrginalId.assign(cpOriginalID);
					 std::istringstream is( strOrginalId );
					 size_t count = 0;
					 std::string line;
					 while ( std::getline( is, line, '-' ) ) ++count;
					 std::size_t pos =  strOrginalId.find_first_of('-');
					 if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
					 pos =  strOrginalId.find_first_of('-');
					 if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
					if(count>3 && cpSuffix != NULL && tc_strlen(cpSuffix)>0)
					 {
						
						pos = strOrginalId.find_last_of(cpSuffix);
						if(pos != std::string::npos) strOrginalId= strOrginalId.replace(pos-tc_strlen(cpSuffix),(strOrginalId.length()), "");
					 }
					 TC_write_syslog("\n Ng5_BMF_ITEM_create_or_ref_id 301: cpOriginalID %s\n", strOrginalId.c_str());
					 ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ORIGINALID, strOrginalId.c_str()));
					
				  }
			      
			      for(itMap=mapOldNewSuffix.begin();itMap!=mapOldNewSuffix.end();itMap++ )
			      {

			      	if(tc_strcmp(itMap->first,cpSourceItemID)==0)
			        {
						int iValueLength = tc_strlen(itMap->second);
						cpNewSuffix = (char*)MEM_alloc(sizeof(char)*iValueLength+1);
						tc_strcpy(cpNewSuffix,itMap->second);
						TC_write_syslog("\n >>>>>  cpNewSuffix :%s\n",cpNewSuffix);
						isOldSuffixMatched =true ;
						break;

			       }

			      }
                  if(isOldSuffixMatched)
                  {
					   //cpNewSuffix = (char*)MEM_alloc(sizeof(char)*tc_strlen(cpSuffix)+1);
					   //tc_strcpy(cpNewSuffix,cpSuffix);
					   //New Suffix
					     if(tc_strlen(cpSourceOEM)>0)
                    	  {


                              tag_t *ptSecObjs  = NULLTAG;
                    		  tag_t tRelTypeTag = NULLTAG;
                    		  int    iRelCount  = 0;

                    		  ITKCALL(GRM_find_relation_type(HASENGPART2MFGPARREV,&tRelTypeTag));
                    		  ITKCALL(GRM_list_secondary_objects_only(tRev2CopyFrom,tRelTypeTag,&iRelCount,&ptSecObjs ));
                    		  for(int iObjx =0; iObjx<iRelCount; iObjx++)
                    		  {

                                Ng5_getMfgCustomPartNum(ptSecObjs[iObjx], cpSourceOEM,&cpCustomerPartNo);
                    		  }
                    		  NG5_MEM_TCFREE(ptSecObjs);

                    	  }
						
						
					 if(tc_strlen(cpCustomerPartNo)>0)
                     {
                          //Custmer Part with New Suffix
						  cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpCustomerPartNo)+tc_strlen("-")+tc_strlen(cpNewSuffix))+1);
                    	   tc_strcpy(cpMfgItemId, MHYPHEN);
                    	   tc_strcat(cpMfgItemId, cpPlantcode);
                    	   tc_strcat(cpMfgItemId, HYPHEN);
                    	   tc_strcat(cpMfgItemId, cpCustomerPartNo);
                     }
					 else
					 {
						//  New Suffix with Eng ID
					   cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpOriginalID)+tc_strlen("-")+tc_strlen(cpNewSuffix))+1);
					   tc_strcpy(cpMfgItemId, MHYPHEN);
					   tc_strcat(cpMfgItemId, cpPlantcode);
					   tc_strcat(cpMfgItemId, HYPHEN);
					   tc_strcat(cpMfgItemId, cpOriginalID);
					 }
					 if(tc_strlen(cpNewSuffix)>0)
					 {
						tc_strcat(cpMfgItemId, HYPHEN);
						tc_strcat(cpMfgItemId, cpNewSuffix);
					 }
                  }
                  else
                  {
                      if(tc_strcmp(cpPlantcode,cpSourcePlantID)!=0)
                      {
                    	  if(tc_strlen(cpSourceOEM)>0)
                    	  {


                              tag_t *ptSecObjs  = NULLTAG;
                    		  tag_t tRelTypeTag = NULLTAG;
                    		  int    iRelCount  = 0;

                    		  ITKCALL(GRM_find_relation_type(HASENGPART2MFGPARREV,&tRelTypeTag));
                    		  ITKCALL(GRM_list_secondary_objects_only(tRev2CopyFrom,tRelTypeTag,&iRelCount,&ptSecObjs ));
                    		  for(int iObjx =0; iObjx<iRelCount; iObjx++)
                    		  {

                                Ng5_getMfgCustomPartNum(ptSecObjs[iObjx], cpSourceOEM,&cpCustomerPartNo);
                    		  }
                    		  NG5_MEM_TCFREE(ptSecObjs);

                    	  }

                    	  if(tc_strlen(cpCustomerPartNo)>0)
                    	  {
                    		  cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpCustomerPartNo)+tc_strlen("-")+tc_strlen(cpSuffix))+1);
                    		  tc_strcpy(cpMfgItemId, MHYPHEN);
                    		  tc_strcat(cpMfgItemId, cpPlantcode);
                    		  tc_strcat(cpMfgItemId, HYPHEN);
                    		  tc_strcat(cpMfgItemId, cpCustomerPartNo);
                    	  }
                    	  else
                    	  {
                    	      cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpOriginalID)+tc_strlen("-")+tc_strlen(cpSuffix))+1);
                    	      tc_strcpy(cpMfgItemId, MHYPHEN);
                    	      tc_strcat(cpMfgItemId, cpPlantcode);
                    	      tc_strcat(cpMfgItemId, HYPHEN);
                    	      tc_strcat(cpMfgItemId, cpOriginalID);
                    	  }
                    	  cpNewSuffix = (char*)MEM_alloc(sizeof(char)*tc_strlen(cpSuffix)+1);
                    	  tc_strcpy(cpNewSuffix,cpSuffix);
                    	  if(tc_strlen(cpNewSuffix)>0)
                          {
                    	        tc_strcat(cpMfgItemId, HYPHEN);
                    	        tc_strcat(cpMfgItemId, cpNewSuffix);
                          }
                      }
                      else
                      {
						  cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpEbomItemId))+1);
						  tc_strcpy(cpMfgItemId,cpEbomItemId);
                      }
                  }


                	NG5_MEM_TCFREE(cpSuffix);
                	NG5_MEM_TCFREE(cpOriginalID);
                	NG5_MEM_TCFREE(cpSourcePlantID);


			}
			TC_write_syslog("\n >>>>> MFG Item ID: %s\n", cpMfgItemId);

			ifail = Ng5_find_item(cpMfgItemId,MFGPART,&tMfgItem);
			TC_write_syslog("\n >>>>> tMfgItem: %d\n", tMfgItem);

			if (tMfgItem != NULLTAG)
			{
				
				TC_write_syslog("\n >>>>> iEBOMLevel: %d\n", iEBOMLevel);
				if (iEBOMLevel > 1)
				{
					ifail = Ng5_check_skip_ebom_node( tEBOMLineNode,cpOEMStr,cpPlantcode,&lIsEBOMSkip);
					if (lIsEBOMSkip == false)
					{
						TC_write_syslog("\n >>>>> Existing Mfg Node to be Linked =%s", cpMfgItemId);
						ifail = AOM_set_value_string(tMfgItemCreateInput, ATTR_ITEM_ID, cpMfgItemId);
						*tCreateInput = tMfgItemCreateInput;
					}
					else
					{
						TC_write_syslog("\n >>>>> Eng node (Subassemblies) to be skipped =%s", cpMfgItemId);

						ifail = Ng5_find_item(cpMfgItemId,MFGPART,&tMfgItem);
						*tCreateInput = NULLTAG;



					}
				}
				else
				{
					// First Level subassembly node to be copied
					ifail = AOM_set_value_string(tMfgItemCreateInput, ATTR_ITEM_ID, cpMfgItemId);
					*tCreateInput = tMfgItemCreateInput;

				}
			}
			else
			{

				TC_write_syslog("\n >>>>> 214 New Manufacturing Node = %s\n", cpMfgItemId);

				ITKCALL(TCTYPE_find_type(MFGPARTREV, NULL , &tMfgItemRevType));
				ITKCALL(TCTYPE_construct_create_input(tMfgItemRevType, &tMfgItemRevCreateInput));

				ITKCALL(AOM_ask_value_string(tEBOMLineNode, BOMLINEREVID,&cpEbomItemRevID ));
				if(tSourceMBOM !=NULLTAG)
				{
					ITKCALL(AOM_set_value_tag(tMfgItemRevCreateInput, SOURCEMBOM, tSourceMBOM));
					if(tc_strlen(cpSourceOEM)>0)
					{
						ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, RQRDCUSTPARTNO, YES));
						ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, ATTR_CUST_NAME, cpSourceOEM));
						
					}
				}

				ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, ATTR_OBJECT_NAME, cpObjStr));
				ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, PLANTS, cpPlantcode));
				ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, SUFFIX, cpNewSuffix));
				ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, MFGPARTTYPE, SEMIFINISHED));
				ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput,"ng5_make_buy", makeBuy));
				TC_write_syslog("\n >>>>> 214A cpCustomerPartNo , cpOEMStr = %s\n", cpCustomerPartNo, cpOEMStr);
				if(cpCustomerPartNo != NULL && cpOEMStr != NULL)
				{
					ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, RQRDCUSTPARTNO, YES));
					ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, ATTR_CUST_NAME, cpOEMStr));
				}

				ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ATTR_ITEM_ID, cpMfgItemId));
				ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ATTR_OBJECT_NAME, cpObjStr));


				ITKCALL(AOM_set_value_tag(tMfgItemCreateInput,REVISION, tMfgItemRevCreateInput));
				if (iEBOMLevel > 1)
				{
					ifail = Ng5_check_skip_ebom_node( tEBOMLineNode,cpOEMStr,cpPlantcode,&lIsEBOMSkip);
					if (lIsEBOMSkip == false)
					{
						TC_write_syslog("\n >>>>> Existing Manufacturing Node To be linked =%s", cpMfgItemId);
						ifail = AOM_set_value_string(tMfgItemCreateInput, ATTR_ITEM_ID, cpMfgItemId);
						*tCreateInput = tMfgItemCreateInput;
					}
					else
					{
						
					   *tCreateInput = NULLTAG;

					}
				}
				else
				{
					*tCreateInput = tMfgItemCreateInput;
				}
			}

			return ITK_ok;

    	
    	}
    	else
    	{

      		ITKCALL(ITEM_ask_id2(tEBOMNode, &cpEbomItemId));
      		TC_write_syslog("\n >>>>>  EBOM Node Without Children - COMPONENT:%s\n",cpEbomItemId);
      		ifail = TCTYPE_find_type(MFGPART, NULL, &tMfgItemType);
      		ifail = TCTYPE_construct_create_input(tMfgItemType, &tMfgItemCreateInput);
      		 *tCreateItemType = tMfgItemType;
      		TC_write_syslog("\n >>>>>  USer data - :%s\n",cpUserData);
			 TC_write_syslog("\n >>>>>  Ng5_BMF_ITEM_create_or_ref_id 539 - cpEBOMNodeType :  MFGPART %s : %s\n",cpEBOMNodeType,MFGPART);
      		 if(tc_strcmp(cpEBOMNodeType,MFGPART)!=0)
      		 {


      	        if(tc_strlen(cpOEMStr)>0)
      		    {

      				Ng5_getMfgCustomPartNum(tRev2CopyFrom, cpOEMStr,&cpCustomerPartNo);


      		    }
				TC_write_syslog("\n >>>>>  Ng5_BMF_ITEM_create_or_ref_id 550 - ORIGINALID : %s\n",cpEbomItemId);
      		    ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ORIGINALID, cpEbomItemId));
      		    if(tc_strlen(cpCustomerPartNo)>0)
      			{
					cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpCustomerPartNo))+1);
					tc_strcpy(cpMfgItemId, MHYPHEN);
					tc_strcat(cpMfgItemId, cpPlantcode);
					tc_strcat(cpMfgItemId, HYPHEN);
					tc_strcat(cpMfgItemId, cpCustomerPartNo);

      			}
      			else
      	        {
				   cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpEbomItemId))+1);
				   tc_strcpy(cpMfgItemId, MHYPHEN);
				   tc_strcat(cpMfgItemId, cpPlantcode);
				   tc_strcat(cpMfgItemId, HYPHEN);
				   tc_strcat(cpMfgItemId, cpEbomItemId);
      		   }

      		 }
      		else
      	    {
			  char* cpOriginalID     = NULL; //Mem_Free
			  char* cpSuffix         = NULL; //Mem Free
			  char* cpSourcePlantID  = NULL;
			  char* cpSourceItemID   = NULL;
			  //char* cpSourceOEM      = NULL;

			  //logical isSuffixChanged = false;
			  //Set Source MBOM for childline
				tSourceMBOM =tRev2CopyFrom ;
			  logical   isOldSuffixMatched = false;
			  map<char*, char*>::iterator itMap; //object for forloop
			  ITKCALL(AOM_ask_value_string(tEBOMNode,ORIGINALID,&cpOriginalID));
			  ITKCALL(AOM_ask_value_string(tRev2CopyFrom,SUFFIX,&cpSuffix));
			  ITKCALL(AOM_ask_value_string(tRev2CopyFrom,PLANTS,&cpSourcePlantID));
			  ITKCALL(AOM_ask_value_string(tRev2CopyFrom,CUSTOMER,&cpSourceOEM));
			  ITKCALL(AOM_ask_value_string(tRev2CopyFrom,ATTR_ITEM_ID,&cpSourceItemID));
			  if(tc_strncasecmp(cpOriginalID,MHYPHEN,2)!=0)
			  {
			      TC_write_syslog("\n Ng5_BMF_ITEM_create_or_ref_id 587: cpOriginalID %s\n", cpOriginalID);
				  ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ORIGINALID, cpOriginalID));
			  }else
			  {
				 std::string strOrginalId ="";
				 strOrginalId.assign(cpOriginalID);
				 std::istringstream is( strOrginalId );
				 size_t count = 0;
				 std::string line;
				 while ( std::getline( is, line, '-' ) ) ++count;
				 std::size_t pos =  strOrginalId.find_first_of('-');
				 if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
				 pos =  strOrginalId.find_first_of('-');
				 if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
				 if(count>3 && cpSuffix != NULL && tc_strlen(cpSuffix)>0)
				 {
					
					pos = strOrginalId.find_last_of(cpSuffix);
					if(pos != std::string::npos) strOrginalId= strOrginalId.replace(pos-tc_strlen(cpSuffix),(strOrginalId.length()), "");
				 }
				 TC_write_syslog("\n Ng5_BMF_ITEM_create_or_ref_id 607: cpOriginalID %s\n",  strOrginalId.c_str());
				 ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ORIGINALID, strOrginalId.c_str()));
				
			  }
			
			  for(itMap=mapOldNewSuffix.begin();itMap!=mapOldNewSuffix.end();itMap++ )
			  {

				if(tc_strcmp(itMap->first,cpSourceItemID)==0)
				{
					int iValueLength = tc_strlen(itMap->second);
					cpNewSuffix = (char*)MEM_alloc(sizeof(char)*iValueLength+1);
					tc_strcpy(cpNewSuffix,itMap->second);
					TC_write_syslog("\n >>>>>  cpNewSuffix :%s\n",cpNewSuffix);
					if(tc_strcmp(cpSuffix,cpNewSuffix)!=0)
					{
					 isOldSuffixMatched =true ;
					break;
					}
				 }

			}
			if(isOldSuffixMatched)
			{
				 //cpNewSuffix = (char*)MEM_alloc(sizeof(char)*tc_strlen(cpSuffix)+1);
				 
				 //tc_strcpy(cpNewSuffix,cpSuffix);
				 
				  if(tc_strlen(cpSourceOEM)>0)
                    {


                              tag_t *ptSecObjs  = NULLTAG;
                    		  tag_t tRelTypeTag = NULLTAG;
                    		  int    iRelCount  = 0;

                    		  ITKCALL(GRM_find_relation_type(HASENGPART2MFGPARREV,&tRelTypeTag));
                    		  ITKCALL(GRM_list_secondary_objects_only(tRev2CopyFrom,tRelTypeTag,&iRelCount,&ptSecObjs ));
                    		  for(int iObjx =0; iObjx<iRelCount; iObjx++)
                    		  {

                                Ng5_getMfgCustomPartNum(ptSecObjs[iObjx], cpSourceOEM,&cpCustomerPartNo);
                    		  }
                    		  NG5_MEM_TCFREE(ptSecObjs);

                     }
					
					 if(tc_strlen(cpCustomerPartNo)>0)
                     {
                          //Custmer Part with New Suffix
						  cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpCustomerPartNo)+tc_strlen("-")+tc_strlen(cpNewSuffix))+1);
                    	   tc_strcpy(cpMfgItemId, MHYPHEN);
                    	   tc_strcat(cpMfgItemId, cpPlantcode);
                    	   tc_strcat(cpMfgItemId, HYPHEN);
                    	   tc_strcat(cpMfgItemId, cpCustomerPartNo);
                     }
					 else
					 {
						//  New Suffix with Eng ID
					   cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpOriginalID)+tc_strlen("-")+tc_strlen(cpNewSuffix))+1);
					   tc_strcpy(cpMfgItemId, MHYPHEN);
					   tc_strcat(cpMfgItemId, cpPlantcode);
					   tc_strcat(cpMfgItemId, HYPHEN);
					   tc_strcat(cpMfgItemId, cpOriginalID);
					 }
				if(tc_strlen(cpNewSuffix)>0)
				{
							tc_strcat(cpMfgItemId, HYPHEN);
							tc_strcat(cpMfgItemId, cpNewSuffix);
				}
			}
      		else
      		{
				if(tc_strcmp(cpPlantcode,cpSourcePlantID)!=0)
      			{
					if(tc_strlen(cpSourceOEM)>0)
      				{


						 tag_t *ptSecObjs  = NULLTAG;
						 tag_t tRelTypeTag = NULLTAG;
						 int    iRelCount  = 0;

						 ITKCALL(GRM_find_relation_type(HASENGPART2MFGPARREV,&tRelTypeTag));
						 ITKCALL(GRM_list_secondary_objects_only(tRev2CopyFrom,tRelTypeTag,&iRelCount,&ptSecObjs ));
						 for(int iObjx =0; iObjx<iRelCount; iObjx++)
						  {

							 Ng5_getMfgCustomPartNum(ptSecObjs[iObjx], cpSourceOEM,&cpCustomerPartNo);
						   }
						   NG5_MEM_TCFREE(ptSecObjs);

					}
					if(tc_strlen(cpCustomerPartNo)>0)
					{

						 cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpCustomerPartNo)+tc_strlen("-")+tc_strlen(cpSuffix))+1);
						 tc_strcpy(cpMfgItemId, MHYPHEN);
						 tc_strcat(cpMfgItemId, cpPlantcode);
						 tc_strcat(cpMfgItemId, HYPHEN);
						 tc_strcat(cpMfgItemId, cpCustomerPartNo);
				   }
				   else
				   {
						 cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpOriginalID)+tc_strlen("-")+tc_strlen(cpSuffix))+1);
						 tc_strcpy(cpMfgItemId, MHYPHEN);
						 tc_strcat(cpMfgItemId, cpPlantcode);
						 tc_strcat(cpMfgItemId, HYPHEN);
						 tc_strcat(cpMfgItemId, cpOriginalID);
				   }

				   if(tc_strlen(cpSuffix)>0)
				   {
					   cpNewSuffix = (char*)MEM_alloc(sizeof(char)*tc_strlen(cpSuffix)+1);
					   tc_strcpy(cpNewSuffix,cpSuffix);
					   tc_strcat(cpMfgItemId, HYPHEN);
					   tc_strcat(cpMfgItemId, cpNewSuffix);
					}
				}
				else
				{
					 cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpEbomItemId))+1);
					 tc_strcpy(cpMfgItemId,cpEbomItemId);
				}


			}

				 NG5_MEM_TCFREE(cpSuffix);
				 NG5_MEM_TCFREE(cpOriginalID);
				 NG5_MEM_TCFREE(cpSourcePlantID);
      	}
      	TC_write_syslog("\n >>>>>  EBOM Node Without Children -MFG ID :%s\n",cpMfgItemId);
		ifail = Ng5_find_item(cpMfgItemId,MFGPART,&tMfgItem);
		if (tMfgItem != NULLTAG)
    	{

			if (iEBOMLevel > 1)
			{
				ifail = Ng5_check_skip_ebom_node( tEBOMLineNode,cpOEMStr,cpPlantcode,&lIsEBOMSkip);
				if (lIsEBOMSkip == false)
				{
					TC_write_syslog("\n >>>>> Existing Manufacturing Node To be linked =%s", cpMfgItemId);
					ifail = AOM_set_value_string(tMfgItemCreateInput, ATTR_ITEM_ID, cpMfgItemId);
					*tCreateInput = tMfgItemCreateInput;
				}
				else
				{
					
				   *tCreateInput = NULLTAG;

				}
			}
			else
			{
				// First Level component node to be copied
				ifail = AOM_set_value_string(tMfgItemCreateInput, ATTR_ITEM_ID, cpMfgItemId);
				*tCreateInput = tMfgItemCreateInput;
			}
		}
    	else
    	{

			TC_write_syslog("\n >>>>> 285 New Manufacturing Node = %s\n", cpMfgItemId);

			ifail = TCTYPE_find_type(MFGPARTREV, NULL , &tMfgItemRevType);
			ifail = TCTYPE_construct_create_input(tMfgItemRevType, &tMfgItemRevCreateInput);

			ITKCALL(AOM_ask_value_string(tEBOMLineNode, BOMLINEREVID, &cpEbomItemRevID ));
			if(tSourceMBOM !=NULLTAG)
			{
				ITKCALL(AOM_set_value_tag(tMfgItemRevCreateInput, SOURCEMBOM, tSourceMBOM));
				if(tc_strlen(cpSourceOEM)>0)
				{
					ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, RQRDCUSTPARTNO, YES));
					ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, ATTR_CUST_NAME, cpSourceOEM));
						
				}
			}
			ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, ATTR_OBJECT_NAME, cpObjStr));
			ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, PLANTS, cpPlantcode));
			ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, ATTR_OBJECT_DESC, cObjDesc));
			ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, SUFFIX, cpNewSuffix));
			ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput,"ng5_make_buy", makeBuy));
			TC_write_syslog("\n >>>>> 215 makeBuy = %s\n",  makeBuy);
			if(cpCustomerPartNo != NULL && cpOEMStr != NULL)
			{
				ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, RQRDCUSTPARTNO, YES));
				ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, ATTR_CUST_NAME, cpOEMStr));
			}
			
			
			ITKCALL(AOM_set_value_string(tMfgItemRevCreateInput, MFGPARTTYPE, COMPONENT));
           
			ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ATTR_ITEM_ID, cpMfgItemId));
			ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ATTR_OBJECT_NAME, cpObjStr));
			ITKCALL(AOM_set_value_string(tMfgItemCreateInput, ATTR_OBJECT_DESC, cObjDesc));
			
			ITKCALL(AOM_set_value_tag(tMfgItemCreateInput, REVISION, tMfgItemRevCreateInput));
			if (iEBOMLevel > 1)
			{
				ifail = Ng5_check_skip_ebom_node( tEBOMLineNode,cpOEMStr,cpPlantcode,&lIsEBOMSkip);
				if (lIsEBOMSkip == false)
				{
					TC_write_syslog("\n >>>>> Existing Manufacturing Node To be linked =%s", cpMfgItemId);
					ifail = AOM_set_value_string(tMfgItemCreateInput, ATTR_ITEM_ID, cpMfgItemId);
					*tCreateInput = tMfgItemCreateInput;
				}
				else
				{
					
				   *tCreateInput = NULLTAG;

				}
			}
			else
			{

				*tCreateInput = tMfgItemCreateInput;
			}
    	}

		return ITK_ok;


    	}
		NG5_MEM_TCFREE(cpNewSuffix);
    	NG5_MEM_TCFREE(cpObjStr1);
		NG5_MEM_TCFREE(cpMfgItemId);
    	NG5_MEM_TCFREE(cpObjName);
    	NG5_MEM_TCFREE(cpEBOMNodeType);
    	NG5_MEM_TCFREE(cpEbomItemRevID);
    	NG5_MEM_TCFREE(cpPlantcode);
    	NG5_MEM_TCFREE(cpOEMStr);
    	NG5_MEM_TCFREE(cpCustomerPartNo);
    	

    }	

	NG5_MEM_TCFREE(cpEbomItemId);
	NG5_MEM_TCFREE(cpObjStr);
	NG5_MEM_TCFREE(cObjDesc);
	NG5_MEM_TCFREE (ttForms);
	TC_write_syslog("\n >>>>>  Exiting Ng5_BMF_ITEM_create_or_ref_id\n");
    return ITK_ok;
}
/*
* Function to find Item  as per Item type
*/
int Ng5_find_item(const char* cpItemid, char* cpobjtype,tag_t* tItemTag )
{
	int n = 0, ifail      = ITK_ok;
    tag_t *items          = NULL;
    const char* names[2]  = {ATTR_ITEM_ID,ATTR_OBJECT_TYPE };
    const char* values[2] = { cpItemid,cpobjtype };
    ifail = ITEM_find_items_by_key_attributes( 2, names, values, &n, & items );
	if (n > 0) *tItemTag   = items[0];
	NG5_MEM_TCFREE(items);
    return ifail;
}
/*
* Function to find Item Revision  as per Item type
*/
int Ng5_find_item_rev(const char* cpItemid, const char* cpRevid, char* cpobjtype,tag_t* tItemRevTag )
{
	int n = 0, ifail = ITK_ok;
    tag_t *items = NULL;
    const char* names[2] = { ATTR_ITEM_ID,ATTR_OBJECT_TYPE };
    const char* values[2] = { cpItemid,cpobjtype };
    ifail = ITEM_find_item_revs_by_key_attributes( 2, names, values, cpRevid, &n, & items );
	if (n > 0) *tItemRevTag = items[0];
	NG5_MEM_TCFREE(items);
    return ifail;
}



/*The function to check if a EBOM  node to be skipped
*
*/
int Ng5_check_skip_ebom_node(tag_t tEBOMLineNode, char* cpOEMStr, char* cpPlantcode, logical* lIsEBOMSkip)
{
	int 		ifail 				= ITK_ok;
	tag_t 		tPEbomItemRev 		= NULLTAG;
	
	char  		*cpParentMfgItemId   	= NULL; // (MEM_FREE)
	char  		*cpEbomItemId     		= NULL; // (MEM_FREE)
	char  		*cpPCustomerPartNo		= NULL; // (MEM_FREE)
	TC_write_syslog("\n >>>>>  Entering Ng5_check_skip_ebom_node");
	tag_t parentLine = NULLTAG;
	Ng5_get_bline_attr_tag ( tEBOMLineNode, BOMLINEPARENTLINE, &parentLine);
    TC_write_syslog("\n >>>>>  parentLine  : %d ",parentLine);
    if(parentLine != NULLTAG)
    {
		Ng5_get_bline_attr_tag ( parentLine, BOMLINEREVISION, &tPEbomItemRev);
    }
    TC_write_syslog("\n >>>>>  tPEbomItemRev  : %d ",tPEbomItemRev);
	ITKCALL(AOM_ask_value_string(tPEbomItemRev, ATTR_ITEM_ID , &cpEbomItemId ));
	if(tPEbomItemRev != NULLTAG)
	{
		Ng5_getMfgCustomPartNum(tPEbomItemRev, cpOEMStr,&cpPCustomerPartNo);
		if(cpPCustomerPartNo != NULL && tc_strlen(cpPCustomerPartNo)>0)
		{
			 cpParentMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen(cpPCustomerPartNo))+1);
			 tc_strcpy(cpParentMfgItemId, MHYPHEN);
			 tc_strcat(cpParentMfgItemId, cpPlantcode);
			 tc_strcat(cpParentMfgItemId, HYPHEN);
			 if(tc_strncasecmp(cpPCustomerPartNo,MHYPHEN,2 )==0) tc_strcpy(cpParentMfgItemId, cpPCustomerPartNo);
			 else tc_strcat(cpParentMfgItemId, cpPCustomerPartNo);
		}
		else
		{
			cpParentMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantcode)+tc_strlen("-")+tc_strlen( cpEbomItemId))+1);
			tc_strcpy(cpParentMfgItemId, MHYPHEN);
			tc_strcat(cpParentMfgItemId, cpPlantcode);
			tc_strcat(cpParentMfgItemId, HYPHEN);
			if(tc_strncasecmp(cpEbomItemId,MHYPHEN,2 )==0) tc_strcpy(cpParentMfgItemId, cpEbomItemId);
			else tc_strcat(cpParentMfgItemId, cpEbomItemId);
		}
	}
	
	TC_write_syslog("\n>>>>> MBOM Parent ID=%s ", cpParentMfgItemId);
	 *lIsEBOMSkip = false;
    tag_t *tPrimary= NULL;
   	tag_t tRelTypeTag  	= NULLTAG;
   	int imfgCount =0;
    
   	ITKCALL( GRM_find_relation_type(Ng5_MFGTOENG_PRIMARY_REL,&tRelTypeTag));
   	ITKCALL( GRM_list_primary_objects_only( tPEbomItemRev, tRelTypeTag, &imfgCount, &tPrimary ));
    TC_write_syslog(">>>>> Entry imfgCount : %d\n",imfgCount);
    for(int icn=0; icn<imfgCount && tPrimary != NULL; icn++)
	{
		char *chMatlType = NULL;
		AOM_ask_value_string(tPrimary[icn], ATTR_OBJECT_TYPE, &chMatlType);
		if(tc_strcmp(chMatlType, Ng5_MFGTOENG_PRIMARY_TYPE) == 0)
		{
			char* cmfgId = NULL;
			AOM_ask_value_string(tPrimary[icn], ATTR_ITEM_ID, &cmfgId);
			TC_write_syslog(">>>>> cmfgId : %d\n",cmfgId);
			if(cmfgId != NULL && tc_strcmp(cpParentMfgItemId,cmfgId) ==0)
			{
				NG5_MEM_TCFREE(cmfgId);
				*lIsEBOMSkip = true;
				break;
			}
		  NG5_MEM_TCFREE(chMatlType);
		}
	}
    NG5_MEM_TCFREE(tPrimary);
	
	NG5_MEM_TCFREE(cpParentMfgItemId);
	NG5_MEM_TCFREE(cpEbomItemId);
	NG5_MEM_TCFREE(cpPCustomerPartNo);
    TC_write_syslog("\n >>>>>  Exiting Ng5_check_skip_ebom_node\n");
	return ifail;
}
/*
 * Function to get Latest Released Revision(Latest Working if Latest Released is  not avialble) of EBOM Item
 */
int Ng5_getRev2CopyFrom(tag_t tItemTag,tag_t* tRevTag)
{
	int    iFail          = ITK_ok;
	tag_t*    ptRevList   = NULL;  /*Mem_free*/
	tag_t*   ptStatusList = NULL ; /*Mem_free*/
	tag_t      tRlsdRev   = NULLTAG ;
	char*   cStatusName   = NULL;  /*Mem_free*/
	char*    cRevStatus   = NULL;
	int            iRev   = 0;
	int      iStatusCnt   = 0;
	ITKCALL(ITEM_list_all_revs(tItemTag,&iRev,&ptRevList));
    for	(int iRevx = iRev-1 ; iRevx >=0; iRevx--)
	{
		ITKCALL(WSOM_ask_release_status_list(ptRevList[iRevx] ,&iStatusCnt,&ptStatusList));
		if(iStatusCnt >0)
		{
			ITKCALL(AOM_ask_name (ptStatusList[iStatusCnt-1],&cStatusName));
			if(tc_strcmp(cStatusName,RELEASED)==0)
			{
				
				*tRevTag = ptRevList[iRevx];
				break;
			}
			NG5_MEM_TCFREE(cStatusName);
		}
		
		NG5_MEM_TCFREE(ptStatusList);
	}
	 
	if(*tRevTag== NULLTAG)
	{

	 for	(int iRevx = iRev-1 ; iRevx >=0; iRevx--)
	 	{
	 		ITKCALL(AOM_ask_value_string(ptRevList[iRevx] ,STATUS_INDICATOR,&cRevStatus));
	 		if(tc_strcmp(cRevStatus,LATEST_REV)==0)
	 		{


	 				*tRevTag = ptRevList[iRevx];

	 				break;

	 		}
	 		else if(tc_strcmp(cRevStatus,OBSOLETE_REV)==0)
	 		{

 				*tRevTag = ptRevList[iRevx];

 				break;

	 		}
            NG5_MEM_TCFREE(cRevStatus);

	 	}
	}
	NG5_MEM_TCFREE(ptRevList);
	
	
	return ITK_ok;
}

/*Funtion to check if the object type is valid to be cloned tomanufacturing part
*/

logical Ng5_validType2Clone(char* cpEBOMNodeType)
{
	logical valid = false ;
	char** cpPrefVal = NULL;
	char* cpType2Clone=NULL;
	int   iPrefCount = 0;
	PREF_ask_char_values(EBOM2MBOMCLONPREF,&iPrefCount,&cpPrefVal);

	for(int iPrefx=0; iPrefx<iPrefCount; iPrefx++)
	{

		if(tc_strstr(cpPrefVal[iPrefx],CLONE)!=NULL)
		{
			
			cpType2Clone =tc_strtok(cpPrefVal[iPrefx],COLON);
			while(cpType2Clone!=NULL)
			{


				if(tc_strcmp(cpType2Clone,cpEBOMNodeType)==0)
				{
				   valid = true;
					return valid ;
				}
				cpType2Clone = tc_strtok(NULL,COLON);
				
			}
		}
	}
   return valid; 
}

/*Funtion to check if the object type is valid to be copied as a child MBOM structure
*/
logical Ng5_validType2Copy(char* cpEBOMNodeType)
{
	logical valid = false ;
	char** cpPrefVal = NULL;
	char* cpType2Copy=NULL;
	int   iPrefCount = 0;
	PREF_ask_char_values(EBOM2MBOMCLONPREF,&iPrefCount,&cpPrefVal);
	for(int iPrefx=0; iPrefx<iPrefCount; iPrefx++)
	{
		if(tc_strstr(cpPrefVal[iPrefx],COPY)!=NULL)
		{
			
			cpType2Copy =tc_strtok(cpPrefVal[iPrefx],COLON);
			while(cpType2Copy!=NULL)
			{
				if(tc_strcmp(cpType2Copy,cpEBOMNodeType)==0)
				{
				   valid = true;
					return valid ;
				}
				cpType2Copy = tc_strtok(NULL,COLON);
				
			}
           NG5_MEM_TCFREE(cpType2Copy);
		}
	}
	NG5_MEM_TCFREE(cpPrefVal);
	
   return valid; 
}

/******************************************************************************
*get_bline_attr_tag ()
*Utility function to get a 'tag' type attribute in a BOM Line.
*
* Parameters
* bline_t : tag_t : BOM line tag whose attribute is to be obtained
* attr : char* : Attribute name
* attr_t : tag* : Return tag value
*
* Returns
* ITK_ok  : int : Success
* !ITK_ok : int : Failure
*
******************************************************************************/

int Ng5_get_bline_attr_tag (
      tag_t bline_t,      /* <I> */
      char  *attr,        /* <I> */
      tag_t *attr_t       /* <O> */
      )
{

  int attr_id = 0;   /* a random invalid mode */
  ITKCALL ( BOM_line_look_up_attribute (attr, &attr_id) );
  ITKCALL ( BOM_line_ask_attribute_tag ( bline_t, attr_id, attr_t) );
  return ITK_ok;

}




//Check If Raw Material Exists with sameID)
tag_t Ng5_isRawMaterialExists(tag_t tEBOMItem)
{

	 char* cpItemID    = NULL;
	 char* cObjectType = NULL;
	 int n_items       = 0;
	 tag_t* tItems      = NULL;
	 tag_t tRMItem    = NULLTAG;
	 AOM_ask_value_string(tEBOMItem,ATTR_ITEM_ID,&cpItemID);
	 char    query_name[QRY_name_size_c+1]   = "Item...";
	 ITKCALL(ITEM_find(cpItemID,&n_items,&tItems));
     for(int ifoundx=0; ifoundx <n_items; ifoundx++)
     {
    	 ITKCALL (AOM_ask_value_string (tItems[ifoundx], ATTR_OBJECT_TYPE, &cObjectType));
    	 if(tc_strcmp(cObjectType, RAW_MATERIAL) == 0)
    	 {
    		 tRMItem = tItems[ifoundx];
    		 break;
    	 }
     }

     return tRMItem;

	}

tag_t Ng5_isPackagingPartExists(tag_t tEBOMItem)
{

	 char* cpItemID    = NULL;
	 char* cObjectType = NULL;
	 int n_items       = 0;
	 tag_t* tItems      = NULL;
	 tag_t tRMItem    = NULLTAG;
	 AOM_ask_value_string(tEBOMItem,ATTR_ITEM_ID,&cpItemID);
	 char    query_name[QRY_name_size_c+1]   = "Item...";
	 ITKCALL(ITEM_find(cpItemID,&n_items,&tItems));
     for(int ifoundx=0; ifoundx <n_items; ifoundx++)
     {
    	 ITKCALL (AOM_ask_value_string (tItems[ifoundx], ATTR_OBJECT_TYPE, &cObjectType));
    	 if(tc_strcmp(cObjectType, PKG_PART) == 0)
    	 {
    		 tRMItem = tItems[ifoundx];
    		 break;
    	 }
     }

     return tRMItem;

	}


