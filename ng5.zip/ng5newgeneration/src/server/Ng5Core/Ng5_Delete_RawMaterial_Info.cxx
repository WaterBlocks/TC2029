/*********************************************************************************************
** File Name:         Ng5_Delete_RawMaterial_Info.cxx
**
** File Description:
** This file contains the implementation for the Extension Ng5_Delete_RawMaterial_Info
**
**
** This Extension is to capture delete and update the latest Raw Material information on Engineered Part Rev When association between Enginnered Part Rev and Raw Material Rev are removed.
** 1. Capturing of Raw Material object String of all Raw Materials
** 2. Capturing of Raw Material Quantity of all Raw Materials
** 3. Capturing of Raw Material Unit of Measure of all Raw Materials
** 4. On removal of Raw Materials from engineered part rev meta data has to in sync with associated Raw Materials.
** 5. Raw Material info located on Engineered Part revision has to persistantly capture the updated information details in Teamcenter application
** 6. Data Model is going to capture the constraints object properties
**
** History:
** Date			|  	AGM		|	Name          		|	Comments
** ------------------------------------------------------------------------------------------------
** 20/01/2017	| 			|	Anil Gummareddypura |    Initial Version
** 01/08/2018	|			|	Meenakshi			|	1. Code format, replaced hardcoded string WRITE with ACCESS_WRITE 
** 01/08/2018	|			|	Arjun				|	1. Moved the History to the button of the File header
** 													|	2. replaced hardcoded string type_string with ATTR_TYPE_STRING
** 													|	3. Added MEM_Free for 2 char pointer variables
** 05/07/2021	|			|	Balaji				|    TC12 Upgrade
*********************************************************************************************/

#include <Ng5Core/Ng5_Delete_RawMaterial_Info.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <iostream>
#include <string>

using namespace std;

int Ng5_Delete_RawMaterial_Info( METHOD_message_t * msg, va_list args )

{
	TC_write_syslog ("\n\t Entering  Ng5_Delete_RawMaterial_Info...\n" );

	/*Varaibles Initializing, Copying and Parsing of extension triggered arguments*/

	int			iFail				  	= ITK_ok;
	tag_t  		tPrimaryObjectrev     	= NULLTAG;
	tag_t  		tSecondaryObjectrev   	= NULLTAG;
	tag_t  		tRelationTag          	= NULLTAG;

	va_list 	largs;
	va_copy(largs,args);
	tRelationTag 					  	= va_arg(largs, tag_t);

	tag_t  		tRelationTypeTag  	  	= NULLTAG;
	char 		*chrobjType  		  	= NULL ;
	int    		inoofGRMObjs			= 0;
	GRM_relation_t  		*tGRMObjs	= NULLTAG;
	char 		*chtmpstr 				= NULL;
	
	logical		bflag 					= false;
	char* 		chpdelRawMatNameVal 	= NULL;
	char        *chPrimaryobjType       = NULL ;
	tag_t    	tdelPIobjTag  			= NULLTAG;
	tag_t		tdelUOMobjTag			= NULLTAG;
	char* 		chpdelRawMatUOMVal 		= NULL;
	double 		chpdelRawMatQtyVal     	= 0.00;
	std::size_t iIntialdelStrlen 		= 0;
	char 		*chpRawMaterialToDelete = NULL;
	char 		*cpNewRawMatinfo 		= NULL;

	std::string 	strRawMaterialiInfo	("");
	std::string 	strRawMaterialDelInfo("");
	std::string 	strRawMaterialiTempInfo("");
	std::string 	strRawMaterialDelTempInfo("");
	std::string 	strRawMaterialfInfo("");
	std::string 	strreplace ("");

	chpdelRawMatUOMVal = (char * ) MEM_alloc ( sizeof(char) * 8);

	if( tRelationTag != NULLTAG){

		NG5_ITK_CALL(GRM_ask_relation_type (tRelationTag,&tRelationTypeTag));

		NG5_ITK_CALL( AOM_ask_value_string (tRelationTag,"type_string",&chrobjType) );

		/* Finding Primary object(Engineered Part Rev) and Secondary object(Raw Material Rev) details*/

		if (chrobjType != NULL && tc_strlen(chrobjType) > 0 && tc_strcmp ( chrobjType,HAS_RAW_MATERIAL_RELATION) == 0){

			NG5_ITK_CALL(GRM_ask_primary (tRelationTag,&tPrimaryObjectrev));

			NG5_ITK_CALL(GRM_list_secondary_objects (tPrimaryObjectrev,tRelationTypeTag,&inoofGRMObjs,&tGRMObjs));

			for (int icount =0 ; icount <inoofGRMObjs; icount++){

				char 		*chpgrmRelObjType  			= NULL ;
				

				tag_t   	tPIobjTag  					= NULLTAG;
				tag_t   	tUOMobjTag  				= NULLTAG;
				char* 		chpRawMatUOMVal 			= NULL;
				double 		chpRawMatQtyVal     		= 0.00;
				char* 		chpRawMatNameVal 			= NULL;
				std::size_t tiIntialStrlen 				= 0;
				char   		*chpRawMatInfo 				= NULL;

				chpRawMatUOMVal = (char * ) MEM_alloc ( sizeof(char) * 8);

				/*Capturing the Raw Material requried information*/

				NG5_ITK_CALL( AOM_ask_value_tag (tGRMObjs[icount].secondary,(const char *) ITEMS_TAG, &tPIobjTag) );

				NG5_ITK_CALL(ITEM_ask_unit_of_measure(tPIobjTag,&tUOMobjTag));

				if (tUOMobjTag != NULLTAG) {

					ITK (UOM_ask_symbol (tUOMobjTag, &chpRawMatUOMVal));

					TC_write_syslog("\n\t List of UOM value: <%s> ...",chpRawMatUOMVal);

				}else {

					tc_strcpy (chpRawMatUOMVal, "each");

				}

				NG5_ITK_CALL( AOM_ask_value_double ( tGRMObjs[icount].the_relation, (const char *) ATTR_RAWMATERIAL_QTY, &chpRawMatQtyVal) );

				NG5_ITK_CALL( AOM_ask_value_string ( tGRMObjs[icount].secondary, (const char *) ATTR_RAWMATERIAL_NAME, &chpRawMatNameVal) );

				/* Concatinating Raw Material Details and Associating the latest Raw Material Info Associated with Enginnered Part Rev*/

				tiIntialStrlen = (tc_strlen(chpRawMatNameVal) + sizeof(double) + tc_strlen(chpRawMatUOMVal)+tc_strlen("|")+1);

				chpRawMatInfo = (char *) MEM_alloc ( sizeof (char ) * tiIntialStrlen);

				snprintf(chpRawMatInfo, (sizeof (char )* tiIntialStrlen) , "%s~%.3f~%s", chpRawMatNameVal,chpRawMatQtyVal,chpRawMatUOMVal);

				tc_strcat(chpRawMatInfo,"|");

				/* If Raw Material properties are intial capture Raw Material details*/

				if (tc_strcmp(chtmpstr,NULL)==0 && icount == 0 ){

					chtmpstr = (char *) MEM_alloc((tc_strlen(chpRawMatInfo) + 1)*sizeof(char));

					tc_strcpy(chtmpstr,chpRawMatInfo);

				} else { 	/* If Raw Material properties are already available appened to existing Raw Material details*/

					chtmpstr = (char *) MEM_realloc(chtmpstr,(tc_strlen(chpRawMatInfo) + tc_strlen(chtmpstr)+ 1)*sizeof(char));

					tc_strcat(chtmpstr,chpRawMatInfo);

				}
				NG5_MEM_TCFREE (chpRawMatInfo);
				NG5_MEM_TCFREE (chpRawMatNameVal);
				NG5_MEM_TCFREE (chpRawMatUOMVal);
			}	/*Validate and update the Raw Material info latest on Engineering Part Rev*/
			if (tc_strcmp(chtmpstr,NULL)!=0){

				NG5_ITK_CALL(WSOM_ask_object_type2(tPrimaryObjectrev,&chPrimaryobjType));

				NG5_ITK_CALL(AM_check_privilege (tPrimaryObjectrev, ACCESS_WRITE, &bflag));

				if(true == bflag && (tc_strcmp ( chPrimaryobjType,ENG_PART_REVISION ) == 0)){

					NG5_ITK_CALL(GRM_ask_secondary  (tRelationTag,&tSecondaryObjectrev));

					NG5_ITK_CALL( AOM_ask_value_string ( tSecondaryObjectrev, (const char *) ATTR_RAWMATERIAL_NAME, &chpdelRawMatNameVal) );

					NG5_ITK_CALL( AOM_ask_value_tag (tSecondaryObjectrev,(const char *) ITEMS_TAG, &tdelPIobjTag) );

					NG5_ITK_CALL(ITEM_ask_unit_of_measure(tdelPIobjTag,&tdelUOMobjTag));

					if (tdelUOMobjTag != NULLTAG) {

						ITK (UOM_ask_symbol (tdelUOMobjTag, &chpdelRawMatUOMVal));

						TC_write_syslog("\n\t Deletion requested UOM value: <%s> ...",chpdelRawMatUOMVal);

					} else {

						tc_strcpy (chpdelRawMatUOMVal, "each");

					}

					NG5_ITK_CALL( AOM_ask_value_double ( tRelationTag, (const char *) ATTR_RAWMATERIAL_QTY, &chpdelRawMatQtyVal) );

					if (chtmpstr != NULL){ /*Finding the triggred Raw material information & removing the same from associated rawmaterial info.*/

						TC_write_syslog ("\n\t Entering  Ng5_RawMaterial_deletion mode...\n" );

						iIntialdelStrlen = (tc_strlen(chpdelRawMatNameVal) + sizeof(double) + tc_strlen(chpdelRawMatUOMVal) +1);

						chpRawMaterialToDelete = (char *) MEM_alloc ( sizeof (char ) * iIntialdelStrlen);

						snprintf(chpRawMaterialToDelete, (sizeof (char )* iIntialdelStrlen) , "%s~%.3f~%s",chpdelRawMatNameVal,chpdelRawMatQtyVal,chpdelRawMatUOMVal);

						tc_strcat(chpRawMaterialToDelete,"|");

						std::string strRawMaterialiInfo(chtmpstr);

						std::string strRawMaterialDelInfo(chpRawMaterialToDelete);
						//AGM# :Added MEM_FREE
						NG5_MEM_TCFREE (chpRawMaterialToDelete);

						strRawMaterialiTempInfo = strRawMaterialiInfo;

						strRawMaterialDelTempInfo = strRawMaterialDelInfo.substr(0,strRawMaterialDelInfo.length());

						if (strRawMaterialiTempInfo.find(strRawMaterialDelTempInfo) != std::string::npos) {

							strRawMaterialiTempInfo.replace(strRawMaterialiTempInfo.find(strRawMaterialDelTempInfo),strRawMaterialDelTempInfo.length(),strreplace);
						}

						if ( strRawMaterialiTempInfo.c_str() != NULL && tc_strlen ( strRawMaterialiTempInfo.c_str()) > 0 ) {

							cpNewRawMatinfo = (char * ) MEM_alloc ( sizeof (char) * (strlen (strRawMaterialiTempInfo.c_str())  + 1 ) );

							if ( cpNewRawMatinfo)

								tc_strcpy ( cpNewRawMatinfo, strRawMaterialiTempInfo.c_str());

						} /*Update the processed Raw Material information*/

						NG5_ITK_CALL(AOM_refresh(tPrimaryObjectrev,true));

						NG5_ITK_CALL( AOM_UIF_set_value ( tPrimaryObjectrev, ATTR_ENGPARTREV_RAWMATINFO, cpNewRawMatinfo));

						NG5_ITK_CALL(AOM_save_with_extensions(tPrimaryObjectrev)); //TC 12 Upgrade

						NG5_ITK_CALL(AOM_refresh(tPrimaryObjectrev,false));
						//AGM# :Added MEM_FREE
						NG5_MEM_TCFREE (cpNewRawMatinfo);

					}else {
						TC_write_syslog("\n\t Deletion Raw Material info is Null \n");
						//std::cout << "Raw Material info   is Null \n";
					}
				}   /*Free up the consumed memory*/
				NG5_MEM_TCFREE (chpdelRawMatNameVal);
				NG5_MEM_TCFREE (chpdelRawMatUOMVal);
				NG5_MEM_TCFREE (chPrimaryobjType);
			}
			NG5_MEM_TCFREE (tGRMObjs);
			NG5_MEM_TCFREE (chtmpstr);
		}
		NG5_MEM_TCFREE (chrobjType);
	}
	return iFail;
}
