//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_LaunchPrg_Iman_Save_PostAction
 *
 */
 
#ifndef NG5_LAUNCHPRG_IMAN_SAVE_POSTACTION_HXX
#define NG5_LAUNCHPRG_IMAN_SAVE_POSTACTION_HXX
#include <tccore/method.h>
#include <ug_va_copy.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/grm.h>
#include <lov/lov.h>
#include <tc/preferences.h>
#include <fclasses/tc_string.h>
#include <Ng5Core/libng5core_exports.h>

#define Ng5_SSOPkg 									"Ng5_SSOPkg"
#define Ng5_SSOPkgRevision							"Ng5_SSOPkgRevision"
#define Ng5_rHasSSOPackage							"Ng5_rHasSSOPackage"
#define Ng5_SSOFolders 								"Ng5_SSOFolders"
#define Ng5_rHasSSOFolders  						"Ng5_rHasSSOFolders"
#define object_name									"object_name"
#define SSO_Package_name							"Go"
#define revision									"revision"
#define Ng5_Gate_DV_Start_Folders 					"Ng5_Gate_DV_Start_Folders"
#define Ng5_Gate_DV_Release_Folders 				"Ng5_Gate_DV_Release_Folders"
#define Ng5_Gate_Final_Prod_Release_Folders 		"Ng5_Gate_Final_Prod_Release_Folders"
#define Ng5_Gate_Customer_Part_Approval_Folders 	"Ng5_Gate_Customer_Part_Approval_Folders"


#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_LaunchPrg_Iman_Save_PostAction(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_LAUNCHPRG_IMAN_SAVE_POSTACTION_HXX
