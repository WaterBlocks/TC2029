//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *  This file contains the implementation for the Extension Ng5_ICEPartForm_IMAN_Save_PostAction
 *  Ng5_ICEPartForm_IMAN_Save_PostAction.cxx  has the code which will take the user input values of ‘ng5_sap_net_weight’ and ‘ng5_sap_weight_uom’, traverse to each Plant Form, convert the ‘ng5_sap_net_weight’ according to ‘ng5_plant_weightuom’ and populate the ‘ng5_plant_netweight’ on all the Plant Forms. 
 * Updated on 13 May 2021 - Propagation of 'ng5_sap_net_weight’ to ‘ng5_plant_netweight’ should work even when Plant Form has the 'Enriched' status. 
 * 05 July 2021 -TC12 Upgrade
 */
#include <Ng5Core/Ng5_ICEPartForm_IMAN_Save_PostAction.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <iostream>
#include <string>
#include <math.h>
#include <iomanip>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <sa/sa_errors.h>
#include <ug_va_copy.h>
#include <ce/ce.h>
#include <constants/constants.h>

#include <base_utils/ScopedSmPtr.hxx>
#include <stdarg.h>
#include <sstream>
#include <fclasses/tc_string.h>

#include "Ng5_CommonUtils.hxx"

using namespace std;
using namespace ng5newgeneration;

int Ng5_ICEPartForm_IMAN_Save_PostAction( METHOD_message_t * msg, va_list args )
{
	TC_write_syslog ("\n\t Entering  Ng5_ICEPartForm_IMAN_Save_PostAction...\n" );

	int 		iFail 			= ITK_ok;
	tag_t 		inst_class_id   = NULLTAG;
	char* 		classname 		= NULL;
	tag_t   	tStorageID  	= NULLTAG;
	char*		cMfgDesc 		= NULL;
	char*		cSAPUom 		= NULL;
	bool 		isNull 			= false;
	double  	dSAPWt         	= 0.0;
	tag_t   	tAttrTag       	= NULLTAG;
	tag_t   	tUOMAttrTag    	= NULLTAG;
	tag_t   	tMfgDescAttrTag = NULLTAG;
	tag_t       tMMTransAttrTag = NULLTAG;
	tag_t 		tObject 		= NULLTAG;

	METHOD_PROP_MESSAGE_OBJECT(msg, tObject);

	ITKCALL(POM_class_of_instance(tObject,&inst_class_id));
	ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tObject))
	{
		//TC_write_syslog("\n After is_descendant_of_Form\n");
		tag_t form_tag = tObject;
		tObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tObject));
	}

    if (tObject != NULLTAG)
   	{
    	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, ICEPARTFORM_STORAGE, ATTR_SAP_WT, &tAttrTag));
		ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, ICEPARTFORM_STORAGE, ATTR_SAP_UOM, &tUOMAttrTag));
		if (tAttrTag != NULLTAG || tUOMAttrTag != NULLTAG)
		{
			NG5_ITK_CALL( AOM_ask_value_double (tObject, ATTR_SAP_WT, &dSAPWt));
			NG5_ITK_CALL( AOM_ask_value_string (tObject, ATTR_SAP_UOM, &cSAPUom));
			//TC_write_syslog("\n Ng5_ICEPartForm_IMAN_Save_PostAction: dSAPWt = %f cSAPUom = %s \n", dSAPWt, cSAPUom);

			tag_t t_formObj = NULLTAG;

			METHOD_PROP_MESSAGE_OBJECT(msg, t_formObj);

			logical isCNInitiated = false;
			tag_t trelType = NULLTAG;
			int iPrimCnt = 0;
			tag_t *tPrimEngPN = NULL;

			ITKCALL (GRM_find_relation_type(REL_ICEPARTFORM, &trelType));
			ITKCALL (GRM_list_primary_objects_only(t_formObj, trelType, &iPrimCnt, &tPrimEngPN));
			if(iPrimCnt > 0 && tPrimEngPN != NULL)
			{
				int iPNCount = 0;

				for(int iNx= 0; iNx< iPrimCnt; iNx++)
				{
					char* cEPObjType = NULL;
					AOM_ask_value_string(tPrimEngPN[iNx], ATTR_OBJECT_TYPE, &cEPObjType);

					if(tc_strcmp(cEPObjType, ENG_PART) == 0 || tc_strcmp(cEPObjType, RAW_MATERIAL) == 0 || tc_strcmp(cEPObjType, PHANTOM_PART) == 0 || tc_strcmp(cEPObjType, PKG_PART) == 0)
					{
						// ENG_PART found
						iPNCount +=1;

						tag_t trelMM = NULLTAG;
						int iMMCnt = 0;
						tag_t *tPrimMMs = NULL;

						//Start Traverse to Material Master from Eng Part
						ITKCALL (GRM_find_relation_type(REL_MATLMSTR, &trelMM));
						//check if EngPart already has relation with ICEPartForm
						ITKCALL (GRM_list_secondary_objects_only (tPrimEngPN[iNx], trelMM, &iMMCnt, &tPrimMMs));

						for(int iMMx= 0; iMMx< iMMCnt; iMMx++)
						{
							char* cObjMMType = NULL;
							AOM_ask_value_string(tPrimMMs[iMMx], ATTR_OBJECT_TYPE, &cObjMMType);

							if(tc_strcmp(cObjMMType, MATL_MASTER) == 0)
							{
								// Material Master found
								//Start Traverse to Plant Forms from Matl Mstr
								tag_t trelPF = NULLTAG;
								int iPFCnt = 0;
								tag_t *tPrimPFs = NULL;

								//Start Traverse to Matl Mstr from Eng Part
								ITKCALL (GRM_find_relation_type(REL_PLANTFORM, &trelPF));

								//check if EngPart already has relation with ICEPartForm
								ITKCALL (GRM_list_secondary_objects_only (tPrimMMs[iMMx], trelPF, &iPFCnt, &tPrimPFs));
								//TC_write_syslog("\n Ng5_ICEPartFormImpl: Number of Plant Forms %d\n", iPFCnt);

								for(int iPFx= 0; iPFx< iPFCnt; iPFx++)
								{
									char*	cObjPFType = NULL;
									AOM_ask_value_string(tPrimPFs[iPFx], ATTR_OBJECT_TYPE, &cObjPFType);

									//TC_write_syslog("\n Plant Form Object type is %s  \n", cObjPFType);
									if(tc_strcmp(cObjPFType, PLANTFORM) == 0)
									{
										//Plant Form found
										int iRelStatCnt = 0;
										tag_t* tPFRelStats = NULL;
										char* cpRelStatusType = NULL;
										char*	cPlantUOM = NULL;
										double	newValue = 0.0;

										ITKCALL(WSOM_ask_release_status_list(tPrimPFs[iPFx], &iRelStatCnt, &tPFRelStats));
										if(iRelStatCnt > 0)
										{
											ITKCALL (Ng5_CommonUtils::getConvertedWeight(cSAPUom, cPlantUOM, dSAPWt, &newValue));

											TC_write_syslog("\n Ng5_ICEPartForm_IMAN_Save_PostAction:getConvertedWeight for enriched Plant Forms: newValue of Weight=%f\n",newValue);

											AM__set_application_bypass(true);

											ITKCALL (AOM_refresh(tPrimPFs[iPFx], TRUE));
											ITKCALL (AOM_set_value_double (tPrimPFs[iPFx], ATTR_PLANT_WT, newValue));
											ITKCALL (AOM_save_with_extensions(tPrimPFs[iPFx]));//TC12 Upgrade
											ITKCALL (AOM_refresh(tPrimPFs[iPFx], FALSE));

											AM__set_application_bypass(false);
										}
										else
										{
											char*	cPlantUOM = NULL;
											double	newValue = 0.0;
											AOM_ask_value_string(tPrimPFs[iPFx], ATTR_PLANT_UOM, &cPlantUOM);

											//TC_write_syslog("\n Ng5_ICEPartForm_IMAN_Save_PostAction: cSAPUom, cPlantUOM, dSAPWt=%s-%s-%f \n",cSAPUom, cPlantUOM, newValue);

											ITKCALL (Ng5_CommonUtils::getConvertedWeight(cSAPUom, cPlantUOM, dSAPWt, &newValue));

											TC_write_syslog("\n Ng5_ICEPartForm_IMAN_Save_PostAction:getConvertedWeight: newValue of Weight=%f\n",newValue);

											ITKCALL (AOM_refresh(tPrimPFs[iPFx], TRUE));
											ITKCALL (AOM_set_value_double (tPrimPFs[iPFx], ATTR_PLANT_WT, newValue));
											ITKCALL (AOM_save_with_extensions(tPrimPFs[iPFx])); //TC 12 Upgrade
											ITKCALL (AOM_refresh(tPrimPFs[iPFx], FALSE));

											NG5_MEM_TCFREE(cPlantUOM);
										}
										NG5_MEM_TCFREE (tPFRelStats);
										NG5_MEM_TCFREE (cpRelStatusType);
									}
									NG5_MEM_TCFREE(cObjPFType);
								}
								NG5_MEM_TCFREE (tPrimPFs);
							//End Traverse to all Plant Forms
							}
							NG5_MEM_TCFREE(cObjMMType);
							//End Traverse to Plant Forms from Matl Mstr
						}
						NG5_MEM_TCFREE (tPrimMMs);
					}
					NG5_MEM_TCFREE(cEPObjType);
				}
				//End Traverse to Matl Mstr from Eng Part
			}
			NG5_MEM_TCFREE(tPrimEngPN);
			NG5_MEM_TCFREE(cSAPUom);
			NG5_MEM_TCFREE(cMfgDesc);
			NG5_MEM_TCFREE (classname);
		}
		else
		{
			TC_write_syslog("\n ** tAttrTag and tUOMAttrTag tag values are Empty **\n");
		}
   	}
    return iFail;
}

