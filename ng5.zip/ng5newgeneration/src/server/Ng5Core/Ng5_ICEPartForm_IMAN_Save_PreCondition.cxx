//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *  This file contains the implementation for the Extension Ng5_ICEPartForm_IMAN_Save_PostAction
 *  Ng5_ICEPartForm_IMAN_Save_PreCondition.cxx will check for the minimum value of 'ng5_sap_net_weight' as per ‘ng5_sap_weight_uom’.
 */
#include <Ng5Core/Ng5_ICEPartForm_IMAN_Save_PreCondition.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <iostream>
#include <string>
#include <math.h>
#include <iomanip>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <sa/sa_errors.h>
#include <ug_va_copy.h>
#include <ce/ce.h>
#include <constants/constants.h>

#include <base_utils/ScopedSmPtr.hxx>
#include <stdarg.h>
#include <sstream>
#include <fclasses/tc_string.h>

#include "Ng5_CommonUtils.hxx"

#define SA_insufficient_privileges (ErrorICEAttributesLocked)
#define BMF_artifact_not_found (SA_ERROR_BASE + 10002)

using namespace std;
using namespace ng5newgeneration;

int Ng5_ICEPartForm_IMAN_Save_PreCondition( METHOD_message_t * msg, va_list args )
{
	TC_write_syslog ("\n\t Entering  Ng5_ICEPartForm_IMAN_Save_PreCondition...\n" );

	int 		iFail 			= ITK_ok;
	tag_t 		inst_class_id   = NULLTAG;
	char* 		classname 		= NULL;
	tag_t   	tStorageID  	= NULLTAG;
	char*		cSAPUom 		= NULL;
	bool 		isNull 			= false;
	double  	dSAPWt         	= 0.0;
	tag_t   	tAttrTag       	= NULLTAG;
	tag_t   	tUOMAttrTag    	= NULLTAG;
	tag_t 		tObject 		= NULLTAG;

	METHOD_PROP_MESSAGE_OBJECT(msg, tObject);

	ITKCALL(POM_class_of_instance(tObject,&inst_class_id));
	ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tObject))
	{
		//TC_write_syslog("\n After is_descendant_of_Form\n");
		tag_t form_tag = tObject;
		tObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tObject));
	}

	if(tObject != NULLTAG)
	   	{
	    	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, ICEPARTFORM_STORAGE, ATTR_SAP_WT, &tAttrTag));
			ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, ICEPARTFORM_STORAGE, ATTR_SAP_UOM, &tUOMAttrTag));
			if (tAttrTag != NULLTAG || tUOMAttrTag != NULLTAG)
			{
				NG5_ITK_CALL( AOM_ask_value_double (tObject, ATTR_SAP_WT, &dSAPWt));
				NG5_ITK_CALL( AOM_ask_value_string (tObject, ATTR_SAP_UOM, &cSAPUom));
				TC_write_syslog("\n Ng5_ICEPartForm_IMAN_Save_PreCondition: dSAPWt = %f cSAPUom = %s \n", dSAPWt, cSAPUom);

				/*if((tc_strcmp(cSAPUom, "G") == 0 && dSAPWt<1) ||
				   (tc_strcmp(cSAPUom, "KG") == 0 && dSAPWt<0.001) ||
				   (tc_strcmp(cSAPUom, "LB")== 0 && dSAPWt<0.002) ||
				   (tc_strcmp(cSAPUom, "OZ")== 0 && dSAPWt<0.035))
				{
					TC_write_syslog("\n ** SAP Net Weight is less than minimum. **\n");
					iFail = SA_insufficient_privileges;
					EMH_store_initial_error_s1(EMH_severity_error, ErrorICEAttributesLocked , "SAP Net Weight is less than minimum." );
					return iFail;
				}
				else
				{
					TC_write_syslog("\n ** SAP Net Weight is as per the requirement. **");
				}*/
			}
			else
			{
				TC_write_syslog("\n ** tAttrTag and tUOMAttrTag tag values are Empty **\n");
			}
	   	}
		else
		{
			TC_write_syslog("\n ** tObject value is Empty **\n");
		}
		NG5_MEM_TCFREE(cSAPUom);
		NG5_MEM_TCFREE (classname);
 return iFail;
}
