//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_BOMLine_cut_restrict
 *
 */
#include <Ng5Core/Ng5_BOMLine_cut_restrict.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <Ng5Core/Ng5_BMF_ITEM_create_or_ref_id.hxx>
#include <Ng5Core/Ng5_BOMLine_move_restrict.hxx>

int Ng5_BOMLine_cut_restrict( METHOD_message_t * msg, va_list args )
{

	int	iFail						= ITK_ok;
	int	iBaselineRevCount			= ITK_ok;

	int tBomocc =0;
	int isequence =0;
	int ipacked =0;
	int isequence1 =0;
	int tBomocc1 =0;
	int iparentBaselineRevCount =0;
	int iChildBOMLineCount =0;
			
	char* cpobjOccEff = NULL;
	char* cpObjFindNo = NULL;
	logical  isPacked = NULL;
	char* cpparentname = NULL;
	char* cpMfgRevIDa = NULL;
	char* ParentItemID = NULL;
	char* cpparentObjOccEff = NULL;
	char* cpparentObjFindNo = NULL;
	char* cpchildMfgRevID = NULL;
	char  *cpObjectType    		 	= NULL; // (MEM_FREE)
	char  *cpMfgItemID    		 	= NULL; // (MEM_FREE)
	char  *cpMfgRevID    		 	= NULL; // (MEM_FREE)
	char  *cpQADFLAG    		 	= NULL; // (MEM_FREE)
	tag_t Latestbaseline = NULL;
	tag_t tMfgItemparentRevTag = NULL;
	tag_t bom_window = NULLTAG;
	tag_t rev_rule = NULLTAG;
	tag_t bom_line = NULLTAG;
	tag_t* tParentBaselineMfgItemRevTags = NULL;
	tag_t* tChildBOMLines = NULL;
	tag_t tBOMLine					= NULLTAG;
	tag_t tMfgItemRevTag			= NULLTAG;
	tag_t *tBaselineMfgItemRevTags	= NULL;
			


	//logical isBaselined				= false;


	va_list largs;
    va_copy( largs, args );
    tBOMLine = va_arg(largs, tag_t);
    va_end( largs );


	TC_write_syslog("\n >>>>>  Entering Ng5_BOMLine_cut_restrict\n");

	ITKCALL(AOM_ask_value_string(tBOMLine, BOMLINEOBJTYPE, &cpObjectType ));

	if(tc_strcmp(cpObjectType, MFGPART)==0)
	{
		TC_write_syslog("\n >>>>> Ng5_BOMLine_cut_restrict - Object Type %s  \n",cpObjectType);

			ITKCALL(AOM_ask_value_string(tBOMLine, BOMLIMEITEMID,&cpMfgItemID ));
			TC_write_syslog("\n >>>>> Ng5_BOMLine_cut_restrict - Object Item %s  \n",cpMfgItemID);


			ITKCALL(AOM_ask_value_string(tBOMLine, BOMLINEREVID,&cpMfgRevID));

			TC_write_syslog("\n >>>>> Ng5_BOMLine_cut_restrict - Object Rev  %s  \n",cpMfgRevID);
			
			
			ITKCALL(BOM_line_look_up_attribute("bl_occ_effectivity",&tBomocc));
			ITKCALL(BOM_line_ask_attribute_string(tBOMLine,tBomocc,&cpobjOccEff));

			TC_write_syslog("\n >>>>> Ng5_BOMLine_cut_restrict - iFail %d    cpobjOccEff %s  \n",iFail,cpobjOccEff);

			ITKCALL(BOM_line_look_up_attribute("bl_sequence_no",&isequence));
			ITKCALL(BOM_line_ask_attribute_string(tBOMLine ,isequence,&cpObjFindNo));

			TC_write_syslog("\n >>>>> Ng5_BOMLine_cut_restrict - iFail %d    cpObjFindNo %s  \n",iFail,cpObjFindNo);


			ITKCALL(BOM_line_look_up_attribute("bl_is_packed",&ipacked));
			ITKCALL(BOM_line_ask_attribute_logical(tBOMLine ,ipacked,&isPacked));

			//Ng5_find_item_rev (cpMfgItemID, cpMfgRevID, cpObjectType, &tMfgItemRevTag );
			
			ITKCALL(AOM_ask_value_string(tBOMLine,"bl_formatted_parent_name",&cpparentname));
			ParentItemID = tc_strtok(cpparentname,"/");
			Ng5_find_item_rev(ParentItemID,"01", cpObjectType, &tMfgItemparentRevTag);
			if(tMfgItemparentRevTag != NULL)
			{
				Latestbaseline = Ng5_FindLatestbaselineRevision(tMfgItemparentRevTag);
			 if(Latestbaseline != NULLTAG)
		      {
		     //  TC_write_syslog("\n>>>>> Parent - Number of Baselines =%d  tagID %d \n", iparentBaselineRevCount,tParentBaselineMfgItemRevTags[0]);
		   
					   ITKCALL(AOM_ask_value_string(Latestbaseline,"item_revision_id",&cpMfgRevIDa ));
					   TC_write_syslog("\n>>>>> Parent - latest revision id =%s \n", cpMfgRevIDa);
					   ITKCALL((BOM_init_module()));
					   ITKCALL((BOM_create_window (&bom_window)));
					   ITKCALL((CFM_find ("ADNT Precise",&rev_rule )));
					   ITKCALL(BOM_set_window_config_rule (bom_window,rev_rule ));
					   ITKCALL(BOM_set_window_top_line(bom_window,NULLTAG,Latestbaseline,NULLTAG,&bom_line));
					   ITKCALL( BOM_line_ask_all_child_lines(bom_line,&iChildBOMLineCount,&tChildBOMLines));
					   if (iChildBOMLineCount>0)
					   {
					 for(int i =0; i<iChildBOMLineCount; i++)
					 {
						 ITKCALL(AOM_ask_value_string(tChildBOMLines[i],BOMLIMEITEMID,&cpchildMfgRevID));
				 //ITKCALL(AOM_ask_value_string(tChildBOMLines[i],"bl_occ_effectivity",&cpparentObjOccEff ));
				 //ITKCALL(AOM_ask_value_string(tChildBOMLines[i], "bl_sequence_no",&cpparentObjFindNo ));

						 ITKCALL(BOM_line_look_up_attribute("bl_occ_effectivity",&tBomocc1));
						 ITKCALL(BOM_line_ask_attribute_string(tChildBOMLines[i],tBomocc1,&cpparentObjOccEff));

						 TC_write_syslog("\n >>>>> Ng5_BOMLine_cut_restrict - iFail %d    cpparentObjOccEff %s  \n",iFail,cpparentObjOccEff);

						 ITKCALL(BOM_line_look_up_attribute("bl_sequence_no",&isequence1));
						 ITKCALL(BOM_line_ask_attribute_string(tChildBOMLines[i],isequence1,&cpparentObjFindNo));

						 TC_write_syslog("\n >>>>> Ng5_BOMLine_cut_restrict - iFail %d    cpparentObjFindNo %s  \n",iFail,cpparentObjFindNo);

				 
						 if(tc_strcmp(cpMfgItemID,cpchildMfgRevID)==0 )
						 {
						//printf("\n >>>>>   Parent ID %s  ID cpparentObjOccEff %s cpparentObjFindNo %s  !!\n",cpchildMfgRevID,cpparentObjOccEff,cpparentObjFindNo);
//
						   if(isPacked == true)
						   {
							   if(tc_strcmp(cpparentObjOccEff,cpobjOccEff)==0 )
							   {
								 TC_write_syslog("\n>>>>> MOVE - Updating MBOM transferred to QAD: \n");
								 EMH_store_error(EMH_severity_error, ErrorBOMLineCutRestrict);
								return ErrorBOMLineCutRestrict;
                               }else
                               {
                            	   TC_write_syslog("\n Able to Cut bom_line occ_effectivity is not match  find no of both obj is cpparentObjFindNo %s cpObjFindNo %s \n",cpparentObjFindNo,cpObjFindNo);
                               }

						   }else{
							   TC_write_syslog("\n find no of both obj is cpparentObjFindNo %s cpObjFindNo %s  and Occ eff is cpparentObjOccEff  %s  cpobjOccEff  %s \n",cpparentObjFindNo,cpObjFindNo,cpparentObjOccEff,cpobjOccEff);

							   	 if((tc_strcmp(cpparentObjOccEff,cpobjOccEff)==0) && (tc_strcmp(cpparentObjFindNo,cpObjFindNo)==0 ))
							   	   {
							   		  // printf("\n>>>>> MOVE - Updating MBOM transferred to QAD: BOM Line =%s REV ID=%s Type=%s \n", cpMfgItemID, cpMfgRevID, cpObjectType );
							   		 EMH_store_error(EMH_severity_error, ErrorBOMLineCutRestrict);
							   		   return ErrorBOMLineCutRestrict;
                                   }else
							       {
								      printf("\n Able to Cut, occ_effectivity and find no not match  \n");
    						       }

					 	      }


				       }
	   			        else
	   			           {TC_write_syslog("\n>>>>> Updating MBOM NOT transferred to QAD: BOM Line =%s REV ID=%s Type=%s \n", cpMfgItemID, cpMfgRevID, cpObjectType ); }
			 }
						NG5_MEM_TCFREE(cpparentObjOccEff);
						 NG5_MEM_TCFREE(cpparentObjFindNo);
						 NG5_MEM_TCFREE(cpchildMfgRevID);
						 ITKCALL(BOM_refresh_window	(bom_window));
						ITKCALL(BOM_close_window(bom_window));
						 NG5_MEM_TCFREE(cpMfgRevIDa);
				   }

			 


		}
		}

			printf("\n At last portion  \n");
											 NG5_MEM_TCFREE(cpMfgItemID);
					                         	 NG5_MEM_TCFREE(cpMfgRevID);
											NG5_MEM_TCFREE(cpobjOccEff);
											 NG5_MEM_TCFREE(cpparentname);
											//NG5_MEM_TCFREE(ParentItemID);
						// NG5_MEM_TCFREE(tBaselineMfgItemRevTags);
											
						 NG5_MEM_TCFREE(cpObjFindNo);
						
						
						 
						
						
						// NG5_MEM_TCFREE(tChildBOMLines);




	}


    NG5_MEM_TCFREE(cpObjectType);

	TC_write_syslog("\n >>>>>  Exiting Ng5_BOMLine_cut_restrict\n");

	return iFail;

}
