//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_propagateInfoOnRelate
 *
 */
 
#ifndef NG5_PROPAGATEINFOONRELATE_HXX
#define NG5_PROPAGATEINFOONRELATE_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>

#include <string.h>
#include <sstream>

using namespace std;
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_propagateInfoOnRelate(METHOD_message_t* msg, va_list args);

int ng5_copyParticipant(tag_t sourceObject, tag_t targetObject, string strPrefValue, logical lAlreadyHasRelation);
int ng5_checkProperty(tag_t sourceObject, tag_t targetObject, string strPropName);
int ng5_copyProperty(tag_t tSourceObject, tag_t  tTargetObject, string strPropName);
int ng5_copyRelations(tag_t sourceObject, tag_t targetObject,  string strRelationName , int isTargetSec);
tag_t* ng5_getRelatedObjects(tag_t tObject , string strRelationName , int *iRelatedObjectsCount , int* isTargetSec );
void ng5_propagate_errors( int status, string errorText, int clearErrors );
int ng5_remove_participants(tag_t tTargetObject, string strParticipant);
int ng5_update_participants(tag_t tSourceObject, tag_t tTargetObject, string strParticipant );
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>


                
#endif  // NG5_PROPAGATEINFOONRELATE_HXX
