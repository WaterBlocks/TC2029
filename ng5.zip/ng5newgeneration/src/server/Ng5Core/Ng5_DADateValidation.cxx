//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
* @file
*
*   This file contains the implementation for the Extension Ng5_DADateValidation
/// Ng5_DADateValidation extension pre-condition code 
/// @Author - Somashekar M
/// This extesnion will be called when DARevision is saved.
/// DARevision Start Date and End Date validation is checked 
///
*
*/
#include <Ng5Core/Ng5_DADateValidation.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <fclasses/tc_date.h>

int Ng5_DADateValidation( METHOD_message_t * /*msg*/, va_list args )
{
	int ifail = ITK_ok;
	tag_t tDARev = NULLTAG;
	date_t dtStartDate;
	date_t dtEndDate;
	int iDiffinMinutes = 0;
	int iStartDateLater = 0;
	char	*cpExtDateVal	=	NULL;

	tDARev = va_arg(args, tag_t);

	try
	{
		ITK(AOM_ask_value_date(tDARev, ATTR_TARGET_START_DATE, &dtStartDate));

		ITK(AOM_ask_value_date(tDARev, ATTR_TARGET_COMPLETION_DATE, &dtEndDate));

		ITK(EPM_get_differenceInDates (dtStartDate,dtEndDate,&iDiffinMinutes));

		ITK(POM_compare_dates(dtStartDate,dtEndDate,&iStartDateLater));


		//Check for Start Date is Later than End Date
		if(iStartDateLater==1)
		{
			ITK( EMH_store_initial_error_s1( EMH_severity_error , ErrorCodeForDADatesValidation2, "Invalid End Date" ));
			ifail = ErrorCodeForDADatesValidation2;
			return ErrorCodeForDADatesValidation2;
		}


		//Check for date difference greater than 90 days(90*24*60)
		if(iDiffinMinutes>129600)
		{
			ITK( EMH_store_initial_error_s1( EMH_severity_error , ErrorCodeForDADatesValidation, "Invalid End Date" ));
			ifail = ErrorCodeForDADatesValidation;
			return ErrorCodeForDADatesValidation;
		}


	}
	catch( ... )
	{
		TC_write_syslog("\n Inside  catch for DA Revision Ng5_DADateValidation\n");
	}

	return 0;

}
