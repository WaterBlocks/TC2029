//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_updateMfgPartID
 *
 *
 *   Sahida Khatun	  		Initial Creation			July 2022
 *   Padma Cherukumilli     Included the Creation of ICE Part Form	Oct 2022
 *
 *
 */
#include <Ng5Core/Ng5_updateMfgPartID.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <string.h>
#include <sstream>
#include <string>
#include "Ng5_CommonUtils.hxx"

int  Ng5_TCTYPE_Create_ICEPF(char * pcTCTypename, char *pcObjName, char *cMfgDesc1, tag_t *tCreatedObjTag);

/* Function Name   : Ng5_updateMfgPartID
 * Description     : Post Action on IMAN_save of Manufacturing Part to Update Item ID with M-, Plant Code , Suffix  
 * Creation History: Sahida Khatun  (initial Craetion  -July 2022)
 * Update          : Padma Cherukumilli (Creation of ICE Part Form - Oct 2022)
 */
int Ng5_updateMfgPartID( METHOD_message_t *msg, va_list args)
{
	TC_write_syslog ("--->>>>> Entering IMAN_SAVE - Ng5_updateMfgPartID---\n");

	int iFail              	  = ITK_ok;
	int iCount				  = 0;
	int nEIPForms             = 0;
	int qry_entry_count       = 1;

	char*   cpPlantCode       = NULL;//MEM FREE
	char*	cpSuffix	      = NULL;//MEM FREE
	char*	cpItemId	      = NULL;//MEM FREE
	char*   cpRevID           = NULL;//MEM Free
	char*   cpHyphenOrigID      = NULL;//MEM_free
	char*   cpUpperCaseSuffix = NULL;
	char*   cpOriginalID    = NULL;
	char*   cMfgDesc1	 = NULL;
	tag_t   tRelICEtype   = NULLTAG;
	tag_t   tICEform      = NULLTAG;
	tag_t   trelation     = NULLTAG;
	tag_t   tSourceMBOM   = NULLTAG;

	char*   cObjectType   = NULL;
	tag_t   query_tag     = NULLTAG;
	char    query_name[QRY_name_size_c+1]   = "Item...";
	char*   cpOrgID    = NULL;
	tag_t*  eipForms      = NULLTAG;

    tag_t tMfgItemRev       = va_arg (args, tag_t);

    tag_t tMfgItem		    = NULLTAG;
    tag_t tSourceIPFPart    = NULLTAG;


	ITKCALL(AOM_ask_value_string( tMfgItemRev, PLANTS, &cpPlantCode ));
	if(tc_strlen(cpPlantCode)==0)
	{
		return ITK_ok;
	}
	ITKCALL(AOM_ask_value_string( tMfgItemRev, ATTR_ITEM_REV_ID, &cpRevID ));
	if(tc_strstr(cpRevID,DOT)!=NULL)
	{
		TC_write_syslog ("--->>>>> Baseline Revision Id %s",cpRevID);
		return ITK_ok;
	}

	ITKCALL(AOM_ask_value_string( tMfgItemRev, SUFFIX, &cpSuffix ));
	ITKCALL(AOM_ask_value_tag(tMfgItemRev,SOURCEMBOM,&tSourceMBOM ));
	TC_write_syslog ("\n--->>>>> Source MBOM %d",tSourceMBOM );
	if(tSourceMBOM!=NULLTAG)
    {
		tag_t tSourceMBOMItem = NULLTAG;
	    ITKCALL(ITEM_ask_item_of_rev(tSourceMBOM,&tSourceMBOMItem));
		NG5_ITK_CALL (GRM_list_secondary_objects_only (tSourceMBOMItem, tRelICEtype, &nEIPForms, &eipForms));
    }
	cpUpperCaseSuffix = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpSuffix))+1);
	for(int iSuffiX =0 ; iSuffiX<tc_strlen(cpSuffix); iSuffiX++)
	{
	        cpUpperCaseSuffix[iSuffiX]= (char)toupper(cpSuffix[iSuffiX]);
	 }
	
    if(tc_strlen(cpUpperCaseSuffix)>0)
    {
	ITKCALL(AOM_refresh(tMfgItemRev,true));
    ITKCALL(AOM_set_value_string(tMfgItemRev, SUFFIX,stripBlanks(cpUpperCaseSuffix)));
    ITKCALL(AOM_save_without_extensions(tMfgItemRev));
    ITKCALL(AOM_refresh(tMfgItemRev,false));
    }

    TC_write_syslog ("\n--->>>>> Upper Case id set %s",cpUpperCaseSuffix);
	ITKCALL(ITEM_ask_item_of_rev(tMfgItemRev, &tMfgItem ));

	NG5_ITK_CALL (AOM_ask_value_string (tMfgItem, ATTR_MFG_DSC, &cMfgDesc1));
	//TC_write_syslog("\n Ng5_updateMfgPartID:cMfgDesc1 %s\n", cMfgDesc1);

	//get the relation type for the ICEPartForm
	NG5_ITK_CALL (GRM_find_relation_type(REL_ICEPARTFORM, &tRelICEtype));

	tag_t*  mipForms = NULLTAG;
	int 	nIPForms = 0;

	//check if MfgPart already has relation with ICEPartForm
    NG5_ITK_CALL (GRM_list_secondary_objects_only (tMfgItem, tRelICEtype, &nIPForms, &mipForms));

    TC_write_syslog("\n Ng5_updateMfgPartID: No of IPFs on Mfg Part %d\n", nIPForms);
	ITKCALL(ITEM_ask_id2(tMfgItem, &cpItemId));
	ITKCALL(AOM_ask_value_string( tMfgItem, ORIGINALID, &cpOriginalID ));
	TC_write_syslog("\n >>>121 cpOriginalID %s\n", cpOriginalID);
//Set Original ID for Stand Alone
	if(tc_strlen(cpOriginalID )==0  || tc_strncasecmp(cpOriginalID,MHYPHEN,2) ==0)
	{
	  if(tc_strncasecmp(cpItemId,MHYPHEN,2) !=0 )
	  {
		ITKCALL(AOM_refresh(tMfgItem,true));
		TC_write_syslog("\n >>>127 cpOriginalID %s\n", cpItemId);
		ITKCALL(AOM_set_value_string(tMfgItem, ORIGINALID, cpItemId));
		ITKCALL(AOM_save_without_extensions(tMfgItem));
		ITKCALL(AOM_refresh(tMfgItem,false));
	 }else
	 {
		 std::string strOrginalId ="";
	     strOrginalId.assign(cpOriginalID);
		 std::istringstream is( strOrginalId );
		 size_t count = 0;
		 std::string line;
		 while ( std::getline( is, line, '-' ) ) ++count;
		 std::size_t pos =  strOrginalId.find_first_of('-');
		 if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
		 pos =  strOrginalId.find_first_of('-');
		 if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
		 if(count>3 && cpUpperCaseSuffix != NULL && tc_strlen(cpUpperCaseSuffix)>0)
		 {
			
			pos = strOrginalId.find_last_of(cpUpperCaseSuffix);
			if(pos != std::string::npos) strOrginalId= strOrginalId.replace(pos-tc_strlen(cpUpperCaseSuffix),(strOrginalId.length()), "");
		 }
		ITKCALL(AOM_refresh(tMfgItem,true));
		TC_write_syslog("\n >>>150 cpOriginalID %s\n",  strOrginalId.c_str());
		ITKCALL(AOM_set_value_string(tMfgItem, ORIGINALID, strOrginalId.c_str()));
		ITKCALL(AOM_save_without_extensions(tMfgItem));
		ITKCALL(AOM_refresh(tMfgItem,false));
	 }

	}
//If Manufacturing Part already has M- i.e it is already renamed

	if (tc_strncasecmp(cpItemId,MHYPHEN,2) ==0 )
	{
		cpHyphenOrigID  = (char*)MEM_alloc(sizeof(char)*(tc_strlen(HYPHEN)+tc_strlen(cpOriginalID))+tc_strlen(HYPHEN)+1);
		tc_strcpy(cpHyphenOrigID, HYPHEN);
		tc_strcat(cpHyphenOrigID,cpOriginalID);
		//tc_strcat(cpHyphenOrigID,HYPHEN);
        if(tc_strstr(cpItemId,cpHyphenOrigID)!= NULL )
        {
			TC_write_syslog("\n>>>>> Update Engineered Part \n");
			Ng5_setMfgItemIDWithPlantCodeSuffix(tMfgItem,tMfgItemRev, cpOriginalID, cpPlantCode, cpSuffix);


		
		}
		else
		{
           TC_write_syslog("\n>>>>> Customer Part ID \n");
           tag_t tRelType    = NULLTAG;
           tag_t* tEBOMITEMs = NULLTAG;
           tag_t  tEBOMRev   = NULLTAG;
           char* cpCustomerPartNUM = NULLTAG;
           char* cpOEMName         = NULLTAG;

           ITKCALL(AOM_ask_value_string( tMfgItemRev, CUSTOMER, &cpOEMName ));


           int   iCount = 0;
           ITKCALL( GRM_find_relation_type(HASPLANTBOM, &tRelType) );
           GRM_list_primary_objects_only(tMfgItemRev,tRelType,&iCount,&tEBOMITEMs);
           if(iCount >0)
           {
           for(int iRelx = 0 ;iRelx <iCount; iRelx++)
           {
        	   Ng5_getRev2CopyFrom(tEBOMITEMs[iRelx],&tEBOMRev);
        	   if(tc_strlen(cpOEMName)>0)
        	   {
        	   Ng5_getMfgCustomPartNum(tEBOMRev,cpOEMName,&cpCustomerPartNUM);
        	   if(tc_strlen(cpCustomerPartNUM)>0)
        		   break;
        	   }
           }
           }
           else
           	{  //If Customer Part ID ,get  the Eng Part to get the Customer Part No
           	     tag_t* tEBOMRevs   = NULL;
           	     tag_t tSecRelType  = NULLTAG;
           	     ITKCALL( GRM_find_relation_type(HASENGPART2MFGPARREV, &tSecRelType) );
           	     GRM_list_secondary_objects_only(tMfgItemRev,tSecRelType,&iCount,&tEBOMRevs);
           	     for(int iRelx = 0 ;iRelx <iCount; iRelx++)
           	      {

           	    	    if(tc_strlen(cpOEMName)>0)
           	    		{
           	    			 	     Ng5_getMfgCustomPartNum(tEBOMRevs[iRelx],cpOEMName,&cpCustomerPartNUM);
           	    			 	      if(tc_strlen(cpCustomerPartNUM)>0)
           	    			 	       break;
           	    	    }
           	      }

           	  NG5_MEM_TCFREE(tEBOMRevs);
           	 }

           if(tc_strlen(cpCustomerPartNUM)>0)
           {
        	   Ng5_setMfgItemIDWithPlantCodeSuffix(tMfgItem,tMfgItemRev,cpCustomerPartNUM, cpPlantCode, cpSuffix);

           }



           NG5_MEM_TCFREE(tEBOMITEMs);
           NG5_MEM_TCFREE(cpCustomerPartNUM);
           NG5_MEM_TCFREE(cpOEMName);



        }



		iFail = QRY_find2 (query_name,&query_tag);

		if(query_tag != NULLTAG)
		{
			ITKCALL(AOM_ask_value_string( tMfgItem, ORIGINALID, &cpOrgID ));
			TC_write_syslog("\n Ng5_updateMfgPartID:cpOriginalID %s\n", cpOrgID);

			tag_t*  aItem	= NULLTAG;
			int nParts = 0;
			logical isRawMaterial   = false;
			logical isPackagingPart =  false;
			char ** entries = NULL;
			entries = (char **)MEM_alloc( sizeof(char*)*1 );
			entries[0] = (char *)MEM_alloc( sizeof(char) * ( tc_strlen(cpItemId)+5 ) );
			tc_strcpy(entries[0], "Item ID");
			char** values = NULL;
			values = (char **)MEM_alloc( sizeof(char*)*1 );
			values[0] = (char *)MEM_alloc( sizeof(char) * ( tc_strlen(cpItemId)+1 ) );
			tc_strcpy(values[0], cpOrgID);

			ITKCALL(QRY_execute (query_tag, qry_entry_count,entries,values, &nParts, &aItem));

			if (nParts != 0)
			{
				TC_write_syslog("\n Ng5_updateMfgPartID: Item found %d\n", nParts);
			 for (int i = 0; i < nParts; i++)
		     {
				NG5_ITK_CALL (AOM_ask_value_string (aItem[i], ATTR_OBJECT_TYPE, &cObjectType));
									//TC_write_syslog("\n Ng5_updateMfgPartID:ObjectType of Item found %s\n", cObjectType);

			   if(tc_strcmp(cObjectType, RAW_MATERIAL) == 0)
			   {
			         NG5_ITK_CALL (GRM_list_secondary_objects_only (aItem[i], tRelICEtype, &nEIPForms, &eipForms));
			         isRawMaterial =true;
			         break;
			   }

		     }

			 if(!isRawMaterial)
			 {

				  for (int i = 0; i < nParts; i++)
				   {			//TC_write_syslog("\n Ng5_updateMfgPartID:ObjectType of Item found %s\n", cObjectType);
				 			NG5_ITK_CALL (AOM_ask_value_string (aItem[i], ATTR_OBJECT_TYPE, &cObjectType));
				 		    if(tc_strcmp(cObjectType, PKG_PART) == 0)
				 		    {
				 				 NG5_ITK_CALL (GRM_list_secondary_objects_only (aItem[i], tRelICEtype, &nEIPForms, &eipForms));
				 		         isPackagingPart =true;
				 				 break;
				 		    }
				   }
			    if(!isPackagingPart)
			    {
				 for (int i = 0; i < nParts; i++)
				 {		//TC_write_syslog("\n Ng5_updateMfgPartID:ObjectType of Item found %s\n", cObjectType);
					   NG5_ITK_CALL (AOM_ask_value_string (aItem[i], ATTR_OBJECT_TYPE, &cObjectType));
				 	   if(tc_strcmp(cObjectType, ENG_PART) == 0 || tc_strcmp(cObjectType, PHANTOM_PART) == 0)
				 		{
				 			         NG5_ITK_CALL (GRM_list_secondary_objects_only (aItem[i], tRelICEtype, &nEIPForms, &eipForms));
				 			        // isRawMaterial =true;
				 			         break;
				 		}
			        }
			    }
			 }





	            TC_write_syslog("\n Ng5_updateMfgPartID: No of IPFs on Item %d\n", nEIPForms);



					if(nEIPForms ==0)
					{
						TC_write_syslog("\n Ng5_updateMfgPartID: Object type is other");
						if(tSourceMBOM!=NULLTAG)
						{
							tag_t tSourceMBOMItem = NULLTAG;
					                ITKCALL(ITEM_ask_item_of_rev(tSourceMBOM,&tSourceMBOMItem));
						        NG5_ITK_CALL (GRM_list_secondary_objects_only (tSourceMBOMItem, tRelICEtype, &nEIPForms, &eipForms));
						}
					    else
						{
								int n_found = 0;
								tag_t* tExistingMBOM =NULLTAG;
							    Ng5_FindMfgPartWithOriginalID(cpItemId,&n_found,&tExistingMBOM);
								TC_write_syslog("\n No of Mfg Part Found %d:",n_found);
							    for(int iMfgx = 0; iMfgx <n_found;iMfgx++)
								{
									NG5_ITK_CALL (GRM_list_secondary_objects_only(tExistingMBOM[iMfgx], tRelICEtype, &nEIPForms, &eipForms));
									if(nEIPForms>0)
								    {
											tSourceIPFPart = tExistingMBOM[iMfgx];
										    TC_write_syslog("\n IPF tag %d:",eipForms[0]);
											break;
									}
								}

						 }


					}
				}

			else
			{
				if(tSourceMBOM!=NULLTAG)
				{
					tag_t tSourceMBOMItem = NULLTAG;
					ITKCALL(ITEM_ask_item_of_rev(tSourceMBOM,&tSourceMBOMItem));
					NG5_ITK_CALL (GRM_list_secondary_objects_only(tSourceMBOMItem, tRelICEtype, &nEIPForms, &eipForms));
				}
				else
				{
					int n_found = 0;
					tag_t* tExistingMBOM =NULLTAG;
					Ng5_FindMfgPartWithOriginalID(cpOrgID,&n_found,&tExistingMBOM);
					TC_write_syslog("\n No of Mfg Part Found %d:",n_found);
					for(int iMfgx = 0; iMfgx <n_found;iMfgx++)
					{
						NG5_ITK_CALL (GRM_list_secondary_objects_only(tExistingMBOM[iMfgx], tRelICEtype, &nEIPForms, &eipForms));
						if(nEIPForms>0)
						{
							tSourceIPFPart = tExistingMBOM[iMfgx];
                           break;
						}
					}

				}

			}
	}
	}


else
	{
		TC_write_syslog("\n With New ID  %s:",cpItemId);
		TC_write_syslog ("\n--->>>>> New ID : Original ID %s",cpOriginalID);
		ITKCALL(AOM_ask_value_tag(tMfgItemRev,SOURCEMBOM,&tSourceMBOM ));

		iFail = QRY_find2 (query_name,&query_tag);

		if(query_tag != NULLTAG)
		{
			tag_t*  aItem	= NULLTAG;
			int nParts = 0;
			char ** entries = NULL;
			entries = (char **)MEM_alloc( sizeof(char*)*1 );
			entries[0] = (char *)MEM_alloc( sizeof(char) * ( tc_strlen(cpItemId)+5 ) );
			tc_strcpy(entries[0], "Item ID");
			char** values = NULL;
			values = (char **)MEM_alloc( sizeof(char*)*1 );
			values[0] = (char *)MEM_alloc( sizeof(char) * ( tc_strlen(cpItemId)+1 ) );
			tc_strcpy(values[0], cpOriginalID);

			ITKCALL(QRY_execute (query_tag, qry_entry_count,entries,values, &nParts, &aItem));

			if (nParts != 0)
			{
				//TC_write_syslog("\n Ng5_updateMfgPartID: Item found %d\n", nParts);
				logical isRawMaterial = false;
				logical isPackagingPart = false;

				for (int i = 0; i < nParts; i++)
			     {
			          NG5_ITK_CALL (AOM_ask_value_string (aItem[i], ATTR_OBJECT_TYPE, &cObjectType));
				      TC_write_syslog("\n Ng5_updateMfgPartID:ObjectType of Item found %s\n", cObjectType);

					  if(tc_strcmp(cObjectType, RAW_MATERIAL) == 0)
					   {
						  isRawMaterial =true;
						  NG5_ITK_CALL (GRM_list_secondary_objects_only (aItem[i], tRelICEtype, &nEIPForms, &eipForms));

					        TC_write_syslog("\n Ng5_updateMfgPartID: No of IPFs on Item %d\n", nEIPForms);
						    break;
					   }
			     }
				if(!isRawMaterial)
				{
				     for (int i = 0; i < nParts; i++)
				     {
					     NG5_ITK_CALL (AOM_ask_value_string (aItem[i], ATTR_OBJECT_TYPE, &cObjectType));
		                TC_write_syslog("\n Ng5_updateMfgPartID:ObjectType of Item found %s\n", cObjectType);

				        if(tc_strcmp(cObjectType, PKG_PART) == 0)
						{
				        	   isPackagingPart  =true;
							   NG5_ITK_CALL (GRM_list_secondary_objects_only (aItem[i], tRelICEtype, &nEIPForms, &eipForms));

							  TC_write_syslog("\n Ng5_updateMfgPartID: No of IPFs on Item %d\n", nEIPForms);
					          break;
					  }
					}
				}
				if(!isRawMaterial && !isPackagingPart  )
				{


					for (int i = 0; i < nParts; i++)
				   {
					NG5_ITK_CALL (AOM_ask_value_string (aItem[i], ATTR_OBJECT_TYPE, &cObjectType));
					TC_write_syslog("\n Ng5_updateMfgPartID:ObjectType of Item found %s\n", cObjectType);

					if(tc_strcmp(cObjectType, ENG_PART) == 0 || tc_strcmp(cObjectType, RAW_MATERIAL) == 0||tc_strcmp(cObjectType, PHANTOM_PART) == 0)
					{
					    NG5_ITK_CALL (GRM_list_secondary_objects_only (aItem[i], tRelICEtype, &nEIPForms, &eipForms));

					    TC_write_syslog("\n Ng5_updateMfgPartID: No of IPFs on Item %d\n", nEIPForms);
					    if(nEIPForms>0)
					    {
					    	break;
					    }
					}
					else
					{
						TC_write_syslog("\n Ng5_updateMfgPartID: Object type is other");
						if(tSourceMBOM!=NULLTAG)
						{
											tag_t tSourceMBOMItem = NULLTAG;
										    ITKCALL(ITEM_ask_item_of_rev(tSourceMBOM,&tSourceMBOMItem));
										    NG5_ITK_CALL (GRM_list_secondary_objects_only (tSourceMBOMItem, tRelICEtype, &nEIPForms, &eipForms));
					   }
						else
						{
							int n_found = 0;
							tag_t* tExistingMBOM =NULLTAG;
						    Ng5_FindMfgPartWithOriginalID(cpItemId,&n_found,&tExistingMBOM);
						    TC_write_syslog("\n No of Mfg Part Found %d:",n_found);
						    for(int iMfgx = 0; iMfgx <n_found;iMfgx++)
							{
								NG5_ITK_CALL (GRM_list_secondary_objects_only(tExistingMBOM[iMfgx], tRelICEtype, &nEIPForms, &eipForms));
								if(nEIPForms>0)
								{
										tSourceIPFPart = tExistingMBOM[iMfgx];
										TC_write_syslog("\n IPF tag %d:",eipForms[0]);
										break;
								}
							}

						}


					}
				}
			}
			else
			{
				TC_write_syslog("\n Ng5_updateMfgPartID: Item tag empty from query \n");
				if(tSourceMBOM!=NULLTAG)
				{
					tag_t tSourceMBOMItem = NULLTAG;
				    ITKCALL(ITEM_ask_item_of_rev(tSourceMBOM,&tSourceMBOMItem));
				    NG5_ITK_CALL (GRM_list_secondary_objects_only (tSourceMBOMItem, tRelICEtype, &nEIPForms, &eipForms));
				}
				else
				{
					int n_found = 0;
					tag_t* tExistingMBOM =NULLTAG;
					Ng5_FindMfgPartWithOriginalID(cpItemId,&n_found,&tExistingMBOM);
					TC_write_syslog("\n No of Mfg Part Found %d:",n_found);
				    for(int iMfgx = 0; iMfgx <n_found;iMfgx++)
					{
							NG5_ITK_CALL (GRM_list_secondary_objects_only(tExistingMBOM[iMfgx], tRelICEtype, &nEIPForms, &eipForms));
						    if(nEIPForms>0)
							{
								tSourceIPFPart = tExistingMBOM[iMfgx];
								TC_write_syslog("\n IPF tag %d:",eipForms[0]);
				                break;
						   }
					}

					}


		}

			TC_write_syslog("\n>>>>> ITEM ID to be updated for PREFIX, PLANTCODE & SUFFIX \n");
			TC_write_syslog("\n MFG ID =%s",cpItemId );
			Ng5_setMfgItemIDWithPlantCodeSuffix(tMfgItem,tMfgItemRev,cpItemId, cpPlantCode, cpSuffix);
		
	}
		}
	}
    if(nEIPForms == 0 && nIPForms == 0)
    {
        //create ICE part form and attach them to Mfg Part respectively.
        iFail = Ng5_TCTYPE_Create_ICEPF (ICEPART_FORM, cpItemId, cMfgDesc1, &tICEform);

        if(iFail == ITK_ok && tICEform != NULLTAG)
        {
            NG5_ITK_CALL (GRM_find_relation_type (REL_ICEPARTFORM, &tRelICEtype));
            NG5_ITK_CALL (GRM_create_relation (tMfgItem, tICEform, tRelICEtype, NULLTAG, &trelation));
            NG5_ITK_CALL (GRM_save_relation(trelation));
            NG5_ITK_CALL (AOM_refresh(tICEform,true));
            NG5_ITK_CALL (AOM_save_with_extensions(tICEform));
            NG5_ITK_CALL (AOM_refresh(tICEform,false));
        }
        else
        {
        	TC_write_syslog("\n Ng5_updateMfgPartID: ICEPartForm not created\n");

        }
    }
    else
    {
    	if(tSourceMBOM!=NULLTAG)
    	{

    		
    		Ng5_CopyProps(tMfgItemRev,tSourceMBOM);
    	 }
    	else
    	{
    		tag_t tIPFRel=NULLTAG;
    		if(nIPForms == 0)
    		{
    		 NG5_ITK_CALL(GRM_find_relation(tMfgItem,eipForms[0],tRelICEtype,&tIPFRel));
    		TC_write_syslog("\n IPF tag Relation check ");
    		if(tIPFRel == NULLTAG)
            {
                   GRM_create_relation(tMfgItem,eipForms[0],tRelICEtype,NULLTAG,&tIPFRel);
                   GRM_save_relation(tIPFRel);
    		}
    		TC_write_syslog("\n IPF relation Tag %d:",tIPFRel);
    		}
    		TC_write_syslog("\n IPF relation Tag is null");
    	}
    }

	

	NG5_MEM_TCFREE(cpPlantCode);
	NG5_MEM_TCFREE(cpSuffix);
	NG5_MEM_TCFREE(cpItemId);
	NG5_MEM_TCFREE(cpOriginalID);
	NG5_MEM_TCFREE(cpRevID);
	NG5_MEM_TCFREE(cpHyphenOrigID);
	//NG5_MEM_TCFREE(cpUpperCaseSuffix);
	//NG5_MEM_TCFREE(cpMfgIdStr);
	NG5_MEM_TCFREE(cMfgDesc1);
	NG5_MEM_TCFREE(eipForms);
	NG5_MEM_TCFREE(cpOrgID);
	NG5_MEM_TCFREE(cObjectType);
	TC_write_syslog ("--->>>>> Exiting IMAN_SAVE - Ng5_updateMfgPartID---\n");

 	return iFail;

}

/**********************************************************************************
 **  Function Name: Ng5_TCTYPE_Create_ICEPF
 **  Parameters:
 **     char*  pcTCTypename (I)
 **     char*  pcObjName    (I)
 **     char*  cMfgDesc1    (I)
 **     tag_t* tCreateObjTag(O)
 **
 **  Description:
 **   Based on input type name, object_name and ng5_mfg_desc provided, it creates the ICE Part Form
 **   and also sets the value of object_name and ng5_mfg_desc with provided input pcObjName.
***********************************************************************************/
int  Ng5_TCTYPE_Create_ICEPF(char * pcTCTypename, char *pcObjName, char *cMfgDesc1, tag_t *tCreatedObjTag)
{

    int    iFail           = ITK_ok;
    tag_t  tTypeTag        = NULLTAG;
    tag_t  tCreateInputTag = NULLTAG;

    TC_write_syslog("\n Update_MfgPart : Entering Ng5_TCTYPE_Create_ICEPF\n");

    //Find type tag to construct create input
    NG5_ITK_CALL(TCTYPE_find_type ( pcTCTypename, NULL, &tTypeTag )) ;
    NG5_ITK_CALL(TCTYPE_construct_create_input ( tTypeTag, &tCreateInputTag)) ;

    if ( iFail == ITK_ok && tCreateInputTag != NULLTAG )
    {
        TC_write_syslog("\n Entering Ng5_TCTYPE_Create_ICEPF: Creating ICE Part Form\n");

        NG5_ITK_CALL(AOM_set_value_string ( tCreateInputTag, OBJECT_NAME, pcObjName )) ;
        NG5_ITK_CALL(AOM_set_value_string ( tCreateInputTag, ATTR_MFG_DSC, cMfgDesc1 )) ;
        NG5_ITK_CALL(TCTYPE_create_object ( tCreateInputTag, tCreatedObjTag )) ;

        if ( *tCreatedObjTag != NULLTAG )
        {
        //TC_write_syslog("\n Entering Ng5_TCTYPE_Create_Object: Saving Form\n");
        AOM_save_with_extensions ( *tCreatedObjTag ) ;//TC 12 Upgrade
        }
    }
    TC_write_syslog("\n Exiting Ng5_TCTYPE_Create_ICEPF\n");
    return iFail;
}

/* Function Name   : Ng5_setMfgItemIDWithPlantCodeSuffix
 * Description     : Function to Update Item ID with Plant Code and Suffix  
 * Creation History: Sahida Khatun  -initial Creation  -July 2022
 */
int Ng5_setMfgItemIDWithPlantCodeSuffix(tag_t tItem,tag_t tItemRev, char *cpItemId, char *cpPlantCode, char *cpSuffix)
{

	int	iFail              			= ITK_ok;

	char *cpMfgItemId 				= NULL;
	char *cpUpperCaseSuffix         = NULL;
	char *cpExistingMfgID           = NULL;


	if (tc_strlen(cpSuffix) > 0)
	{


		//transform(cpSuffix.begin(), cpSuffix.end(), cpSuffix.begin(), ::toupper);
		cpUpperCaseSuffix = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpSuffix))+1);
        for(int iSuffiX =0 ; iSuffiX<tc_strlen(cpSuffix); iSuffiX++)
        {

        	cpUpperCaseSuffix[iSuffiX]= (char)toupper(cpSuffix[iSuffiX]);
        }
		//tc_strupr(stripBlanks(cpSuffix),&cpUpperCaseSuffix);
        TC_write_syslog("\n Suffix Converted to UpperCase: %s\n", stripBlanks(cpUpperCaseSuffix));
		cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantCode)+tc_strlen(HYPHEN)+tc_strlen(cpItemId)+ tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);
		tc_strcpy(cpMfgItemId, MHYPHEN);
		tc_strcat(cpMfgItemId, cpPlantCode);
		tc_strcat(cpMfgItemId, HYPHEN);
		tc_strcat(cpMfgItemId, cpItemId);
		tc_strcat(cpMfgItemId, HYPHEN);
		tc_strcat(cpMfgItemId,stripBlanks(cpUpperCaseSuffix));
		TC_write_syslog("\n Item ID with Suffix: %s\n", cpMfgItemId);
	}
	else
	{
		cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cpPlantCode)+tc_strlen(HYPHEN)+tc_strlen(cpItemId))+1);
		tc_strcpy(cpMfgItemId, MHYPHEN);
		tc_strcat(cpMfgItemId, cpPlantCode);
		tc_strcat(cpMfgItemId,HYPHEN);
		tc_strcat(cpMfgItemId, cpItemId);
		TC_write_syslog("\n Item ID without Suffix: %s\n", cpMfgItemId);
	}

	AOM_ask_value_string(tItem, ATTR_ITEM_ID, &cpExistingMfgID);
	//Baseline Fix
   // if(tc_strcmp(cpMfgItemId,cpExistingMfgID)!=0)
   // {
       AOM_refresh(tItem, TRUE);
       AOM_set_value_string(tItem, ATTR_ITEM_ID, cpMfgItemId);
    

      AOM_save_without_extensions(tItem);
      AOM_refresh(tItem, false);
    //}
	Ng5_setBVRName(tItem,tItemRev);

    NG5_MEM_TCFREE(cpMfgItemId);
    NG5_MEM_TCFREE(cpExistingMfgID);
    //NG5_MEM_TCFREE(cpUpperCaseSuffix);
	return iFail;


}

int  Ng5_FindMfgPartWithOriginalID(char* cpOrgID,int* n_found,tag_t** tExistingMBOM)
{

	tag_t*  aItem	= NULLTAG;
	tag_t   tQuery  = NULLTAG;
	int nParts = 0;
	int iFail = ITK_ok;
	char ** entries = NULL;

	entries = (char **)MEM_alloc( sizeof(char*)*1 );
	entries[0] = (char *)MEM_alloc( sizeof(char) * ( tc_strlen("Original Item ID")+5 ) );
	tc_strcpy(entries[0], "Original Item ID");
	char** values = NULL;
	values = (char **)MEM_alloc( sizeof(char*)*1 );
	values[0] = (char *)MEM_alloc( sizeof(char) * ( tc_strlen(cpOrgID)+1 ) );
	tc_strcpy(values[0], cpOrgID);
	iFail = QRY_find2	("Manufacturing Part",&tQuery);
	ITKCALL(QRY_execute (tQuery, 1,entries,values, &nParts, &aItem));
	*n_found =nParts;
	*tExistingMBOM = aItem;
	return iFail;

}


