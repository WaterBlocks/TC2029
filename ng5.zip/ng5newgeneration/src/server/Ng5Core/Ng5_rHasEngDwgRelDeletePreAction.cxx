//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasEngDwgRelDeletePreAction
 *   Function will get called whenever the Relationship between Engineered Part/Support Part Design
 *   and Drawing Revision is removed with the Relation HasEngDwg.
 *   It checks for the Engineering Part/Support Part Design attached to Drawing Revision typed
 *   reference property ng5_nxdwglink_parts. If yes then removes the  Engineered Part Revision
 *   /Support Part Design from this property.
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   07/05/2017  Rampaul Jayapaul  Initial Version
 *   07/05/2021  Balaji            TC12 Upgrade
 */
#include <Ng5Core/Ng5_rHasEngDwgRelDeletePreAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_rHasEngDwgRelDeletePreAction(METHOD_message_t* msg, va_list args)
{

	int iFail = ITK_ok;
	tag_t 	tRelation 	=	NULLTAG;


	TC_write_syslog("\n Entering Ng5_rHasEngDwgRelDeletePostAction \n");
	tRelation = msg->object_tag; // Get Relationship tag

	if (NULLTAG != tRelation)
	{
		tag_t tPartRev = NULLTAG;
		tag_t tDrawingRev = NULLTAG;

		// Get Primary object
		//Drawing Revision in case of NX
		ITK( GRM_ask_primary( tRelation, &tPartRev ));

		//Get Secondary object - EngineeredPart
		ITK( GRM_ask_secondary( tRelation, &tDrawingRev ));


		if (NULLTAG != tPartRev && NULLTAG != tDrawingRev)
		{

			char *cpPrimObjClassName = NULL;
			char *cpSecObjClassName = NULL;
			tag_t tPrimType = NULLTAG;
			tag_t tSecType = NULLTAG;


			ITK( TCTYPE_ask_object_type( tPartRev, &tPrimType ));
			if (tPrimType != NULLTAG)
			{
				ITK( TCTYPE_ask_class_name2 ( tPrimType,&cpPrimObjClassName));
			}
			ITK( TCTYPE_ask_object_type( tDrawingRev, &tSecType ));
			if (tSecType != NULLTAG)
			{
				ITK( TCTYPE_ask_class_name2 ( tSecType,&cpSecObjClassName));
			}

			if (NULL != cpPrimObjClassName && NULL != cpSecObjClassName)
			{
				// Allow only if the primary object is Engineered Part Revision and
				// Secondary Object is Drawing Revision

				if ( ((tc_strcmp(cpPrimObjClassName, ITEM_ENGINEERED_PART_REVISION) == 0) ||
						(tc_strcmp(cpPrimObjClassName, ITEM_SUPPORT_DESIGN_REVISION) == 0)) &&
						(tc_strcmp(cpSecObjClassName, ITEM_ENGINEERED_DRAWING_REVISION) == 0))
				{
					int numofEngPrt = 0;

					tag_t *tagPrtValues = NULLTAG;

					logical engPartExist = false;

					logical	lPriVerdict	=	false;

					ITK( AM_check_privilege (tDrawingRev, ACCESS_WRITE, &lPriVerdict) ); //Allow only if the logged in user has write access to Primary object

					if (true == lPriVerdict)
					{
						NG5_ITK_CALL(
								AOM_ask_value_tags(tDrawingRev,NX_DWG_TO_ENGPART,&numofEngPrt,&tagPrtValues));
						//Checking if the Part count is more than 0
						if (numofEngPrt > 0 && tagPrtValues != NULL)
						{
							for (int indxEngPrt = 0; indxEngPrt < numofEngPrt;indxEngPrt++)
							{
								//Checking if the Engineered Part is already attached to Drawing Property
								if (tagPrtValues[indxEngPrt] == tPartRev)
								{
									NG5_ITK_CALL(AOM_refresh(tDrawingRev,TRUE));
									NG5_ITK_CALL(AOM_set_value_tag_at(tDrawingRev,NX_DWG_TO_ENGPART,indxEngPrt, NULL));
									NG5_ITK_CALL(AOM_save_with_extensions(tDrawingRev));//TC 12 Upgrade
									NG5_ITK_CALL(AOM_refresh(tDrawingRev,FALSE));
									if (iFail != ITK_ok)
									{
										return iFail;
									}
									break;
								}
							}

						}

					}
					MEM_free(tagPrtValues);
				}
			}
			MEM_free(cpPrimObjClassName);
			MEM_free(cpSecObjClassName);
		}
	}
	return iFail;

}
