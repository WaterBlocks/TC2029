//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasDerivedFromRelDeletePreAction
 *   Function will get called whenever the 'Has Derived From' Relation is deleted between Engineered Part Rev
 *   and Engineered Part Rev & the typed reference property ng5_derived_from_parts gets updated by removing the Engineered Part Rev
 *   from this property.
 *   Similarly, it will work  whenever the 'Has Derived From' Relation is deleted between Raw Material Rev
 *   and Raw Material Rev.
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   05/31/2018  Meenakshi Shenoy  Initial Version
 *   07/05/2021  Balaji            TC12 Upgrade
 */
#include <Ng5Core/Ng5_rHasDerivedFromRelDeletePreAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_rHasDerivedFromRelDeletePreAction(METHOD_message_t* msg, va_list args) {

	int iFail = ITK_ok;
	tag_t tRelation = NULLTAG;

	TC_write_syslog("\n Entering Ng5_rHasDerivedFromRelDeletePreAction \n");

	// Get Relationship tag
	tRelation = msg->object_tag;

	if (NULLTAG != tRelation) {
		tag_t tPartRev = NULLTAG;
		tag_t tEngRev = NULLTAG;

		NG5_ITK_CALL(GRM_ask_primary(tRelation, &tPartRev));

		NG5_ITK_CALL(GRM_ask_secondary(tRelation, &tEngRev));

		if (NULLTAG != tPartRev && NULLTAG != tEngRev) {

			int numofEngPrt = 0;

			tag_t *tagPrtValues = NULLTAG;

			logical engPartExist = false;

			logical lPriVerdict = false;


			NG5_ITK_CALL(AOM_ask_value_tags(tEngRev, DERIVED_FROM_PARTS, &numofEngPrt, &tagPrtValues));
			//Checking if the Part count is more than 0
			if (numofEngPrt > 0 && tagPrtValues != NULL) {
				for (int indxEngPrt = 0; indxEngPrt < numofEngPrt;
						indxEngPrt++) {
					//Checking if the Engineered Part is already attached to Drawing Property
					if (tagPrtValues[indxEngPrt] == tPartRev) {
						NG5_ITK_CALL(AM_check_privilege(tEngRev, ACCESS_WRITE, &lPriVerdict)); //Allow only if the logged in user has write access to Primary object

						if (true == lPriVerdict) {

							NG5_ITK_CALL(AOM_refresh(tEngRev, TRUE));
							NG5_ITK_CALL(AOM_set_value_tag_at(tEngRev,DERIVED_FROM_PARTS, indxEngPrt, NULL));
							TC_write_syslog("\n Setting Property ng5_derived_from_parts \n");
							NG5_ITK_CALL(AOM_save_with_extensions(tEngRev));//TC 12 Upgrade
							NG5_ITK_CALL(AOM_refresh(tEngRev, FALSE));



							if (iFail != ITK_ok) {
								return iFail;
							}

						}
						else
						{
							logical lPriVerdict1 = false;
							// if the part is released, bypass is set to update the property
							AM__set_application_bypass(true);
							NG5_ITK_CALL(AM_check_privilege(tEngRev, ACCESS_WRITE, &lPriVerdict1));
							if (lPriVerdict1) {
								TC_write_syslog("\n access obtained \n");
								NG5_ITK_CALL(AOM_refresh(tEngRev, TRUE));
								NG5_ITK_CALL(AOM_set_value_tag_at(tEngRev,DERIVED_FROM_PARTS, indxEngPrt, NULL));
								TC_write_syslog("\n Setting Property ng5_derived_from_parts \n");
								NG5_ITK_CALL(AOM_save_with_extensions(tEngRev));//TC 12 Upgrade
								NG5_ITK_CALL(AOM_refresh(tEngRev, FALSE));
							}
							else
							{
								TC_write_syslog("\n access not obtained \n");
							}
							AM__set_application_bypass(false);

						}
					}

				}
			}

			TC_write_syslog("\n Leaving Ng5_rHasDerivedFromRelDeletePreAction \n");
			MEM_free(tagPrtValues);

		}



	}

	return iFail;
}
