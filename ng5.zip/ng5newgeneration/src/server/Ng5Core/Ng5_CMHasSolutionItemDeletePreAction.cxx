//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file
 *
 *   This file contains the implementation for the Extension Ng5_CMHasSolutionItemDeletePreAction
 *   Function will get called whenever Eng Part Rev & Raw Material Rev are detached from Solutions folder present under Design Freeze Change Object.
 *   It checks for the  Eng Part Rev & Raw Material Rev detached from Solutions folder present under Design Freeze Change Object & the property
 *   ng5_DesignFreeze on Eng Part Rev & Raw Material Rev gets updated.
 *
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   09/26/2018  Meenakshi Shenoy  Initial Version
 *
 */
#include <Ng5Core/Ng5_CMHasSolutionItemDeletePreAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_removePartRevfromDFRev(tag_t tPartRev, tag_t tDsgnFrzRev);

int Ng5_setDFPropertyValue(tag_t tPartRev, int indxDsgnFrzRev);

int Ng5_CMHasSolutionItemDeletePreAction(METHOD_message_t* msg, va_list args) {

	int iFail = ITK_ok;
	tag_t tRelation = NULLTAG;

	TC_write_syslog("\n Entering Ng5_CMHasSolutionItemDeletePreAction \n");

	// Get Relationship tag
	tRelation = msg->object_tag;

	if (NULLTAG != tRelation) {
		tag_t tDsgnFrzRev = NULLTAG;
		tag_t tPartRev = NULLTAG;

		NG5_ITK_CALL(GRM_ask_primary(tRelation, &tDsgnFrzRev));

		NG5_ITK_CALL(GRM_ask_secondary(tRelation, &tPartRev));

		if (NULLTAG != tDsgnFrzRev && NULLTAG != tPartRev) {

			char* cObjectType = NULL;
			/*Added check to verify object type = Eng Part rev or Raw Material rev only.
			For rest of the types, code will skip the execution.*/
			NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));

			TC_write_syslog("\n object type is %s\n", cObjectType);
			if(tc_strcmp(cObjectType, ENG_PART_REVISION) == 0 ||tc_strcmp(cObjectType, RAW_MATERIAL_REVISION) == 0 )
			{
				iFail = Ng5_removePartRevfromDFRev(tPartRev, tDsgnFrzRev);

				}
			MEM_TCFREE(cObjectType);

			}

			TC_write_syslog("\n Leaving Ng5_CMHasSolutionItemDeletePreAction \n");

		}


	return iFail;
}

/**
 * Function Name 	:	Ng5_setPropertyValue
 * Description		:	This function sets the ng5_DesignFreeze property value
 * Parameters		:	tPartRev Tag of Secondary (I)
 * 						indxDsgnFrzRev Index number(I)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 * 10/05/2018 	|			|	Meenakshi Shenoy	|	1. Added this function as part of restructuring this extension code
 *
 */
int Ng5_setDFPropertyValue(tag_t tPartRev, int indxDsgnFrzRev)
{
	int iFail = ITK_ok;
	NG5_ITK_CALL(AOM_refresh(tPartRev, TRUE));
	NG5_ITK_CALL(AOM_set_value_tag_at(tPartRev,DESIGN_FREEZE_PROPERTY, indxDsgnFrzRev, NULL));
	TC_write_syslog("\n Setting Property ng5_DesignFreeze \n");
	NG5_ITK_CALL(AOM_save(tPartRev));
	NG5_ITK_CALL(AOM_refresh(tPartRev, FALSE));

	return iFail;

}

/**
 * Function Name 	:	Ng5_removePartRevfromDFRev
 * Description		:	This function checks whether DF rev is attached to Part Rev & also checks for the access on Part Rev.
 * Parameters		:	tPartRev Tag of Secondary (I)
 *                      tDsgnFrzRev Tag of Primary (I)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 * 10/08/2018 	|			|	Meenakshi Shenoy	|	1. Added this function as part of restructuring this extension code
 *
 */

int Ng5_removePartRevfromDFRev(tag_t tPartRev, tag_t tDsgnFrzRev)
{
	int iFail = ITK_ok;
	int numofdsgnfrzrevs = 0;

					tag_t *tagtDsgnFrzRevs = NULLTAG;

					logical tDsgnFrzRevexist = false;

					logical lPriVerdict = false;


					NG5_ITK_CALL(AOM_ask_value_tags(tPartRev, DESIGN_FREEZE_PROPERTY, &numofdsgnfrzrevs, &tagtDsgnFrzRevs));
					//Checking if the DF Rev count is more than 0
					if (numofdsgnfrzrevs > 0 && tagtDsgnFrzRevs != NULL) {
						for (int indxDsgnFrzRev = 0; indxDsgnFrzRev < numofdsgnfrzrevs;
								indxDsgnFrzRev++) {
							//Checking if the DF Rev is already attached to ng5_DesignFreeze Property
							if (tagtDsgnFrzRevs[indxDsgnFrzRev] == tDsgnFrzRev)
							{

								NG5_ITK_CALL(AM_check_privilege(tPartRev, ACCESS_WRITE, &lPriVerdict));
								//Allow only if the logged in user has write access to Primary object

															if (true == lPriVerdict) {
																iFail = Ng5_setDFPropertyValue(tPartRev, indxDsgnFrzRev);


																if (iFail != ITK_ok) {
																	return iFail;
																}
															}
							}

						}
					}
					MEM_TCFREE(tagtDsgnFrzRevs);
					return iFail;
}
