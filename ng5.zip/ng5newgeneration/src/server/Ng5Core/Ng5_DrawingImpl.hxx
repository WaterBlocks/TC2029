/*********************************************************************************************
** File Name:         Ng5_DrawingImpl.hxx
**
** File Description:
** This file contains declaration for overriding finalizecreateinput method
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- ------------------------
**   12/28/2016	 Shibabrata 	declaration for overriding finalizecreateinput method
*********************************************************************************************/

#ifndef NG5NEWGENERATION__NG5_DRAWINGIMPL_HXX
#define NG5NEWGENERATION__NG5_DRAWINGIMPL_HXX

#include <Ng5Core/Ng5_DrawingGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_DrawingImpl; 
    class Ng5_DrawingDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_DrawingImpl
    : public ng5newgeneration::Ng5_DrawingGenImpl
{
public:


    ///
    /// Description for the Finalize Create Input
    /// @param creInput - desc for  creInput parameter
    /// @return - Return desc for Initialize for Create
    ///
    int  finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a Ng5_Drawing
    explicit Ng5_DrawingImpl( Ng5_Drawing& busObj );

    ///
    /// Destructor
    virtual ~Ng5_DrawingImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_DrawingImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_DrawingImpl( const Ng5_DrawingImpl& );

    ///
    /// Copy constructor
    Ng5_DrawingImpl& operator=( const Ng5_DrawingImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_DrawingDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_DRAWINGIMPL_HXX
