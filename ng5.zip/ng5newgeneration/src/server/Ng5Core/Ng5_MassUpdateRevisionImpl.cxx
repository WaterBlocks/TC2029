//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_MassUpdateRevisionImpl
//

#include <Ng5Core/Ng5_MassUpdateRevisionImpl.hxx>
#include <Ng5Core/Ng5_linkEBOMToPlantMBOM.hxx>

#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include <tc/tc.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include<time.h>
#define NG5_EFFECTIVE_DATE           "ng5_Effective_Date"

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_MassUpdateRevisionImpl::Ng5_MassUpdateRevisionImpl(Ng5_MassUpdateRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_MassUpdateRevisionImpl::Ng5_MassUpdateRevisionImpl( Ng5_MassUpdateRevision& busObj )
   : Ng5_MassUpdateRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_MassUpdateRevisionImpl::~Ng5_MassUpdateRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_MassUpdateRevisionImpl::~Ng5_MassUpdateRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_MassUpdateRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_MassUpdateRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_MassUpdateRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// Description for the Finalize Create Input
/// @param creInput - desc for  creInput parameter
/// @return - Return desc for Initialize for Create
///
int  Ng5_MassUpdateRevisionImpl::finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput )
{
    int ifail 						= ITK_ok;
    int result 						= 2;

	date_t	dStartDate	    		= NULLDATE;
	date_t	dEndDate	    		= NULLDATE;
	date_t	deffectiveDate	    	= NULLDATE;
	date_t 	setstartdate 			= NULLDATE;
	date_t setenddate 				= NULLDATE;
	date_t seteffectivedate 		= NULLDATE;
	date_t start_eff_apac_value		= NULLDATE;
	date_t currentTime = NULLDATE;

	bool    isMassUpdateTypeNull 	= true;
    bool    isStartDateNull     	= true;
    bool    isEndDateNull     		= true;
    bool    isEffectiveDateNull     = true;

    tag_t tCurrentGroupmember		= NULLTAG;
    tag_t tCurrentGroup 			= NULLTAG;

    char * szCurrentGroupName 		= NULL;
    char * start_date_str			= NULL;
    char * end_date_str				= NULL;
    char * effective_date_str		= NULL;
    char * current_date_str			= NULL;
    char * Plant 					= NULL;
    char * timestamp				= NULL;

    std::string start;
    std::string end;
    std::string effective;
    std::string cptokendigit;
	std::string sMassUpdateType;

    // Your Implementation
    TC_write_syslog("Entering method Ng5_MassUpdateRevisionImpl finalizeCreateInputBase \n");

	 ifail = super_finalizeCreateInputBase(  creInput );
	//getting group from session
	ITK( SA_ask_current_groupmember  ( &tCurrentGroupmember ) );
	if ( tCurrentGroupmember != NULLTAG )
	{
		ITK( SA_ask_groupmember_group  ( tCurrentGroupmember, &tCurrentGroup ) );
		ITK( SA_ask_group_full_name (tCurrentGroup, &szCurrentGroupName) );
		cptokendigit=tc_strtok(szCurrentGroupName,".");
		creInput->setString("ng5_Plants",cptokendigit,false);
	 }

	creInput->getString(NG5_MASS_UPDATE_TYPE,  sMassUpdateType, isMassUpdateTypeNull);
	creInput->getDate(NG5_START_EFFECTIVITY, dStartDate,isStartDateNull);
	creInput->getDate(NG5_END_EFFECTIVITY, dEndDate,isEndDateNull);
	creInput->getDate(NG5_EFFECTIVE_DATE, deffectiveDate,isEffectiveDateNull);

	Plant = (char *)MEM_alloc (((int)tc_strlen(cptokendigit.c_str())+1)* sizeof(char) );
	tc_strcpy ( Plant, cptokendigit.c_str());

	if(!isStartDateNull)
	{
		if (Ng5_isPlantTZ_GT_ServTRZ(Plant))
		{
		start_eff_apac_value = getTomorrowDate(dStartDate);
		DATE_date_to_string(start_eff_apac_value,"%d-%b-%y",&start_date_str);
		TC_write_syslog("\n Start Effectivity APAC Date= %s  \n",start_date_str);
		start.append(start_date_str);
		start.append(" 12:00");
		ITK_string_to_date(start.c_str(),&setstartdate);
		creInput->setDate(NG5_START_EFFECTIVITY ,setstartdate, false);
		}
		else
		{
			DATE_date_to_string(dStartDate,"%d-%b-%y",&start_date_str);
			TC_write_syslog("\n Start Effectivity APAC Date= %s  \n",start_date_str);
			start.append(start_date_str);
			start.append(" 12:00");
			ITK_string_to_date(start.c_str(),&setstartdate);
			creInput->setDate(NG5_START_EFFECTIVITY ,setstartdate, false);
		}
	}

	if(!isEndDateNull)
	{
		if (Ng5_isPlantTZ_GT_ServTRZ(Plant))
		{
			start_eff_apac_value = getTomorrowDate(dEndDate);
			DATE_date_to_string(start_eff_apac_value,"%d-%b-%y",&end_date_str);
			TC_write_syslog("\n End Effectivity APAC Date= %s  \n",end_date_str);
			end.append(end_date_str);
			end.append(" 12:00");
			ITK_string_to_date(end.c_str(),&setenddate);
			creInput->setDate(NG5_END_EFFECTIVITY ,setenddate, false);
		}
		else
		{
			DATE_date_to_string(dEndDate,"%d-%b-%y",&end_date_str);
			TC_write_syslog("\n End Effectivity APAC Date= %s  \n",end_date_str);
			end.append(end_date_str);
			end.append(" 12:00");
			ITK_string_to_date(end.c_str(),&setenddate);
			creInput->setDate(NG5_END_EFFECTIVITY ,setenddate, false);
		}

	}
	else
	{
		if(tc_strcmp(sMassUpdateType.c_str(),NG5_ADD)==0 || tc_strcmp(sMassUpdateType.c_str(),NG5_ADD_WITH_SIBLING)==0 ||tc_strcmp(sMassUpdateType.c_str(),NG5_REPLACE)==0)
		{
			TC_write_syslog("\n End Effectivity for Up= %s  \n",Ng5_UP_DATE);
			end.append(Ng5_UP_DATE);
			ITK_string_to_date(end.c_str(),&setenddate);
			creInput->setDate(NG5_END_EFFECTIVITY ,setenddate, false);
			TC_write_syslog("\n line 189= \n");
		}
	}

	TC_write_syslog("\n line 189= \n");
	if(!isEffectiveDateNull)
	{
		if (Ng5_isPlantTZ_GT_ServTRZ(Plant))
		{

			start_eff_apac_value = getTomorrowDate(deffectiveDate);
			DATE_date_to_string(start_eff_apac_value,"%d-%b-%y",&effective_date_str);
			TC_write_syslog("\n Effective APAC Date= %s  \n",effective_date_str);
			effective.append(effective_date_str);
			effective.append(" 12:00");
			ITK_string_to_date(effective.c_str(),&seteffectivedate);
			creInput->setDate(NG5_EFFECTIVE_DATE ,seteffectivedate, false);
		}
		else
		{
			DATE_date_to_string(deffectiveDate,"%d-%b-%y",&effective_date_str);
			TC_write_syslog("\n Effective APAC Date= %s  \n",effective_date_str);
			effective.append(effective_date_str);
			effective.append(" 12:00");
			ITK_string_to_date(effective.c_str(),&seteffectivedate);
			creInput->setDate(NG5_EFFECTIVE_DATE ,seteffectivedate, false);
		}
	}
	else
	{
			
		ifail = Ng5_current_get_time_stamp("%d-%b-%y",&current_date_str);
		effective.append(current_date_str);
		effective.append(" 12:00");
		ITK_string_to_date(effective.c_str(),&seteffectivedate);
		creInput->setDate(NG5_EFFECTIVE_DATE ,seteffectivedate, false);
		
	}
	
	if(tc_strcmp(sMassUpdateType.c_str(),NG5_ADD)==0 || tc_strcmp(sMassUpdateType.c_str(),NG5_ADD_WITH_SIBLING)==0)
	{
		if(isStartDateNull)
		{
			EMH_store_initial_error_s1(EMH_severity_error,NG5_NO_START_DATE_SELECTION,"Add Scenario");
			return NG5_NO_START_DATE_SELECTION ;
		}
	}

	if(tc_strcmp(sMassUpdateType.c_str(),NG5_ADD)==0 || tc_strcmp(sMassUpdateType.c_str(),NG5_ADD_WITH_SIBLING)==0 ||tc_strcmp(sMassUpdateType.c_str(),NG5_REPLACE)==0 || tc_strcmp(sMassUpdateType.c_str(),NG5_REMOVE)==0|| tc_strcmp(sMassUpdateType.c_str(),NG5_REMOVE_WITH_SIBLING)==0|| tc_strcmp(sMassUpdateType.c_str(),NG5_MODIFY)==0)
		{

			if(!isStartDateNull && !isEndDateNull)
					{

						POM_compare_dates(dStartDate,dEndDate,&result);
						if(result==1)
						{

						EMH_store_initial_error_s1(EMH_severity_error,NG5_START_END_EFFECTIVITY," ");
						return NG5_START_END_EFFECTIVITY ;
						}
					}
		}

	if(tc_strcmp(sMassUpdateType.c_str(),NG5_REMOVE)==0 || tc_strcmp(sMassUpdateType.c_str(),NG5_REMOVE_WITH_SIBLING)==0)
	{
		if(isEndDateNull)
		{
			EMH_store_initial_error_s1(EMH_severity_error,NG5_NO_END_DATE_SELECTION,"Remove Scenario");
			return NG5_NO_END_DATE_SELECTION ;
		}
	}

	if(tc_strcmp(sMassUpdateType.c_str(),NG5_REPLACE)==0 )
		{
			if( isStartDateNull )
			{
				EMH_store_initial_error_s1(EMH_severity_error,NG5_START_END_DATE_SELECTION,"Replace Scenario");
				return NG5_START_END_DATE_SELECTION ;
			}
		}

	if(tc_strcmp(sMassUpdateType.c_str(),NG5_MODIFY)==0 )
			{
				if(isEndDateNull && isStartDateNull )
				{
					EMH_store_initial_error_s1(EMH_severity_error,NG5_START_OR_END_DATE_SELECTION,"Modify Scenario");
					return NG5_START_OR_END_DATE_SELECTION ;
				}
			}

	MEM_free(szCurrentGroupName);
	MEM_free(Plant);
	MEM_free(start_date_str);
	MEM_free(end_date_str);
	MEM_free(effective_date_str);
	MEM_free(current_date_str);
	TC_write_syslog("exiting method Ng5_MassUpdateRevisionImpl finalizeCreateInputBase \n");
    return ifail;
}
int Ng5_current_get_time_stamp1(char* format, char** timestamp)
{
	TC_write_syslog("entering timestap line 316 \n");
	int retcode       = ITK_ok;
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	TC_write_syslog("line 322 \n");
	newTime = localtime(&localTime);
	TC_write_syslog("line 324 \n");
	currentTime.month = newTime->tm_mon;
	TC_write_syslog("line 326 \n");
	currentTime.year = newTime->tm_year + 1900;
	TC_write_syslog("line 328 \n");
	currentTime.day = newTime->tm_mday;
	TC_write_syslog("line 330 \n");
	currentTime.hour = newTime->tm_hour;
	TC_write_syslog("line 332 \n");
	currentTime.minute = newTime->tm_min;
	TC_write_syslog("line 334 \n");
	currentTime.second = newTime->tm_sec;
	TC_write_syslog("line 336 \n");
	DATE_date_to_string(currentTime, format, timestamp);
	TC_write_syslog("line 338 %s \n",timestamp);
	return retcode;
}

