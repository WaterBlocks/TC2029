/*********************************************************************************************
** File Name:         Ng5_Update_Master_ID.cxx
**
** File Description:
	This file contains the implementation to concatenate three strings
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   12/09/2016  Shibabrata Jena      Initial Version
**   07/05/2021  Balaji               TC12 Upgrade

*********************************************************************************************/

#include <Ng5Core/Ng5_Update_Master_ID.hxx>
#include <tccore/method.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>

using namespace std;


//-----------------------------------------------------------------------------------------------------
// int Ng5_Update_Master_ID( METHOD_message_t * msg, va_list args )
// implementation for the extension on createpost and saveaspost post action of Customer part Form to
// concatenate three values namely customer part number, customer part revision and customer name
//------------------------------------------------------------------------------------------------------
int Ng5_Update_Master_ID( METHOD_message_t * msg, va_list args )
{
	TC_write_syslog("Entering method Ng5_Update_Master_ID \n");
	tag_t tForm = msg->object_tag;

	if(tForm != NULLTAG)
	{
		char* cPartMasterID = NULL;
		char* cCustomerPartRevision = NULL;
		char* cCustomer = NULL;
		char* cCustomerPartNumber = NULL;

		ITK(AOM_ask_value_string(tForm, CUSTOMER_PART_NUMBER, &cCustomerPartNumber));
		ITK(AOM_ask_value_string(tForm, CUSTOMER_PART_REVISION, &cCustomerPartRevision));
		ITK(AOM_ask_value_string(tForm, CUSTOMER_NAME, &cCustomer));
		cPartMasterID = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cCustomerPartNumber) + tc_strlen(cCustomerPartRevision) + tc_strlen(cCustomer) + 10));
		tc_strcpy(cPartMasterID, cCustomerPartNumber);

		tc_strcat(cPartMasterID, HYPHEN);
		tc_strcat(cPartMasterID, cCustomerPartRevision);
		tc_strcat(cPartMasterID, HYPHEN);
		tc_strcat(cPartMasterID, cCustomer);

		ITK(AOM_set_value_string(tForm, CUSTOMER_MASTER_ID, cPartMasterID));
		ITK(AOM_save_with_extensions(tForm));//TC 12 Upgrade

		MEM_free(cPartMasterID);
		MEM_free(cCustomerPartNumber);
		MEM_free(cCustomerPartRevision);
		MEM_free(cCustomer);
	}
	TC_write_syslog("Exiting method Ng5_Update_Master_ID \n");
 	return ITK_ok;

}
