//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_setOccurrenceEffectivity
 *
 */
 
#ifndef NG5_SETOCCURRENCEEFFECTIVITY_HXX
#define NG5_SETOCCURRENCEEFFECTIVITY_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_setOccurrenceEffectivity(METHOD_message_t* msg, va_list args);
int Ng5_get_bline_attr(
      tag_t bline_t,      /* <I> */
      char  *attr,        /* <I> */
      tag_t *attr_t       /* <O> */
      );
date_t getTomorrowDate(date_t d);
bool Ng5_isPlantTZ_GT_ServTRZ (char* cpPlantStr);
tag_t Ng5_findItemRevisionFromBOMLine1(tag_t bom_line);
int Ng5_find_rev1(char *item_id, char *rev_id, tag_t *rev);

#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_SETOCCURRENCEEFFECTIVITY_HXX
