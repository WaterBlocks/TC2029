/*********************************************************************************************
** File Name:         Ng5_absItemRevisionFormCreatePost.hxx
**
** File Description:
	This file contains the declaration for the extension named Ng5_absItemRevisionFormCreatePost
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   1/12/2017  Shibabrata Jena      Initial Version

*********************************************************************************************/
#ifndef NG5_ABSITEMREVISIONFORMCREATEPOST_HXX
#define NG5_ABSITEMREVISIONFORMCREATEPOST_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
//-----------------------------------------------------------------------------------------------------
// int Ng5_absItemRevisionFormCreatePost( METHOD_message_t * msg, va_list args )
// definition  of the extension on IMAN_save of catia_assebly_model_attributes post action
// to update the design weight on the part revision
//------------------------------------------------------------------------------------------------------
                 
extern NG5CORE_API int Ng5_absItemRevisionFormCreatePost(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_ABSITEMREVISIONFORMCREATEPOST_HXX
