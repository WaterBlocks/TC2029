//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_Validate_Mfg_CreateInput
 *   History
 *   Sahida Khatun       Initial Creation     July ,2022
 */
 
#ifndef NG5_VALIDATE_MFG_CREATEINPUT_HXX
#define NG5_VALIDATE_MFG_CREATEINPUT_HXX
#include <tccore/method.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <Ng5Core/Ng5_BMF_ITEM_create_or_ref_id.hxx>
#include <Ng5Core/Ng5_linkEBOMToPlantMBOM.hxx>
#include <ctype.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_Validate_Mfg_CreateInput(METHOD_message_t* msg, va_list args);
logical Ng5_isAlphaNumeric(char* cpItemID);
logical Ng5_validSpecChar(char* cpSuffix);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_VALIDATE_MFG_CREATEINPUT_HXX
