
 /*********************************************************************************************
** File Name:        Ng5_SetUgmasterOEM.hxx

**
** File Description: This file contains the declaration for the Extension Ng5_SetUgmasterOEM
**
**
** History:
** mm/dd/yyyy    Name                  Comments
** ----------    ------------------    -------------------------
**   08/29/2018  Manjula Tirunagari    Initial Version

*********************************************************************************************/
 
#ifndef NG5_SETUGMASTEROEM_HXX
#define NG5_SETUGMASTEROEM_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_SetUgmasterOEM(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_SETUGMASTEROEM_HXX
