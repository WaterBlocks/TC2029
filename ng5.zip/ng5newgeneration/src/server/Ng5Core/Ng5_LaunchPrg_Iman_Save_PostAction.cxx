//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_LaunchPrg_Iman_Save_PostAction
 *
 */
#include <Ng5Core/Ng5_LaunchPrg_Iman_Save_PostAction.hxx>

int create_sso_package_and_linkto_launch(tag_t launch);

int Ng5_LaunchPrg_Iman_Save_PostAction( METHOD_message_t * msg, va_list args)
{
	int ifail=ITK_ok;
	TC_write_syslog("\n\n Entered extension on IMAN_save\n\n");


	tag_t launchtag = msg->object_tag;
	TC_write_syslog("\n\n launch tag from msg: %d\n\n", launchtag);


	TCTYPE_save_operation_context_t save_context;
	TCTYPE_ask_save_operation_context(&save_context);

	if(save_context == TCTYPE_save_on_create){
		TC_write_syslog("\n\n It is save on create\n\n");

		ifail= create_sso_package_and_linkto_launch(launchtag);
		TC_write_syslog("\n\n SSO Package Revision Tag:%d\n\n",ifail);

		}

 
 return 0;

}

int create_sso_package_and_linkto_launch(tag_t launch){

	int ifail =ITK_ok;
	tag_t ssopkg_type = NULLTAG;
	tag_t ssopkgrev_type = NULLTAG;
	tag_t ssopkg_create_tag = NULLTAG;
	tag_t ssopkgrev_create_tag = NULLTAG;
	tag_t ssopkg_created = NULLTAG;
	tag_t ssopkg_rev = NULLTAG;
	tag_t relation_tag = NULLTAG;
	tag_t relation_created = NULLTAG;
	char *launchId = NULL;

	ifail= TCTYPE_find_type(Ng5_SSOPkg, Ng5_SSOPkg, &ssopkg_type);
	ifail= TCTYPE_find_type(Ng5_SSOPkgRevision, Ng5_SSOPkgRevision, &ssopkgrev_type);

	ifail= TCTYPE_construct_create_input(ssopkgrev_type, &ssopkgrev_create_tag);
	ifail= AOM_set_value_string(ssopkgrev_create_tag, object_name, SSO_Package_name);

	ifail= TCTYPE_construct_create_input(ssopkg_type, &ssopkg_create_tag);
	ifail= AOM_set_value_string(ssopkg_create_tag, object_name, SSO_Package_name);
	ifail= AOM_set_value_tag(ssopkg_create_tag, revision, ssopkgrev_create_tag);

	ifail= TCTYPE_create_object(ssopkg_create_tag, &ssopkg_created);

	ifail= AOM_save_with_extensions(ssopkg_created); //TC 12 Upgrade
	ifail= AOM_unlock(ssopkg_created);
	ifail= ITEM_ask_latest_rev(ssopkg_created, &ssopkg_rev);

	ifail= GRM_find_relation_type(Ng5_rHasSSOPackage, &relation_tag);
	ifail= GRM_create_relation(launch, ssopkg_rev, relation_tag, NULLTAG, &relation_created);
	ifail= GRM_save_relation(relation_created);
	TC_write_syslog("\n\n Relation created and saved, ifail:%d\n\n",ifail);

	ifail = ITEM_ask_id2(launch, &launchId);
	if( tc_strlen(launchId) > 0 && tc_strcmp(launchId, "") != 0)
	{
		TC_write_syslog("\n *** LauncId is %s *** \n", launchId);
	}
	else
	{
		TC_write_syslog("\n *** LaunchId is Empty *** \n");
	}


	return ssopkg_rev;
}

