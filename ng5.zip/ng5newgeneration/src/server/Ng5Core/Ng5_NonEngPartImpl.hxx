//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_NonEngPartImpl
//

#ifndef NG5NEWGENERATION__NG5_NONENGPARTIMPL_HXX
#define NG5NEWGENERATION__NG5_NONENGPARTIMPL_HXX

#include <Ng5Core/Ng5_NonEngPartGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_NonEngPartImpl; 
    class Ng5_NonEngPartDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_NonEngPartImpl
    : public ng5newgeneration::Ng5_NonEngPartGenImpl
{
public:


    ///
    /// Description for the Finalize Create Input
    /// @param creInput - desc for  creInput parameter
    /// @return - Return desc for Initialize for Create
    ///
    int  finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a Ng5_NonEngPart
    explicit Ng5_NonEngPartImpl( Ng5_NonEngPart& busObj );

    ///
    /// Destructor
    virtual ~Ng5_NonEngPartImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_NonEngPartImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_NonEngPartImpl( const Ng5_NonEngPartImpl& );

    ///
    /// Copy constructor
    Ng5_NonEngPartImpl& operator=( const Ng5_NonEngPartImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_NonEngPartDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_NONENGPARTIMPL_HXX
