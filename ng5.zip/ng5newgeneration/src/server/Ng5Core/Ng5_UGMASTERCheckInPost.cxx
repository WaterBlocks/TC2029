//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_UGMASTERCheckInPost
 *
 */
#include <Ng5Core/Ng5_UGMASTERCheckInPost.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>


#include <math.h>

int Ng5_UGMASTERCheckInPost( METHOD_message_t * msg, va_list args )
{
 


    int        retCode            = ITK_ok;

    TC_write_syslog("\n Entering Ng5_UGMASTERCheckInPost \n");

    //Get the dataset tag from arguments
    tag_t     tDataset         = NULLTAG;

    va_list largs;
    va_copy(largs,args);
    tDataset = va_arg(largs, tag_t);

    if (NULLTAG != tDataset)
    {

        int    iNamedRefs      = 0;
        tag_t  *tpNamedRefs    = NULL;
        tag_t  tObjType        = NULLTAG;
        char   *chTypeName     = NULL;
        int iPartRevs = 0;
          tag_t *tPartRevs = NULL;


        TCTYPE_ask_object_type(tDataset,&tObjType);
        //TC12 Upgrade
        TCTYPE_ask_name2 (tObjType,&chTypeName);


        if (tc_strcmp(chTypeName,DATASET_UGMASTER) !=0 )
        {
            TC_write_syslog("Exiting method Ng5_SetUgmasterOEM as dataset is not a UGMASTER.\n");
            return retCode;
        }

        //Get all the named references of the Dataset
        ITK (AE_ask_dataset_named_refs (tDataset, &iNamedRefs, &tpNamedRefs) );

        if( (iNamedRefs > 0) && (tpNamedRefs != NULL) )
        {
            //Scan through each Named Reference
            for(int iNr=0; iNr<iNamedRefs; iNr++)
            {
                if(NULLTAG != tpNamedRefs[iNr])
                {
                    //Check the Type Name of the Named Reference
                    tag_t    tNrType    =    NULLTAG;
                    ITK( TCTYPE_ask_object_type(tpNamedRefs[iNr], &tNrType) );
                    if (NULLTAG != tNrType)
                    {
                        char    *cpNRClassName    = NULL;
                        ITK( TCTYPE_ask_name2( tNrType, &cpNRClassName ) ) ;

                        if(NULL != cpNRClassName)
                        {
                            //If the type is ugpartattributesForm
                            if (tc_strcmp (cpNRClassName, UGPART_ATTR_FORM) == 0)
                            {
                                char *cpOEMName = NULL;
                                tag_t pom_instance = NULLTAG;
                                FORM_ask_pom_instance(tpNamedRefs[iNr], &pom_instance);
                                AOM_ask_value_string(pom_instance,NX_ENV,&cpOEMName);
                                TC_write_syslog("OEM environment value from UGPartAttributes Form is %s \n",cpOEMName);

                                tag_t tRelTypeTag = NULLTAG;
                                ITK(GRM_find_relation_type(REL_SPECIFICATION, &tRelTypeTag));
                                //find the primary objects
                                if(tRelTypeTag != NULLTAG &&  (cpOEMName != NULL))
                                {

                                    ITK(GRM_list_primary_objects_only(tDataset, tRelTypeTag, &iPartRevs, &tPartRevs));


                                    if(iPartRevs > 0 && tPartRevs != NULL)
                                    {
                                        char *cpItemRevOEMValue =  NULL;
                                        ITK(AOM_ask_value_string(tPartRevs[0],OEM_ENV ,&cpItemRevOEMValue));
					//US 153988
                                       // if ( cpItemRevOEMValue ==  NULL || tc_strlen(cpItemRevOEMValue)==0 )
                                        {
                                            TC_write_syslog("Setting OEM_env as %s \n",cpOEMName);
                                            ITK(AOM_refresh(tPartRevs[0], POM_modify_lock));
                                            ITK(AOM_set_value_string(tPartRevs[0],OEM_ENV ,cpOEMName));
                                            ITK(AOM_save_with_extensions(tPartRevs[0]));//TC12 Upgrade
                                            ITK(AOM_refresh(tPartRevs[0], POM_no_lock));
                                            NG5_MEM_TCFREE( cpOEMName );
                                        }
                                        NG5_MEM_TCFREE( cpItemRevOEMValue );

                                    }
                                }
                            }
                            //US 250412
                            if (tc_strcmp (cpNRClassName, UGPART_MASS_FORM) == 0)
                            {


								tag_t pom_instance = NULLTAG;
								tag_t tRelTypeTag = NULLTAG;
								double dform_weight = 0.00;
								double dweight = 0.00;
								double epsilon = 0.0000001f;
								char* pcobj_type=NULL;
								int iBOM = 0;
								tag_t* ptBOMviewRev =NULLTAG;

								FORM_ask_pom_instance(tpNamedRefs[iNr], &pom_instance);
								ITK(AOM_ask_value_double(pom_instance,MASS,&dform_weight));

								ITK(GRM_find_relation_type(REL_SPECIFICATION, &tRelTypeTag));
								if(tRelTypeTag != NULLTAG )
								{
									ITK(GRM_list_primary_objects_only(tDataset, tRelTypeTag, &iPartRevs, &tPartRevs));

									for(int ipri=0; ipri<iPartRevs; ipri++)
									{
										ITK(WSOM_ask_object_type2(tPartRevs[ipri],&pcobj_type));


										if((tc_strcmp(pcobj_type, ENG_PART_REVISION) == 0 || tc_strcmp(pcobj_type, ITEM_EXTERNAL_PART_REVISION ) == 0 || tc_strcmp(pcobj_type, ITEM_SUPPORT_DESIGN_REVISION) == 0) )
										{

											ITK(GRM_find_relation_type(REL_SPECIFICATION, &tRelTypeTag));
											ITK(AOM_ask_value_tags(tPartRevs[ipri], STRUCTURE_REVISION, &iBOM, &ptBOMviewRev));

											if(iBOM==0)
											{
												ITK(AOM_ask_value_double(tPartRevs[ipri],DESIGN_WEIGHT,&dweight));

											    if(fabs(dweight - dform_weight) < epsilon)
												{

													ITK ( AOM_refresh( tPartRevs[ipri], TRUE));
													ITK(AOM_set_value_double (tPartRevs[ipri], DESIGN_WEIGHT, dweight));
													ITK( AOM_save_with_extensions( tPartRevs[ipri]));
													ITK( AOM_refresh( tPartRevs[ipri], FALSE));
												}
											}
										}
										MEM_TCFREE(ptBOMviewRev);
									}
									MEM_TCFREE(pcobj_type);
								}

                            }
								MEM_TCFREE(tPartRevs);

                        }
                    }
                }

            }
        }
		MEM_TCFREE(chTypeName);
    }

     TC_write_syslog("Exiting method Ng5_UGMASTERCheckInPost.\n");

 return 0;

}
