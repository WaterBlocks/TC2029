/*********************************************************************************************
** File Name:        Ng5_absItemRevisionDeepCopyPost.hxx

**
** File Description: This file contains the #defines, macros and error codes for the Adient project
**
**
** History:
** mm/dd/yyyy     Name                  Comments
** ----------          -------               -------------------------
** 12/22/2016  Atish Misal      Initial Creation

*********************************************************************************************/
 
#ifndef NG5_ABSITEMREVISIONDEEPCOPYPOST_HXX
#define NG5_ABSITEMREVISIONDEEPCOPYPOST_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_absItemRevisionDeepCopyPost(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_ABSITEMREVISIONDEEPCOPYPOST_HXX
