//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_rHasMBOMItemPreCondition
 *
 */
 
#ifndef NG5_RHASMBOMITEMPRECONDITION_HXX
#define NG5_RHASMBOMITEMPRECONDITION_HXX
#include <Ng5Core/Ng5_CMHasProblemItemCreatePostAction.hxx>
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif

                 
extern NG5CORE_API int Ng5_rHasMBOMItemPreCondition(METHOD_message_t* msg, va_list args);
tag_t Ng5_Find_First_Rev(tag_t Item);
#define MFGCNRevision                      "Ng5_MfgCNRevision"
#define MFG_PART                           "Ng5_MfgPart"
#define MFG_PARTRev                        "Ng5_MfgPartRevision"
#define ITEM_ID                        	   "item_id"
#define ITEM_REV_ID                        "item_revision_id"
#define ErrorPlantMatchError				ErrorBase  + 2134
#define ERROR_MBOM_NOT_BASELINE				ErrorBase  + 3100
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_RHASMBOMITEMPRECONDITION_HXX
