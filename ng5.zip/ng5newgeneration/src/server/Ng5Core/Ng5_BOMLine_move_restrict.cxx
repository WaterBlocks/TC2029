//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_BOMLine_move_restrict
 *
 */
#include <Ng5Core/Ng5_BOMLine_move_restrict.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <Ng5Core/Ng5_BMF_ITEM_create_or_ref_id.hxx>


int Ng5_BOMLine_move_restrict( METHOD_message_t * msg, va_list args )
{

		int	iFail						= ITK_ok;
		int	iBaselineRevCount			= ITK_ok;
		int iItemCount 					=0;
		int iparentBaselineRevCount  =0;
	    int iChildBOMLineCount =0;
	    int tBomocc =0;
	    int isequence =0;
	    int ipacked =0;
	    int tBomocc1 =0;
	    int isequence1 =0;


	    logical isPacked = false;

	    tag_t bom_window = NULL;
	    tag_t rev_rule = NULL;
	    tag_t bom_line = NULL;
		tag_t *tChildBOMLines = NULL;
		tag_t tBOMLine					= NULLTAG;
		tag_t tParentBOMLine			= NULLTAG;

		tag_t tMfgItemRevTag			= NULLTAG;
		tag_t tMfgItemparentRevTag  = NULLTAG;
		tag_t *tBaselineMfgItemRevTags	= NULL;
		tag_t parentbaselinewindow =  NULL;
		//tag_t parent_tag 				= NULLTAG;
		int count					= 0;
		tag_t *source_bomlines			= NULL;
		tag_t *target_bomlines			= NULL;
		tag_t *tParentBOMLinetag		= NULL;
		tag_t *tParentBaselineMfgItemRevTags = NULL;
		tag_t  Latestbaseline = NULLTAG;


		char  *cpObjectType    		 	= NULL; // (MEM_FREE)
		char  *cpMfgItemID    		 	= NULL; // (MEM_FREE)
		char  *cpMfgRevID    		 	= NULL; // (MEM_FREE)
		char  *cpQADFLAG    		 	= NULL; // (MEM_FREE)
		char * cpparentname 			= NULL;
		char* ParentItemID = NULL;
		char* cpchildMfgRevID = NULL;
		char* cpObjFindNo = NULL;
		char* cpMfgRevIDa = NULL;
		char* cpobjOccEff = NULL;
		char* cpparentObjOccEff = NULL;
		char* cpparentObjFindNo = NULL;
		va_list largs;
	    va_copy( largs, args );
	    tParentBOMLine = va_arg(largs, tag_t);
	    count = va_arg(largs, int);
	    source_bomlines = va_arg(largs, tag_t*);
	    target_bomlines = va_arg(largs, tag_t*);
	    va_end( largs );
	    tBOMLine = source_bomlines[0];
		TC_write_syslog("\n >>>>>  Entering Ng5_BOMLine_move_restrict count is %d!!\n",count);
		for(int jcount=0; jcount<count; jcount++)
		{
		  ITKCALL(AOM_ask_value_string(source_bomlines[jcount], BOMLINEOBJTYPE,&cpObjectType));
		  printf("\n>>>>> MOVE - cpObjectType =%s \n", cpObjectType);
          if(tc_strcmp(cpObjectType, MFGPART)==0)
		   {
			ITKCALL(AOM_ask_value_string(source_bomlines[jcount], BOMLINEOBJTYPE, &cpObjectType ));

			ITKCALL(AOM_ask_value_string(source_bomlines[jcount], BOMLIMEITEMID,&cpMfgItemID ));

			ITKCALL(AOM_ask_value_string(source_bomlines[jcount], BOMLINEREVID,&cpMfgRevID ));

			ITKCALL(BOM_line_look_up_attribute(BOMOCCURRENCE,&tBomocc));
			ITKCALL(BOM_line_ask_attribute_string(source_bomlines[jcount],tBomocc,&cpobjOccEff));

			ITKCALL(BOM_line_look_up_attribute(BOMFINDNO,&isequence));
			ITKCALL(BOM_line_ask_attribute_string(source_bomlines[jcount],isequence,&cpObjFindNo));

			ITKCALL(BOM_line_look_up_attribute(BOMPacked,&ipacked));
			ITKCALL(BOM_line_ask_attribute_logical(source_bomlines[jcount],ipacked,&isPacked));

			/*ITKCALL(AOM_ask_value_string(source_bomlines[jcount],"bl_occ_effectivity",&cpobjOccEff ));
			ITKCALL(AOM_ask_value_string(source_bomlines[jcount], "bl_sequence_no",&cpObjFindNo ));
			ITKCALL(AOM_ask_value_logical(source_bomlines[jcount],"bl_is_packed",&isPacked));
*/
			//Ng5_find_item_rev (cpMfgItemID, cpMfgRevID, cpObjectType, &tMfgItemRevTag );

			// ITKCALL(ITEM_rev_list_baselineRevs (tMfgItemRevTag, NULL , &iBaselineRevCount, &tBaselineMfgItemRevTags));


			TC_write_syslog("\n>>>>> MOVE Occurence Effectivity  %s Find No %s   is Packed =%d \n", cpobjOccEff ,cpObjFindNo,isPacked);


			ITKCALL(AOM_ask_value_string(source_bomlines[jcount],BOMLINEPARENT, &cpparentname ));
			ParentItemID = tc_strtok(cpparentname,"/");
			Ng5_find_item_rev(ParentItemID,"01", cpObjectType, &tMfgItemparentRevTag);
			if(tMfgItemparentRevTag != NULL)
			{
			  TC_write_syslog("\n >>>>>  Entering Ng5_BOMLine_move_restrict Parent Name %s  ID only %s %d !!\n",cpparentname,ParentItemID,tMfgItemparentRevTag);
		    //  ITKCALL(ITEM_rev_list_baselineRevs (tMfgItemparentRevTag, NULL , &iparentBaselineRevCount, &tParentBaselineMfgItemRevTags));
				Latestbaseline = Ng5_FindLatestbaselineRevision(tMfgItemparentRevTag);
			 if(Latestbaseline != NULLTAG)
		      {
		     //  TC_write_syslog("\n>>>>> Parent - Number of Baselines =%d  tagID %d \n", iparentBaselineRevCount,tParentBaselineMfgItemRevTags[0]);
		    ITKCALL(AOM_ask_value_string(Latestbaseline,"item_revision_id",&cpMfgRevIDa ));
			TC_write_syslog("\n>>>>> Parent - latest revision id =%s \n", cpMfgRevIDa);
		    ITKCALL((BOM_init_module()));
			 ITKCALL((BOM_create_window (&bom_window)));
			 ITKCALL((CFM_find ("ADNT Precise",&rev_rule )));
			 ITKCALL(BOM_set_window_config_rule (bom_window,rev_rule ));
			 ITKCALL(BOM_set_window_top_line(bom_window,NULLTAG,Latestbaseline,NULLTAG,&bom_line));
			
			 ITKCALL( BOM_line_ask_all_child_lines(bom_line,&iChildBOMLineCount,&tChildBOMLines));
			 TC_write_syslog("\n Recurrsion iChildBOMLineCount %d\n",iChildBOMLineCount);
			  if(iChildBOMLineCount >0 )
			 {
			 for(int i =0; i<iChildBOMLineCount; i++)
			 {
				 ITKCALL(AOM_ask_value_string(tChildBOMLines[i],BOMLIMEITEMID,&cpchildMfgRevID));
				 //ITKCALL(AOM_ask_value_string(tChildBOMLines[i],"bl_occ_effectivity",&cpparentObjOccEff ));
				 //ITKCALL(AOM_ask_value_string(tChildBOMLines[i], "bl_sequence_no",&cpparentObjFindNo ));

				 ITKCALL(BOM_line_look_up_attribute(BOMOCCURRENCE,&tBomocc1));
				 ITKCALL(BOM_line_ask_attribute_string(tChildBOMLines[i],tBomocc1,&cpparentObjOccEff));

				 ITKCALL(BOM_line_look_up_attribute(BOMFINDNO,&isequence1));
				 ITKCALL(BOM_line_ask_attribute_string(source_bomlines[jcount],isequence1,&cpparentObjFindNo));



				 TC_write_syslog("\n cpMfgItemID %s   cpchildMfgRevID %s------------------cpparentObjOccEff %s   cpparentObjFindNo %s \n",cpMfgItemID,cpchildMfgRevID,cpparentObjOccEff,cpparentObjFindNo);
				 if(tc_strcmp(cpchildMfgRevID,cpchildMfgRevID)==0 )
				 {
					 if(isPacked == true)
					 {
						 if(tc_strcmp(cpparentObjOccEff,cpobjOccEff)==0 )
						 {
							 TC_write_syslog("\n>>>>> MOVE - Updating MBOM transferred to QAD: BOM Line =%s REV ID=%s Type=%s \n", cpMfgItemID, cpMfgRevID, cpObjectType );
								EMH_store_error_s1(EMH_severity_error, ErrorBOMLineCutRestrict1, "BOMLine removal not allowed on QAD Transferred MBOM");
								return ErrorBOMLineCutRestrict1;


						 }else
						 {
							 TC_write_syslog("\n Able to Cut bom_line occ_effectivity is not match  \n");
						 }

					 }else{
						 if(tc_strcmp(cpparentObjOccEff,cpobjOccEff)==0 && tc_strcmp(cpparentObjFindNo,cpObjFindNo)==0 )
							{
							 TC_write_syslog("\n>>>>> MOVE - Updating MBOM transferred to QAD: BOM Line =%s REV ID=%s Type=%s \n", cpMfgItemID, cpMfgRevID, cpObjectType );
								EMH_store_error_s1(EMH_severity_error, ErrorBOMLineCutRestrict1, "BOMLine removal not allowed on QAD Transferred MBOM");
								return ErrorBOMLineCutRestrict1;


							 }else
							{
								 TC_write_syslog("\n Able to Cut, occ_effectivity and find no not match  \n");
    						 }

					 	 }


				 }
	   			else
	   			{

	 				TC_write_syslog("\n>>>>> Updating MBOM NOT transferred to QAD: BOM Line =%s REV ID=%s Type=%s \n", cpMfgItemID, cpMfgRevID, cpObjectType );

				 }
			 }

                  NG5_MEM_TCFREE(tChildBOMLines);
				  NG5_MEM_TCFREE(cpchildMfgRevID);
				  NG5_MEM_TCFREE(cpparentObjOccEff);
			      NG5_MEM_TCFREE(cpparentObjFindNo);
			

			 }else{

				 TC_write_syslog("\n cEmpty bom_line  \n");
			 }
				ITKCALL(BOM_refresh_window	(bom_window));
			 ITKCALL(BOM_close_window(bom_window));


			NG5_MEM_TCFREE(cpMfgRevIDa);	

		 
		}else{
			TC_write_syslog("\n >>>>>Ng5_BOMLine_move_restrict---Patent baseline count is 0 !!!\n");
			 }

		}
//TC_write_syslog("\n >>>>>Ng5_BOMLine_move_restrict---Patent cpparentname count is 0 !!!\n");
			        		NG5_MEM_TCFREE(cpparentname);
			        		NG5_MEM_TCFREE(cpMfgItemID);
			        	    NG5_MEM_TCFREE(cpMfgRevID);
TC_write_syslog("\n >>>>>Ng5_BOMLine_move_restrict---Patent ParentItemID count is 0 !!!\n");
			        	  //  NG5_MEM_TCFREE(ParentItemID);
			        	 //   NG5_MEM_TCFREE(cpchildMfgRevID);
						   TC_write_syslog("\n >>>>>Ng5_BOMLine_move_restrict---cpObjFindNo  count is 0 !!!\n");	  
							NG5_MEM_TCFREE(cpObjFindNo);
			        	    // NG5_MEM_TCFREE(cpMfgRevIDa);
			        TC_write_syslog("\n >>>>>Ng5_BOMLine_move_restrict---cpobjOccEff  count is 0 !!!\n");	  
			        	    NG5_MEM_TCFREE(cpobjOccEff);
			        	   
			        	   // NG5_MEM_TCFREE(source_bomlines);
			        	   // NG5_MEM_TCFREE(target_bomlines);
			        	   // NG5_MEM_TCFREE(tParentBOMLinetag);
			        	  
			        	 
		   }

				NG5_MEM_TCFREE(cpObjectType);
 

		}




		TC_write_syslog("\n >>>>>  Entering Ng5_BOMLine_move_restrict!!!\n");
 
		return iFail;

}

tag_t	Ng5_FindLatestbaselineRevision(tag_t tMfgItemparentRevTag)
{
	
	tag_t   Itemtag = NULL;
	tag_t tbaseline= NULL;
	tag_t*   ptStatusList = NULL ; /*Mem_free*/
	tag_t      tRlsdRev = NULLTAG ;
	char*   cStatusName = NULL;
	char* revname =  NULL;
	int            iRev = 0;
	int      iStatusCnt = 0;

	   ITKCALL(ITEM_ask_item_of_rev(tMfgItemparentRevTag,&Itemtag));
	   ITKCALL(ITEM_ask_latest_rev(Itemtag,&tbaseline));
	   ITKCALL(AOM_ask_value_string(tbaseline,"item_revision_id",&revname ));
		ITKCALL(WSOM_ask_release_status_list(tbaseline,&iStatusCnt,&ptStatusList));
		if(iStatusCnt >0)
		{
			ITKCALL(AOM_ask_name (ptStatusList[0],&cStatusName));
			if(tc_strcmp(cStatusName,"Ng5_MBOMBaseline")==0)
			{
				
				tRlsdRev = tbaseline;
				//break;
			 }
		}
		

	return tRlsdRev;
}
