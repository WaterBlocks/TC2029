//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasMBOMItemPreCondition
 *
 */
#include <Ng5Core/Ng5_rHasMBOMItemPreCondition.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

/****************************************************************************************************
*Function Name :Ng5_rHasMBOMItemPreCondition
*Description   :This function checks either plant code is same for MFGCN Rev and MBOM ItemRev
*****************************************************************************************************/
int Ng5_rHasMBOMItemPreCondition( METHOD_message_t * msg, va_list args)
{
	TC_write_syslog("\n <<<Entering Ng5_rHasMBOMItemPreCondition>>>\n");
	int iFail           		= ITK_ok;
	tag_t tMfgCNRev     		= NULLTAG;
	tag_t tPartRev      		= NULLTAG;
	tag_t tRelationType 		= NULLTAG;	
	tag_t tTargetRev 			= NULLTAG;
	tag_t tItem 				= NULLTAG;
	char* cObjectType 			= NULL;//MEM FREE
	char* cObjectType1 			= NULL;//MEM FREE
	char* cPlantCodeMfgPrt  	= NULL;//MEM FREE
	char* cPlantCodeMfgPrtRev 	= NULL;//MEM FREE
	char* cPlantCodeMfgCN    	= NULL;//MEM FREE	
	char* cRevID				= NULL;//MEM FREE
	char* cItemID				= NULL;//MEM FREE
	tMfgCNRev     = va_arg(args, tag_t);
	tPartRev      = va_arg(args, tag_t);
	tRelationType = va_arg(args, tag_t);
	int	iBaselineRevCount			= 0;
	tag_t *tBaselineMfgItemRevTags	= NULL;
	if (NULLTAG != tMfgCNRev && NULLTAG != tPartRev && NULLTAG != tRelationType)
	{
		NG5_ITK_CALL(AOM_ask_value_string(tMfgCNRev,ATTR_OBJECT_TYPE, &cObjectType1));
		if(tc_strcmp(cObjectType1, MFGCNRevision) == 0)
		{
			NG5_ITK_CALL(AOM_ask_value_string(tMfgCNRev, PLANTS, &cPlantCodeMfgCN ));
			NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));
			if(tc_strcmp(cObjectType, MFG_PART) == 0 )
			{
				tTargetRev = Ng5_Find_First_Rev(tPartRev);
				NG5_ITK_CALL(AOM_ask_value_string(tTargetRev, PLANTS, &cPlantCodeMfgPrt ));
				if(tc_strcmp(cPlantCodeMfgPrt, cPlantCodeMfgCN) != 0 )
				{
					EMH_store_error_s1(EMH_severity_error,ErrorPlantMatchError,"Plant Id of MCN & MBOM Items does not match.");
					return ErrorPlantMatchError;
				}

			}
			if(tc_strcmp(cObjectType, MFG_PARTRev) == 0 )
			{
				iFail = AOM_ask_value_string(tPartRev,ITEM_REV_ID, &cRevID);
				NG5_ITK_CALL(ITEM_rev_list_baselineRevs (tPartRev, NULL , &iBaselineRevCount, &tBaselineMfgItemRevTags));
				if(iBaselineRevCount==0)
				{
					//ifailresult=1;
					NG5_ITK_CALL(EMH_store_error_s1(EMH_severity_error,ERROR_MBOM_NOT_BASELINE,""));
				}
				TC_write_syslog("\n cRevID %s \n",cRevID);
				if(tc_strcmp(cRevID, "01") == 0 ||tc_strcmp(cRevID, "A") == 0  )
				{
					TC_write_syslog("\n Line 81 - Doing nothing as it is expected revison \n");
					tTargetRev = tPartRev;
					// Do nothing
				}
				else
				{
					iFail = AOM_ask_value_string(tPartRev,ITEM_ID, &cItemID);
					iFail= Ng5_find_Item(cItemID,MFGPART,&tItem);
					tTargetRev = Ng5_Find_First_Rev(tItem);
				}
				NG5_ITK_CALL(AOM_ask_value_string(tTargetRev, PLANTS, &cPlantCodeMfgPrtRev ));
				if(tc_strcmp(cPlantCodeMfgPrtRev, cPlantCodeMfgCN) != 0 )
				{
					EMH_store_error_s1(EMH_severity_error,ErrorPlantMatchError,"Plant Id of MCN & MBOM Items does not match.");
					return ErrorPlantMatchError;
				}
			}
			MEM_TCFREE(cObjectType);
			MEM_TCFREE(cObjectType1);
			MEM_TCFREE(cPlantCodeMfgCN);
			MEM_TCFREE(cPlantCodeMfgPrt);
			MEM_TCFREE(cPlantCodeMfgPrtRev);
			MEM_TCFREE(cRevID);
			MEM_TCFREE(cItemID);
		}

		if(tc_strcmp(cObjectType1, "Ng5_MassUpdateRevision") == 0)
		{
			NG5_ITK_CALL(AOM_ask_value_string(tMfgCNRev, "ng5_Plants", &cPlantCodeMfgCN ));
			NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));
			if(tc_strcmp(cObjectType, MFG_PART) == 0 )
			{
				tTargetRev = Ng5_Find_First_Rev(tPartRev);
				NG5_ITK_CALL(AOM_ask_value_string(tTargetRev, PLANTS, &cPlantCodeMfgPrt ));
				if(tc_strcmp(cPlantCodeMfgPrt, cPlantCodeMfgCN) != 0 )
				{
					EMH_store_error_s1(EMH_severity_error,ErrorPlantMatchError,"Plant Id of MCN & MBOM Items does not match.");
					return ErrorPlantMatchError;
				}
				NG5_ITK_CALL(ITEM_rev_list_baselineRevs (tTargetRev, NULL , &iBaselineRevCount, &tBaselineMfgItemRevTags));
				if(iBaselineRevCount==0)
				{
									//ifailresult=1;
					TC_write_syslog("line 122 \n");
					NG5_ITK_CALL(EMH_store_error_s1(EMH_severity_error,ERROR_MBOM_NOT_BASELINE,""));
					return ERROR_MBOM_NOT_BASELINE;
				}

			}
			if(tc_strcmp(cObjectType, MFG_PARTRev) == 0 )
			{
				iFail = AOM_ask_value_string(tPartRev,ITEM_REV_ID, &cRevID);
				NG5_ITK_CALL(ITEM_rev_list_baselineRevs (tPartRev, NULL , &iBaselineRevCount, &tBaselineMfgItemRevTags));
				if(iBaselineRevCount==0)
				{
					//ifailresult=1;
					TC_write_syslog("line 122 \n");
					NG5_ITK_CALL(EMH_store_error_s1(EMH_severity_error,ERROR_MBOM_NOT_BASELINE,""));
					return ERROR_MBOM_NOT_BASELINE;
				}
				TC_write_syslog("\n cRevID %s \n",cRevID);
				if(tc_strcmp(cRevID, "01") == 0 ||tc_strcmp(cRevID, "A") == 0  )
				{
					TC_write_syslog("\n Line 81 - Doing nothing as it is expected revison \n");
					tTargetRev = tPartRev;
					// Do nothing
				}
				else
				{
					iFail = AOM_ask_value_string(tPartRev,ITEM_ID, &cItemID);
					iFail= Ng5_find_Item(cItemID,MFGPART,&tItem);
					tTargetRev = Ng5_Find_First_Rev(tItem);
				}
				NG5_ITK_CALL(AOM_ask_value_string(tTargetRev, PLANTS, &cPlantCodeMfgPrtRev ));
				if(tc_strcmp(cPlantCodeMfgPrtRev, cPlantCodeMfgCN) != 0 )
				{
					EMH_store_error_s1(EMH_severity_error,ErrorPlantMatchError,"Plant Id of MCN & MBOM Items does not match.");
					return ErrorPlantMatchError;
				}
			}
			MEM_TCFREE(cObjectType);
			MEM_TCFREE(cObjectType1);
			MEM_TCFREE(cPlantCodeMfgCN);
			MEM_TCFREE(cPlantCodeMfgPrt);
			MEM_TCFREE(cPlantCodeMfgPrtRev);
			MEM_TCFREE(cRevID);
			MEM_TCFREE(cItemID);
		}

		TC_write_syslog("\n Leaving Ng5_rHasMBOMItemPreCondition \n");
		return iFail;
	}
}

/****************************************************************************************************
*Function Name : Ng5_Find_First_Revision
*Description   : This function retrieves the first revision for an Item
*****************************************************************************************************/
tag_t Ng5_Find_First_Rev(tag_t Item)
{
	TC_write_syslog("\n Inside Ng5_Find_First_Rev \n");
	int  ifail	  = ITK_ok;	
	tag_t Rev_tag = NULL;
	ifail = ITEM_find_revision(Item,"01",&Rev_tag);
	if (Rev_tag == NULL)
	{
		ifail = ITEM_find_revision(Item,"A",&Rev_tag);
	}
	TC_write_syslog("\n Existed Ng5_Find_First_Rev \n");
	return Rev_tag;
}
