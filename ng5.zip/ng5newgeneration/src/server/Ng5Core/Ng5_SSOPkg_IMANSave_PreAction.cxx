//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_SSOPkg_IMANSave_PreAction
 *
 */
#include <Ng5Core/Ng5_SSOPkg_IMANSave_PreAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <base_utils/TcResultStatus.hxx>

using namespace ng5newgeneration;

int Ng5_SSOPkg_IMANSave_PreAction( METHOD_message_t * msg, va_list args )
{
	int ifail = ITK_ok;

	va_list uargs;
	va_copy(uargs,args);

	tag_t ssopkgrev_tag = va_arg(uargs, tag_t);
	va_end(uargs);

	if(ssopkgrev_tag != NULLTAG)
	{
		TC_write_syslog("\n\n ********Entering IMANSave Pre Action*********\n\n");
		TC_write_syslog("\n\n SSO Tag is :%d\n\n",ssopkgrev_tag);

		scoped_smptr<char> strCheckedOut;

		ifail = AOM_ask_value_string(ssopkgrev_tag, "checked_out", &strCheckedOut);
		TC_write_syslog("\n Is CHecked Out: %s\n", strCheckedOut.getString());

		if(tc_strcmp(strCheckedOut.getString(), "Y") == 0)
		{
			scoped_smptr<char> cObjectType;
			ifail = AOM_ask_value_string(ssopkgrev_tag, "object_type", &cObjectType);
			TC_write_syslog("\n object type is %s\n", cObjectType.getString());

			scoped_smptr<char> strSSOPkgName;
			ifail = AOM_ask_value_string(ssopkgrev_tag, "object_name", &strSSOPkgName);
			TC_write_syslog("\n object name is %s\n", strSSOPkgName.getString());

			tag_t tRelationTag = NULLTAG;
			ifail = GRM_find_relation_type("Ng5_rHasSSOPackage", &tRelationTag);
			TC_write_syslog("\n\n SSO Package relation tag:%d\n\n",tRelationTag);

			int count = 0;
			scoped_smptr<tag_t> primaryObj;
			ifail = GRM_list_primary_objects_only(ssopkgrev_tag, tRelationTag, &count, &primaryObj);

			if( count > 0)
			{
				scoped_smptr<char> primObjType;
				ifail = AOM_ask_value_string(primaryObj[0], "object_type", &primObjType);
				TC_write_syslog("\n object type is %s\n", primObjType.getString());

				int nSec = 0;
				scoped_smptr<tag_t> secondaryObjs;
				ifail = GRM_list_secondary_objects_only(primaryObj[0], tRelationTag, &nSec, &secondaryObjs);
				TC_write_syslog("\n\n No. of Secondary object:%d\n\n",count);

				for( int i = 0; i < nSec; i++)
				{
					scoped_smptr<char> obj_name;
					ifail = AOM_ask_value_string(secondaryObjs[i], OBJECT_NAME, &obj_name);
					if(tc_strcmp(obj_name.getString(), strSSOPkgName.getString()) == 0)
					{
						TC_write_syslog("\n\n Inside If loop\n\n");
						EMH_store_error_s1(EMH_severity_error, ErrorCodeForMultipleSSOPackage, "Multiple SSO Package cannot be created");

						return ErrorCodeForMultipleSSOPackage;
					}
				}
			}

		}
	}

	return ifail;
}
