//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_EngPartImpl
//

#include <Ng5Core/Ng5_EngPartImpl.hxx>

#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <stdarg.h>
#include <string>
#include <sstream>
#include <fclasses/tc_string.h>

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_EngPartImpl::Ng5_EngPartImpl(Ng5_EngPart& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_EngPartImpl::Ng5_EngPartImpl( Ng5_EngPart& busObj )
   : Ng5_EngPartGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_EngPartImpl::~Ng5_EngPartImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_EngPartImpl::~Ng5_EngPartImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_EngPartImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_EngPartImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_EngPartGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

/*
 * **
 * Created By	:	Thirupathy Natesan
 * Created Date	:	26-Dec-2016
 *
 * Functionality:	Setter for a string Property
 * 					@param value - Value to be set for the parameter
 * 					@param isNull - If true, set the parameter value to null
 * 					@return - Status. 0 if successful
 * 					This Getter method get the objects copied with Ng5_rHasReplacedbyRel
 * 					And array will be stored in Ng5_replacement_for runtime property.
 */


///
/// Getter for a Tag Array Property
/// @param values - Parameter value
/// @param isNull - Returns true for an array element if the parameter value at that location is null
/// @return - Status. 0 if successful
///
/*int  Ng5_EngPartImpl::getNg5_replacement_forBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const
{
    int ifail = ITK_ok;

    		int         iRefs           =       0;
        	int         *ipLevels       =       NULL;
        	char        **sz2Rels       =       NULL;
        	tag_t       tPR                     =       NULLTAG;
        	tag_t       *tpRefs         =       NULL;
        	TC_write_syslog("\n\t Entering Ng5_EngPartImpl::getNg5_replacement_forBase \n");

        	//Get the Part  Tag
        	Ng5_EngPart *bo = getNg5_EngPart();
        	tPR = ((Teamcenter::BusinessObject*)bo)->getTag();

        	std::vector<tag_t>      vTagValues;
        	std::vector<int>        vIsNullLocal;

        	vTagValues.clear();

        	//Getting all where referenced secondary objects
        	ITK( WSOM_where_referenced( tPR, 1, &iRefs, &ipLevels, &tpRefs, &sz2Rels) );

        	for(int iWhere=0; iWhere<iRefs; iWhere++)
        	{
        		if( sz2Rels[iWhere] != NULL)
        		{
        			if(NULLTAG != tpRefs[iWhere])
        			{
        				char    cObjectType[WSO_name_size_c+1]    =       {'\0'};
        				char    cRelationName[WSO_name_size_c+1]  =       {'\0'};
        				ITK( WSOM_ask_object_type(tpRefs[iWhere], cObjectType) );
        				if (tc_strcpy(cRelationName,sz2Rels[iWhere]) == 0);
        				{
        					//Checking if referenced type is a Eng Part and relation as Ng5_rHasReplacedByrel
        					if(( tc_strcmp(ENG_PART, cObjectType) == 0) && (tc_strcmp(PartToPart_ReplacedBy_Rel,cRelationName) == 0))
        					{
        						vTagValues.push_back(tpRefs[iWhere]);
        						vIsNullLocal.push_back(false);
        					}
        				}	
        			}

        		}
        	}
        	if(vTagValues.size() > 0)
        	{
        		values.clear();
        		values.swap(vTagValues);
        	}
        	if(vIsNullLocal.size() > 0)
        	{
        		isNull.clear();
        		isNull.swap(vIsNullLocal);
        	}

        	if(ipLevels != NULL)
        		MEM_TCFREE(ipLevels);
        	if(sz2Rels != NULL)
        		MEM_TCFREE(sz2Rels);
        	if(tpRefs != NULL)
        		MEM_TCFREE(tpRefs);

    return ifail;
}*/

///
/// Setter for a Tag Array Property
/// @param values - Values to be set for the parameter
/// @param isNull - If array element is true, set the parameter value at that location as null
/// @return - Status. 0 if successful
///
/*int  Ng5_EngPartImpl::setNg5_replacement_forBase( const std::vector<tag_t> & values, const std::vector<int> * isNull )
{
    int ifail = ITK_ok;

    // Your Implementation

    return ifail;
}*/

