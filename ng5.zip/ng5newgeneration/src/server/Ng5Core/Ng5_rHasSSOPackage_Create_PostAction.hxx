//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_rHasSSOPackage_Create_PostAction
 *
 */
 
#ifndef NG5_RHASSSOPACKAGE_CREATE_POSTACTION_HXX
#define NG5_RHASSSOPACKAGE_CREATE_POSTACTION_HXX
#include <tccore/method.h>
#include <ug_va_copy.h>
#include <tccore/item.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/project.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <cstring>
#include <Ng5Core/libng5core_exports.h>

#define object_name 							"object_name"
#define item_id									"item_id"
#define Ng5_launchprg_masterprg					"ng5_launchprg_masterprg"
#define SSOPkg_Name_value2						"Design Verification Release"
#define SSOPkg_Name_value3						"Final Production Release"
#define SSOPkg_Name_value4						"Customer Part Approval"
#define SSOPkg_Name_value5					    "Post Launch"
#define SSOPkg_Name_value6						"Production"
#define SSOPkg_Name_value7						"End of Production"
#define IMAN_master_form						"IMAN_master_form"
#define items_tag								"items_tag"


#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_rHasSSOPackage_Create_PostAction(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_RHASSSOPACKAGE_CREATE_POSTACTION_HXX
