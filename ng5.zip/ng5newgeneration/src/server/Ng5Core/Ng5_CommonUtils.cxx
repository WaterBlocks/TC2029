/*********************************************************************************************
** File Name:         Ng5_CommonUtils.cxx
**
** File Description:
** This file contains implementation logic for common functions
**
** History			:
** 		Date	|  	AGM		|	Name          	|	Comments
** ------------------------------------------------------------------------------------------------
**  12/09/2016	|			|Pradnya Hingankar  |	Initial Version
**
**  12/22/2016	|			|Atish Misal 		|	Added method getLatestRevisionOverlay
**
**  12/28/2016	|			|Pradnya Hingankar	|	Modified method isStatused to return true if ItemRevision is statused irrespective of the Name of the status.
**
**  30/07/2018	|			|Arjun				|	1. updated the Function history with new format for all the functions.
**  			|			|					|	2. Added MEM_Free in the getLatestRevisionOverlay function.
**  			|			|					|	3. Removed duplicate header file entries
** 				|			|					|
****  03/12/2018	|           |Bhanu Srikanth     | 1. Added function setNg5_ChangeState
*********************************************************************************************/

#include "Ng5_CommonUtils.hxx"
#include <math.h>
#include <sa/am.h>

using namespace std;

namespace ng5newgeneration {
Ng5_CommonUtils::Ng5_CommonUtils() {
    // TODO Auto-generated constructor stub

}

Ng5_CommonUtils::~Ng5_CommonUtils() {
	// TODO Auto-generated destructor stub
}
/**
 * Function Name 	:	getLatestRevisionOverlay
 * Description		:	This function returns the Latest Revision.
 * Parameters		:
 * 						ItemRevision Tag (I)
 * Return Type		: 	tag_t
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 *  30/07/2018 	|			|	Arjun  			|	1. updated the Function history with new format for all the functions.
 *  			|			|					|	2. Added MEM_Free in the getLatestRevisionOverlay function.
 *  3/08/2018 	|			|	Arjun  			|	removed NG5_ITK_CALL macro for the API PREF_ask_value_count_at_location as it returns
 *  07/05/2021  |           |   Balaji          |   TC12 Upgrade			|
 *
 */
 
tag_t Ng5_CommonUtils::getLatestRevisionOverlay(tag_t tNewRevision)
{

	tag_t tItemTag 			= NULLTAG;
	tag_t tLatestRevProcess = NULLTAG;
	tag_t *ptRevList 		= NULL;
	tag_t tLatestRevTag		= NULLTAG;
	tag_t tPrevRevTag		= NULLTAG;
	tag_t tCurrentRevTag	= NULLTAG;

	int iFail				= ITK_ok;
	int iRevCounter			= 0;
	int iRevCount 			= 0;

	ITK(ITEM_ask_item_of_rev (tNewRevision,&tItemTag));

	//get all revisions

	ITK(ITEM_list_all_revs(tItemTag,&iRevCount,&ptRevList));
	for (int iRevCounter = 0; iRevCounter < iRevCount; iRevCounter++) {
		logical isObsolete 		= false;
		logical isFoundLatest 	= false;
		logical isClosed 		= false;
		logical isValidTag		= false;
		tag_t 	tLocalRevTag	= NULLTAG;

		tLocalRevTag=ptRevList[iRevCounter];

		POM_is_tag_valid(tLocalRevTag,&isValidTag);

		if (isValidTag == true)	{
		//Skip the revision if it is baseline Revision
			if (Ng5_CommonUtils::isStatused(tLocalRevTag, BASELINE_STATUS) || tLocalRevTag==tNewRevision || Ng5_CommonUtils::isMinor(tLocalRevTag))
			{
				if (iRevCounter == iRevCount - 1) {
					//tLatestRevTag = tPrevRevTag;
					tLatestRevProcess=tLatestRevTag;
					continue;
				} else
					continue;
			}
			else {
				if (iRevCounter == 0) {
					tCurrentRevTag = ptRevList[iRevCounter];
					tPrevRevTag = tCurrentRevTag;
					tLatestRevTag = tCurrentRevTag;
				}
				if (iRevCounter > 0) {
					if (iRevCounter == iRevCount - 1) {
						tLatestRevTag = tPrevRevTag;
						isFoundLatest = true;

						//tPrevRevTag = tCurrentRevTag;
						tCurrentRevTag = ptRevList[iRevCounter];
						tLatestRevTag = tCurrentRevTag;
						tLatestRevProcess=tLatestRevTag;
					}
					else {
						tPrevRevTag = tCurrentRevTag;
						tCurrentRevTag = ptRevList[iRevCounter];
						tLatestRevTag = tCurrentRevTag;
					}
					tLatestRevProcess=tLatestRevTag;
				}
			}
		}
	}
	//AGM# :Added MEM_FREE
	NG5_MEM_TCFREE( ptRevList );
	return tLatestRevProcess;
}
/**
 * Function Name 	:	isMinor
 * Description		:	This function returns true if item revision is minjor else false will be returned in case of major revision / baseline revision.
 * Parameters		:
 * 						ItemRevision Tag (I)
 * Return Type		: 	logical
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 *  12/01/2017 	|			|	Atish Misal		| This function returns true if item revision is minjor else false will be returned in case of major revision / baseline revision.
 *  30/07/2018	|			|	Arjun			| updated the Function history with new format.
 *
 */
logical Ng5_CommonUtils::isMinor(tag_t tItemRevTag)
{
		logical isMinor    = true;
		char *pcMinorRevId = NULL;
		char *pcRevID      = NULL;
		char* cRevId       = NULL;
		int iMaxNum        = 3;
		int iRevSize       = 0;
		
	    ITK(ITEM_ask_rev_id2 ( tItemRevTag, &cRevId ));
		iRevSize = strlen(cRevId);
		// Checking Rev ID size if it's less than or equal to 3 means this is Revise operation not a Baseline operation.
		if (iRevSize < iMaxNum  )
			{
				//This is major revision
			isMinor = false;
		}
		else if (iRevSize <= 6)
		{

			// Tokanise Revision Id to find out Major /Minor / Baseline Id
			pcRevID = tc_strtok(cRevId, ".");
			//AAaa  =  minor
			//AA = Major
			pcMinorRevId = tc_strtok(NULL, ".");

			if (iMaxNum < tc_strlen(pcMinorRevId)) {
				//Setting flag true for Only Revise operation
				//if pcMinorRevId is greater than 3 means its a minor revision
				isMinor = false;

			}
			if (strlen(pcRevID) > 2)
			//When there is no baseline and rev id size is less than 6. e.g. Minor revision (AAaa)
			{
				isMinor = true;
			}

		}
		
			

		MEM_TCFREE (cRevId);
		return isMinor;
}

/**
 * Function Name 	:	isMinorRevision
 * Description		:	This function returns true if item revision is minjor else false will be returned in case of major revision / baseline revision.
 * Parameters		:
 * 						ItemRevision ID (I)
 * Return Type		: 	logical
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 *  12/01/2017 	|			|	Shibabrata jena	| This function returns true if item revision is minjor else false will be returned in case of major revision / baseline revision.
 *  30/07/2018	|			|	Arjun			| updated the Function history with new format.
 *
 */
logical Ng5_CommonUtils::isMinorRevision(char * cRevId)
{
		logical isMinor =true;
		char *pcMinorRevId = NULL;
		char *pcRevID = NULL;
		int iMaxNum = 3;
		int iRevSize = 0;
		iRevSize = strlen(cRevId);
		// Checking Rev ID size if it's less than or equal to 3 means this is Revise operation not a Baseline operation.
		if (iRevSize < iMaxNum  )
			{
				//This is major revision
			isMinor = false;
		}
		else if (iRevSize <= 6)
		{

			// Tokanise Revision Id to find out Major /Minor / Baseline Id
			pcRevID = tc_strtok(cRevId, ".");
			//AAaa  =  minor
			//AA = Major
			pcMinorRevId = tc_strtok(NULL, ".");

			if (iMaxNum < tc_strlen(pcMinorRevId)) {
				//Setting flag true for Only Revise operation
				//if pcMinorRevId is greater than 3 means its a minor revision
				isMinor = false;

			}
			if (strlen(pcRevID) > 2)
			//When there is no baseline and rev id size is less than 6. e.g. Minor revision (AAaa)
			{
				isMinor = true;
			}

		}



		return isMinor;
}

/**
 * Function Name 	:	isStatused
 * Description		:	Passing the status name to be checked and ItemRev tag as input parameters If the passed status matches with any of the statuses of the input object, function returns true else false
 * Parameters		:
 * 						Item Revision Tag  	(I)
 * 						Status Name 		(I)
 * Return Type		: 	logical
 *
 * History			:
 * Date			|  	AGM		|	Name          		|	Comments
 * ------------------------------------------------------------------------------------------------
 *  09/12/2016 	|			|	Pradnya Hingankar	| Passing the status name to be checked and ItemRev tag as input parameters If the passed status matches with any of the statuses of the input object, function returns true else false
 *  30/07/2018	|			|	Arjun				| updated the Function history with new format.
 *
 */
logical Ng5_CommonUtils::isStatused(tag_t tItemRevTag, char * szStatusName)
{
	int iStatusCnt 			= 0;
	tag_t *ptStatusList 	= NULL;


	ITK(WSOM_ask_release_status_list(tItemRevTag , &iStatusCnt , &ptStatusList));

	if (iStatusCnt > 0)
	{
		if(szStatusName == NULL || tc_strlen(szStatusName) == 0 )
		{
			return true;
		}
		char *szTempStatusName 	= NULL;
		ITK(AOM_ask_name (ptStatusList[0],&szTempStatusName));

		if (tc_strcmp(szTempStatusName, szStatusName) == 0)
		{
			return true;

		}
		MEM_TCFREE(szTempStatusName);

	}
	MEM_TCFREE(ptStatusList);

	return false;

}
/**
 * Function Name 	:	loadAllPreferencesIntoMap
 * Description		:	This function reads the SITE preference with the given name, splits the value with delimitor = and loads the values into Map.
 * Parameters		:
 * 						Preference Name (I)
 * 						Preference values in Map (0)
 * Return Type		: 	Int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 * 30/07/2018  	|			|	Arjun      		|	Added ITK macro, changed code format and added comments.
 */
int Ng5_CommonUtils::loadAllPreferencesIntoMap( string  szPreferenceName, map<string, string> &MapPreference)
{
    int    iFail           = ITK_ok;
    int    iValueCount     = 0;
    int    iPrefValueCount = 0;
    scoped_smptr< char*> chPrefValue;
    MapPreference.clear();

    TC_write_syslog("\n Entering Ng5_CommonUtils::loadAllPreferencesIntoMap \n");

    //Added NG5_ITK_CALL macro.
    PREF_ask_value_count_at_location( szPreferenceName.c_str(), TC_preference_site,  &iValueCount );
    //Above API returns ITK_ok if preference is found, else returns which is breaking the functionality so removing NG5_ITK_CALL
    if(iValueCount == 0)
    {
    	TC_write_syslog( "\n Not found any values in preference %s", szPreferenceName.c_str() );
    	TC_write_syslog ("\n Exiting loadAllPreferencesIntoMap function..\n");
    	return iFail;
    }

    NG5_ITK_CALL(PREF_ask_char_values_at_location( szPreferenceName.c_str(), TC_preference_site, &iPrefValueCount , &chPrefValue ));

     TC_write_syslog("\n Preference %s having %d values ",szPreferenceName.c_str(), iPrefValueCount );

    for (int iPrefIndex =0 ; iPrefIndex < iPrefValueCount; iPrefIndex++ )
    {
    	char  * chParticipant     = NULL;
    	char  * chRoleAttribute   = NULL;

    	chParticipant  = tc_strtok ( chPrefValue.get()[iPrefIndex] , "=" );
    	chRoleAttribute = tc_strtok ( NULL , NULL );

    	string szParticipant(chParticipant);
    	string szRoleAttribute(chRoleAttribute);
    	TC_write_syslog("\n ||%d||%s||%s||", iPrefIndex, szParticipant.c_str(), szRoleAttribute.c_str());
    	MapPreference[szParticipant] = szRoleAttribute;

    }
    TC_write_syslog ("\n Exiting loadAllPreferencesIntoMap function..\n");

    return iFail;
}


/**
 * Function Name 	:	ZeroPadNumber
 * Description		:	the number is converted to string with zero pad to make it length of 4 characters
 * Parameters		:
 * 						Number (I)
 * Return Type		: 	std::string
 *
 * History			:
 * Date			|  	AGM		|	Name          		|	Comments
 * ------------------------------------------------------------------------------------------------
 *  -		 	|			|	-					| the number is converted to string with zero pad to make it length of 4 characters
 *  30/07/2018	|			|	Arjun				| updated the Function history with new format.
 *
 */
std::string Ng5_CommonUtils::ZeroPadNumber(int num)
{
	stringstream ss;

	// the number is converted to string with the help of stringstream
	ss << num;
	std::string ret;
	ss >> ret;

	// Append zero chars
	int str_length = ret.length();
	for (int i = 0; i < 4 - str_length; i++)
		ret = "0" + ret;
	return ret;
}

/**
 * Function Name 	:	splitStringToVector
 * Description		:	Splits the input string with delimiter and returns the string vector
 * Parameters		:
 * 						Original String  (I)
 * 						Delimiter	(I)
 * Return Type		: 	vector<string>
 *
 * History			:
 * Date			|  	AGM		|	Name          		|	Comments
 * ------------------------------------------------------------------------------------------------
 *  -		 	|			|	-					| Splits the input string with delimiter and returns the string vector
 *  30/07/2018	|			|	Arjun				| updated the Function history with new format.
 *
 */
vector<string> Ng5_CommonUtils::splitStringToVector ( string strOrginalString, string strDelimiter )
{

	int iSplitCout = 0;
	size_t iFound;

	vector<string> vecSplitList;

	for (;iFound=strOrginalString.find(strDelimiter, iSplitCout+1);) {
		if (iFound != string::npos || iSplitCout == 0 ) {
			if (strOrginalString.substr(iSplitCout, iFound).size() > 0) {
				vecSplitList.push_back(strOrginalString.substr(iSplitCout, iFound));
			}
			if (iFound == string::npos) break;
		}
		else if (strOrginalString.substr(iSplitCout, iFound).size() > 0) {
			vecSplitList.push_back(strOrginalString.substr(iSplitCout, iFound));
			break;
		}

		iSplitCout = iFound+1;
	}

	return vecSplitList;

}

/**
 * Function Name 	:	Ng5_isCurrentGroup
 * Description		:	Returns true if the current group name matches with group name passed as argument
 * Parameters		:
 * 						Group Name  (I)
 * Return Type		: 	Int
 *
 * History			:
 * Date			|  	AGM		|	Name          		|	Comments
 * ------------------------------------------------------------------------------------------------
 *  -		 	|			|	-					| Returns true if the current group name matches with group name passed as argument
 *  30/07/2018	|			|	Arjun				| updated the Function history with new format.
 *
 */
int Ng5_CommonUtils::Ng5_isCurrentGroup(char *szGroupName)
{
	tag_t tCurrentGroupmember= NULLTAG;
	tag_t tCurrentGroup = NULLTAG;
    //TC12 Upgrade
	char *szCurrGroupName = NULL;

	ITK( SA_ask_current_groupmember  ( &tCurrentGroupmember ) );
	if ( tCurrentGroupmember != NULLTAG )
	{
		ITK( SA_ask_groupmember_group  ( tCurrentGroupmember, &tCurrentGroup ) );
		if ( tCurrentGroup != NULLTAG )
		{
			//TC12 Upgrade changed API, need to cleaup the variable.
			//Did not complete that activitity.
			ITK( SA_ask_group_name2(tCurrentGroup, &szCurrGroupName) );
			TC_write_syslog("\n Current Group is %s",szCurrGroupName);
			if(strcmp(szCurrGroupName,szGroupName)==0)
			{
				TC_write_syslog("\n Group Matches");
				MEM_TCFREE (szCurrGroupName);
				return true;
			}
		}
	}

	return false;
}

/**
 * Function Name 	:	Find_All_Primary_Object
 * Description		:	Returns the count and array Primary Objects for given Object with given relation name
 * Parameters		:
 * 						Secondary Object  		(I)
 * 						Relation Name			(I)
 * 						Primary Object Count 	(O)
 * 						Primary Object tag array(O)
 * Return Type		: 	Int
 *
 * History			:
 * Date			|  	AGM		|	Name          		|	Comments
 * ------------------------------------------------------------------------------------------------
 *  -		 	|			|	-					| Returns the count and array Primary Objects for given Object with given relation name
 *  30/07/2018	|			|	Arjun				| updated the Function history with new format.
 *
 */
int Ng5_CommonUtils::Find_All_Primary_Object (
						tag_t Secondary_Object, /**< (I)Primary  Object Tag */
						char *relation_name,  /**< (I) Relation Name */
						int *Primary_Object_Count,   /**< (O)Count of Secondary object */
						tag_t **Primary_Object_Tags) /**< (OF)List of Secondary object tag */
{
	int ifail = ITK_ok;
	*Primary_Object_Tags = NULL;
	*Primary_Object_Count = 0;
	if ((Secondary_Object != NULLTAG) &&(relation_name != NULL))
	{
		tag_t  Relation_Type_Tag  = NULLTAG;
		ITK(GRM_find_relation_type(relation_name,&Relation_Type_Tag));
		if (Relation_Type_Tag != NULLTAG)
		{
			ITK(GRM_list_primary_objects_only(Secondary_Object,Relation_Type_Tag,Primary_Object_Count,Primary_Object_Tags));
		}
	}
	return ifail;
}

/**
 * Function Name 	:	Find_All_Secondary_Objects
 * Description		:	Returns the count and array Secondary Objects for given Object with given relation name
 * Parameters		:
 * 						Primary Object  			(I)
 * 						Relation Name				(I)
 * 						Secondary Object Count 		(O)
 * 						Secondary Object tag array	(O)
 * Return Type		: 	Int
 *
 * History			:
 * Date			|  	AGM		|	Name          		|	Comments
 * ------------------------------------------------------------------------------------------------
 *  -		 	|			|	-					| Returns the count and array Secondary Object for given Object with given relation name
 *  30/07/2018	|			|	Arjun				| updated the Function history with new format.
 *
 */
int Ng5_CommonUtils::Find_All_Secondary_Objects(tag_t tPrimaryObject, /**< (I)Primary  Object Tag */
												char *relation_name,  /**< (I) Relation Name */
												int *iObjectCount,   /**< (O)Count of Secondary object */
												tag_t **ptSecObjectTags) /**< (OF)List of Secondary object tag */

{
	int ifail = ITK_ok;
	*ptSecObjectTags = NULL;
	*iObjectCount = 0;

	if ((tPrimaryObject != NULLTAG) &&(relation_name != NULL))
	{
		tag_t  tRelationTypeTag  = NULLTAG;
		ITK(GRM_find_relation_type(relation_name,&tRelationTypeTag));
		if (tRelationTypeTag != NULLTAG)
		{
			ITK(GRM_list_secondary_objects_only(tPrimaryObject,tRelationTypeTag,iObjectCount,ptSecObjectTags));
		}
	}
		return ifail;
}

/**
 * Function Name 	:	Ng5_ProgramExport
 * Description		:	Exports the PLMXML file of given Program into the location present in preference NG5_PROGRAM_PLMXML_EXPORT_LOC and with transfer mode present in the preference NG5_MASTERPROGRAM_PLMXML_TRANSFER_MODE
 * Parameters		:
 * 						Program Revision  			(I)
 * Return Type		: 	Int
 *
 * History			:
 * Date			|  	AGM		|	Name          		|	Comments
 * ------------------------------------------------------------------------------------------------
 *  -		 	|			|	-					| Exports the PLMXML file of given Program into the location present in preference NG5_PROGRAM_PLMXML_EXPORT_LOC and with transfer mode present in the preference NG5_MASTERPROGRAM_PLMXML_TRANSFER_MODE
 *  30/07/2018	|			|	Arjun				| updated the Function history with new format.
 *
 */
int Ng5_CommonUtils::Ng5_programExport( tag_t tPR )
{
	int iFail = ITK_ok;
	char *tempXMLFileLoc = NULL;
	char* objType = NULL;
	char *progTfrMd = NULL ;
	tag_t tProgramItem = NULLTAG;
	char* item_id = NULL;
	char* slatest_rev_id = NULL;
	std::string xmlFileName ("");
	std::string logFileName ("");
	tag_t session = NULLTAG;
	tag_t *transfer_modes = NULL;
	int n_transfer_modes = 0;
	int n_objects = 1;
	tag_t objects[1];
	try
	{
		NG5_ITK_CALL( ITEM_ask_item_of_rev( tPR, &tProgramItem ));
		NG5_ITK_CALL( AOM_ask_value_string ( tProgramItem, "item_id", &item_id ));
		NG5_ITK_CALL(AOM_ask_value_string ( tPR,REV_ID, &slatest_rev_id));
		// Get the PLMXML File Export Location & Transfer Mode defined in the Preferences
		NG5_ITK_CALL(PREF_ask_char_value(NG5_PROGRAM_PLMXML_EXPORT_LOC,0,&tempXMLFileLoc));
		TC_write_syslog("\n  value of pref NG4_PROGRAM_PLMXML_EXPORT_LOC is --%s--  \n",tempXMLFileLoc);
		NG5_ITK_CALL( AOM_ask_value_string( tPR, "object_type", &objType ));

		if(( tc_strcmp( objType, "Ng5_MasterPrgRevision" ) == 0 )|| ( tc_strcmp( objType, NG5_LAUNCH_PRG_REVISION ) == 0) )
		{
			NG5_ITK_CALL(PREF_ask_char_value(NG5_MASTERPROGRAM_PLMXML_TRANSFER_MODE,0,&progTfrMd));
		}
		TC_write_syslog("\n  value  of pref NG4_PROGRAM_PLMXML_TRANSFER_MODE is --%s-- \n",progTfrMd);

		// Construct the Absolute File Path for the PLMXML file. e.g:/home/infodba/<ProgramID>.xml
		xmlFileName.assign( tempXMLFileLoc );
		xmlFileName.append( item_id );
		xmlFileName.append( "_" );
		xmlFileName.append( slatest_rev_id );
		xmlFileName.append( ".xml" );
		TC_write_syslog("\n  value  of  xmlFileName is --%s-- \n",xmlFileName.c_str());

		// Construct the Absolute File Path for the LOG file. e.g: /home/infodba/log/<ProgramID>.log
		// Expected a directory named "log" created under the location
		// mentioned in  preference"Ng4_Program_Plmxml_Export_Loc"
		logFileName.assign( tempXMLFileLoc );
		logFileName.append( "log\\" );
		logFileName.append( item_id );
		logFileName.append( "_" );
		logFileName.append( slatest_rev_id );
		logFileName.append( ".log" );
		TC_write_syslog("\n  value  of  logFileName is --%s-- \n",logFileName.c_str());

		// Create PIE session
		NG5_ITK_CALL(PIE_create_session(&session));
		TC_write_syslog("\n  after  PIE_create_session \n");
		// Set the name of the XML file to export
		NG5_ITK_CALL(PIE_session_set_file(session, xmlFileName.c_str()));
		TC_write_syslog("\n  after  PIE_session_set_file \n");
		// Set the name of the log file
		NG5_ITK_CALL(PIE_session_set_log_file(session, logFileName.c_str()));
		TC_write_syslog("\n  after  PIE_session_set_log_file \n");
		// Get transfer mode
		NG5_ITK_CALL(PIE_find_transfer_mode2 (progTfrMd, "", &n_transfer_modes,   &transfer_modes)) ;
		TC_write_syslog("\n  after  PIE_find_transfer_mode \n");
		// Set the transfer mode on the session
		if ( n_transfer_modes > 0 && transfer_modes[0] != NULL )
		{
			NG5_ITK_CALL(PIE_session_set_transfer_mode(session, transfer_modes[0])) ;
			TC_write_syslog("\n  after  PIE_session_set_transfer_mode \n");
			objects[0] = tPR;
			// Export the PLMXML File
			NG5_ITK_CALL(PIE_session_export_objects(session, n_objects, objects));
		}
		TC_write_syslog("\n  after  PIE_session_export_objects \n");
		NG5_ITK_CALL(PIE_delete_session(session));
		TC_write_syslog("\n  after  PIE_delete_session \n");
		
		MEM_TCFREE( tempXMLFileLoc );
		MEM_TCFREE( objType );
		MEM_TCFREE( progTfrMd );
		MEM_TCFREE( item_id );
		MEM_TCFREE( slatest_rev_id );
		MEM_TCFREE( transfer_modes );
	}
	catch(...)
	{
		MEM_free( tempXMLFileLoc );
		MEM_free( objType );
	    MEM_free( progTfrMd );
	    MEM_free( item_id );
	    MEM_free( slatest_rev_id );
	    MEM_free( transfer_modes );
	}
	return iFail;
}

/**
 * Function Name 	:	setNg5_UpdateDAProperty
 * Description		:	This function is called from getNg5_da_stateBase which is in DARevisionImpl.cxx
 * Parameters		:
 * 						DA Revision Tag (I)
 * Return Type		: 	Int
 *
 * History			:
 * Date			|  	Octane		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 *  21/1/2020 	|	326035		|	Monali  		|	1. This function sets the ng5_DeviationAuthorization property on Eng Part Rev and Raw Material Rev to NULL.
 *  			|				|					|
 *
 *
 */

int Ng5_CommonUtils::setNg5_UpdateDAProperty (tag_t tDARevTag)
{
	int ifail = ITK_ok;
	int iSecObjCount = 0;
	tag_t *ptSecObjets = NULL;
	int numofdevauthrevs = 0;
	tag_t *tagtDevAuthRevs = NULLTAG;
	logical lPriVerdict = false;
	char * cpErrorMsgString = NULL;
	

	TC_write_syslog("\n Inside setNg5_UpdateDAProperty \n");

	Ng5_CommonUtils::Find_All_Secondary_Objects(tDARevTag,"CMHasProblemItem",&iSecObjCount,&ptSecObjets);

	TC_write_syslog("\n Eng Part Rev and Raw Mat Rev  count in setNg5_UpdateDAProperty function is: %d \n", iSecObjCount);

	for(int inx=0; inx<iSecObjCount; inx++)
	{

	      if(NULLTAG != ptSecObjets[inx])
	       {
	    	  	  	  	//Get the secondary object type
	    	            //TC12 Upgrade output need to be cleaned.
						char   *cObjectType = NULL;
	            		ITK( WSOM_ask_object_type2 (ptSecObjets[inx], &cObjectType) );

	            		TC_write_syslog("\n Object Type : %s \n",cObjectType);

	            		//Checking if object type is a Eng Part Revision or Raw Material Revision
	            		if((tc_strcmp(cObjectType, ENG_PART_REVISION )) == 0 || (tc_strcmp(cObjectType, RAW_MATERIAL_REVISION )) == 0)
	            		{
	            			ITK(AOM_ask_value_tags(ptSecObjets[inx], DEVIATION_AUTHORIZATION_PROPERTY, &numofdevauthrevs, &tagtDevAuthRevs));

							 TC_write_syslog("\n Dev Autho count : %d \n", numofdevauthrevs);

							//Checking if the 'Deviation Authorization' rev count is more than 0

							if (numofdevauthrevs > 0 && tagtDevAuthRevs != NULL)

							{

								for (int indxDevAuthRev = 0; indxDevAuthRev < numofdevauthrevs; indxDevAuthRev++)

								{

									//Checking if the 'Deviation Authorization' rev is already attached to ng5_DeviationAuthorization Property

									if (tagtDevAuthRevs[indxDevAuthRev] == tDARevTag)

									{

										ITK( AM_check_privilege (ptSecObjets[inx], "WRITE", &lPriVerdict));

										AM__set_application_bypass(true);

										ITK( AM_check_privilege (ptSecObjets[inx], "WRITE", &lPriVerdict));

										if (lPriVerdict)

										{

											TC_write_syslog("\n access obtained \n");

											ITK(AOM_refresh(ptSecObjets[inx],TRUE));

											//ITKCALL(AOM_set_value_tag_at(ptSecObjs[iLoopSec],NG5_DEV_AUTHORIZATION,numofdevauthrevs,ptTargetAttachments[iIndex]));

											ifail = AOM_set_value_tag_at(ptSecObjets[inx],DEVIATION_AUTHORIZATION_PROPERTY,indxDevAuthRev,NULL);
											//ITK(AOM_set_value_tag_at(ptSecObjets[inx],"ng5_DeviationAuthorization",indxDevAuthRev,NULL));
											EMH_ask_error_text(ifail,&cpErrorMsgString);

											TC_write_syslog( "Error while setting DA property to Null in setNg5_UpdateDAProperty: [%s]\n", cpErrorMsgString);

											TC_write_syslog("\n Setting Property ng5_DeviationAuthorization to Null \n");

											ITK(AOM_save_with_extensions(ptSecObjets[inx]));//TC12 Upgrade

											ITK(AOM_refresh(ptSecObjets[inx],FALSE));

										}

										else

										{

											TC_write_syslog("\n access not obtained \n");

										}

										AM__set_application_bypass(false);
									}//if (tagtDevAuthRevs[indxDevAuthRev] == tDARevTag)

								}//for (int indxDevAuthRev = 0; indxDevAuthRev < numofdevauthrevs; indxDevAuthRev++)

							}//if (numofdevauthrevs > 0 && tagtDevAuthRevs != NULL)

	            		 }//if((tc_strcmp(cObjectType, ENG_PART_REVISION )) == 0 || (tc_strcmp(cObjectType, RAW_MATERIAL_REVISION )) == 0)
               NG5_MEM_TCFREE(cObjectType);
	           }//if(NULLTAG != ptSecObjets[inx])
			
	 }//for(int inx=0; inx<iSecObjCount; inx++)

	NG5_MEM_TCFREE(ptSecObjets);
	NG5_MEM_TCFREE(tagtDevAuthRevs);
	NG5_MEM_TCFREE(cpErrorMsgString);

	return ifail;
}


/**
 * Function Name 	:	setNg5_ChangeState
 * Description		:	This function is called from getNg5_da_stateBase which is in DARevisionImpl.cxx
 * Parameters		:
 * 						ItemRevision Tag (I)
 * Return Type		: 	tag_t
 *
 * History			:
 * Date			|  	Octane		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 *  03/12/2018 	|	251037		|	Bhanu  			|	1. This function sets the ng5_changestate attribute value to Closed.
 *  			|			|					|	
 *  
 *
 */

int Ng5_CommonUtils::setNg5_ChangeState(tag_t tDARevTag)
{
	int ifail = ITK_ok;
	int ilockType = 0;
	tag_t 		 tattrId					=   NULLTAG;
	TC_write_syslog("\n Inside setNg5_ChangeState \n");
	ITK( POM_attr_id_of_attr( ATTR_CHANGE_STATE, CHANGE_ITEM_REVISION, &tattrId));
	TC_write_syslog("\n Inside setNg5_ChangeState attrId is %d\n", tattrId);
	ITK(POM_ask_instance_lock(tDARevTag, &ilockType));
	TC_write_syslog("\n Inside setNg5_ChangeState locktype is %d\n", ilockType);
	if(ilockType == 1)
	{
		TC_write_syslog("\n Inside setNg5_ChangeState entered POM_Modify_lock session");
		ITK( POM_set_attr_string( 1, &tDARevTag, tattrId, CLOSED_STATE));
		ITK( POM_save_instances( 1, &tDARevTag, true));
	}
	else
	{
		TC_write_syslog("\n Inside setNg5_ChangeState Else POM_Modify_lock session \n");
		
		AM__set_application_bypass(true);
		ITK(POM_set_env_info(POM_bypass_attr_update,FALSE,0,0,0,""));
		TC_write_syslog("\n POM Bypass set successfully \n");
		TC_write_syslog("\n Bypass set successfully \n");
		ITK(POM_refresh_instances_any_class(1, &tDARevTag, POM_modify_lock));
		ITK( POM_set_attr_string( 1, &tDARevTag, tattrId, CLOSED_STATE));
		ITK( POM_save_instances( 1, &tDARevTag, true));
		ITK(POM_refresh_instances(1, &tDARevTag, NULLTAG,ilockType));
		ITK(POM_set_env_info(POM_bypass_attr_update,TRUE,0,0,0,""));
		TC_write_syslog("\n POM Bypass revoked successfully \n");
		AM__set_application_bypass(false);
	
	}
	TC_write_syslog("\n Leaving setNg5_ChangeState ");
	return ifail;
}
/**
 * Function Name 	:	getConvertedWeight
 * Description		:	This function is called from getConvertedWeight which is used in Ng5_ICEPartFormImpl.cxx, Ng5_rHasMatlMasterRelCreatePostAction.cxx and Ng5_rHasPlantFormRelCreatePostAction.cxx
 * Parameters		:	cSAPUom, cPlantUOM, value and newValue(converted value)
 *
 * Return Type		: 	Int
 *
 * History			:
 * Date			|  	Octane		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 *  21/1/2020 	|	399009		|	Padma   		|	1. This function converts the SAP Net Weight property value on ICE Part Form according to Plant Net Weight UOM on Plant Form.
 *  			|				|					|
 *
 *
 */

int Ng5_CommonUtils::getConvertedWeight (char* cSAPUom, char* cPlantUOM, double value, double* newValue)
{
    int 	ifail 				= ITK_ok;
	tag_t 	tChangeItemRev 		= NULLTAG;
	char* 	sapPlantUOM			= NULL;
	string 	wtCoversionPref 	= "";
	double 	dStroreValue		= 0.0;
	double 	finalValue			= 0.0;

	TC_write_syslog("\n setNg5_sap_net_weightBase: Entering getConvertedWeight \n");
	TC_write_syslog("\n **** setNg5_sap_net_weightBase:getConvertedWeight: cSAPUom, cPlantUOM, value=%s-%s-%f \n",cSAPUom, cPlantUOM,value);
	map<string, string> MapPrefValues;
	MapPrefValues.clear();

	sapPlantUOM = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cSAPUom) + tc_strlen(UNDERSCORE) + tc_strlen(cPlantUOM) + 10));
	tc_strcpy(sapPlantUOM, cSAPUom);
	tc_strcat(sapPlantUOM, UNDERSCORE);
	tc_strcat(sapPlantUOM, cPlantUOM);

	TC_write_syslog("\n ###sapPlantUOM :: %s\n",sapPlantUOM);

	wtCoversionPref = string(PREF_WEIGHT_CONVERSIONS);
	Ng5_CommonUtils::loadAllPreferencesIntoMap(wtCoversionPref, MapPrefValues);

	for(map<string, string>::iterator itr = MapPrefValues.begin() ; itr != MapPrefValues.end() ; ++itr)
	{
		if(tc_strcmp(sapPlantUOM, itr->first.c_str()) == 0)
		{
			//TC_write_syslog("\n itr->second.c_str() :: %s\n",itr->second.c_str());
			//TC_write_syslog("\n itr->first.c_str() :: %s\n",itr->first.c_str());
			dStroreValue = 0.0;
			dStroreValue = atof(itr->second.c_str());
			TC_write_syslog("\n setNg5_sap_net_weightBase:getConvertedWeight: dStroreValue= %f\n",dStroreValue);

			//*newValue = dStroreValue * value;
			//TC_write_syslog("\n setNg5_sap_net_weightBase:getConvertedWeight: newValue= %f\n",*newValue);
			*newValue = roundTo5Places(dStroreValue * value);
			TC_write_syslog("\n setNg5_sap_net_weightBase:getConvertedWeight: newValue= %f\n",*newValue);
			break;
		}
		//TC_write_syslog("\n itr->first.c_str() :: %s\n",itr->first.c_str());
		//TC_write_syslog("\n itr->second.c_str() :: %s\n",itr->second.c_str());
	}
	TC_write_syslog("\n End of setNg5_sap_net_weightBase:getConvertedWeight \n");

	NG5_MEM_TCFREE (sapPlantUOM);
	return ifail;
}
double Ng5_CommonUtils::roundTo5Places(double d) {
    return round(d * 1000) / 1000.0;
}

int Ng5_CommonUtils::getAttrIDTag (tag_t tObject, char* sClassName, char* sAttrName, tag_t* tAttrTag)
{
	int ifail 				= ITK_ok;
	tag_t inst_class_id     = NULLTAG;
	int values_index        = -1;
	tag_t tAttrDateId       = NULLTAG;
	char FormClassName[TCTYPE_class_name_size_c+1]   = {'\0'};

	ITKCALL(POM_attr_id_of_attr(sAttrName,sClassName,tAttrTag));
	return ifail;
}

logical Ng5_CommonUtils::is_descendant_of_Form(tag_t object)
{
	tag_t form_class = NULLTAG;
    ITKCALL(POM_class_id_of_class(CLS_FORM, &form_class));

    tag_t class_tag = NULLTAG;
    ITKCALL(POM_class_of_instance(object, &class_tag));

    logical verdict = FALSE;
    ITKCALL(POM_is_descendant(form_class, class_tag, &verdict));

    return (verdict);
}

char* Ng5_CommonUtils::convertSpecialCharacters(char* cpOriginalFileName)
{
	 char cspecialCharecters[256+1] = "~&*():\\/<>?\"[]|{}`";
	 char cunderScore ='_';

	 TC_write_syslog("\n Entering  Ng5_CommonUtils::convertSpecialCharecters\n");

			for(int i = 0; cpOriginalFileName[i] != '\0'; i++)
			{

				for (int j = 0; cspecialCharecters[j] != '\0'; j++)
				{

					if( cpOriginalFileName[i] == cspecialCharecters[j])
					{

						cpOriginalFileName[i] = cunderScore;
					}
				}
			}
			TC_write_syslog("\n Entering  Ng5_CommonUtils::convertSpecialCharecters\n");

return cpOriginalFileName;
}

}
