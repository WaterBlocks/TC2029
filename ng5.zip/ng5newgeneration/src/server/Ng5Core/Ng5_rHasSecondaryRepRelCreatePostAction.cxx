//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasSecondaryRepRelCreatePostAction
 *   Function will get fired whenever the Relationship between Engineered Part and Support Design Revision
 *   is created with Relation HasSecondaryRepRel.
 *   It checks for the Engineering Part attached to Support Design Revision typed reference property
 *   ng5_related_engg_parts. If not then attaches the  Eng Part Revision to this property.
 *
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   14/04/2022  Jogesh Fulsunge  Initial Version
 */

#include <Ng5Core/Ng5_rHasSecondaryRepRelCreatePostAction.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <base_utils/TcResultStatus.hxx>
#include <fclasses/tc_string.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <string.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tcinit/tcinit.h>
#include <tccore/grm.h>

using namespace Teamcenter;

int Ng5_rHasSecondaryRepRelCreatePostAction( METHOD_message_t * msg, va_list args )
{
	int iFail = ITK_ok;

	tag_t tEnggPartRev = NULLTAG;
	tag_t tSupportDesRev = NULLTAG;
	tag_t tRelationType = NULLTAG;

	TC_write_syslog("\n Entering Ng5_rHasSecondaryRepRelCreatePostAction \n");
	tEnggPartRev = va_arg(args, tag_t);
	tSupportDesRev = va_arg(args, tag_t);
	tRelationType = va_arg(args, tag_t);

	if (NULLTAG != tEnggPartRev && NULLTAG != tSupportDesRev && NULLTAG != tRelationType)
	{
		scoped_smptr<char> cpPrimObjClassName;
		scoped_smptr<char> cpSecObjClassName;
		tag_t tPrimType = NULLTAG;
		tag_t tSecType = NULLTAG;

		ITK( TCTYPE_ask_object_type( tEnggPartRev, &tPrimType ));
		if (tPrimType != NULLTAG)
		{
			ITK( TCTYPE_ask_class_name2 ( tPrimType,&cpPrimObjClassName));
		}
		ITK( TCTYPE_ask_object_type( tSupportDesRev, &tSecType ));
		if (tSecType != NULLTAG)
		{
			ITK( TCTYPE_ask_class_name2 ( tSecType,&cpSecObjClassName));
		}

		if (NULL != cpPrimObjClassName.get() && NULL != cpSecObjClassName.get())
		{
			// Allow only if the primary object is Engineered Part Revision and
			// Secondary Object is Drawing Revision

			if ( (tc_strcmp(cpPrimObjClassName.getString(), ITEM_ENGINEERED_PART_REVISION) == 0) && (tc_strcmp(cpSecObjClassName.getString(), ITEM_SUPPORT_DESIGN_REVISION) == 0))
			{
				int numofEngPrt = 0;

				scoped_smptr<tag_t> tagPrtValues;
				logical engPartExist = false;

				logical	lPriVerdict	=	false;

				ITK( AM_check_privilege (tSupportDesRev, ACCESS_WRITE, &lPriVerdict) ); //Allow only if the logged in user has write access to Primary object

				if (true == lPriVerdict)
				{
					NG5_ITK_CALL(AOM_ask_value_tags(tSupportDesRev,RELATED_ENGG_PARTS,&numofEngPrt,&tagPrtValues));
					//Checking if the Part count is more than 0
					if (numofEngPrt > 0 && tagPrtValues != NULL)
					{
						for (int indxEngPrt = 0; indxEngPrt < numofEngPrt;indxEngPrt++)
						{
							//Checking if the Engineered Part is already attached to Support Design Property
							if (tagPrtValues[indxEngPrt] == tEnggPartRev)
							{
								engPartExist = true;
							}
						}
					}
					//Setting the Property of Support Design with Eng Part Values
					//If the Part Does not exist or Property value count is 0
					if (engPartExist == false || numofEngPrt == 0)
					{
						NG5_ITK_CALL(AOM_refresh(tSupportDesRev,TRUE));
						NG5_ITK_CALL(AOM_set_value_tag_at(tSupportDesRev,RELATED_ENGG_PARTS,numofEngPrt, tEnggPartRev));
						NG5_ITK_CALL(AOM_save_with_extensions(tSupportDesRev));
						NG5_ITK_CALL(AOM_refresh(tSupportDesRev,FALSE));
						if (iFail != ITK_ok)
						{
							return iFail;
						}
					}
				}

			}

		}
	}
	TC_write_syslog("\n Exiting Ng5_rHasSecondaryRepRelCreatePostAction \n");
	return iFail;
}
