//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_MfgCNRevisionImpl
//

#ifndef NG5NEWGENERATION__NG5_MFGCNREVISIONIMPL_HXX
#define NG5NEWGENERATION__NG5_MFGCNREVISIONIMPL_HXX

#include <Ng5Core/Ng5_MfgCNRevisionGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_MfgCNRevisionImpl; 
    class Ng5_MfgCNRevisionDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_MfgCNRevisionImpl
    : public ng5newgeneration::Ng5_MfgCNRevisionGenImpl
{
public:


    ///
    /// Description for the Finalize Create Input
    /// @param creInput - desc for  creInput parameter
    /// @return - Return desc for Initialize for Create
    ///
    int  finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a Ng5_MfgCNRevision
    explicit Ng5_MfgCNRevisionImpl( Ng5_MfgCNRevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_MfgCNRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_MfgCNRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_MfgCNRevisionImpl( const Ng5_MfgCNRevisionImpl& );

    ///
    /// Copy constructor
    Ng5_MfgCNRevisionImpl& operator=( const Ng5_MfgCNRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_MfgCNRevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_MFGCNREVISIONIMPL_HXX
