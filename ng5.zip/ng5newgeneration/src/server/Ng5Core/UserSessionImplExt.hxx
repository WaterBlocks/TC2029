//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object UserSessionImpl
//

#ifndef NG5__NG5NEWGENERATION__USERSESSIONIMPL_HXX
#define NG5__NG5NEWGENERATION__USERSESSIONIMPL_HXX

#include <Ng5Core/UserSessionGenImplExt.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5
{
    namespace ng5newgeneration
    {
        class UserSessionImpl; 
        class UserSessionDelegate;
    }
}

class  NG5CORE_API ng5::ng5newgeneration::UserSessionImpl
    : public ng5::ng5newgeneration::UserSessionGenImpl
{
public:

    ///
    /// 
    /// @param ng5_isBurSite - 
    /// @return - 
    ///
    int  ng5_isBurSiteBase( bool *ng5_isBurSite );
	int  ng5_bypass_rulesBase( bool *isbypass );
	int  ng5_isXBOMApplicableBase(bool *ng5_isXBOMApplicable);
	int  ng5_isLiveSourceApplicableBase(bool *ng5_isLiveSourceApplicable);



protected:
    ///
    /// Constructor for a UserSession
    explicit UserSessionImpl( UserSession& busObj );

    ///
    /// Destructor
    virtual ~UserSessionImpl();

private:
    ///
    /// Default Constructor for the class
    UserSessionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    UserSessionImpl( const UserSessionImpl& );

    ///
    /// Copy constructor
    UserSessionImpl& operator=( const UserSessionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5::ng5newgeneration::UserSessionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5__NG5NEWGENERATION__USERSESSIONIMPL_HXX
