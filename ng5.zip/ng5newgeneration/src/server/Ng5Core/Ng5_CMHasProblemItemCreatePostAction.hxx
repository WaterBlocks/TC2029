//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_CMHasProblemItemCreatePostAction
 *
 */
 
#ifndef NG5_CMHASPROBLEMITEMCREATEPOSTACTION_HXX
#define NG5_CMHASPROBLEMITEMCREATEPOSTACTION_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_CMHasProblemItemCreatePostAction(METHOD_message_t* msg, va_list args);

tag_t Ng5_Find_First_Revision12(tag_t Item);
int Ng5_find_Item(const char* cpItemid,const char* cpObjType,tag_t* tItemTag );
//int Ng5_DeleteImpactedRelation(tag_t tTargetObject ,char* cp2RelationNames);
int Ng5_DeleteRelation11(tag_t tPrimay,tag_t tSecondary,char* cp2RelationNames);
#define MASSUPDATERev                         "Ng5_MassUpdateRevision"
#define MFGPART                         	  "Ng5_MfgPart"
#define MFGPARTRev                            "Ng5_MfgPartRevision"
#define ITEM_ID                        	  	  "item_id"
#define ITEM_REV_ID                           "item_revision_id"
#define rPROBLEMS                             "CMHasProblemItem"
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_CMHASPROBLEMITEMCREATEPOSTACTION_HXX
