//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   The Extension Ng5_PlantForm_IMAN_Save_PostAction populates the value of 'SAP Net Weight' in 'Plant Net Weight' attribute according to UOM conversion.
 *
 */
#include <Ng5Core/Ng5_PlantForm_IMAN_Save_PostAction.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <iostream>
#include <string>
#include <iomanip>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <ug_va_copy.h>
#include <ce/ce.h>
#include <constants/constants.h>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdarg.h>
#include <sstream>
#include <fclasses/tc_string.h>
#include "Ng5_CommonUtils.hxx"

using namespace std;
using namespace ng5newgeneration;

int Ng5_PlantForm_IMAN_Save_PostAction( METHOD_message_t * msg, va_list args )
{
	TC_write_syslog ("\n\t Entering  Ng5_PlantForm_IMAN_Save_PostAction...\n" );

	int 		iFail 			= ITK_ok;
	tag_t 		inst_class_id   = NULLTAG;
	char* 		classname 		= NULL;
	tag_t   	tStorageID  	= NULLTAG;
	tag_t 		tObject 		= NULLTAG;
	double  	dSAPWt         	= 0.0;
	char*		cSAPUom 		= NULL;
	double  	dPlantWt       	= 0.0;
	char*		cPlantUom 		= NULL;
	char*		cItemType 		= NULL;
	char*		cCoOrigin 		= NULL;
	tag_t   	tItmTypAttrTag	= NULLTAG;
	tag_t   	tCooAttrTag     = NULLTAG;
	tag_t   	tAttrTag       	= NULLTAG;
	tag_t   	tUOMAttrTag    	= NULLTAG;

	METHOD_PROP_MESSAGE_OBJECT(msg, tObject);

	ITKCALL(POM_class_of_instance(tObject,&inst_class_id));
	ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tObject))
	{
		//TC_write_syslog("\n After is_descendant_of_Form\n");
		tag_t form_tag = tObject;
		tObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tObject));
	}
    if (tObject != NULLTAG)
   	{
    	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, PLANTFORM_STORAGE, ATTR_ITEM_TYPE, &tItmTypAttrTag));
    	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, PLANTFORM_STORAGE, ATTR_COUNTRY_OF_ORIGIN, &tCooAttrTag));

		if (tItmTypAttrTag != NULLTAG || tCooAttrTag != NULLTAG)
		{
			NG5_ITK_CALL( AOM_ask_value_string (tObject, ATTR_ITEM_TYPE, &cItemType));
			NG5_ITK_CALL( AOM_ask_value_string (tObject, ATTR_COUNTRY_OF_ORIGIN, &cCoOrigin));

			if ((tc_strcmp(cItemType,"PG-0") == 0) ||
				(tc_strcmp(cItemType,"PG-1") == 0) ||
				(tc_strcmp(cItemType,"PG-2") == 0) ||
				(tc_strcmp(cItemType,"BBPHOG") == 0) ||
				(tc_strcmp(cItemType,"BBPNO") == 0) ||
				(tc_strcmp(cItemType,"XC") == 0) ||
				(tc_strcmp(cItemType,"RC") == 0))
			{
				NG5_ITK_CALL (AOM_refresh(tObject, TRUE));
				NG5_ITK_CALL (AOM_set_value_string (tObject, ATTR_COUNTRY_OF_ORIGIN, NULL));
				//TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction:cCoOrigin %s\n", cCoOrigin);
				NG5_ITK_CALL (AOM_save_with_extensions(tObject));//TC 12 Upgrade
				NG5_ITK_CALL (AOM_refresh(tObject, FALSE));
			}
		}

		ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, PLANTFORM_STORAGE, ATTR_PLANT_WT, &tAttrTag));
		ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, PLANTFORM_STORAGE, ATTR_PLANT_UOM, &tUOMAttrTag));

		if (tAttrTag != NULLTAG || tUOMAttrTag != NULLTAG)
		{
			NG5_ITK_CALL( AOM_ask_value_double (tObject, ATTR_PLANT_WT, &dPlantWt));
			NG5_ITK_CALL( AOM_ask_value_string (tObject, ATTR_PLANT_UOM, &cPlantUom));
			TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction: dPlantWt = %f cPlantUom = %s \n", dPlantWt, cPlantUom);

			tag_t t_formObj = NULLTAG;

			METHOD_PROP_MESSAGE_OBJECT(msg, t_formObj);

			tag_t trelPF = NULLTAG;
			int iMMCnt = 0;
			tag_t *tPrimMMs = NULL;

			//Start traversing from Plant Form to Material Master
			ITKCALL (GRM_find_relation_type(REL_PLANTFORM, &trelPF));
			//Get Material Master
			NG5_ITK_CALL(GRM_list_primary_objects_only(t_formObj, trelPF, &iMMCnt, &tPrimMMs));
			//TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction:iMMCnt %d\n", iMMCnt);

			if(iMMCnt > 0 && tPrimMMs != NULL)
				{
					int iPNCount = 0;
					for(int iMMx= 0; iMMx< iMMCnt; iMMx++)
						{
						char* cObjMMType = NULL;
						AOM_ask_value_string(tPrimMMs[iMMx], ATTR_OBJECT_TYPE, &cObjMMType);
						//TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction:Object Type = %s \n",cObjMMType);

							//Material Master found
						if(tc_strcmp(cObjMMType, MATL_MASTER) == 0)
							{
								tag_t tRelMM = NULLTAG;
								int iPrimCnt = 0;
								tag_t *tPrimEngPN = NULL;

								//Traverse from Material Master to Eng Part
								NG5_ITK_CALL (GRM_find_relation_type(REL_MATLMSTR, &tRelMM));
								//Get Eng part
								ITKCALL(GRM_list_primary_objects_only(tPrimMMs[iMMx], tRelMM, &iPrimCnt, &tPrimEngPN));
								//TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction:iPrimCnt %d\n", iPrimCnt);

								if(iPrimCnt > 0 && tPrimEngPN != NULL)
									{
										int iPNCount = 0;

										for(int iNx= 0; iNx< iPrimCnt; iNx++)
											{
												char* cEPObjType = NULL;
												AOM_ask_value_string(tPrimEngPN[iNx], ATTR_OBJECT_TYPE, &cEPObjType);

												if(tc_strcmp(cEPObjType, ENG_PART) == 0 || tc_strcmp(cEPObjType, RAW_MATERIAL) == 0 || tc_strcmp(cEPObjType, PHANTOM_PART) == 0 || tc_strcmp(cEPObjType, PKG_PART) == 0)
													{
														//ENG_PART found
														iPNCount +=1;
														tag_t 	trelIPFType = NULLTAG;
														int 	iIPFCnt 	= 0;
														tag_t 	*tPrimIPF 	= NULL;

														//Get the relation type for the ICE Part form and Eng Part
														NG5_ITK_CALL (GRM_find_relation_type(REL_ICEPARTFORM, &trelIPFType));
														//Get ICE Part Form of Eng Part
														NG5_ITK_CALL(GRM_list_secondary_objects_only(tPrimEngPN[iNx], trelIPFType, &iIPFCnt, &tPrimIPF));
														//TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction:iPrimCnt %d\n", iIPFCnt);

														if(iIPFCnt > 0 && tPrimIPF != NULL)
															{
															char* cObjIPFType = NULL;
															AOM_ask_value_string(tPrimIPF[0], ATTR_OBJECT_TYPE, &cObjIPFType);
															//TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction:Object Type = %s \n",cObjIPFType);

															//Get SAP Net Weight
															double 	dSAPwt 		= 0.0;
															char*	cSAPUom 	= NULL;

															AOM_ask_value_string(tPrimIPF[0], ATTR_SAP_UOM, &cSAPUom);
															//TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction:cSAPUom=%s \n",cSAPUom);
															AOM_ask_value_double(tPrimIPF[0], ATTR_SAP_WT, &dSAPwt);
															//TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction: SAP Net Weight=%f\n",dSAPwt);

															NG5_ITK_CALL(Ng5_CommonUtils::getConvertedWeight(cSAPUom, cPlantUom, dSAPwt, &dPlantWt));
															TC_write_syslog("\n Ng5_PlantForm_IMAN_Save_PostAction:getConvertedWeight: newValue of Weight=%f\n",dPlantWt);

															ITKCALL (AOM_refresh(tObject, TRUE));
															ITKCALL (AOM_set_value_double (tObject, ATTR_PLANT_WT, dPlantWt));
															ITKCALL (AOM_save_with_extensions(tObject));//TC 12 Upgrade
															ITKCALL (AOM_refresh(tObject, FALSE));

															}
														NG5_MEM_TCFREE(tPrimIPF);
													}
												NG5_MEM_TCFREE(cEPObjType);
											}
								}
							NG5_MEM_TCFREE(tPrimEngPN);
							}
						NG5_MEM_TCFREE(cObjMMType);
						}
				}
			NG5_MEM_TCFREE (tPrimMMs);
		}
		else
		{
			TC_write_syslog("\n ** tAttrTag and tUOMAttrTag tag values are Empty **\n");
		}
	}
    NG5_MEM_TCFREE(cPlantUom);
    NG5_MEM_TCFREE(cItemType);
    NG5_MEM_TCFREE(cCoOrigin);
    NG5_MEM_TCFREE (classname);
return iFail;
}
