//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_Validate_Mfg_CreateInput
 *   History
 *   Sahida Khatun       Initial Creation     July ,2022
 *
 */
#include <Ng5Core/Ng5_Validate_Mfg_CreateInput.hxx>
#include <sstream>
#include <string>



/* 
 *  
 *   Function Name :  Ng5_Validate_Mfg_CreateInput
 *   Description   :  This is the PreCondition on IMAN_save of Manufacturing Part Revision to check if 
 *                    all the create inputs are correct
 *   History
 *   Sahida Khatun       Initial Creation     July ,2022
 *
 */
int Ng5_Validate_Mfg_CreateInput( METHOD_message_t *msg, va_list args  )
{
 
	    char* cpReCustPartNo = NULL; //OF
	    char* cpOEMName      = NULL; //OF
	    char* cpItemID       = NULL; //OF
	    char* cpRevID        = NULL;
	    char* cpMfgItemID    = NULL; 
	    char* cpSuffix       = NULL;//OF
	    char* cpWithSuffixID = NULL;
	    char* cpTypeName     = NULL; //OF
	    char* cPlantCode     = NULL; //OF
	    char* cPrimaryID     = NULL; //OF
	    tag_t* tEItems       = NULL;
	    tag_t  objTypeTag    = NULLTAG;
	    tag_t  tERevision    = NULLTAG;
	    tag_t  tRelationType = NULLTAG;
	    tag_t  tMfgItem      = NULLTAG;
	    tag_t* tPrimaryObjs  = NULL;
	    char*   cpOriginalID = NULL;
	    int    nPrimarycount = 0;
	    int    nItems        = 0;

                TC_write_syslog("Entering Ng5_Validate_Mfg_CreateInput");
		tag_t tMfgItemRev               = va_arg (args, tag_t);
		ITKCALL(AOM_ask_value_string( tMfgItemRev, RQRDCUSTPARTNO, &cpReCustPartNo));
		ITKCALL(AOM_ask_value_string( tMfgItemRev, ATTR_ITEM_ID, &cpItemID));
		ITKCALL(AOM_ask_value_string( tMfgItemRev, PLANTS, &cPlantCode));
		ITKCALL(AOM_ask_value_string( tMfgItemRev, SUFFIX, &cpSuffix));
		ITKCALL(ITEM_ask_item_of_rev(tMfgItemRev, &tMfgItem ));
		ITKCALL(ITEM_ask_id2(tMfgItem, &cpItemID));
		ITKCALL(AOM_ask_value_string( tMfgItem, ORIGINALID, &cpOriginalID ));
		TC_write_syslog("\n Item ID   %s\n", cpItemID);
		ITKCALL(AOM_ask_value_string( tMfgItemRev, ATTR_ITEM_REV_ID, &cpRevID ));
		if(tc_strlen(cPlantCode)==0)
		{
			TC_write_syslog ("--->>>>> Plant ID is blank",cPlantCode);
			return ITK_ok;
		}

		if(tc_strstr(cpRevID,DOT)!=NULL)
		{
			TC_write_syslog ("--->>>>> Baseline Revision Id %s",cpRevID);
			return ITK_ok;
		}
		ITKCALL(AOM_ask_value_string( tMfgItemRev, CUSTOMER, &cpOEMName ));
		TC_write_syslog("\n OEM Name: %s\n", cpOEMName);
		//cpMfgItemID= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cPlantCode)+tc_strlen(HYPHEN)+tc_strlen(cpItemID)+tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);

		if((tc_strlen(cpSuffix)>0) && (!Ng5_validSpecChar(cpSuffix)))
		{
			EMH_store_error_s1(EMH_severity_error,ErrorSuffixInvalidChar,cpSuffix);
			return ErrorSuffixInvalidChar ;
		}
		if(tc_strcmp(cpReCustPartNo,YES)==0)
		{
			if(tc_strlen(cpOEMName)==0)
			{
				EMH_store_error(EMH_severity_error,ErrorCodeNoOEMError );
			        return ErrorCodeNoOEMError ;

			}


		}
	    if(tc_strncasecmp(cpItemID,MHYPHEN,2)!=0)
	    {

	    	cpMfgItemID= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cPlantCode)+tc_strlen(HYPHEN)+tc_strlen(cpItemID)+tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);
	        tc_strcpy(cpMfgItemID,MHYPHEN);
	        tc_strcat(cpMfgItemID,cPlantCode);
	        tc_strcat(cpMfgItemID,HYPHEN);
	    	cpWithSuffixID =(char*)MEM_alloc(sizeof(char)*(tc_strlen(cpItemID)+tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);
			tc_strcpy(cpWithSuffixID,cpItemID);
			if(tc_strlen(cpSuffix)>0)
			{

			  tc_strcat(cpWithSuffixID,HYPHEN);
			  tc_strcat(cpWithSuffixID,cpSuffix);

			}
			tc_strcat(cpMfgItemID,cpWithSuffixID);
			
			if(tc_strlen(cpMfgItemID)>25)
			{
				EMH_store_error_s1(EMH_severity_error,ErrorLongItemID,cpWithSuffixID );
				return ErrorLongItemID ;
			}

		
			ITKCALL(ITEM_find(cpItemID,&nItems,&tEItems));
			for(int iEIx=0;iEIx <nItems;iEIx++)
			{
				TCTYPE_ask_object_type(tEItems[iEIx],&objTypeTag);
				TCTYPE_ask_class_name2(objTypeTag,&cpTypeName);
				if(Ng5_validType2Clone(cpTypeName))
				{

					ITKCALL(Ng5_getRev2CopyFrom(tEItems[iEIx],&tERevision));
					ITKCALL(GRM_find_relation_type(HASENGPART2MFGPARREV,&tRelationType));
					ITKCALL(GRM_list_primary_objects_only(tERevision,tRelationType,&nPrimarycount,&tPrimaryObjs));
					for(int iPx=0 ; iPx < nPrimarycount;iPx++)
					{
					ITKCALL(AOM_ask_value_string( tPrimaryObjs[iPx], ATTR_ITEM_ID, &cPrimaryID));
					if(tc_strcmp(cPrimaryID,cpMfgItemID)==0)
					{

					   EMH_store_error_s2(EMH_severity_error,ErrorSameMfgID,cPlantCode,cpMfgItemID);
					   return ErrorSameMfgID ;
					}

					}
				}
			}


	    }
	    else
	    {

             tag_t* tRevList       = NULL;
             tag_t* tRelStatusList = NULL;

             int   iCount       = 0;
             int   iStatusCount   = 0;
             int   iRelRev        = 0;

             //tag_t tSatusList      = NULLTAG;
            ///oolean  lHasRleasedRev = false;
             cpMfgItemID= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(cPlantCode)+tc_strlen(HYPHEN)+tc_strlen(cpOriginalID)+tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);
             tc_strcpy(cpMfgItemID,MHYPHEN);
             tc_strcat(cpMfgItemID,cPlantCode);
             tc_strcat(cpMfgItemID,HYPHEN);
			
	    	 ITEM_list_all_revs(tMfgItem,&iCount,&tRevList);

	    	 for(int iRevx = 0; iRevx<iCount;iRevx++  )
	    	 {

	    		 ITKCALL(AOM_ask_value_tags(tRevList[iRevx],RELEASE_STATUS_LIST,&iStatusCount,&tRelStatusList));
	    		 TC_write_syslog("\n Status  COunt : %d\n", iStatusCount);
	    		 if(iStatusCount>0)
	    		 {

	    			 iRelRev++;
	    		 }


	    	 }
			 TC_write_syslog("\n>>>>> cpOriginalID : %s \n",cpOriginalID);
			 if(tc_strncasecmp(cpOriginalID,MHYPHEN,2)==0)
			 {
				 std::string strOrginalId ="";
				 strOrginalId.assign(cpOriginalID);
				 
				 std::istringstream is( strOrginalId );
				 size_t count = 0;
				 std::string line;
				 while ( std::getline( is, line, '-' ) ) ++count;
				 std::size_t pos =  strOrginalId.find_first_of('-');
				 if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
				 pos =  strOrginalId.find_first_of('-');
				 if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
				 if(count>3 && tc_strlen(cpSuffix)>0)
				 {
					
					pos = strOrginalId.find_last_of(cpSuffix);
					if(pos != std::string::npos) strOrginalId= strOrginalId.replace(pos-tc_strlen(cpSuffix),(strOrginalId.length()), "");;
				 }
				 tc_strcpy(cpOriginalID, strOrginalId.c_str());
			 }
			  TC_write_syslog("\n>>>>> cpOriginalID post : %s \n",cpOriginalID);
					
	    	 if(tc_strstr(cpItemID,cpOriginalID)!= NULL)
	    	 {
       	    	 cpWithSuffixID =(char*)MEM_alloc(sizeof(char)*(tc_strlen(cpOriginalID)+tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);
	           	 tc_strcpy(cpWithSuffixID,cpOriginalID);
	    	 }
	    	 else
	    	 {

	    		 tag_t tRelType    = NULLTAG;

	    		 tag_t* tEBOMITEMs = NULL;

	    		 tag_t  tEBOMRev   = NULLTAG;
	    		 char* cpCustomerPartNUM = NULLTAG;

	    		 int   iCount = 0;

	    	     ITKCALL( GRM_find_relation_type(HASPLANTBOM, &tRelType) );
	    		 GRM_list_primary_objects_only(tMfgItemRev,tRelType,&iCount,&tEBOMITEMs);
	    		 if(iCount >0)
	    		 {
	    		  for(int iRelx = 0 ;iRelx <iCount; iRelx++)
	    		  {
	    		       Ng5_getRev2CopyFrom(tEBOMITEMs[iRelx],&tEBOMRev);
	    		       if(tc_strlen(cpOEMName)>0)
	    		       {
	    		         	   Ng5_getMfgCustomPartNum(tEBOMRev,cpOEMName,&cpCustomerPartNUM);
	    		         	   if(tc_strlen(cpCustomerPartNUM)>0)
	    		         		   break;
	    		        }
	    		    }
	    		 }
	    		 else
	    	    {
	    			 tag_t* tEBOMRevs   = NULL;
	    			 tag_t tSecRelType  = NULLTAG;
	    			 ITKCALL( GRM_find_relation_type(HASENGPART2MFGPARREV, &tSecRelType) );
	    			 GRM_list_secondary_objects_only(tMfgItemRev,tSecRelType,&iCount,&tEBOMRevs);
	    			 for(int iRelx = 0 ;iRelx <iCount; iRelx++)
	    			 {

	    			 	 if(tc_strlen(cpOEMName)>0)
	    			 	 {
	    			 	     Ng5_getMfgCustomPartNum(tEBOMRevs[iRelx],cpOEMName,&cpCustomerPartNUM);
	    			 	      if(tc_strlen(cpCustomerPartNUM)>0)
	    			 	       break;
	    			 	  }
	    			  }

	    			 NG5_MEM_TCFREE(tEBOMRevs);
	    		 }

	    		   if(tc_strlen(cpCustomerPartNUM)>0)
	    		   {
	    			   cpWithSuffixID =(char*)MEM_alloc(sizeof(char)*(tc_strlen(cpCustomerPartNUM)+tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);
	    			   tc_strcpy(cpWithSuffixID,cpCustomerPartNUM);

	    		 }


	    		 NG5_MEM_TCFREE(tEBOMITEMs);
	    		 NG5_MEM_TCFREE(cpCustomerPartNUM);


	    	 }
	    	 if(tc_strlen(cpSuffix)>0 && cpWithSuffixID != NULL)
	    	 {
				 tc_strcat(cpWithSuffixID,HYPHEN);
				 tc_strcat(cpWithSuffixID,cpSuffix);
	    	 }
			 TC_write_syslog("\n cpWithSuffixID    33333: %s\n", cpWithSuffixID);
             if(tc_strncasecmp(cpWithSuffixID,MHYPHEN,2)==0)
			 {
				 tc_strcpy(cpMfgItemID,cpWithSuffixID);
			 }
			 else tc_strcat(cpMfgItemID,cpWithSuffixID);
             TC_write_syslog("\n Manufacturing ID 33333: %s\n", cpMfgItemID);
			 tag_t* tMItems   = NULL;
			 tag_t objTypeTag = NULLTAG;
			 char* cpTypeName = NULL;
			 int    nItems = 0;
			  
			 ITKCALL(ITEM_find(cpMfgItemID,&nItems,&tMItems))

    		for(int iMIx=0;iMIx <nItems;iMIx++)
    		{
    			  if(tMItems[iMIx] !=tMfgItem)
    			  {
    		    	TCTYPE_ask_object_type(tMItems[iMIx],&objTypeTag);
    		    	TCTYPE_ask_class_name2(objTypeTag,&cpTypeName);

    		    	if(tc_strcmp(cpTypeName,MFGPART)==0)
    		    	{



					       EMH_store_error_s3(EMH_severity_error,ErrorSameSuffixSameID,cPlantCode,cpItemID,cpSuffix);

						   return ErrorSameSuffixSameID ;
    		    	}
    			  }





    		}
			 NG5_MEM_TCFREE(tMItems);
			 NG5_MEM_TCFREE(cpTypeName);
             TC_write_syslog("\n Released Rev %d\n", iRelRev);
             if(iRelRev>0)
             {


            	 if(tc_strcmp(cpMfgItemID,cpItemID)!=0)
            	 {
            	       EMH_store_error_s1(EMH_severity_error,ErrorEditBaselinedRev,cpWithSuffixID );
            	       return ErrorEditBaselinedRev ;
            	 }
             }

             if(tc_strlen(cpMfgItemID)>25)
             {
                	EMH_store_error_s1(EMH_severity_error,ErrorLongItemID,cpWithSuffixID );
                	return ErrorLongItemID ;
             }

                   NG5_MEM_TCFREE (tRevList);
		   NG5_MEM_TCFREE(tRelStatusList);
		   

	    }
     NG5_MEM_TCFREE(cpReCustPartNo);
	 NG5_MEM_TCFREE(cpOEMName);
	 NG5_MEM_TCFREE(cpItemID);
	 NG5_MEM_TCFREE(cpSuffix);
	 NG5_MEM_TCFREE(cpTypeName);
	 NG5_MEM_TCFREE(cPlantCode);
	 NG5_MEM_TCFREE(cPrimaryID);
	 NG5_MEM_TCFREE(cpOriginalID);
	 NG5_MEM_TCFREE(cpRevID);
	 TC_write_syslog("Exiting Ng5_Validate_Mfg_CreateInput");
	 return ITK_ok;

	}


/*
 * Function to check if the Item ID is alphanumeric or not
 */
	logical Ng5_isAlphaNumeric(char* cpItemID)

	{
		logical isAlphaNumeric = true;
		for(int idx=0;idx<tc_strlen(cpItemID);idx++)
		{
			if(!isalnum(cpItemID[idx]))
			{
				isAlphaNumeric = false;
				return isAlphaNumeric;
			}
		}

		return isAlphaNumeric;

	}

/*
 * Function to check if suffix has valid special character
 */
	logical Ng5_validSpecChar(char* cpSuffix)
	{
		logical validSpecChar = false;

		int     iValues       = 0;
		char* cpSpecChars   = NULL;

		 ITKCALL(PREF_ask_char_value(MFG_SPEC_CHAR_PREF,0,&cpSpecChars));

			for(int idx=0;idx<tc_strlen(cpSuffix);idx++)
			{
				if(!isalnum(cpSuffix[idx]))
				{
					int isMatched = 0;
					for(int iValx=0;iValx<tc_strlen(cpSpecChars);iValx++)
					{
	                  if(cpSuffix[idx]==cpSpecChars[iValx])
	                  {

						isMatched =1;

						break;
	                  }

					}
					if(isMatched >0)
					{
						validSpecChar = true;

					}
					else
					{
						validSpecChar = false;
						return validSpecChar;
					}
				}
				else
				{
					validSpecChar = true;
				}
			}

			return validSpecChar ;
	}
