//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
 * @file
 *
 *   This file contains the implementation for the Extension Ng5_CMHasProblemItemCreatePostAction
 *   Function will get called whenever Eng Part Rev & Raw Material Rev are attached to Problems folder present under Deviation Authorization Change Object.
 *   It checks for the  Eng Part Rev & Raw Material Rev attached to Problems folder present under Deviation Authorization Change Object & the property
 *   ng5_DeviationAuthorization on Eng Part Rev & Raw Material Rev gets updated.
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   09/26/2018  Meenakshi Shenoy  Initial Version
 *   07/05/2021  Balaji            TC12 Upgrade
 */
#include <Ng5Core/Ng5_CMHasProblemItemCreatePostAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_associatePartRevtoDARev(tag_t tPartRev, tag_t tDevAuthRev);

int Ng5_setDAPropertyValue(tag_t tPartRev, int numofdevauthrevs,tag_t tDevAuthRev);

/****************************************************************************************************
*Function Name : Ng5_CMHasProblemItemCreatePostAction
*Description   : This function Pastes the first Revision of an Mfg ITEM when trying to paste ITEM or other revision object on Mass Update Revsion with relation Problems
*****************************************************************************************************/
int Ng5_CMHasProblemItemCreatePostAction(METHOD_message_t *msg,
		va_list args) 
{
TC_write_syslog("\n Entering Ng5_CMHasProblemItemCreatePostAction\n");
int iFail			= ITK_ok;
tag_t tDevAuthRev 	= NULLTAG;
tag_t tPartRev 		= NULLTAG;
tag_t tRelationType = NULLTAG;
tag_t tRelation 	= NULLTAG;
tag_t tHasEngRel 	= NULLTAG;
tag_t tTargetRev 	= NULLTAG;
tag_t tItem 		= NULLTAG;
char* cObjectType 	= NULL;
char* cObjectType1 	= NULL;
char* cRevID		= NULL;
char* cItemID		= NULL;
tDevAuthRev   = va_arg(args, tag_t);
tPartRev 	  = va_arg(args, tag_t);
tRelationType = va_arg(args, tag_t);
if (NULLTAG != tDevAuthRev && NULLTAG != tPartRev && NULLTAG != tRelationType) 
{
/*	Added check to verify object type = Eng Part rev or Raw Material rev only.
	For rest of the types, code will skip the execution.*/
	NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));
	NG5_ITK_CALL(AOM_ask_value_string(tDevAuthRev,ATTR_OBJECT_TYPE, &cObjectType1));
	if(tc_strcmp(cObjectType1, MASSUPDATERev) == 0)
	{
		//iFail = Ng5_associatePartRevtoDARev(tPartRev,tDevAuthRev);
		if(tc_strcmp(cObjectType, MFGPART) == 0 )
		{
			tTargetRev = Ng5_Find_First_Revision12(tPartRev);
			iFail = Ng5_DeleteRelation11(tDevAuthRev,tPartRev,rPROBLEMS);
			iFail = GRM_find_relation_type(rPROBLEMS, &tRelationType);
			iFail = GRM_find_relation(tDevAuthRev, tTargetRev, tRelationType, &tRelation);
			if (iFail == ITK_ok && tRelation == NULLTAG)
			{
				iFail = GRM_create_relation(tDevAuthRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
				iFail = GRM_save_relation(tHasEngRel);
			}
		}
		if(tc_strcmp(cObjectType, MFGPARTRev) == 0 )
		{
			iFail = AOM_ask_value_string(tPartRev,ITEM_REV_ID, &cRevID);
			TC_write_syslog("\n After AOM_ask_value_string cRevID :%s ",cRevID);
			if(tc_strcmp(cRevID, "01") == 0 ||tc_strcmp(cRevID, "A") == 0  )
			{
				TC_write_syslog("\n Doing nothing as it is expected revison \n");
				// Do nothing
			} 
			else
			{
				iFail = AOM_ask_value_string(tPartRev,ITEM_ID, &cItemID);
				iFail= Ng5_find_Item(cItemID,MFGPART,&tItem);
				tTargetRev = Ng5_Find_First_Revision12(tItem);
				iFail = Ng5_DeleteRelation11(tDevAuthRev,tPartRev,rPROBLEMS);
				iFail = GRM_find_relation_type(rPROBLEMS, &tRelationType);
				iFail = GRM_find_relation(tDevAuthRev, tTargetRev, tRelationType, &tRelation);
				if (iFail == ITK_ok && tRelation == NULLTAG)
				{
					iFail = GRM_create_relation(tDevAuthRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
					iFail = GRM_save_relation(tHasEngRel);
				}
			}

		}
	}
	MEM_TCFREE(cObjectType);
	MEM_TCFREE(cObjectType1);
	MEM_TCFREE(cRevID);
	MEM_TCFREE(cItemID);
}
TC_write_syslog("\n Leaving Ng5_CMHasProblemItemCreatePostAction \n");
return iFail;
}

/****************************************************************************************************
*Function Name :Ng5_DeleteImpactedRelation
*Description   :This function removes the objects which is having that corresponding Relation
*****************************************************************************************************/
int Ng5_DeleteImpactedRelation(tag_t tTargetObject ,char* cp2RelationNames)
{
	TC_write_syslog(">>>>> Entering Ng5_DeleteImpactedRelation\n");
    int     ifail                      = 0;
    int     ImpactObjCount             = 0;
    int     iImpact					   = 0;
    int     iVal					   = 0;
    int     iCount                     = 0;
    tag_t   tImapactedRelation         = NULLTAG;
    tag_t   tImapctedrelation_type     = NULLTAG;	
    GRM_relation_t * tImpactobj ;
    ifail =  GRM_find_relation_type(cp2RelationNames, &tImapctedrelation_type);
    ifail =  GRM_list_secondary_objects(tTargetObject,tImapctedrelation_type,&ImpactObjCount,&tImpactobj);
    if(ImpactObjCount >0)
        {
        for(iImpact = 0 ;iImpact < ImpactObjCount ;iImpact++)
            {
             ifail = GRM_delete_relation(tImpactobj[iImpact].the_relation);
            }
        }
	TC_write_syslog(">>>>> Exiting Ng5_DeleteImpactedRelation\n");
    return ITK_ok;
}

/****************************************************************************************************
*Function Name : Ng5_DeleteRelation2
*Description   : This function removes the relation with primary object
*****************************************************************************************************/
int Ng5_DeleteRelation11(tag_t tPrimay,tag_t tSecondary,char* cp2RelationNames)
{
	TC_write_syslog("\n *****************************Enter Of Ng5_DeleteRelation MBOM Items********************** \n");
	tag_t tagDelRel = NULLTAG;
	int ifail 		= ITK_ok;
    tag_t tRelType  = NULLTAG;
	ifail =  GRM_find_relation_type(cp2RelationNames, &tRelType);
	ifail = AOM_refresh(tPrimay,TRUE);
	if( ifail == ITK_ok)
	{
		ifail = GRM_find_relation (tPrimay,tSecondary,tRelType,&tagDelRel);
	}
	if(tagDelRel != NULLTAG)
        ifail = GRM_delete_relation(tagDelRel);
        if( ifail == ITK_ok)
			ifail = AOM_refresh(tPrimay,FALSE);
    TC_write_syslog("\n *****************************Enter Of Ng5_DeleteRelation MBOM Items********************** \n");
    return ifail;
}

/****************************************************************************************************
*Function Name : Ng5_Find_First_Revision12
*Description   : This function retrieves the first revision for an Item
*****************************************************************************************************/
tag_t Ng5_Find_First_Revision12(tag_t Item)
{
	TC_write_syslog("\n Inside Ng5_Find_First_Revision12 \n");
	int  ifail	  = ITK_ok;
	tag_t Rev_tag = NULL;
	ifail = ITEM_find_revision(Item,"01",&Rev_tag);
	TC_write_syslog("\n After ITEM_find_revision :%d ",ifail);
	if (Rev_tag == NULL)
	{
		ifail = ITEM_find_revision(Item,"A",&Rev_tag);
		TC_write_syslog("\n 1 After ITEM_find_revision :%d ",ifail);
	}
	TC_write_syslog("\n Exited Ng5_Find_First_Revision12 \n");
	return Rev_tag;
}


int Ng5_find_Item(const char* cpItemid,const char* cpObjType,tag_t* tItemTag )
{
	int n = 0, ifail = ITK_ok;
    tag_t *items = NULL;
    const char* names[2] = { ATTR_ITEM_ID,ATTR_OBJECT_TYPE };
    const char* values[2] = { cpItemid,cpObjType };
    ifail = ITEM_find_items_by_key_attributes(2, names, values, &n, & items );
	if (n ==1 && ifail==ITK_ok)
	{
		*tItemTag = items[0];
	}
	else
	{
		*tItemTag = NULLTAG;
	}
	MEM_TCFREE(items);
    return ifail;
}

/*===========================================================================================================
   Function      :  Ng5_gettime_stamp
   Description   :  Get the current time stamp !!
   Parameter     :  char* cpTimeStamp( O )			time stamp
   Return        :  char(char value)					char return
=============================================================================================================*/
char Ng5_gettime_stamp(char *cpTimeStamp)
{
	time_t curtime;
	struct tm *loctime;
	/* Get the current time. */
	curtime = time (NULL);
	/* Convert it to local time representation. */
	loctime = localtime (&curtime);
	sprintf(cpTimeStamp,"%d%.2d%.2d_%.2d%.2d%.2d",loctime->tm_year+1900,loctime->tm_mon+1,loctime->tm_mday,loctime->tm_hour,loctime->tm_min,loctime->tm_sec);
	return(*cpTimeStamp);
}
/**
 * Function Name 	:	Ng5_setDAPropertyValue
 * Description		:	This function sets the ng5_DeviationAuthorization property value
 * Parameters		:	tPartRev Tag of Secondary (I)
 * 						numofdevauthrevs number of DA's(I)
 * 						tDevAuthRev Tag of Primary
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 * 09/26/2018 	|			|	Meenakshi Shenoy	|	1. Added this function as part of restructuring this extension code
 *
 */

int Ng5_setDAPropertyValue(tag_t tPartRev, int numofdevauthrevs,tag_t tDevAuthRev)
{
	int iFail = ITK_ok;
	NG5_ITK_CALL(AOM_refresh(tPartRev,TRUE));
	NG5_ITK_CALL(AOM_set_value_tag_at(tPartRev,DEVIATION_AUTHORIZATION_PROPERTY,numofdevauthrevs, tDevAuthRev));
	TC_write_syslog("\n Setting Property ng5_DeviationAuthorization \n");
	NG5_ITK_CALL(AOM_save_with_extensions(tPartRev)); //TC 12 Upgrade
	NG5_ITK_CALL(AOM_refresh(tPartRev,FALSE));

	return iFail;

}

/**
 * Function Name 	:	Ng5_associatePartRevtoDARev
 * Description		:	This function checks whether DA rev is already attached to the DA property on Part Rev & also checks for the access on Part Rev.
 * Parameters		:	tPartRev Tag of Secondary (I)
 * 						tDevAuthRev Tag of Primary (I)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 * 10/08/2018 	|			|	Meenakshi Shenoy	|	1. Added this function as part of restructuring this extension code
 *
 */

int Ng5_associatePartRevtoDARev(tag_t tPartRev, tag_t tDevAuthRev)
{
	int iFail = ITK_ok;

int numofdevauthrevs = 0;

			tag_t *tagtDevAuthRevs = NULLTAG;

			logical tDevAuthRevexist = false;

			logical lPriVerdict = false;


			NG5_ITK_CALL(AOM_ask_value_tags(tPartRev,DEVIATION_AUTHORIZATION_PROPERTY,&numofdevauthrevs,&tagtDevAuthRevs));


			//Checking if the 'Deviation Authorization' rev count is more than 0
			if (tagtDevAuthRevs > 0 && tagtDevAuthRevs != NULL) {
				for (int indxDevAuthRev = 0; indxDevAuthRev < numofdevauthrevs; indxDevAuthRev++) {

					//Checking if the 'Deviation Authorization' rev is already attached to ng5_DeviationAuthorization Property
					if (tagtDevAuthRevs[indxDevAuthRev] == tDevAuthRev) {
						tDevAuthRevexist = true;
						break;

					}


				}
			}

			//Setting the ng5_DeviationAuthorization Property by adding the 'Deviation Authorization' rev to it

			NG5_ITK_CALL( AM_check_privilege (tPartRev, ACCESS_WRITE, &lPriVerdict));

				//  Part rev is released, bypass is set to update the property
				AM__set_application_bypass(true);
				NG5_ITK_CALL( AM_check_privilege (tPartRev, ACCESS_WRITE, &lPriVerdict));
				if (lPriVerdict) {
					TC_write_syslog("\n access obtained \n");
					iFail = Ng5_setDAPropertyValue(tPartRev,numofdevauthrevs,tDevAuthRev);
				} else {
					TC_write_syslog("\n access not obtained \n");
				}

				AM__set_application_bypass(false);
				MEM_TCFREE(tagtDevAuthRevs);
				return iFail;
}
