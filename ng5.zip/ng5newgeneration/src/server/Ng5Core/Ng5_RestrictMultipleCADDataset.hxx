/*==========================================================================================

                    Copyright (c) 2017 - Adient

============================================================================================
File description:

    Ng5_RestrictMultipleCADDataset.hxx


Teamcenter-CAD Integration Multiple Dataset Restriction


=============================================================================================
   Date			Name                    Description of Change
  22-Nov-2021	Sahida Khatun              Initial creation

==================================================================================================*/
#ifndef NG5_RESTRICTMULTIPLECADDATASET_HXX
#define NG5_RESTRICTMULTIPLECADDATASET_HXX
#include <tccore/method.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <tc/tc.h>
#include <fclasses/tc_ctype.h>
#include "Ng5_CommonUtils.hxx"
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif

extern NG5CORE_API int Ng5_RestrictMultipleCADDataset(METHOD_message_t* msg, va_list args);

#ifdef __cplusplus
                   }
#endif

#include <Ng5Core/libng5core_undef.h>

#endif  //NG5_RESTRICTMULTIPLECADDATASET_HXX
