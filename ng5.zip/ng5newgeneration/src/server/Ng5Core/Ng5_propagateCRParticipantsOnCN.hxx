//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_propagateCRParticipantsOnCN
 *
 */
 
#ifndef NG5_PROPAGATECRPARTICIPANTSONCN_HXX
#define NG5_PROPAGATECRPARTICIPANTSONCN_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#include <string.h>
#include <sstream>
using namespace std;
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_propagateCRParticipantsOnCN(METHOD_message_t* msg, va_list args);
int ng5_copyParticipant2(tag_t sourceObject, tag_t targetObject,  string strPrefValue);

#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_PROPAGATECRPARTICIPANTSONCN_HXX
