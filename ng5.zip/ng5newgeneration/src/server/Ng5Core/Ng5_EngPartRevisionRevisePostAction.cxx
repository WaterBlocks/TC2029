/*********************************************************************************************
** File Name:         Ng5_EngPartRevisionRevisePostAction.cxx
**
** File Description:
	This file contains the implementation to post action on revise and create new revision operation.
	The method is responsible for setting the initial revision and major /minor revision of Eng Part
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   2/27/2017  Shibabrata Jena      Initial Version
**   5/07/2021  Balaji               TC12 Upgrade
*********************************************************************************************/
#include <Ng5Core/Ng5_EngPartRevisionRevisePostAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>

#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <tccore/method.h>
using namespace ng5newgeneration;

//-----------------------------------------------------------------------------------------------------
// int Ng5_EngPartRevisionRevisePostAction( METHOD_message_t * msg, va_list args )
// implementation for the extension on post action of Item_Copy_rev operation of Eng part revision
// and update the custom properties ng5_rev_type and ng5_is_initial_rev
//------------------------------------------------------------------------------------------------------

int Ng5_EngPartRevisionRevisePostAction( METHOD_message_t * msg, va_list args )
{
 
	TC_write_syslog("\n Entering Ng5_EngPartRevisionRevisePostAction  \n");
	int iFail = ITK_ok;
	tag_t tNewItem = va_arg(args, tag_t);
	const char* rev_id = va_arg(args, char*);
	tag_t *tNewRevision = va_arg(args, tag_t*);// New  Revision tag

	METHOD_id_t messageMethod = msg->method;
	//void * iMethodId =  messageMethod.id;
	//iMethodId = messageMethod->id;

	try
	{
			if (tNewRevision != NULL )
			{
				if (tNewRevision[0] != NULLTAG)
				{

					logical lValidTag = false;

					tag_t tLatestRev = tNewRevision[0];

					// Checking weather tag is valid for setting up latest icon
					ITK(POM_is_tag_valid (tLatestRev,&lValidTag ));

					if (lValidTag == true)
					{
						//check if Rev is major or minor

		                ITK(AOM_refresh(tLatestRev,true));
		                //
		                logical isMinorRev = false;

						isMinorRev = Ng5_CommonUtils::isMinorRevision((char*)rev_id);
						if(!isMinorRev)

		                {

		                ITK(AOM_set_value_string(tLatestRev, REV_TYPE, MAJOR));
		                }
		                else if(isMinorRev)
		                {
		                	ITK(AOM_set_value_string(tLatestRev, REV_TYPE, MINOR));
		                }
		                //check if the extension is ITEM_COPY_MSG or ITEM_CREATE_REV_msg

		                METHOD_id_t methodIdCreateRev;
		                METHOD_find_method(ENG_PART_REVISION,ITEM_CREATE_REV_MSG,&methodIdCreateRev);
		                /*char * cMessageName = NULL;
		                METHOD_get_message_name(messageMethod.id, &cMessageName);*/
		                TC_write_syslog("\n Message id is is %d\n", messageMethod.id);
		                if(methodIdCreateRev.id == messageMethod.id)
		                {
		                	ITK(AOM_set_value_string(tLatestRev, IS_INITIAL_REV, YES));
		                }

						ITK(AOM_save_with_extensions(tLatestRev)); //TC 12 Upgrade

						ITK(AOM_refresh(tLatestRev,false));
					}
				}
			}
	}
	catch (...)
	{

	}

	TC_write_syslog("\n Exiting Ng5_EngPartRevisionRevisePostAction \n");
	return iFail;

}
