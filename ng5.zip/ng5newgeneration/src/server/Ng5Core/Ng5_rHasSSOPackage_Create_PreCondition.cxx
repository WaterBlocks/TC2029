/*********************************************************************************************
** File Name:         Ng5_rHasSSOPackage_Create_PreCondition.cxx
**
** File Description:
*   This file contains the implementation for the Extension Ng5_rHasSSOPackage_Create_PreCondition
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   29/07/2020  Monali Nakil      Initial Version
								   Added implementation for Defect 397007: SSO Package creation possible even without assignment to Project


*********************************************************************************************/
#include <Ng5Core/Ng5_rHasSSOPackage_Create_PreCondition.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <base_utils/TcResultStatus.hxx>


using namespace ng5newgeneration;

int Ng5_rHasSSOPackage_Create_PreCondition( METHOD_message_t * msg, va_list args )
{
	 int ifail = ITK_ok;
	 ResultStatus status;
	 const char* prop_name = NULL;
	 tag_t masterprg_tag = NULLTAG;
	 char* masterPrg_id = NULL;
	 tag_t project_tag = NULLTAG;
	 tag_t tCurrentGroupmember = NULLTAG;
	 tag_t tUser = NULLTAG;
	 logical lIsPrivilegeUser = FALSE;
	 char* cObjectType = NULL;

	TC_write_syslog("\n Entering Ng5_rHasSSOPackage_Create_PreCondition  \n");

	if(Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_ADMIN)||Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_DBA))
	{
		//skipping for DBA and Admin
		TC_write_syslog("\n Skipping  SSO Package creation precondition Validation for dba and admin");
		return ITK_ok;

	}

	va_list uargs;
	va_copy(uargs,args);

	tag_t cust_object_tag = va_arg(uargs, tag_t);
	tag_t ssopkgrev_tag = va_arg(uargs, tag_t);
	va_end(uargs);

	TC_write_syslog("\n\n Object Tag is :%d\n\n",cust_object_tag);
	TC_write_syslog("\n\n SSO Tag is :%d\n\n",ssopkgrev_tag);

	ITK(AOM_ask_value_string(cust_object_tag, OBJECT_TYPE, &cObjectType));
	TC_write_syslog("\n object type is %s\n", cObjectType);

	if(tc_strcmp(cObjectType, LAUNCHPRG)==0)
	{
		ifail = validate_sso_pkg( ssopkgrev_tag, cust_object_tag );

		int error_code = ifail;
		if( error_code == ITK_ok)
		{
			ifail = AOM_ask_value_tag(cust_object_tag, Ng5_launchprg_masterprg, &masterprg_tag);
			TC_write_syslog("\n\n Master Prg Tag: %d\n\n",masterprg_tag);

			if( masterprg_tag != NULLTAG)
			{
				ifail = AOM_ask_value_string(masterprg_tag, ITEM_ID, &masterPrg_id);
				TC_write_syslog("\n\n Master Prg ID: %s\n\n",masterPrg_id);

				if(masterPrg_id != NULL)
				{
					ifail =  PROJ_find(masterPrg_id, &project_tag);
					TC_write_syslog("\n\n Project Tag: %d\n\n", project_tag);

					if( project_tag != NULLTAG)
					{
						ifail = SA_ask_current_groupmember(&tCurrentGroupmember);
						TC_write_syslog("\n\n Current Group member Tag: %d\n\n", tCurrentGroupmember);

						ifail = SA_ask_groupmember_user(tCurrentGroupmember, &tUser);
						TC_write_syslog("\n\n Current Group member user Tag: %d\n\n", tUser);

						ifail = PROJ_is_user_a_privileged_member(project_tag, tUser, &lIsPrivilegeUser);

						if (!lIsPrivilegeUser)
						{
							// return error Message
							EMH_store_error_s1(EMH_severity_error, ErrorCodeForNotProjectMember, "Validation Failed");
							return ErrorCodeForNotProjectMember;
						}
					}//if( project_tag != NULLTAG)

				}//if(masterPrg_id != NULL)

			}//if( masterprg_tag != NULLTAG)
		}// if(ifail == ITK_ok)
		else
		{
			tag_t ssopkg_tag = NULLTAG;
			ifail = AOM_ask_value_tag(ssopkgrev_tag, "items_tag", &ssopkg_tag);
			TC_write_syslog("\n\n SSO Package Tag:%d\n\n",ssopkg_tag);
			
			ifail = AOM_lock_for_delete(ssopkg_tag);
			ifail = AOM_delete(ssopkg_tag);
			return error_code;
		}

	 }//if(tc_strcmp(cObjectType, "Ng5_LaunchPrg")==0)

	 MEM_TCFREE(masterPrg_id);
	 MEM_TCFREE(cObjectType);

	TC_write_syslog("\n Exiting Ng5_rHasSSOPackage_Create_PreCondition \n");

	return ifail;

}

int validate_sso_pkg( const tag_t ssoPkgRev, const tag_t tLaunchPrg )
{
	int ifail = ITK_ok;
	ResultStatus status;

	char* strSSOPkgName = NULL;
	status = AOM_ask_value_string(ssoPkgRev, OBJECT_NAME, &strSSOPkgName);

	tag_t tRelationTag 		= NULLTAG;
	status = GRM_find_relation_type("Ng5_rHasSSOPackage", &tRelationTag);
	TC_write_syslog("\n\n SSO Package relation tag:%d\n\n",tRelationTag);

	int count = 0;
	tag_t* secondaryObjs = NULL;

	status = GRM_list_secondary_objects_only(tLaunchPrg, tRelationTag, &count, &secondaryObjs);
	TC_write_syslog("\n\n No. of Secondary object:%d\n\n",count);

	for( int i = 0; i < count; i++)
	{
		char* obj_name = NULL;
		status = AOM_ask_value_string(secondaryObjs[i], OBJECT_NAME, &obj_name);
		if(tc_strcmp(obj_name, strSSOPkgName) == 0)
		{
			TC_write_syslog("\n\n Inside If loop\n\n");
			EMH_store_error_s1(EMH_severity_error, ErrorCodeForMultipleSSOPackage, "Multiple SSO Package cannot be created");

			return ErrorCodeForMultipleSSOPackage;
		}
	}

	return ifail;
}