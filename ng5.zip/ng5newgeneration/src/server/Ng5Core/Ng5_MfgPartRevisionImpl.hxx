//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_MfgPartImpl
//

#ifndef NG5NEWGENERATION__NG5_MFGPARTIMPL_HXX
#define NG5NEWGENERATION__NG5_MFGPARTIMPL_HXX

#include <Ng5Core/Ng5_MfgPartRevisionGenImpl.hxx>

#include <base_utils/ScopedSmPtr.hxx>
#include <map>
#include <vector>
#include <iostream>
#include <sstream>
#include <fclasses/tc_stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <sa/am.h>
#include <algorithm>
#include <Ng5Core/Ng5_Validate_Mfg_CreateInput.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_MfgPartRevisionImpl;
    class Ng5_MfgPartDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_MfgPartRevisionImpl
    : public ng5newgeneration::Ng5_MfgPartRevisionGenImpl
{
public:


    ///
    /// Description for the Finalize Create Input
    /// @param creInput - desc for  creInput parameter
    /// @return - Return desc for Initialize for Create
    ///
    int  finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a Ng5_MfgPart
    explicit Ng5_MfgPartRevisionImpl( Ng5_MfgPartRevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_MfgPartRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_MfgPartRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_MfgPartRevisionImpl( const Ng5_MfgPartRevisionImpl& );

    ///
    /// Copy constructor
    Ng5_MfgPartRevisionImpl& operator=( const Ng5_MfgPartRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_MfgPartRevisionDelegate;
public:
    static logical Ng5_validItemID(char* cpSuffix);

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_MFGPARTIMPL_HXX
