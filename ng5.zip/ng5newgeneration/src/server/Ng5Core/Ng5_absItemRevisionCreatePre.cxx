/*********************************************************************************************
** File Name:         Ng5_absItemRevisionCreatePre.cxx
**
** File Description:
*   This file contains the implementation for the Extension Ng5_absItemRevisionCreatePre
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   12/09/2016  Pradnya Hingankar      Initial Version
										Added implementation for use case 3502 -To allow many in-process (WIP) alternative revisions at a time.
										This extension makes sure valid Revision ID is given for Engineered Part Revision, Engineered Drawing Revision, COntrol Document
										and Raw Material.
										Valid Revision ID patterns:-
										For Raw Material and Control Document  - AA
										For Engineered Part Revision and Engineered Drawing Revision - AA or AANN
										These validations are not applied if the group is Admin or DBA
	1/08/2018    Pradnya Hingankar		1. Added detailed description of extension
										2. Added detailed Header to Function
	05/18/2022  Sahida Khatun            Modified as part of CM Improvemnet Project								

*********************************************************************************************/


#include <Ng5Core/Ng5_absItemRevisionCreatePre.hxx>


using namespace ng5newgeneration;

int isMinorRevId(char* szRevId)
{
	for(int i = 0; i < strlen( szRevId ); i ++)
	{
		int iRevChar = szRevId[i];
		if (isdigit(iRevChar))
		{
			return true;
		}
	}
	return false;

}
/**
 * Created By	:	Pradnya Hingankar
 * Created Date	:	28-Dec-2016
 * Functionality:	Validates if Item Revision Id is in proper format. Valid Standard Patterns for Revision Id are AA and AANN
 */
int isValidRevisionId(tag_t tItemRevisionTag, char*szCurrentRevId)
{
	char *szObjectType = NULL;
	logical isRawMaterial = false;
	if( szCurrentRevId == NULL && tc_strlen(szCurrentRevId) <= 0 )
	{
		return false;
	}
	if( tItemRevisionTag == NULLTAG)
	{
		return false;
	}
	ITK( AOM_ask_value_string (tItemRevisionTag,ATTR_OBJECT_TYPE,&szObjectType) );
	
	TC_write_syslog("\n szObjectType  is %s",szObjectType);
	//Revision ID schema is same for Raw material and Control Document

	if( szObjectType != NULL && tc_strlen(szObjectType) > 0 &&  ( ((tc_strcmp ( szObjectType,RAW_MATERIAL_REVISION ) == 0) || (tc_strcmp ( szObjectType,RAW_MATERIAL ) == 0) ) ||
			(tc_strcmp ( szObjectType,CONTROL_DOCUMENT_REVISION ) == 0) || (tc_strcmp ( szObjectType,CONTROL_DOCUMENT ) == 0)))
	{
		isRawMaterial = true;
	}

	if (szObjectType != NULL && tc_strlen(szObjectType) > 0 &&  ( (tc_strcmp ( szObjectType,ENG_PART_REVISION ) == 0) || (tc_strcmp ( szObjectType,ENG_PART ) == 0) || (tc_strcmp ( szObjectType,ENG_DRAWING_REVISION ) == 0) || (tc_strcmp ( szObjectType,ENG_DRAWING ) == 0) || isRawMaterial))
	{

		
		if( tc_strlen(szCurrentRevId) == 2 )
		{
			//if Rev Id length is 2, then it should all upper case letters only
			for(int i = 0; i < strlen( szCurrentRevId ); i ++)
			{
				if (!(szCurrentRevId[i] >= 65 && szCurrentRevId[i] <= 90)) //upper char
				{
					return false;
				}
			}

		}
		else if (tc_strlen(szCurrentRevId) == 4 && !isRawMaterial) //if Rev Id length is 4, then it should in format AANN
		{
			for(int i = 0; i < strlen( szCurrentRevId ); i ++)
			{
				if(i<2)
				{
					if (!(szCurrentRevId[i] >= 65 && szCurrentRevId[i] <= 90)) //upper char
					{
						return false;
					}
				}
				else
				{
					if (! (szCurrentRevId[i] >=48 && szCurrentRevId[i] <= 57)) //Number
					{
						return false;
					}
				}
			}
		}
		else //Rev id of any other length is not valid
		{
			return false;

		}
	}

	MEM_TCFREE(szObjectType);
	return true;
}

 /**
 * Function Name 	:	Ng5_getPreviousMajorRev
 * Description		:	This function checks if relation between given input parameters exists, if No that relation is created
 * Parameters		:	tItemTag	Tag of Revision (I)
 * 						tPreviousMajorRev Tag of Previous Major rev(O)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          			|	Comments
 * ------------------------------------------------------------------------------------------------
 *  28/12/2016 	|			|	Pradnya Hingankar		|	1. This method iterates through all revisions of item and returns the latest Major revision of the given Item
 *
 */
int Ng5_getPreviousMajorRev(tag_t tItemTag,tag_t* tPreviousMajorRev)
{
	int retcode = ITK_ok;
	int iRevCount = 0;
	tag_t tPreviousRevision = NULLTAG;
	tag_t *ptRevList = NULL;
	logical isFoundPreviousMajor		= false;

	* tPreviousMajorRev = NULLTAG;

	if(tItemTag == NULLTAG)
	{
		return retcode;

	}
	ITK(ITEM_list_all_revs(tItemTag,&iRevCount,&ptRevList));


	for (int iRevCounter = (iRevCount-1); iRevCounter >= 0; iRevCounter--)
	{
		char* szPreviousRevId = NULL;

		tPreviousRevision = ptRevList[iRevCounter];


		if(tPreviousRevision != NULLTAG)
		{

			ITK(AOM_ask_value_string(tPreviousRevision,ATTR_ITEM_REV_ID,&szPreviousRevId));

			if(!isMinorRevId (szPreviousRevId))
			{

				*tPreviousMajorRev = tPreviousRevision;
				break;
			}
		}
		MEM_TCFREE(szPreviousRevId);
	}
	MEM_TCFREE(ptRevList);
	return retcode;
}



/**
 * Function Name 	:	Ng5_ValidateWIPRevisions
 * Description		:	This function checks if relation between given input parameters exists, if No that relation is created
 * Parameters		:	tItemRevisionTag	Tag of Revision (I)
 * 						szCurrentRevId Rev Id (I)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          			|	Comments
 * ------------------------------------------------------------------------------------------------
 *  28/12/2016 	|			|	Pradnya Hingankar		|	1. This method enforces business requirement of having only one Major WIP revision and Multiple Minor WIP revisions
 *																For Engineered Part Revisions and Engineered Drawing Revisions, if the new revision being created is Major rev,
 *																this function checks if there are any previous wotking major revision, if yes, it throws error.
 *
 */
 int Ng5_ValidateWIPRevisions(tag_t tItemRevisionTag, char*szCurrentRevId)
{
	int retCode = ITK_ok;
	char* szObjType = NULL;
	tag_t tItemTag = NULLTAG;

	if( szCurrentRevId == NULL && tc_strlen(szCurrentRevId) <= 0 )
		return false;

	if( tItemRevisionTag == NULLTAG)
		return false;



	ITK( AOM_ask_value_string (tItemRevisionTag,ATTR_OBJECT_TYPE,&szObjType) );

	if (szObjType != NULL && tc_strlen(szObjType) > 0 &&  ((tc_strcmp ( szObjType,ENG_PART_REVISION ) == 0) || (tc_strcmp ( szObjType,ENG_PART ) == 0) || (tc_strcmp ( szObjType,ENG_DRAWING_REVISION ) == 0) || (tc_strcmp ( szObjType,RAW_MATERIAL_REVISION ) == 0)))
	{

		char* szLatestRevId     = NULL;
		tag_t tLatestRev        = NULLTAG;
		tag_t tPreviousRevision = NULLTAG;
		tag_t tLatestMajor      = NULLTAG;

		tLatestRev = tItemRevisionTag;
		if((tc_strcmp ( szObjType,ENG_PART ) == 0) || (tc_strcmp ( szObjType,ENG_DRAWING ) == 0))
		{
			tItemTag = tItemRevisionTag;
			ITK(ITEM_ask_latest_rev	(tItemRevisionTag,&tLatestRev));
		}
		if( tItemTag == NULLTAG)
		{
			ITK(ITEM_ask_item_of_rev (tItemRevisionTag,&tItemTag));
		}
		if(tLatestRev == NULLTAG || tItemTag == NULLTAG)
		{
			return false;
		}

		ITK(AOM_ask_value_string(tLatestRev,ATTR_ITEM_REV_ID,&szLatestRevId));

		//If Selected revision and new revision both are Minor Revisions or if New revision is Minor Revision then no validations are required


		if((isMinorRevId (szLatestRevId) && isMinorRevId (szCurrentRevId) )|| (isMinorRevId (szCurrentRevId)))
		{
			TC_write_syslog("\n Revision is minor, no validation is needed");
		}
		else //If New Revision is not Minor and selected Rev is Minor
		{

			if((tc_strcmp(szObjType,RAW_MATERIAL_REVISION)==0)||(!(isMinorRevId(szCurrentRevId))))
			{
				//get earlier major revision and check if that is released
				tLatestMajor = Ng5_GetLatestMajor(tItemRevisionTag);
				if(tLatestMajor!= NULLTAG)
				{

					if(!Ng5_CommonUtils::isStatused(tLatestMajor, NULL) )
				   {
						return ErrorCodeOnlyOneWorkingMajor;
				   }
					else if(Ng5_CommonUtils::isStatused(tLatestMajor,FROZEN))
					 {
                          if(Ng5_FrozenAfterCutoffDate(tLatestMajor))
					      {
						    return ErrorPreviousMajorRevInCMProcess;
					      }
					   }

				}
			}



		}

		MEM_TCFREE(szLatestRevId);


	}

	MEM_TCFREE(szObjType);
	return retCode;
}
/**
 * Function Name 	:	Ng5_absItemRevisionCreatePre
 * Description		:	This is Extension Implementation method. This extension makes sure valid Revision ID is given for Engineered Part Revision, Engineered Drawing Revision, 	*					   Control Document and Raw Material.
 *                      Valid Revision ID patterns:-
 *						For Raw Material and Control Document  - AA
 *						For Engineered Part Revision and Engineered Drawing Revision - AA or AANN
 *						These validations are not applied if the group is Admin or DBA
 * Parameters		:	va_list args (I)
 * 						METHOD_message_t * msg (I)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name        |	Comments
 * ------------------------------------------------------------------------------------------------
 * 12/09/2016   | 			| Pradnya       | 	Initial Creation
 * 30/07/2018 	|			| Pradnya  		| 	Added this detailed function Header
 * 19/09/2021   |           | SushmaVejamdla|   243112 - Drawing Revision revise is not working for AWC & RAC
 */
int Ng5_absItemRevisionCreatePre( METHOD_message_t * msg, va_list args)
{
 
	int		retCode	   = ITK_ok;
	bool isReviseOPeration = false;
	char 	*chRevId = NULL;

	char*	chObjType = NULL;
	tag_t 	tReviseRev = NULLTAG;
	tag_t tItemTag = NULLTAG;

	METHOD_id_t methodIdRevise;
	METHOD_id_t methodIdReviseDrawing;

	va_list largs;
	va_copy( largs, args );

	tReviseRev = va_arg(largs,tag_t);	//Exsting rev tag
	chRevId = va_arg(largs, char *);		//New revision id

	TC_write_syslog ("--->>>>> Entered Ng5_absItemRevisionCreatePre ------\n" );


	METHOD_find_method	(	"Ng5_EngPartRevision","ITEM_copy_rev",&methodIdRevise);
	METHOD_find_method	(	"Ng5_DrawingRevision","ITEM_copy_rev",&methodIdReviseDrawing);

	TC_write_syslog("\n Method ID Revise is %d",methodIdRevise.id);
	TC_write_syslog("\n Method ID Revise is %d",methodIdReviseDrawing.id);
	ITK( AOM_ask_value_string (tReviseRev,ATTR_OBJECT_TYPE,&chObjType) );

	if(methodIdRevise.id !=0 || methodIdReviseDrawing.id != 0 )
	{
		TC_write_syslog("\n Is True");
		METHOD_id_t currentMethod = msg->method;

        //243112 - Drawing Revision revise is not working for AWC & RAC
		if(((chObjType != NULL && tc_strlen(chObjType) > 0 ) &&   (tc_strcmp ( chObjType,ENG_PART_REVISION) == 0))|| ((chObjType != NULL && tc_strlen(chObjType) > 0 )&&   (tc_strcmp ( chObjType,ENG_DRAWING_REVISION ) == 0))||((chObjType != NULL && tc_strlen(chObjType) > 0 )&&   (tc_strcmp ( chObjType,RAW_MATERIAL_REVISION  ) == 0)) )//|| currentMethod.id == methodIdReviseDrawing.id)
		{
			isReviseOPeration = true;
		}
	}

	//3502- Validate Revision Id pattern , Valid Revision Id Patterns are AA and AA01 only
	if(Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_ADMIN)||Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_DBA))
	{
		//Skipping all Business rules for Admin and dba Group
		TC_write_syslog("\n Skipping Revision ID Standard Schema Check..as the current Role is Data Migration");
		return retCode;
	}
	if(!(isValidRevisionId(tReviseRev,chRevId)))
	{
		TC_write_syslog("\n Inside error condition for isValidRevisionId..returning error");
		retCode = ErrorCodeInvalidRevisionId;
		EMH_store_error(EMH_severity_error, retCode);
		return retCode;

	}
	//3502- Make sure only one WIP Major revision is present and multiple Minor WIP are present

	if(isReviseOPeration)
	{
		TC_write_syslog("\n Is Revise Operation");
		retCode= Ng5_ValidateWIPRevisions(tReviseRev,chRevId);
		if( retCode != ITK_ok)
		{
			TC_write_syslog("\n Inside error condition for Ng5_ValidateWIPRevisions..returning error");
			EMH_store_error(EMH_severity_error, retCode);
			return retCode;
		}
	}

	TC_write_syslog("\n Leaving Ng5_absItemRevisionCreatePre");
	return retCode;

}
//check if part was frozen after cutoff date 

 logical  Ng5_FrozenAfterCutoffDate(tag_t tPreviousRevision)
 {
	 char* cCutOffDate      = NULL;
	 date_t   dDateFrozenCutoff ;
	 date_t    dDateReleased     ;
	 int     iResult           = 0;
	 logical isFrozenLater     = false;
	 
	 PREF_ask_char_value	(FROZEN_CUTOFF_DATE_PREF,0,&cCutOffDate);
	 DATE_convert_formatted_string_to_date(cCutOffDate,NULL,true,false,&dDateFrozenCutoff);
	 AOM_ask_value_date	(	tPreviousRevision,DATE_RELEASED,&dDateReleased);
	 POM_compare_dates(dDateReleased,dDateFrozenCutoff,&iResult);
	 if(iResult == 1)
	 {
		isFrozenLater =true; 
		TC_write_syslog("\nRevision Was Frozen After Cut-off Date");
	 }
     return isFrozenLater;
	 
	 
 }
//Get the latest Major from Status indicator
 tag_t  Ng5_GetLatestMajor(tag_t tCurrentRevision)
  {
	    tag_t*      ptRevList   = NULL;  /*Mem_free*/

	 	tag_t      tlatestRev  = NULLTAG ;
	 	tag_t      tItemTag    = NULLTAG ;
	 	char*    cStatusName   = NULL;
	 	char*    cRevStatus    = NULL;

	 	int            iRev = 0;
	 	int      iStatusCnt = 0;
	 	ITKCALL(ITEM_ask_item_of_rev(tCurrentRevision,&tItemTag));
	 	ITKCALL(ITEM_list_all_revs(tItemTag,&iRev,&ptRevList));
	     for	(int iRevx = iRev-1 ; iRevx >=0; iRevx--)
	 	{
	 		ITKCALL(AOM_ask_value_string(ptRevList[iRevx] ,STATUS_INDICATOR,&cRevStatus));
	 		if(tc_strcmp(cRevStatus,LATEST_REV)==0)
	 		{


	 				tlatestRev = ptRevList[iRevx];
	 				TC_write_syslog("\nGot Latest Rev");
	 				break;

	 		}


	 	}
	     MEM_TCFREE(ptRevList);
	 	return tlatestRev;

  }
