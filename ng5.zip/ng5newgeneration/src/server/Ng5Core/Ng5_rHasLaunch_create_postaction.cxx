//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasLaunch_create_postaction
 *
 */
#include <Ng5Core/Ng5_rHasLaunch_create_postaction.hxx>

int Ng5_rHasLaunch_create_postaction( METHOD_message_t * msg, va_list args)
{
	int ifail = ITK_ok;
	TC_write_syslog("\n\n Entered extension on rHasLaunch GRM_create operation\n\n");

	tag_t masterPrg = va_arg(args, tag_t);
	tag_t launchPrg = va_arg(args, tag_t);

	TC_write_syslog("\n\n Master Tag :%d\n\n",masterPrg);
	TC_write_syslog("\n\n Launch Tag :%d\n\n",launchPrg);

	char* masterPrg_id =NULL;
	tag_t launchPrg_rev =NULLTAG;
	tag_t rHasSSOPackage_type = NULLTAG;
	int count =0;
	tag_t* sec_tags =NULL;
	tag_t project_tag = NULLTAG;

	AOM_ask_value_string(masterPrg, item_id, &masterPrg_id);
	TC_write_syslog("\n\n Master Prg ID: %s\n\n",masterPrg_id);

	PROJ_find(masterPrg_id, &project_tag);
	TC_write_syslog("\n\n Project Tag: %d\n\n", project_tag);

	GRM_find_relation_type(Ng5_rHasSSOPackage, &rHasSSOPackage_type);
	ifail= GRM_list_secondary_objects_only(launchPrg, rHasSSOPackage_type, &count, &sec_tags);
	TC_write_syslog("\n\n ifail:%d\n\n",ifail);
	TC_write_syslog("\n\n count:%d\n\n", &count);

	for(int i =0; i <count; i++){
		char* sec_type =NULL;
		AOM_ask_value_string(sec_tags[i],object_type, &sec_type);

		if(tc_strcmp(sec_type,Ng5_SSOPkgRevision)==0){
			ifail= PROJ_assign_objects(1, &project_tag, 1, &sec_tags[i]);
			TC_write_syslog("\n\n proj assign ifail: %d\n\n", ifail);
		}
	}
	MEM_free(sec_tags);

 
 return 0;

}
