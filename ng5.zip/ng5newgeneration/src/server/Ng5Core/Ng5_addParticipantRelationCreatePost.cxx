//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_addParticipantRelationCreatePost
 *
 */
#include <Ng5Core/Ng5_addParticipantRelationCreatePost.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdarg.h>
#include <string>
#include <sstream>
#include <fclasses/tc_string.h>

#include "Ng5_CommonUtils.hxx"

using namespace std;
using namespace Teamcenter;
using namespace ng5newgeneration;

int Ng5_addParticipantRelationCreatePost( METHOD_message_t * /*msg*/, va_list args )
{

    int iFail = ITK_ok;
	tag_t tChangeItemRev = NULLTAG;
	tag_t tMasterPrgItem = NULLTAG;
	tag_t tRelationType = NULLTAG;
	string szPreferenceName = "";

	scoped_smptr<char> chChangeObjectType;
	scoped_smptr<char> chMasterPrgObjectType;

	TC_write_syslog("\n Entering Ng5_addParticipantRelationCreatePost \n");

	tMasterPrgItem = va_arg(args, tag_t);
	tChangeItemRev = va_arg(args, tag_t);
	tRelationType = va_arg(args, tag_t);

	map<string, string> MapPrefValues;
	MapPrefValues.clear();

	if(tChangeItemRev == NULLTAG || tMasterPrgItem == NULLTAG)
	{
		return iFail;
	}

	NG5_ITK_CALL(AOM_ask_value_string(tChangeItemRev, ATTR_OBJECT_TYPE, &chChangeObjectType));
	NG5_ITK_CALL(AOM_ask_value_string(tMasterPrgItem, ATTR_OBJECT_TYPE, &chMasterPrgObjectType));

	if((tc_strcmp(chChangeObjectType.getString(),"Ng5_CNRevision")!=0))
	{
	szPreferenceName = string(chChangeObjectType.getString()) + "_" + string(chMasterPrgObjectType.getString()) + "_ParticipantsMap";

	Ng5_CommonUtils::loadAllPreferencesIntoMap(szPreferenceName, MapPrefValues);

	for(map<string, string>::iterator itr = MapPrefValues.begin() ; itr != MapPrefValues.end() ; ++itr)
	{
		tag_t participant_type = NULLTAG;
		tag_t tParticipant = NULLTAG;
		tag_t tRelation_type = NULLTAG;
		tag_t tRelation = NULLTAG;
		tag_t tParticipantUserValue = NULLTAG;

		NG5_ITK_CALL(AOM_ask_value_tag(tMasterPrgItem, itr->second.c_str(), &tParticipantUserValue));

		NG5_ITK_CALL(TCTYPE_find_type(itr->first.c_str(), itr->first.c_str(), &participant_type));

		if(tParticipantUserValue != NULLTAG && participant_type != NULLTAG)
		{
			/*Check Participants status*/
			bool isGrpMemberActive = false;
			bool isUserActive = false;
			logical is_deactivated;
			tag_t tUser = NULLTAG;
			int iUserStatus = 0;
			char* cpUserId = NULL;
			/*Check Group member status*/
			NG5_ITK_CALL(SA_ask_groupmember_inactive(tParticipantUserValue, &is_deactivated));
			if(is_deactivated)
			{
				//Group member is inactive
				TC_write_syslog ("\n Ng5_addParticipantRelationCreatePost --> Group member is inactive");
				
				isGrpMemberActive = false;
			}
			else
			{
				//Group member is ACTIVE
				TC_write_syslog ("\n Ng5_addParticipantRelationCreatePost --> Group member is ACTIVE");
				isGrpMemberActive = true;
			}
			/*Check User status*/
			NG5_ITK_CALL(SA_ask_groupmember_user(tParticipantUserValue, &tUser));
			NG5_ITK_CALL(SA_get_user_status(tUser, &iUserStatus));
			NG5_ITK_CALL(POM_ask_user_id(tUser, &cpUserId));
			if(iUserStatus == 1)
			{
				//User is inactive
				TC_write_syslog ("\n Ng5_addParticipantRelationCreatePost --> cpUserId <%s> is inactive" , cpUserId );
				
				isUserActive = false;
			}
			else
			{
				//User is ACTIVE
				TC_write_syslog ("\n Ng5_addParticipantRelationCreatePost --> cpUserId <%s> is ACTIVE" , cpUserId );
				isUserActive = true;
			}
			NG5_MEM_TCFREE(cpUserId);

			if((isGrpMemberActive == true) && (isUserActive == true))
			{				
				printf("\n  - Both Group member and User id are active \n");
				TC_write_syslog("\n  - Both Group member and User id are active \n");
				NG5_ITK_CALL(AOM_refresh(tChangeItemRev, true));
				if(iFail == ITK_ok)
				{
					tag_t tRelationExist = NULLTAG;
					NG5_ITK_CALL(EPM_create_participant(tParticipantUserValue, participant_type, &tParticipant));

					NG5_ITK_CALL(GRM_find_relation_type(HAS_PARTICIPANTS_TYPE, &tRelation_type));

					NG5_ITK_CALL(GRM_find_relation(tChangeItemRev, tParticipant, tRelation_type, &tRelationExist));

					if(tRelationExist == NULLTAG)
					{
						NG5_ITK_CALL(GRM_create_relation(tChangeItemRev, tParticipant, tRelation_type, NULLTAG, &tRelation));

						NG5_ITK_CALL(GRM_save_relation(tRelation));
						NG5_ITK_CALL(AOM_save_with_extensions(tChangeItemRev));//TC 12 Upgrade
					}
					NG5_ITK_CALL(AOM_refresh(tChangeItemRev, false));

				}
			}
			else
			{

				TC_write_syslog ("\n Ng5_addParticipantRelationCreatePost --> Either Group member or User is inactive, skipping it in Participants");
			}

		}

	}
}

	TC_write_syslog("\n Exiting Ng5_addParticipantRelationCreatePost \n");

	return iFail;
}