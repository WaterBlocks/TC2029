//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_MassUpdateRevisionImpl
//

#ifndef NG5NEWGENERATION__NG5_MASSUPDATEREVISIONIMPL_HXX
#define NG5NEWGENERATION__NG5_MASSUPDATEREVISIONIMPL_HXX

#include <Ng5Core/Ng5_MassUpdateRevisionGenImpl.hxx>
#include <Ng5Core/Ng5_setOccurrenceEffectivity.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_MassUpdateRevisionImpl; 
    class Ng5_MassUpdateRevisionDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_MassUpdateRevisionImpl
    : public ng5newgeneration::Ng5_MassUpdateRevisionGenImpl
{
public:

#define NG5_MASS_UPDATE_TYPE            "ng5_Mass_Update_Type"
#define NG5_START_EFFECTIVITY           "ng5_Start_Effectivity"
#define NG5_END_EFFECTIVITY           "ng5_End_Effectivity"
#define NG5_REPLACE           				"Replace"
#define NG5_ADD           				"Add"
#define NG5_ADD_WITH_SIBLING           				"Add with Sibling"
#define NG5_REMOVE           				"Effect Out"
#define NG5_REMOVE_WITH_SIBLING           	"Effect Out Part2 where Part1 Exist"
#define NG5_MODIFY           				"Modify"
#define CUSTOM_ERRORBASE                         919000
#define NG5_NO_START_DATE_SELECTION				 CUSTOM_ERRORBASE + 3000
#define NG5_NO_END_DATE_SELECTION			CUSTOM_ERRORBASE + 3002
#define NG5_START_END_DATE_SELECTION			CUSTOM_ERRORBASE + 3004
#define NG5_START_OR_END_DATE_SELECTION			CUSTOM_ERRORBASE + 3005
#define NG5_START_END_EFFECTIVITY				CUSTOM_ERRORBASE +3009
#define NG5_PLANTS 						"ng5_Plants"
    ///
    /// Description for the Finalize Create Input
    /// @param creInput - desc for  creInput parameter
    /// @return - Return desc for Initialize for Create
    ///
    int  finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput );
    int Ng5_current_get_time_stamp1(char* format, char** timestamp);

protected:
    ///
    /// Constructor for a Ng5_MassUpdateRevision
    explicit Ng5_MassUpdateRevisionImpl( Ng5_MassUpdateRevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_MassUpdateRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_MassUpdateRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_MassUpdateRevisionImpl( const Ng5_MassUpdateRevisionImpl& );

    ///
    /// Copy constructor
    Ng5_MassUpdateRevisionImpl& operator=( const Ng5_MassUpdateRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_MassUpdateRevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_MASSUPDATEREVISIONIMPL_HXX
