//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_Check_AttachType_On_Delete
 *
 */
#include <Ng5Core/Ng5_Check_AttachType_On_Delete.hxx>
#include <tccore/method.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>

#define MATL_MASTER_REL "Ng5_rHasMatlMstr"

int Ng5_Check_AttachType_On_Delete(  METHOD_message_t * msg, va_list args  )
{


	int	retCode			= ITK_ok;
 	tag_t 	tEngPart 		= NULLTAG;
	tag_t	tMatMstrLink		=	NULLTAG;

	TC_write_syslog("\n Entering Ng5_Check_AttachType_On_Delete  \n");

	tEngPart = va_arg(args, tag_t);	// get source object tag

	// get object string
	char* pszObjStr;
	AOM_ask_value_string(tEngPart,"object_string",&pszObjStr);
	//TC_write_syslog("\n pszObjStr : %s\n",pszObjStr);


	//List Secondary objects with relation "MATL MASTER RELATION"
	int		nMatMstrLinks	=	0;
	tag_t		*tpMatMstrLinks	=	NULL;

	ITK( GRM_find_relation_type(MATL_MASTER_REL, &tMatMstrLink) );

	if(NULLTAG != tEngPart)
	{
		TC_write_syslog("\n Engineered Part / Raw Material %s\n",pszObjStr);


		// check if the relationship exist in EngPart / Raw Material
		ITK( GRM_list_secondary_objects_only(tEngPart, tMatMstrLink, &nMatMstrLinks, &tpMatMstrLinks) );

		if((nMatMstrLinks > 0 ) && (tpMatMstrLinks != NULL))
		{
			TC_write_syslog("\n Found the material master attachment.\n");
			TC_write_syslog("\n Deletion of the item is not allowed due to reference attachment restrictions.\n");
			retCode = ErrorCodeEngPartDeleteMatMaster;
			EMH_store_error(EMH_severity_error, retCode);
            		TC_write_syslog("Existing method Ng5_Check_AttachType_On_Delete.\n");
			return retCode;
		}
	}
	 TC_write_syslog("Existing method Ng5_Check_AttachType_On_Delete.\n");
 return retCode;

}


