//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasMBOMItemPostAction
 *
 */
#include <Ng5Core/Ng5_rHasMBOMItemPostAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

/****************************************************************************************************
*Function Name : Ng5_rHasMBOMItemPostAction
*Description   : This function Pastes the first Revision of an MBOM Item when trying to paste ITEM or other revision object on MFGCN Revsion with relation MBOM Item
*****************************************************************************************************/
int Ng5_rHasMBOMItemPostAction( METHOD_message_t *msg, va_list args)
{
	TC_write_syslog("\n Entering Ng5_rHasMBOMItemPostAction\n");
	int iFail           = ITK_ok;
	char* cObjectType   = NULL;
	char* cObjectType1  = NULL;
	char* cRevID	    = NULL;
	char* cItemID	    = NULL;
	tag_t tObjectRev     = NULLTAG;
	tag_t tPartRev      = NULLTAG;
	tag_t tRelationType = NULLTAG;	
	tag_t tRelation     = NULLTAG;
	tag_t tHasEngRel    = NULLTAG;
	tag_t tTargetRev    = NULLTAG;
	tag_t tItem 	    = NULLTAG;	
	tObjectRev = va_arg(args, tag_t);
	tPartRev = va_arg(args, tag_t);
	tRelationType = va_arg(args, tag_t);
	if (NULLTAG != tObjectRev && NULLTAG != tPartRev && NULLTAG != tRelationType)
	{		
		NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));
		NG5_ITK_CALL(AOM_ask_value_string(tObjectRev,ATTR_OBJECT_TYPE, &cObjectType1));
		
		if(tc_strcmp(cObjectType1, MFG_CNRev) == 0||tc_strcmp(cObjectType1, "Ng5_MassUpdateRevision") == 0)
		{
			if(tc_strcmp(cObjectType, MFGPART) == 0 )
			{
				iFail = Ng5_DeleteRelation2(tObjectRev,tPartRev,rMBOMITEM);
				tTargetRev = Ng5_Find_First_Revision11(tPartRev);
				iFail = GRM_find_relation_type(rMBOMITEM, &tRelationType);
				iFail = GRM_find_relation(tObjectRev, tTargetRev, tRelationType, &tRelation);
				if (iFail == ITK_ok && tRelation == NULLTAG)
				{
					iFail = GRM_create_relation(tObjectRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
					iFail = GRM_save_relation(tHasEngRel);

				}
			}
			if(tc_strcmp(cObjectType, MFGPARTRev) == 0 )
			{
				iFail = AOM_ask_value_string(tPartRev,ITEM_REV_ID, &cRevID);
				if(tc_strcmp(cRevID, "01") == 0 ||tc_strcmp(cRevID, "A") == 0  )
				{
					TC_write_syslog("\n Doing nothing as it is expected revison \n");
					// Do nothing
				} else
				{
					iFail = Ng5_DeleteRelation1(tObjectRev,rMBOMITEM);
					iFail = AOM_ask_value_string(tPartRev,ITEM_ID, &cItemID);
					iFail= Ng5_find_Item(cItemID,MFGPART,&tItem);
					tTargetRev = Ng5_Find_First_Revision11(tItem);
					iFail = GRM_find_relation_type(rMBOMITEM, &tRelationType);
					iFail = GRM_find_relation(tObjectRev, tTargetRev, tRelationType, &tRelation);
					if (iFail == ITK_ok && tRelation == NULLTAG)
					{
						iFail = GRM_create_relation(tObjectRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
						iFail = GRM_save_relation(tHasEngRel);
					}
				}
			}
		}
		MEM_TCFREE(cObjectType);
		MEM_TCFREE(cObjectType1);
		MEM_TCFREE(cRevID);
		MEM_TCFREE(cItemID);
	}
	TC_write_syslog("\n Leaving Ng5_rHasMBOMItemPostAction \n");
	return iFail;
}

/****************************************************************************************************
*Function Name :Ng5_DeleteRelation1
*Description   :This function removes the objects which is having MBOM Item Relation
*****************************************************************************************************/
int Ng5_DeleteRelation1(tag_t tTargetObject ,char* cp2RelationNames)
{
	TC_write_syslog(">>>>> Entering Ng5_DeleteRelation\n");
    int     ifail                      = 0;
    int     SecondaryObjCount          = 0;
    int     ii						   = 0;
    int     iVal					   = 0;		
    int     iCount                     = 0;
    tag_t   tRelationType    		   = NULLTAG;
    GRM_relation_t * tRelobj ;
    ifail =  GRM_find_relation_type(cp2RelationNames, &tRelationType);
    ifail =  GRM_list_secondary_objects(tTargetObject,tRelationType,&SecondaryObjCount,&tRelobj);
    if(SecondaryObjCount >0)
    {
        for(ii = 0 ;ii < SecondaryObjCount ;ii++)
	    {
			ifail = GRM_delete_relation(tRelobj[ii].the_relation);
	    }
    }
    return ITK_ok;
	TC_write_syslog(">>>>> Exiting Ng5_DeleteRelation\n");
 }
 
/****************************************************************************************************
*Function Name : Ng5_DeleteRelation2
*Description   : This function removes the relation with primary object
*****************************************************************************************************/
int Ng5_DeleteRelation2(tag_t tPrimay,tag_t tSecondary,char* cp2RelationNames)
{
	TC_write_syslog("\n *****************************Enter Of Ng5_DeleteRelation MBOM Items********************** \n");
	tag_t tagDelRel = NULLTAG;
	tag_t tRelType  = NULLTAG;
	int ifail       = ITK_ok;    
	ifail =  GRM_find_relation_type(cp2RelationNames, &tRelType);
	ifail = AOM_refresh(tPrimay,TRUE);
	if( ifail == ITK_ok)
		GRM_find_relation (tPrimay,tSecondary,tRelType,&tagDelRel);
	if( tagDelRel != NULLTAG )
        ifail =GRM_delete_relation(tagDelRel);
        if( ifail == ITK_ok)
			ifail = AOM_refresh(tPrimay,FALSE);
    TC_write_syslog("\n *****************************Enter Of Ng5_DeleteRelation MBOM Items********************** \n");
    return ifail;
}

/****************************************************************************************************
*Function Name : Ng5_Find_First_Revision11
*Description   : This function retrieves the first revision for an Item
*****************************************************************************************************/
tag_t Ng5_Find_First_Revision11(tag_t Item)
{	
	TC_write_syslog("\n Inside Ng5_Find_First_Revision11 \n");
	int  ifail    = ITK_ok;
	tag_t Rev_tag = NULL;
	ifail = ITEM_find_revision(Item,"01",&Rev_tag);
	if (Rev_tag == NULL)
	{
		ifail = ITEM_find_revision(Item,"A",&Rev_tag);
	}
	return Rev_tag;
	TC_write_syslog("\n Existed Ng5_Find_First_Revision11 \n");	
}
