//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasSecondaryRepRelDeletePreAction
 *   Function will get called whenever the Relationship between Engineered Part and Support Part Design
 *    is removed with the Relation HasSecondaryRepRel.
 *   It checks for the Engineering Part attached to Support Design Revision typed
 *   reference property ng5_related_engg_parts. If yes then removes the  Engineered Part Revision
 *   from this property.
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   14/04/2022  Jogesh Fulsunge  Initial Version
 *
 */
#include <Ng5Core/Ng5_rHasSecondaryRepRelDeletePreAction.hxx>
#include <base_utils/IFail.hxx>
#include <base_utils/ScopedSmPtr.hxx>
#include <base_utils/TcResultStatus.hxx>
#include <fclasses/tc_string.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <string.h>
#include <tc/emh.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tcinit/tcinit.h>
#include <tccore/grm.h>


using namespace Teamcenter;

int Ng5_rHasSecondaryRepRelDeletePreAction( METHOD_message_t * msg, va_list args )
{
 
	int iFail = ITK_ok;
	tag_t 	tRelation 	=	NULLTAG;

	TC_write_syslog("\n Entering Ng5_rHasSecondaryRepRelDeletePreAction \n");
	tRelation = msg->object_tag; // Get Relationship tag

	if (NULLTAG != tRelation)
	{
		tag_t tEnggPartRev = NULLTAG;
		tag_t tSupportDesRev = NULLTAG;

		// Get Primary object

		ITK( GRM_ask_primary( tRelation, &tEnggPartRev ));

		//Get Secondary object - Support Design Revision
		ITK( GRM_ask_secondary( tRelation, &tSupportDesRev ));


		if (NULLTAG != tEnggPartRev && NULLTAG != tSupportDesRev)
		{

			scoped_smptr<char> cpPrimObjClassName;
			scoped_smptr<char> cpSecObjClassName;
			tag_t tPrimType = NULLTAG;
			tag_t tSecType = NULLTAG;

			ITK( TCTYPE_ask_object_type( tEnggPartRev, &tPrimType ));
			if (tPrimType != NULLTAG)
			{
				ITK( TCTYPE_ask_class_name2 ( tPrimType,&cpPrimObjClassName));
			}
			ITK( TCTYPE_ask_object_type( tSupportDesRev, &tSecType ));
			if (tSecType != NULLTAG)
			{
				ITK( TCTYPE_ask_class_name2 ( tSecType,&cpSecObjClassName));
			}

			if (NULL != cpPrimObjClassName.get() && NULL != cpSecObjClassName.get())
			{
				// Allow only if the primary object is Engineered Part Revision and
				// Secondary Object is Drawing Revision
				if ( (tc_strcmp(cpPrimObjClassName.getString(), ITEM_ENGINEERED_PART_REVISION) == 0) && (tc_strcmp(cpSecObjClassName.getString(), ITEM_SUPPORT_DESIGN_REVISION) == 0))
				{
					int numofEngPrt = 0;
					scoped_smptr<tag_t> tagPrtValues;
					logical engPartExist = false;
					logical	lPriVerdict	=	false;

					ITK( AM_check_privilege (tSupportDesRev, ACCESS_WRITE, &lPriVerdict) ); //Allow only if the logged in user has write access to Primary object

					if (true == lPriVerdict)
					{
						NG5_ITK_CALL(AOM_ask_value_tags(tSupportDesRev,RELATED_ENGG_PARTS,&numofEngPrt,&tagPrtValues));
						//Checking if the Part count is more than 0
						if (numofEngPrt > 0 && tagPrtValues != NULL)
						{
							for (int indxEngPrt = 0; indxEngPrt < numofEngPrt;indxEngPrt++)
							{
								//Checking if the Engineered Part is already attached to Support Design Property
								if (tagPrtValues[indxEngPrt] == tEnggPartRev)
								{
									NG5_ITK_CALL(AOM_refresh(tSupportDesRev,TRUE));
									NG5_ITK_CALL(AOM_set_value_tag_at(tSupportDesRev,RELATED_ENGG_PARTS,indxEngPrt, NULL));
									NG5_ITK_CALL(AOM_save_with_extensions(tSupportDesRev));
									NG5_ITK_CALL(AOM_refresh(tSupportDesRev,FALSE));
									if (iFail != ITK_ok)
									{
										return iFail;
									}
									break;
								}
							}
						}
					}

				}
			}
		}
	}
	TC_write_syslog("\n Exiting Ng5_rHasSecondaryRepRelDeletePreAction \n");
	return iFail;
}
