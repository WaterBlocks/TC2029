//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_EngPartImpl
//

#ifndef NG5NEWGENERATION__NG5_ENGPARTIMPL_HXX
#define NG5NEWGENERATION__NG5_ENGPARTIMPL_HXX

#include <Ng5Core/Ng5_EngPartGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_EngPartImpl; 
    class Ng5_EngPartDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_EngPartImpl
    : public ng5newgeneration::Ng5_EngPartGenImpl
{
public:

    ///
    /// Getter for a Tag Array Property
    /// @param values - Parameter value
    /// @param isNull - Returns true for an array element if the parameter value at that location is null
    /// @return - Status. 0 if successful
    ///
  //  int  getNg5_replacement_forBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;

    ///
    /// Setter for a Tag Array Property
    /// @param values - Values to be set for the parameter
    /// @param isNull - If array element is true, set the parameter value at that location as null
    /// @return - Status. 0 if successful
    ///
 //   int  setNg5_replacement_forBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );


protected:
    ///
    /// Constructor for a Ng5_EngPart
    explicit Ng5_EngPartImpl( Ng5_EngPart& busObj );

    ///
    /// Destructor
    virtual ~Ng5_EngPartImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_EngPartImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_EngPartImpl( const Ng5_EngPartImpl& );

    ///
    /// Copy constructor
    Ng5_EngPartImpl& operator=( const Ng5_EngPartImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_EngPartDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_ENGPARTIMPL_HXX
