//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_updateMfgPartID
 *
 */
 
#ifndef NG5_UPDATEMFGPARTID_HXX
#define NG5_UPDATEMFGPARTID_HXX
#include <tccore/method.h>
#include <Ng5Core/Ng5_linkEBOMToPlantMBOM.hxx>
#include <Ng5Core/Ng5_BMF_ITEM_create_or_ref_id.hxx>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif

extern NG5CORE_API int Ng5_updateMfgPartID(METHOD_message_t* msg, va_list args);
int Ng5_setMfgItemIDWithPlantCodeSuffix(tag_t tItem,tag_t tItemRev,char *cpItemId, char *cpPlantCode, char *cpSuffix);
int Ng5_FindMfgPartWithOriginalID(char* cpOrgID,int* n_found,tag_t** tExistingMBOM);

                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_UPDATEMFGPARTID_HXX
