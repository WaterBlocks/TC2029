//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object ChangeItemRevisionImpl	
//

#include <Ng5Core/ChangeItemRevisionImplExt.hxx>

#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <tc/tc.h>

using namespace ng5newgeneration;
using namespace ng5::ng5newgeneration;

//----------------------------------------------------------------------------------
// ::ng5::ng5newgeneration::ChangeItemRevisionImpl::ChangeItemRevisionImpl(ChangeItemRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
ChangeItemRevisionImpl::ChangeItemRevisionImpl( ChangeItemRevision& busObj )
   : ChangeItemRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// ::ng5::ng5newgeneration::ChangeItemRevisionImpl::~ChangeItemRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
ChangeItemRevisionImpl::~ChangeItemRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// ::ng5::ng5newgeneration::ChangeItemRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int ChangeItemRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = ChangeItemRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int ChangeItemRevisionImpl::setNg5_change_typeBase(const std::string &value, bool isNull )
{
    TC_write_syslog("\n Entering CR Change type Restriction for DOC");
	int ifail = ITK_ok;
    tag_t   tObject 		= 	NULLTAG;
    char* chObjectType = NULL;
    char* pcObjString = NULL;
    tag_t   tAdrAttrTag   = NULLTAG;

    // Your Implementation
    ChangeItemRevision *bo = getChangeItemRevision();
    tObject = ((Teamcenter::BusinessObject*)bo)->getTag();

       if( tObject != NULLTAG)
       {
    	   ITKCALL(WSOM_ask_object_type2 (tObject, &chObjectType ));
    	   if(tc_strcmp("Ng5_CRRevision", chObjectType)==0)
    	   {
    	   		TC_write_syslog("\n Object type is CR Revision.");
    		   ITKCALL(AOM_ask_value_string(tObject,"ng5_change_type", &pcObjString));
    		   TC_write_syslog("\n Change Type : %s",pcObjString);
    	   		if(pcObjString != NULL && tc_strcmp(pcObjString,"Drawing Only Change")==0)
    	   		{
    	   					ITK(EMH_store_error_s1(EMH_severity_error, ErrorDOC, VALIDATION_ERROR));
    	   				    return ErrorDOC;
    	   		}
    	   		else
    	   		{
    	   			Ng5_CommonUtils::getAttrIDTag(tObject,CRRevision,ChangeType,&tAdrAttrTag);

    	   			ITKCALL (AttributeAccessor::setStringValue (tObject, tAdrAttrTag, value,isNull ));
                    TC_write_syslog("\n 'Set NonDOC");
    	   			return ifail;
    	   		}
    	   	}
			else
			{
				TC_write_syslog("\n Object is not CRRevision");
				return ifail;
			}
       }
	   else
	   {
		   TC_write_syslog("\n Object tag is null \n");
		   return ifail;
	   }

}

