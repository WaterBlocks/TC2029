/*********************************************************************************************
** File Name:         Ng5_SubscribePrimaryReviseOnRelationCreate.cxx
**
** File Description:
** This file contains the implementation for the Extension Ng5_SubscribePrimaryReviseOnRelationCreate
**
** History:
**
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   08/2/2017	 Arjun Somisheety      Initial Version
**   08/01/2018  Manjula Tirunagari    Rewritten code for fixing Memory issues
**   07/05/2021  Balaji                TC12 Upgrade

** This Extension is to capture the Subscription on Engineered Part on Revise to the Owner of Support Design on Ng5_rHasSecondaryRepRel creation.
*********************************************************************************************/

#include <Ng5Core/Ng5_SubscribePrimaryReviseOnRelationCreate.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_SubscribePrimaryReviseOnRelationCreate( METHOD_message_t * msg, va_list args )
{

		TC_write_syslog("\n Ng5_SubscribeOnEngPartRevise - Entering");

		int retcode				=	ITK_ok;
		int n_args				=	0;
		char* pszUserName 		= NULL;
		//char* pszobjectType		= NULL;
		//char* pszobjectString	= NULL;
		char* pszargName		   = NULL;
		char* pszargVal			   = NULL;
		char* pszSubject		   = NULL;
		char* pszMessage		   = NULL;
		tag_t tUser 			   = NULLTAG;
		tag_t tPrimaryObj 		   = NULLTAG;
		tag_t teventType 		   = NULLTAG;
		tag_t tItem 			   = NULLTAG;
		tag_t tHandler 			   = NULLTAG;
		tag_t tSubscription 	   = NULLTAG;
		tag_t tRelation			   = msg->object_tag;
		char** handlerProps        = NULL;
		int tlen                   = 0;
		char** pszobjectTypeVals   = NULL;
		int slen                   = 0;
		char** pszobjectStringVals = NULL;

		try
		{

			if(tRelation!=NULLTAG)
			{
				ITK(GRM_ask_primary(tRelation,&tPrimaryObj));
			}
			else
			{
				TC_write_syslog("\n Relation is null");
			}
			if(tPrimaryObj!=NULLTAG)
			{
				ITK(POM_get_user(&pszUserName,&tUser));

				//ITK(POM_ask_user_name(tUser,&pszUserName));

				handlerProps = ( char**) MEM_alloc(sizeof(char*)*1);
				handlerProps[0]=( char*) MEM_alloc(sizeof(char*)*40);

				if(pszUserName!=NULL)
				{
					tc_strcpy((char*)handlerProps[0],pszUserName);
				}
				MEM_TCFREE(pszUserName);

				TC_write_syslog("\n Got Primary Object and User details ..\n");

				ITK(TCEVENTTYPE_find(ITEM_CREATE_REV_EVENT,&teventType));
				ITK(ITEM_ask_item_of_rev(tPrimaryObj,&tItem));
				ITK(TCACTIONHANDLER_find_handler(MAIL_NOTIFICATION,&tHandler));

				if((tUser!=NULLTAG)&&(teventType!=NULLTAG)&&(tHandler!=NULLTAG))
				{
					ITK(SCM_find_subscription(tItem,tUser,teventType,tHandler,&tSubscription));
					if(tSubscription!=NULLTAG)
					{
						TC_write_syslog("\nSubscription Object already exists");
					}
					else
					{

						//ITK(AOM_UIF_ask_value(tItem,ATTR_OBJECT_TYPE,&pszobjectType)); //TC 12 Upgrade
						//ITK(AOM_UIF_ask_value(tItem,ATTR_OBJECT_STRING,&pszobjectString));//TC 12 Upgrade
						ITK(AOM_ask_displayable_values(tItem,ATTR_OBJECT_TYPE,&tlen,&pszobjectTypeVals));
						ITK(AOM_ask_displayable_values(tItem,ATTR_OBJECT_STRING,&slen,&pszobjectStringVals));


						//char* pszSubject = (char*) MEM_alloc(100+tc_strlen(pszobjectType)+tc_strlen(pszobjectString));//TC 12 Upgrade
						//char* pszMessage = (char*) MEM_alloc(100+tc_strlen(pszobjectType)+tc_strlen(pszobjectString));//TC 12 Upgrade
							char* pszSubject = (char*) MEM_alloc(100+tc_strlen(pszobjectTypeVals[0])+tc_strlen(pszobjectStringVals[0]));
							char* pszMessage = (char*) MEM_alloc(100+tc_strlen(pszobjectTypeVals[0])+tc_strlen(pszobjectStringVals[0]));
						sprintf(pszSubject, "Revise Operation notification for %s: %s",pszobjectTypeVals[0], pszobjectStringVals[0]);
						sprintf(pszMessage, "Please Note! %s: %s has been revised to a New Revision Level",pszobjectTypeVals[0], pszobjectStringVals[0]);

						ITK(SCM_subscribe_with_notification_options(tItem,tUser,teventType,tHandler,NULLDATE ,NULLDATE,1,(const char **)handlerProps,pszSubject,pszMessage,0,NULL,&tSubscription ));
						if(tSubscription!=NULLTAG)
						{
							TC_write_syslog("\n Subscription created successfully.\n");
						}
						else
						{
							TC_write_syslog("\n Subscription creation failed : %d.\n",retcode);
						}
						NG5_MEM_TCFREE ( pszSubject );
						NG5_MEM_TCFREE ( pszMessage );

						NG5_MEM_TCFREE_ARRAY ( handlerProps , 1);
						NG5_MEM_TCFREE_ARRAY ( pszobjectTypeVals , 1);
						NG5_MEM_TCFREE_ARRAY ( pszobjectStringVals , 1);
						
						
					}
				}
				else
					TC_write_syslog("\n Usertag, EventType or Handler are null");
			}
			else
			{
				TC_write_syslog("\n Primary Object is NULL");
			}
			TC_write_syslog("\n Ng5_SubscribeOnEngPartRevise - Leaving");
			
		}
		catch (...)
		{
			TC_write_syslog("\n Unexpected Error!! Subscription creation failed \n");
		}
		return ITK_ok;

}