//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_rHasEBOMItemPostActionn
 *
 */
 
#ifndef NG5_RHASEBOMITEMPOSTACTIONN_HXX
#define NG5_RHASEBOMITEMPOSTACTIONN_HXX
#include <tccore/method.h>
#include <Ng5Core/Ng5_CMHasProblemItemCreatePostAction.hxx>
#include<Ng5Core/Ng5_BMF_ITEM_create_or_ref_id.hxx>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_rHasEBOMItemPostActionn(METHOD_message_t* msg, va_list args);

tag_t Ng5_Find_Latest_Revision11(tag_t Item);
int Ng5_DeleteRelation4(tag_t tTargetObject ,char* cp2RelationNames);
int Ng5_DeleteRelation5(tag_t tPrimay,tag_t tSecondary,char* cp2RelationNames);
tag_t  Ng5_GetLatestMajorRev(tag_t tCurrentItem);
tag_t  Ng5_GetLatestMajorRev1(tag_t tCurrentRevision);
//int Ng5_getRev2CopyFrom(tag_t tItemTag,tag_t* tRevTag);
#define rMBOMITEM                         "Ng5_rHasMBOMItem"
#define MFG_CNRev                         "Ng5_MfgCNRevision"
#define MFGPART                           "Ng5_MfgPart"
#define MFGPARTRev                        "Ng5_MfgPartRevision"
#define ITEM_ID                        	  "item_id"
#define ITEM_REV_ID                       "item_revision_id"
#define rEBOMITEM						  "Ng5_rHasEBOM"
#define ENG_PART						  "Ng5_EngPart"
#define ENG_PART_REV 					  "Ng5_EngPartRevision"
#define TC_BASELINED					  "TC Baselined"
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_RHASEBOMITEMPOSTACTIONN_HXX
