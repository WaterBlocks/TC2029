//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_ValidatePlant_PreCondition
 *
 */
#include <Ng5Core/Ng5_ValidatePlant_PreCondition.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

/****************************************************************************************************
*Function Name :Ng5_rHasMBOMItemPreCondition
*Description   :This function checks either plant code is same for Mass Update Rev and MBOM ItemRev
*****************************************************************************************************/
int Ng5_ValidatePlant_PreCondition( METHOD_message_t * msg, va_list args )
{
	int iFail 					= ITK_ok;
	tag_t tMfgCNRev 			= NULLTAG;
	tag_t tPartRev 				= NULLTAG;
	tag_t tRelationType 		= NULLTAG;
	tag_t tFirstRev				= NULLTAG;
	char* cObjectType 			= NULL;//MEM FREE
	char* cObjectType1 			= NULL;//MEM FREE
	char* cPlantCodeMfgPrt  	= NULL;//MEM FREE
	char* cPlantCodeMfgPrtRev  	= NULL;//MEM FREE
	char* cPlantCodeMfgCN    	= NULL;//MEM FREE
	TC_write_syslog("\n Entering Ng5_ValidatePlant_PreCondition\n");
	tMfgCNRev     = va_arg(args, tag_t);
	tPartRev 	  = va_arg(args, tag_t);
	tRelationType = va_arg(args, tag_t);
	NG5_ITK_CALL(AOM_ask_value_string(tMfgCNRev,ATTR_OBJECT_TYPE, &cObjectType1));
	if (NULLTAG != tMfgCNRev && NULLTAG != tPartRev && NULLTAG != tRelationType && tc_strcmp(cObjectType1, "Ng5_MassUpdateRevision") == 0)
	{		
		if(tc_strcmp(cObjectType1, MASSUPDATERev) == 0)
		{
			NG5_ITK_CALL(AOM_ask_value_string(tMfgCNRev, MASSUPDATE_PLANTS, &cPlantCodeMfgCN ));
			NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));
			if(tc_strcmp(cObjectType, MFGPART) == 0 )
			{
				tFirstRev = Ng5_Find_First_Revision12(tPartRev);
				NG5_ITK_CALL(AOM_ask_value_string(tFirstRev, PLANTS, &cPlantCodeMfgPrt ));
				if(tc_strcmp(cPlantCodeMfgPrt, cPlantCodeMfgCN) != 0 )
				{
					EMH_store_error_s1(EMH_severity_error,ErrorPlantMatchError,"Plant Id of Mass Update & MBOM Items does not match.");
					return ErrorPlantMatchError;
				}

			}
			if(tc_strcmp(cObjectType, MFGPARTRev) == 0 )
			{
				NG5_ITK_CALL(AOM_ask_value_string(tPartRev, PLANTS, &cPlantCodeMfgPrtRev ));

				if(tc_strcmp(cPlantCodeMfgPrtRev, cPlantCodeMfgCN) != 0 )
				{
					EMH_store_error_s1(EMH_severity_error,ErrorPlantMatchError,"Plant Id of Mass Update & MBOM Items does not match.");
					return ErrorPlantMatchError;
				}

			}
			MEM_TCFREE(cObjectType);
			MEM_TCFREE(cObjectType1);
			MEM_TCFREE(cPlantCodeMfgCN);
			MEM_TCFREE(cPlantCodeMfgPrt);
			MEM_TCFREE(cPlantCodeMfgPrtRev);
		}
		TC_write_syslog("\n Leaving Ng5_ValidatePlant_PreCondition \n");
	}
	return iFail;
}
