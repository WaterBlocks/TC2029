//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_RestrictOnRelate
 *
 */
#include <Ng5Core/Ng5_RestrictOnRelate.hxx>
#include "Ng5_CommonUtils.hxx"

#include <base_utils/ScopedSmPtr.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include "string.h"
#include <sstream>
#define PLANTS "ng5_Plants"
#define PLANTS1 "ng5_plants"
#define PRIMARY "Ng5_MfgCNRevision"
#define SECONDARY "Ng5_MassUpdateRevision"

int Ng5_RestrictOnRelate( METHOD_message_t * /*msg*/, va_list args )
{
	int iFail  = ITK_ok;
	char* plants                    	= NULL;
	char* Plants                    	= NULL;
	char* PrimaryObjectType = NULL;
	char* SecondaryObjectType = NULL;
	scoped_smptr<char>  pcPrimaryObjectTypeName;
	    scoped_smptr<char>  pcSecondaryObjectTypeName;
	    tag_t  tPrimaryObject      = va_arg(args, tag_t);
	        tag_t  tSecondaryObject    = va_arg(args, tag_t);
	        TC_write_syslog("\n Entering Ng5_RestrictOnRelate \n");
	        NG5_ITK_CALL(WSOM_ask_object_type2(tPrimaryObject, &pcPrimaryObjectTypeName));
			NG5_ITK_CALL(WSOM_ask_object_type2(tPrimaryObject, &PrimaryObjectType));
	            TC_write_syslog("\n PrimaryObjectTypeName %s", string(pcPrimaryObjectTypeName.getString()).c_str());
	            if (iFail != ITK_ok){return iFail;}

	            NG5_ITK_CALL(WSOM_ask_object_type2(tSecondaryObject, &pcSecondaryObjectTypeName));
	            NG5_ITK_CALL(WSOM_ask_object_type2(tSecondaryObject, &SecondaryObjectType));
	            TC_write_syslog("\n SecondaryObjectTypeName %s", string(pcSecondaryObjectTypeName.getString()).c_str());
	            if((tc_strcmp(PrimaryObjectType,"Ng5_MfgCNRevision")==0)&&(tc_strcmp(SecondaryObjectType,"Ng5_MassUpdateRevision")==0))
				{
					ITKCALL (AOM_ask_value_string(tSecondaryObject,PLANTS, &Plants));
					TC_write_syslog("\n Plant for MassUpdate %s \n",Plants);

					ITKCALL (AOM_ask_value_string(tPrimaryObject,PLANTS1, &plants));
					TC_write_syslog("\n Plant for MCN %s \n",plants);

	            	if(tc_strcmp(Plants,plants)!=0)
	            	{
						TC_write_syslog("\n\n Plant Not Match\n");
						 EMH_store_error(EMH_severity_error, ErrorPlantNotMatch);
						 return ErrorPlantNotMatch ;
	            	}
	            }
	            TC_write_syslog("\n Exiting Ng5_RestrictOnRelate \n");
	   NG5_MEM_TCFREE (Plants);
	   NG5_MEM_TCFREE (plants);

 return iFail;

}
