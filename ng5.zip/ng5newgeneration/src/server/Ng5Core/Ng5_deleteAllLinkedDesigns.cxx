/*********************************************************************************************
** File Name:         Ng5_deleteAllLinkedDesigns.cxx
**
** File Description:
** This file contains implementation of extension Ng5_deleteAllLinkedDesigns which is added on Post action of GRM_delete of Relations CATIAV5DWG Link and TC_DrawingUsing.
** CATIAV5DWG and TC_DrawingUsing are relations getting created when CATDrawing and Drawing in NX is created based on CATPart or UGMaster, respectively. This extension deletes
** custom relation Ng5_rHasEngDwgRel between these related Engineering Drawing Revision and Engineering Part revision
**
** History			:
** 		Date	|  	AGM		|	Name          	|	Comments
** ------------------------------------------------------------------------------------------------
**  12/27/2016 	|			|Sachin Rampure  	|	Initial Version
**
**  05/18/2017	|			|Siva Sundararaj 	|	Added condition for NX
**
**  07/30/2018	|			|Pradnya Hingankar	|	Restructured complete code to make it more readable
**
*********************************************************************************************/

#include <Ng5Core/Ng5_deleteAllLinkedDesigns.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_deleteRelationIfExists(tag_t tPrimaryRevTag,tag_t tSecondaryRevTag,char* szRelationName);


int Ng5_deleteAllLinkedDesigns( METHOD_message_t * msg, va_list args )
{
	int		retCode				=	ITK_ok;
	tag_t 	tRelationTag 		=	NULLTAG;
	tag_t tRelationTypeTag 		= 	NULLTAG;
	tag_t tPrimaryDatasetTag 	= 	NULLTAG;
	tag_t tSecondaryRevTag 		= 	NULLTAG;
	tag_t tSecRevTypeTag 		= 	NULLTAG;
	char *szSecRevClassName		= 	NULL;
	logical		lVerdict		=	false;

	TC_write_syslog("\n Entering Ng5_deleteAllLinkedDesigns");

	tPrimaryDatasetTag = va_arg(args, tag_t);//Get Primary Object which is CATDrawing for CATIAV5_DWG (Catia) Relation and Drawing Revision for TC_DrawingUsing (NX)
	tSecondaryRevTag = va_arg(args, tag_t);//Get Secondary object - Engineered/External Part, Support/External Support Design
	tRelationTag = msg->object_tag; // Get CATIAV5_DWG Link OOTB Relationship tag

	if (NULLTAG == tRelationTag )
	{
		return ITK_ok;
	}
	ITK(GRM_ask_primary(tRelationTag,&tPrimaryDatasetTag));
	ITK(GRM_ask_secondary(tRelationTag,&tSecondaryRevTag));
	if( tPrimaryDatasetTag == NULLTAG ||  tSecondaryRevTag == NULLTAG)
	{

	return ITK_ok;
	}
	ITK( AM_check_privilege (tSecondaryRevTag, ACCESS_WRITE, &lVerdict) ); //Allow only if the logged in user has write access to Secondary object i.e Eng Part Revision

	if(!lVerdict)
	{
		return ITK_ok;
	}

	ITK( TCTYPE_ask_object_type( tSecondaryRevTag, &tSecRevTypeTag ) );
	ITK( TCTYPE_ask_class_name2 ( tSecRevTypeTag,&szSecRevClassName) );


	//Proceed only if the secondary object is Engineered Part Revision or Support Design Revision
	if ((tc_strcmp (szSecRevClassName, ITEM_ENGINEERED_PART_REVISION) == 0) ||(tc_strcmp (szSecRevClassName, ITEM_SUPPORT_DESIGN_REVISION) == 0))
	{
		tag_t tCATIAV5DWGLinkRelationType = NULLTAG;
		tag_t tNXTcDrawingUsingRelationType = NULLTAG;

		ITK(GRM_ask_relation_type(tRelationTag,&tRelationTypeTag));
		ITK(GRM_find_relation_type(REL_CATIAV5DWGLINK,&tCATIAV5DWGLinkRelationType));
		ITK(GRM_find_relation_type(REL_NX_TCDWGUSING,&tNXTcDrawingUsingRelationType));


		if(tCATIAV5DWGLinkRelationType == tRelationTypeTag) //if the relation is catiav5_DWGLink
		{
			int		iNumberOfDrawingRev		=	0;
			tag_t	tSpecRel		=	NULLTAG;
			tag_t	*ptDrawingRevisions	=	NULL;
			tag_t tDrgObjType 		= NULLTAG;
			tag_t tDrawingRevision = NULLTAG;
			char	*cpPriObjClassName	=	NULL;
			logical	lPriVerdict	=	false;

			ITK (GRM_find_relation_type (REL_SPECIFICATION,&tSpecRel)); 

			//Get the Drawing Revision from the CATDrawing Dataset
			ITK (GRM_list_primary_objects_only (tPrimaryDatasetTag, tSpecRel,&iNumberOfDrawingRev, &ptDrawingRevisions ));

			if (( NULL != ptDrawingRevisions)&& iNumberOfDrawingRev == 1 )
			{
				tDrawingRevision = ptDrawingRevisions[0];

			}
			else
			{
				return ITK_ok;
			}

			ITK( AM_check_privilege (tDrawingRevision, ACCESS_WRITE, &lPriVerdict) ); //Allow only if the logged in user has write access to Primary object

			if(!lPriVerdict)
			{
				return ITK_ok;
			}
			ITK( TCTYPE_ask_object_type( tDrawingRevision,&tDrgObjType));
			ITK( TCTYPE_ask_class_name2 ( tDrgObjType,&cpPriObjClassName) );
			if (tc_strcmp (cpPriObjClassName, ITEM_ENGINEERED_DRAWING_REVISION ) == 0)//if the Drawing revision is found
			{
				//Check if custom relation Ng5_rHasEngDwgRel between this drawing revision and Eng Part revision exists, if yes delete relation
				retCode = Ng5_deleteRelationIfExists(tSecondaryRevTag,tDrawingRevision,REL_ENGDWGREL);
			}

			MEM_TCFREE(cpPriObjClassName);
			MEM_TCFREE(ptDrawingRevisions);
		}

		//If the relation is TC_DrawingUsing NX relation
		else if (tNXTcDrawingUsingRelationType == tRelationTypeTag) //If the relation is TC_DrawingUsing, NX relation
		{
			tag_t	tDrgObjType	=	NULLTAG;
			char	*cpPriObjClassName	=	NULL;

			ITK( TCTYPE_ask_object_type( tPrimaryDatasetTag, &tDrgObjType));
			ITK( TCTYPE_ask_class_name2 ( tDrgObjType,&cpPriObjClassName) );
			if (tc_strcmp (cpPriObjClassName, ITEM_ENGINEERED_DRAWING_REVISION ) == 0)//if primary object type is Engineering Drawing revision
			{
				//Check if custom relation Ng5_rHasEngDwgRel between this drawing revision and Eng Part revision is exists, if yes delete relation
				retCode = Ng5_deleteRelationIfExists(tSecondaryRevTag,tPrimaryDatasetTag,REL_ENGDWGREL);
			}

			MEM_TCFREE(cpPriObjClassName);
		}
	}
	MEM_TCFREE(szSecRevClassName);
	TC_write_syslog("\n Leaving Ng5_deleteAllLinkedDesigns");

	return retCode;
}
/**
 * Function Name 	:	Ng5_deleteRelationIfExists
 * Description		:	This function checks if relation between given input parameters exists, if yes that relation is deleted
 * Parameters		:	tPrimaryRevTag	Tag of Primary (I)
 * 						tSecondaryRevTag Tag of Secondary (I)
 *					:	szRelationName	Name of Relation (I)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 *  30/07/2018 	|			|	Pradnya  		|	1. Added this function as part of restructing this extension code
 *
 */
int Ng5_deleteRelationIfExists(tag_t tPrimaryRevTag,tag_t tSecondaryRevTag,char* szRelationName)
{
	int retCode = ITK_ok;
	tag_t	tDwgLinkRelationType		=	NULLTAG;
	tag_t	tDwgLinkRelation		=	NULLTAG;

	ITK ( GRM_find_relation_type(szRelationName, &tDwgLinkRelationType) );
	retCode = (GRM_find_relation(tPrimaryRevTag,tSecondaryRevTag,tDwgLinkRelationType,&tDwgLinkRelation));
	if(NULLTAG != tDwgLinkRelation)
	{
		ITK( GRM_delete_relation(tDwgLinkRelation) );
	}
	return retCode;

}
