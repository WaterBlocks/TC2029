//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasEBOMItemPostActionn
 *
 */
#include <Ng5Core/Ng5_rHasEBOMItemPostActionn.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_rHasEBOMItemPostActionn( METHOD_message_t *msg, va_list args )
{
 
		TC_write_syslog("\n Entering Ng5_rHasEBOMItemPostAction\n");

		int iFail           = ITK_ok;

		char* cObjectType   = NULL;
		char* cSelRevID	    = NULL;
		char* cLatestRevID	= NULL;

		tag_t tObjectRev    = NULLTAG;
		tag_t tPartRev      = NULLTAG;
		tag_t tRelationType = NULLTAG;
		tag_t tRelation     = NULLTAG;
		tag_t tHasEngRel    = NULLTAG;
		tag_t tTargetRev    = NULLTAG;

		tObjectRev = va_arg(args, tag_t);
		tPartRev = va_arg(args, tag_t);
		tRelationType = va_arg(args, tag_t);
		tag_t EngPart=NULLTAG;

		if (NULLTAG != tObjectRev && NULLTAG != tPartRev && NULLTAG != tRelationType)
		{
				NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));//OF

				TC_write_syslog("object type %s",cObjectType);
				if(tc_strcmp(cObjectType,ENG_PART) == 0 )
				{
					TC_write_syslog("\n Entering in Eng Part");
					iFail = Ng5_DeleteRelation5(tObjectRev,tPartRev,rEBOMITEM);
					Ng5_getRev2CopyFrom(tPartRev,&tTargetRev);
					iFail = GRM_find_relation_type(rEBOMITEM, &tRelationType);
					iFail = GRM_find_relation(tObjectRev, tTargetRev, tRelationType, &tRelation);
					if (iFail == ITK_ok && tRelation == NULLTAG)
					{
						iFail = GRM_create_relation(tObjectRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
						iFail = GRM_save_relation(tHasEngRel);
					}
				}
				if(tc_strcmp(cObjectType,ENG_PART_REV) == 0 )
				{

					TC_write_syslog("\n Entering in Eng Part Revision");
					iFail = AOM_ask_value_string(tPartRev,ITEM_REV_ID, &cLatestRevID);
					TC_write_syslog("\n Selected Item REV:%s",cLatestRevID);

					ITEM_ask_item_of_rev(tPartRev,&EngPart);
					Ng5_getRev2CopyFrom(EngPart,&tTargetRev);

					iFail = AOM_ask_value_string(tTargetRev,ITEM_REV_ID, &cSelRevID);
					TC_write_syslog("\n Latest Item REV:%s",cSelRevID);
					if(tc_strcmp(cLatestRevID,cSelRevID)==0 )
					{

						TC_write_syslog("\n Doing nothing as same revision already exist in EBOM Items \n");

					}
					else
					{
						iFail = Ng5_DeleteRelation5(tObjectRev,tPartRev,rEBOMITEM);
						iFail = GRM_find_relation(tObjectRev, tTargetRev, tRelationType, &tRelation);
						if (iFail == ITK_ok && tRelation == NULLTAG)
						{
							iFail = GRM_create_relation(tObjectRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
							iFail = GRM_save_relation(tHasEngRel);
						}

					}
				 }
				MEM_free(cObjectType);
				MEM_free(cLatestRevID);
				MEM_free(cSelRevID);

		}

		TC_write_syslog("\n Exiting Ng5_rHasEBOMItemPostAction\n");

		return iFail;

}



/****************************************************************************************************
*Function Name : Ng5_DeleteRelation5
*Description   : This function removes the relation with primary object
*****************************************************************************************************/
int Ng5_DeleteRelation5(tag_t tPrimay,tag_t tSecondary,char* cp2RelationNames)
{
	TC_write_syslog("\n *****************************Enter Of Ng5_DeleteRelation MBOM Items********************** \n");
	tag_t tagDelRel = NULLTAG;
	tag_t tRelType  = NULLTAG;
	int ifail       = ITK_ok;
	ifail =  GRM_find_relation_type(cp2RelationNames, &tRelType);
	ifail = AOM_refresh(tPrimay,TRUE);
	if( ifail == ITK_ok)
		GRM_find_relation (tPrimay,tSecondary,tRelType,&tagDelRel);
	if( tagDelRel != NULLTAG )
        ifail =GRM_delete_relation(tagDelRel);
        if( ifail == ITK_ok)
			ifail = AOM_refresh(tPrimay,FALSE);
    TC_write_syslog("\n *****************************Enter Of Ng5_DeleteRelation MBOM Items********************** \n");
    return ifail;
}
