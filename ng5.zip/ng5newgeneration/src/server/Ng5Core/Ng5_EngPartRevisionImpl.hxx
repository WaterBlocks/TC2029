/*********************************************************************************************
** File Name:         Ng5_EngPartRevisionImpl.hxx
**
** File Description:
		This file contains the declaration for the Business Object Ng5_EngPartRevisionImpl
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   12/09/2016  Pradnya Hingankar      Initial Version

*********************************************************************************************/

#ifndef NG5NEWGENERATION__NG5_ENGPARTREVISIONIMPL_HXX
#define NG5NEWGENERATION__NG5_ENGPARTREVISIONIMPL_HXX

#include <Ng5Core/Ng5_EngPartRevisionGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_EngPartRevisionImpl; 
    class Ng5_EngPartRevisionDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_EngPartRevisionImpl
    : public ng5newgeneration::Ng5_EngPartRevisionGenImpl
{
public:
///
    /// Getter for a Tag Array Property
    /// @param values - Parameter value
    /// @param isNull - Returns true for an array element if the parameter value at that location is null
    /// @return - Status. 0 if successful
    ///
    int  getNg5_ChangeRequestBase( std::vector<tag_t> &values, std::vector<int> &isNull) const;

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_tooling_maturityBase( const std::string &value, bool isNull );

   ///
    /// Getter for a Tag Array Property
    /// @param values - Parameter value
    /// @param isNull - Returns true for an array element if the parameter value at that location is null
    /// @return - Status. 0 if successful
    ///
 //   int  getNg5_derivedBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;
///
    /// Getter for a Tag Array Property
    /// @param values - Parameter value
    /// @param isNull - Returns true for an array element if the parameter value at that location is null
    /// @return - Status. 0 if successful
    ///
    int  getNg5_ProblemReportBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;

    ///
    /// Setter for a Tag Array Property
    /// @param values - Values to be set for the parameter
    /// @param isNull - If array element is true, set the parameter value at that location as null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_ChangeRequestBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );
///
    /// Setter for a Tag Array Property
    /// @param values - Values to be set for the parameter
    /// @param isNull - If array element is true, set the parameter value at that location as null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_ProblemReportBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );
 ///
    /// Getter for a Tag Array Property
    /// @param values - Parameter value
    /// @param isNull - Returns true for an array element if the parameter value at that location is null
    /// @return - Status. 0 if successful
    ///
    int  getNg5_ChangeNoticeBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;

    ///
    /// Setter for a Tag Array Property
    /// @param values - Values to be set for the parameter
    /// @param isNull - If array element is true, set the parameter value at that location as null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_ChangeNoticeBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );

    ///
    /// Setter for a Tag Array Property
    /// @param values - Values to be set for the parameter
    /// @param isNull - If array element is true, set the parameter value at that location as null
    /// @return - Status. 0 if successful
    ///
 //   int  setNg5_derivedBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );

protected:
    ///
    /// Constructor for a Ng5_EngPartRevision
    explicit Ng5_EngPartRevisionImpl( Ng5_EngPartRevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_EngPartRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_EngPartRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_EngPartRevisionImpl( const Ng5_EngPartRevisionImpl& );

    ///
    /// Copy constructor
    Ng5_EngPartRevisionImpl& operator=( const Ng5_EngPartRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_EngPartRevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_ENGPARTREVISIONIMPL_HXX
