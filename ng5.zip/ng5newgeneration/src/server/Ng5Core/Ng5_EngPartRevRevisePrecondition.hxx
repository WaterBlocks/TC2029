/*********************************************************************************************
** File Name:         Ng5_EngPartRevRevisePrecondition.hxx
**
** File Description:
	This file contains the implementation to validate the Revise revise operation and allow revise
	only when the previous revision is already part of Proposed changes of a Change Notice
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   2/27/2017  Shibabrata Jena      Initial Version

*********************************************************************************************/
#ifndef NG5_ENGPARTREVREVISEPRECONDITION_HXX
#define NG5_ENGPARTREVREVISEPRECONDITION_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif

//-----------------------------------------------------------------------------------------------------
// int Ng5_EngPartRevRevisePrecondition( METHOD_message_t * msg, va_list args )
// implementation for the extension on precondition of Item_Copy_rev operation of Eng part revision
// and check whether previous revision is part of proposed changes of Change Notice
//------------------------------------------------------------------------------------------------------
extern NG5CORE_API int Ng5_EngPartRevRevisePrecondition(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_ENGPARTREVREVISEPRECONDITION_HXX
