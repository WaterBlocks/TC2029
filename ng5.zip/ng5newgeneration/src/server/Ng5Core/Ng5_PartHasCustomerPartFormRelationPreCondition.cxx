/*********************************************************************************************
** File Name:         Ng5_PartHasCustomerPartFormRelationPreCondition.cxx
**
** File Description:
	This file contains the declaration for the extension named Ng5_PartHasCustomerPartFormRelationPreCondition
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   12/09/2016  Shibabrata Jena      Initial Version

*********************************************************************************************/
#include <Ng5Core/Ng5_PartHasCustomerPartFormRelationPreCondition.hxx>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <tccore/aom_prop.h>
#include <tccore/grm.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <algorithm>    // std::sort
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <sstream>
//-----------------------------------------------------------------------------------------------------
// int Ng5_PartHasCustomerPartFormRelationPreCondition( METHOD_message_t * msg, va_list args )
// definition  of the extension on GRM Create of Relation pre condition of Ng5_rPartHasCustomerPrtForm
// relation to allow the customer part form to represent only One part
//------------------------------------------------------------------------------------------------------

int Ng5_PartHasCustomerPartFormRelationPreCondition( METHOD_message_t * msg, va_list args )
{

	 TC_write_syslog("Entering method Ng5_PartHasCustomerPartFormRelationPreCondition \n");
	 tag_t tPrimaryObject     =   va_arg(args, tag_t);
	 tag_t tSecondaryObject   =   va_arg(args, tag_t);
	 tag_t tRelationTypetag   =   va_arg(args, tag_t);

	 if(tPrimaryObject != NULLTAG)
	 {
		 char * cPrmaryObjectItemID = NULL;
		 ITK(AOM_ask_value_string(tPrimaryObject, ATTR_ITEM_ID, &cPrmaryObjectItemID));

		 if(tSecondaryObject != NULLTAG)
		 {
			 //find all primary object with the customer paret Form
			 int iPartscount = 0;
			 tag_t * tPartsTags = NULL;
			 if(tRelationTypetag != NULLTAG)
			 {
				 ITK(GRM_list_primary_objects_only(tSecondaryObject,tRelationTypetag, &iPartscount, &tPartsTags ));

				 if(iPartscount > 0 && tPartsTags != NULL)
				 {
					 char * cExistingPartItemID = NULL;
					 ITK(AOM_ask_value_string(tPartsTags[0], ATTR_ITEM_ID, &cExistingPartItemID));
					 if(tc_strcmp(cExistingPartItemID, cPrmaryObjectItemID) != 0)
					 {
						 // return error Message
						 EMH_store_error_s1(EMH_severity_error, ErrorCodeForCustomerPartForm, "Validation Failed");
						 return ErrorCodeForCustomerPartForm;
					 }
				 }
			 }

		 }

	 }
	 TC_write_syslog("Exiting method Ng5_PartHasCustomerPartFormRelationPreCondition \n");
	 return ITK_ok;

}
