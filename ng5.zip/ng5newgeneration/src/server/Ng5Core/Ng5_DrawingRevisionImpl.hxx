//@<COPYRIGHT>@
//==================================================
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_DrawingRevisionImpl
//

#ifndef NG5NEWGENERATION__NG5_DRAWINGREVISIONIMPL_HXX
#define NG5NEWGENERATION__NG5_DRAWINGREVISIONIMPL_HXX

#include <Ng5Core/Ng5_DrawingRevisionGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_DrawingRevisionImpl; 
    class Ng5_DrawingRevisionDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_DrawingRevisionImpl
    : public ng5newgeneration::Ng5_DrawingRevisionGenImpl
{
public:

    ///
    /// Getter for a Tag Array Property
    /// @param values - Parameter value
    /// @param isNull - Returns true for an array element if the parameter value at that location is null
    /// @return - Status. 0 if successful
    ///
    int  getNg5_related_partsBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;

    ///
    /// Setter for a Tag Array Property
    /// @param values - Values to be set for the parameter
    /// @param isNull - If array element is true, set the parameter value at that location as null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_related_partsBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );


protected:
    ///
    /// Constructor for a Ng5_DrawingRevision
    explicit Ng5_DrawingRevisionImpl( Ng5_DrawingRevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_DrawingRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_DrawingRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_DrawingRevisionImpl( const Ng5_DrawingRevisionImpl& );

    ///
    /// Copy constructor
    Ng5_DrawingRevisionImpl& operator=( const Ng5_DrawingRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_DrawingRevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_DRAWINGREVISIONIMPL_HXX
