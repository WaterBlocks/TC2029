//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file
 *
 *   This file contains the implementation for the Extension Ng5_CMHasProblemItemDeletePreAction
 *   Function will get called whenever Eng Part Rev & Raw Material Rev are detached from Problems folder present under Deviation Authorization Change Object.
 *   It checks for the  Eng Part Rev & Raw Material Rev detached from Problems folder present under Deviation Authorization Change Object & the property
 *   ng5_DeviationAuthorization on Eng Part Rev & Raw Material Rev gets updated.
 *
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   09/26/2018  Meenakshi Shenoy  Initial Version
 *   07/05/2021  Balaji            TC12 Upgrade
 */
#include <Ng5Core/Ng5_CMHasProblemItemDeletePreAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_removePartRevfromDARev(tag_t tPartRev, tag_t tDevAuthRev);

int Ng5_setPropertyValue(tag_t tPartRev, int indxDevAuthRev);

int Ng5_CMHasProblemItemDeletePreAction(METHOD_message_t* msg, va_list args) {

	int iFail = ITK_ok;
	tag_t tRelation = NULLTAG;

	TC_write_syslog("\n Entering Ng5_CMHasProblemItemDeletePreAction \n");

	// Get Relationship tag
	tRelation = msg->object_tag;

	if (NULLTAG != tRelation) {
		tag_t tDevAuthRev = NULLTAG;
		tag_t tPartRev = NULLTAG;

		NG5_ITK_CALL(GRM_ask_primary(tRelation, &tDevAuthRev));

		NG5_ITK_CALL(GRM_ask_secondary(tRelation, &tPartRev));

		if (NULLTAG != tDevAuthRev && NULLTAG != tPartRev) {

			char* cObjectType = NULL;
			/*Added check to verify object type = Eng Part rev or Raw Material rev only.
			For rest of the types, code will skip the execution.*/
			NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));

			TC_write_syslog("\n object type is %s\n", cObjectType);
			if(tc_strcmp(cObjectType, ENG_PART_REVISION) == 0 ||tc_strcmp(cObjectType, RAW_MATERIAL_REVISION) == 0 )
			{

				iFail = Ng5_removePartRevfromDARev(tPartRev, tDevAuthRev);

				}
			MEM_TCFREE(cObjectType);

			}

			TC_write_syslog("\n Leaving Ng5_CMHasProblemItemDeletePreAction \n");

		}


	return iFail;
}

/**
 * Function Name 	:	Ng5_setDAPropertyValue
 * Description		:	This function sets the ng5_DeviationAuthorization property value
 * Parameters		:	tPartRev Tag of Primary (I)
 * 						indxDevAuthRev Index number(I)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 * 09/26/2018 	|			|	Meenakshi Shenoy	|	1. Added this function as part of restructuring this extension code
 *
 */
int Ng5_setDAPropertyValue(tag_t tPartRev, int indxDevAuthRev)
{
	int iFail = ITK_ok;
	NG5_ITK_CALL(AOM_refresh(tPartRev, TRUE));
	NG5_ITK_CALL(AOM_set_value_tag_at(tPartRev,DEVIATION_AUTHORIZATION_PROPERTY, indxDevAuthRev, NULL));
	TC_write_syslog("\n Setting Property ng5_DeviationAuthorization \n");
	NG5_ITK_CALL(AOM_save_with_extensions(tPartRev)); //TC 12 Upgrade
	NG5_ITK_CALL(AOM_refresh(tPartRev, FALSE));

	return iFail;

}

/**
 * Function Name 	:	Ng5_removePartRevfromDARev
 * Description		:	This function checks whether DA rev is already attached to the DA property on Part Rev & also checks for the access on Part Rev.
 * Parameters		:	tPartRev Tag of Secondary (I)
 *                      tDevAuthRev Tag of Primary (I)
 * Return Type		: 	int
 *
 * History			:
 * Date			|  	AGM		|	Name          	|	Comments
 * ------------------------------------------------------------------------------------------------
 * 09/26/2018 	|			|	Meenakshi Shenoy	|	1. Added this function as part of restructuring this extension code
 *
 */


int Ng5_removePartRevfromDARev(tag_t tPartRev, tag_t tDevAuthRev)
{
	int iFail = ITK_ok;
	int numofdevauthrevs = 0;

					tag_t *tagtDevAuthRevs = NULLTAG;

					logical tDevAuthRevexist = false;

					logical lPriVerdict = false;


					NG5_ITK_CALL(AOM_ask_value_tags(tPartRev, DEVIATION_AUTHORIZATION_PROPERTY, &numofdevauthrevs, &tagtDevAuthRevs));
					//Checking if the DA Rev count is more than 0
					if (numofdevauthrevs > 0 && tagtDevAuthRevs != NULL) {
						for (int indxDevAuthRev = 0; indxDevAuthRev < numofdevauthrevs;
								indxDevAuthRev++) {
							//Checking if the DA Rev is already attached to ng5_DeviationAuthorization Property
							if (tagtDevAuthRevs[indxDevAuthRev] == tDevAuthRev)
							{

								NG5_ITK_CALL(AM_check_privilege(tPartRev, ACCESS_WRITE, &lPriVerdict));

									// Part revision is released, bypass is set to update the property
									AM__set_application_bypass(true);
									NG5_ITK_CALL(AM_check_privilege(tPartRev, ACCESS_WRITE, &lPriVerdict));
									if (lPriVerdict) {
										TC_write_syslog("\n access obtained \n");
										iFail = Ng5_setDAPropertyValue(tPartRev, indxDevAuthRev);
									}
									else
									{
										TC_write_syslog("\n access not obtained \n");
									}
									AM__set_application_bypass(false);

								}

							}


						}
					MEM_TCFREE(tagtDevAuthRevs);

					return iFail;
}
