//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_noProjectContextError
 *
 */
#include <Ng5Core/Ng5_noProjectContextError.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_noProjectContextError( METHOD_message_t * msg, va_list args  )
{
 
	int ifail = ITK_ok;

	TC_write_syslog("\n ---->In Ng5_noProjectContextError");

	EMH_store_initial_error_s1(EMH_severity_error,ErrorCodeForNoContextProgram,"");

	ifail = ErrorCodeForNoContextProgram;

	return ifail;;

}
