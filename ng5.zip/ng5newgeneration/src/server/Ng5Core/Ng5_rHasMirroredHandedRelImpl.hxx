//@<COPYRIGHT>@
//==================================================
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_rHasMirroredHandedRelImpl
//

#ifndef NG5NEWGENERATION__NG5_RHASMIRROREDHANDEDRELIMPL_HXX
#define NG5NEWGENERATION__NG5_RHASMIRROREDHANDEDRELIMPL_HXX

#include <Ng5Core/Ng5_rHasMirroredHandedRelGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_rHasMirroredHandedRelImpl; 
    class Ng5_rHasMirroredHandedRelDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_rHasMirroredHandedRelImpl
    : public ng5newgeneration::Ng5_rHasMirroredHandedRelGenImpl
{
public:


    ///
    /// desc for validate for create
    /// @param creInput - desc for creInput parameter
    /// @return - ret desc for validate for create
    ///
    int  validateCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a Ng5_rHasMirroredHandedRel
    explicit Ng5_rHasMirroredHandedRelImpl( Ng5_rHasMirroredHandedRel& busObj );

    ///
    /// Destructor
    virtual ~Ng5_rHasMirroredHandedRelImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_rHasMirroredHandedRelImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_rHasMirroredHandedRelImpl( const Ng5_rHasMirroredHandedRelImpl& );

    ///
    /// Copy constructor
    Ng5_rHasMirroredHandedRelImpl& operator=( const Ng5_rHasMirroredHandedRelImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_rHasMirroredHandedRelDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_RHASMIRROREDHANDEDRELIMPL_HXX
