//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_LaunchExport
 *
 */
 
#ifndef NG5_LAUNCHEXPORT_HXX
#define NG5_LAUNCHEXPORT_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_LaunchExport(METHOD_message_t* msg, va_list args);
int autoPopulateLaungPrgName(tag_t tLaunchPrg);                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_LAUNCHEXPORT_HXX
