//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_DARevisionImpl
//

#ifndef NG5NEWGENERATION__NG5_DAREVISIONIMPL_HXX
#define NG5NEWGENERATION__NG5_DAREVISIONIMPL_HXX

#include <Ng5Core/Ng5_DARevisionGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_DARevisionImpl; 
    class Ng5_DARevisionDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_DARevisionImpl
    : public ng5newgeneration::Ng5_DARevisionGenImpl
{
public:

    ///
    /// Getter for a string Property
    /// @param value - Parameter value
    /// @param isNull - Returns true if the Parameter value is null
    /// @return - Status. 0 if successful
    ///
    int  getNg5_da_stateBase( std::string &value, bool &isNull ) const;


protected:
    ///
    /// Constructor for a Ng5_DARevision
    explicit Ng5_DARevisionImpl( Ng5_DARevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_DARevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_DARevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_DARevisionImpl( const Ng5_DARevisionImpl& );

    ///
    /// Copy constructor
    Ng5_DARevisionImpl& operator=( const Ng5_DARevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_DARevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_DAREVISIONIMPL_HXX
