//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_linkEBOMToPlantMBOM
 *
 *
 *  Sahida Khatun	  		Initial Creation			July 2022
 *
 *
 */
#include <Ng5Core/Ng5_linkEBOMToPlantMBOM.hxx>


/*Function to get Customer Part Form Number from the Customer Part form whose
 * OEM name is matching with the OEM Name of Manufacturing Part Revision
 */
int Ng5_getMfgCustomPartNum(tag_t tERevision, char *OEMName,char **CustomerPartNo)
{

	TC_write_syslog("\n Entering Ng5_getMfgCustomerPartNum %s",OEMName);
	int	nMatMstrLinks	    =	0;
	tag_t tRelation         =   NULLTAG;
	tag_t *tpMatMstrLinks	=	NULL;
    (*CustomerPartNo)       =   NULL;
    ITKCALL( GRM_find_relation_type(HASCUSTPARTFORM, &tRelation) );

	if(NULLTAG != tERevision  && tRelation!=NULLTAG)
	{
		// check if the relationship exist in EngPart / Raw Material
		ITKCALL( GRM_list_secondary_objects_only(tERevision, tRelation, &nMatMstrLinks, &tpMatMstrLinks) );
		for(int i=0;i<nMatMstrLinks;i++)
		{
			char *OEMName_mf= NULL;
			if(tpMatMstrLinks[i] != NULLTAG)
			{
				ITKCALL(AOM_ask_value_string(tpMatMstrLinks[i], CUSTOMER ,&OEMName_mf ));

				if(tc_strcmp(OEMName,OEMName_mf)==0)
				{
					ITKCALL(AOM_ask_value_string(tpMatMstrLinks[i], CUSTPARTNUM , CustomerPartNo));
					break;
				}
				NG5_MEM_TCFREE(OEMName_mf);
			}
		}
	}
	NG5_MEM_TCFREE(tpMatMstrLinks);
	TC_write_syslog("\n Leaving Ng5_getMfgCustomerPartNum n");
	return ITK_ok;
}

/*
 * Function to Link MBOM Revision To Latest Released or Latest Working (if Latest Released is not available)
 * EBOM Revision
 */
int Ng5_linkEBOMToPlantMBOM( METHOD_message_t* msg, va_list args )
{

		int iFail                  = ITK_ok;
		int nChild                  =0;

		TC_write_syslog("\n\n Entered extension on Ng5_linkEBOMToPlantMBOM \n\n");

		va_list uargs;
		va_copy(uargs,args);

		tag_t  tPlantMBOMRel        = va_arg (uargs, tag_t);
		int    isNew               	= va_arg (uargs, int);
		va_end(uargs);

		tag_t tEbomItemRev 			= NULLTAG, tEbomItem= NULLTAG;
		tag_t tMfgPartRev	 		= NULLTAG, tMbomItem = NULLTAG;
		tag_t tPlantMbomRev	 		= NULLTAG;
		tag_t tSourceMBOM           = NULLTAG;
		tag_t tBkgTmplt             = NULLTAG;
		tag_t tBkgProcess           = NULLTAG;
	
		char  *cpPlantCode 			= NULL; //MEM_Free
		char  *cpPartType 			= NULL; //MEM_Free
		char  *cpCustNoReq          = NULL; //Mem_free
		char  *cpOEMName            = NULL;  //MEM_free
		char* *cpChildren           = NULL;  //MEM_free
		char*  cpItemID             = NULL; //Mem_free
		char  *cpBgkCloning         = NULL;
        char  *cpProcessName        = NULL;
        char  *cpObjString          = NULL;
        char  *cpIsTopline          = NULL;//Mem_free
		ITKCALL(GRM_ask_primary	(tPlantMBOMRel,&tEbomItem));
		ITKCALL(GRM_ask_secondary (tPlantMBOMRel,&tMfgPartRev ));

		///Add Code for background
		ITKCALL(AOM_ask_value_string(tMfgPartRev,BACKGROUNDCLONING,&cpBgkCloning));
		ITKCALL(AOM_ask_value_string(tMfgPartRev,ATTR_OBJECT_STRING,&cpObjString));
		ITKCALL(AOM_ask_value_tag(tMfgPartRev,SOURCEMBOM,&tSourceMBOM ));
		ITKCALL(AOM_ask_value_string(tMfgPartRev,ATTR_IS_TOPLINE,&cpIsTopline ));
        
		if(tc_strcmp(cpIsTopline,YES)!=0)
		{
			return ITK_ok;
		}



		if(tc_strcmp(cpBgkCloning,YES)==0)
		{
			 EPM_find_process_template(WF_PROCESS_BACKGROUNDCLONING,&tBkgTmplt);
			 int iAttcahTypes[1] = {EPM_target_attachment};

			 cpProcessName = (char*) MEM_alloc((tc_strlen(WF_PROCESS_BACKGROUNDCLONING) + tc_strlen(COLON_SPACE) + tc_strlen(cpObjString)+ 1) * sizeof(char));
			 tc_strcpy(cpProcessName,WF_PROCESS_BACKGROUNDCLONING);
			 tc_strcat(cpProcessName,COLON_SPACE);
			 tc_strcat(cpProcessName,cpObjString);
			 if(tBkgTmplt != NULLTAG)
			 {
				 //tAttachments[0]=tMfgPartRev;
				 ITKCALL(EPM_create_process(cpProcessName, WF_PROCESS_BACKGROUNDCLONING, tBkgTmplt,1, &tMfgPartRev, iAttcahTypes, &tBkgProcess));

			 }
			 NG5_MEM_TCFREE(cpProcessName);
		}
		else
		{
			char* cpOriginalID = NULL;
			ITKCALL(ITEM_ask_item_of_rev(tMfgPartRev,&tMbomItem));
			ITKCALL(AOM_ask_value_string(tEbomItem,ATTR_ITEM_ID,&cpItemID));
			ITKCALL(Ng5_getRev2CopyFrom(tEbomItem,&tEbomItemRev));
			ITKCALL(AOM_refresh(tMbomItem,TRUE));
			ITKCALL(AOM_ask_value_string(tMbomItem,ORIGINALID,&cpOriginalID));
			if(tc_strncasecmp(cpItemID,MHYPHEN,2)!=0  && (cpOriginalID == NULL || tc_strlen(cpOriginalID) ==0 || tc_strncasecmp(cpOriginalID,MHYPHEN,2)==0))
			{
			      TC_write_syslog("\n Ng5_linkEBOMToPlantMBOM 138: cpItemID %s\n", cpItemID);
				  ITKCALL(AOM_set_value_string(tMbomItem,ORIGINALID,cpItemID ));
			}else if(cpOriginalID == NULL || tc_strlen(cpOriginalID) ==0 || tc_strncasecmp(cpOriginalID,MHYPHEN,2)==0)
			{
				std::string strOrginalId ="";
				strOrginalId.assign(cpItemID);
				std::istringstream is( strOrginalId );
				size_t count = 0;
				std::string line;
				while ( std::getline( is, line, '-' ) ) ++count;
				std::size_t pos =  strOrginalId.find_first_of('-');
				if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
				pos =  strOrginalId.find_first_of('-');
				if(pos != std::string::npos) strOrginalId= strOrginalId.replace(0, pos+1, "");
				char* cpSuffix = NULL;
				ITKCALL(AOM_ask_value_string(tEbomItemRev,SUFFIX,&cpSuffix));
				 TC_write_syslog("\n Ng5_linkEBOMToPlantMBOM 154: cpSuffix %s\n", cpSuffix);
				if(count>3 && cpSuffix != NULL && tc_strlen(cpSuffix)>0)
				{
					
					pos = strOrginalId.find_last_of(cpSuffix);
					if(pos != std::string::npos) strOrginalId= strOrginalId.replace(pos-tc_strlen(cpSuffix),(strOrginalId.length()), "");
				}
				TC_write_syslog("\n Ng5_linkEBOMToPlantMBOM 160: cpOriginalID %s\n",  strOrginalId.c_str());
				ITKCALL(AOM_set_value_string(tMbomItem,ORIGINALID,strOrginalId.c_str() ));
				NG5_MEM_TCFREE(cpSuffix);
			  }
			
			ITKCALL(AOM_save_without_extensions(tMbomItem));
			ITKCALL(AOM_refresh(tMbomItem,false));
			
			ITKCALL(AOM_ask_value_string( tMfgPartRev, PLANTS , &cpPlantCode ));
			ITKCALL(AOM_ask_value_string (tMfgPartRev,MFGPARTTYPE,&cpPartType));
			
			if(tSourceMBOM != NULLTAG)
			{
				ITKCALL( AOM_ask_displayable_values(tSourceMBOM,CHILDREN,&nChild,&cpChildren ));
			}
			else 
			{
				ITKCALL( AOM_ask_displayable_values(tEbomItemRev,CHILDREN,&nChild,&cpChildren ));
			}

			TC_write_syslog("\n Ng5_linkEBOMToPlantMBOM 188: nChild %d\n",  nChild);
			
			if (tc_strcmp (cpPartType, COMPONENT )!= 0 && nChild>0)
			{

				ITKCALL(Ng5_createPlantMBOMfromEBOM2 (tEbomItemRev, tMfgPartRev, &tPlantMbomRev ));
				ITKCALL(AOM_refresh(tPlantMbomRev,TRUE));
				ITKCALL(Ng5_linkEBOMViewToPlantMBOMView2(tEbomItemRev, tPlantMbomRev ));
				ITKCALL(Ng5_LinkMfgNodesandENodes(tEbomItemRev,tPlantMbomRev,cpPlantCode));
				Ng5_setSourType(tPlantMbomRev,tEbomItemRev);
				
				if(tSourceMBOM != NULLTAG)
				{
					  Ng5_CopyProps(tPlantMbomRev,tSourceMBOM);
				}
				else
				{
					Ng5_CopyProps(tPlantMbomRev,tEbomItemRev);
				}
				//Ng5_linkICEPartForm(tMfgPartRev, tEbomItemRev);
				ITKCALL(AOM_save_without_extensions(tPlantMbomRev));
				ITKCALL(AOM_refresh(tPlantMbomRev, FALSE));



			}
			else
			{
				TC_write_syslog("\n Ng5_linkEBOMToPlantMBOM 216: tEbomItemRev %d\n",  tEbomItemRev);
				ITKCALL(AOM_refresh(tMfgPartRev, TRUE));
				ITKCALL(Ng5_createRelation(tMfgPartRev,tEbomItemRev,HASENGPART2MFGPARREV));
				ITKCALL(AOM_ask_value_string(tMfgPartRev,RQRDCUSTPARTNO,&cpCustNoReq ));

				ITKCALL(AOM_ask_value_string(tMfgPartRev,CUSTOMER,&cpOEMName ));
				if(tc_strcmp(YES,cpCustNoReq)==0 && tc_strlen(cpOEMName)>0 )
				{
				  iFail = Ng5_setMfgItemIDWithPlantCode2(tMfgPartRev, cpPlantCode,cpOEMName);
				}
				TC_write_syslog("\n Ng5_linkEBOMToPlantMBOM 226: tMfgPartRev %d\n",  tMfgPartRev);
				Ng5_setSourType(tMfgPartRev,tEbomItemRev);
				Ng5_CopyProps(tMfgPartRev,tEbomItemRev);
				Ng5_linkICEPartForm(tMfgPartRev, tEbomItemRev);
				ITKCALL(AOM_save_without_extensions(tMfgPartRev));
				ITKCALL(AOM_refresh(tMfgPartRev, FALSE));


			}
		}
	


		NG5_MEM_TCFREE(cpPlantCode);
		NG5_MEM_TCFREE(cpPartType);
		NG5_MEM_TCFREE(cpCustNoReq);
		NG5_MEM_TCFREE(cpOEMName);
		NG5_MEM_TCFREE(cpChildren);
		NG5_MEM_TCFREE(cpObjString);
		NG5_MEM_TCFREE(cpBgkCloning);
		NG5_MEM_TCFREE(cpIsTopline);

		TC_write_syslog("\n Leaving Ng5_linkEBOMToPlantMBOM \n");

		return iFail;

}


/*
 * This Function creates relation between EBOM Revision and MBOM Revision
 */
int Ng5_createRelation(tag_t tprimary, tag_t tSecondary, char* szRelation)
{
	TC_write_syslog("\n entering Ng5_createRelation \n");

	int iFail       = ITK_ok;
	tag_t tRelation = NULLTAG;
	if(szRelation == NULL) return iFail;
	ITKCALL(GRM_find_relation_type(szRelation, &tRelation));
	if(tRelation != NULLTAG && tprimary != NULLTAG && tSecondary != NULLTAG)
	{
		tag_t tNewRelation = NULLTAG;
		GRM_find_relation(tprimary, tSecondary, tRelation, &tNewRelation);
		if(tNewRelation == NULLTAG)
		{
			GRM_create_relation (tprimary, tSecondary,tRelation,NULLTAG,&tNewRelation);
			if(tNewRelation != NULLTAG)
			{
				ITKCALL(GRM_save_relation(tNewRelation));
				ITKCALL(AOM_refresh(tNewRelation,FALSE));
			}
		}
	}
	TC_write_syslog("\n Leaving Ng5_createRelation \n");
	return iFail;
}

/*
 * Custom function to create Plant MBOM from EBOM with Provided Revision Rule
 */
int Ng5_createPlantMBOMfromEBOM2 (tag_t tEbomRevision, tag_t tMfgPartRevision, tag_t* tPlantMbomRevision )
{

	int iFail			  			= ITK_ok;
	int iRow                        = 0;

	char  *cpEbomItemId     		= NULL; //MEM_-free
	char  *cpPlantMbomItemId     	= NULL; //MEM_Free
	char  *cpPlantCode 				= NULL; //MEM_Free
	char  *cpCurrentTime 			= NULL; //MEM_Free
	char  *cpUserData 				= NULL; //MEM_Free
	char  *cpRevRule                = NULL; //MEM_Free
	char  *cpOEMName                = NULL;
	char  *cpPlantMBOMRev           = NULL ;
	char *oldSuffix                 = NULL;
	char *newSuffix                 = NULL;
	char *cpPlantMBOMStr            = NULL;
	char *cpPlantMBOMRevID          = NULL;
	char *cpUIDStr                  = NULL;


	TC_write_syslog("\n Entering Ng5_createPlantMBOMfromEBOM2 \n");
	ITKCALL(PREF_ask_char_value	(MFGREVRULEPREF,0,&cpRevRule));


	tag_t tEbomItem 				= NULLTAG;
	tag_t tPlantMbomItem            = NULLTAG;
	tag_t tRevRule					= NULLTAG;
	tag_t tBomWindow				= NULLTAG;
	tag_t tMasterMbomToplineline	= NULLTAG;
	tag_t tCloneMbomNode			= NULLTAG;
	tag_t tLatestRev 				= NULLTAG;
    tag_t tSourceMBOM               = NULLTAG;

	ITKCALL(ITEM_ask_item_of_rev(tEbomRevision, &tEbomItem ));

	ITKCALL(ITEM_ask_id2(tEbomItem, &cpEbomItemId));



	ITKCALL(AOM_ask_value_string( tMfgPartRevision, PLANTS , &cpPlantCode ));
	ITKCALL(AOM_ask_value_string( tMfgPartRevision, CUSTOMER , &cpOEMName ));
	ITKCALL(AOM_ask_value_tag( tMfgPartRevision,SOURCEMBOM, &tSourceMBOM ));
	ITKCALL(ITEM_ask_item_of_rev(tMfgPartRevision, &tPlantMbomItem));
	ITKCALL(AOM_ask_value_string (tPlantMbomItem,ATTR_ITEM_ID, &cpPlantMbomItemId));

	ITKCALL(CFM_find (cpRevRule, &tRevRule));
	ITEM_ask_rev_id2 (tMfgPartRevision,&cpPlantMBOMRevID);
	ITK__convert_tag_to_uid(tMfgPartRevision,&cpUIDStr);



	ITKCALL(Ng5_current_get_time_stamp (DATE_FORMAT_STR,&cpCurrentTime));
	

	if(tSourceMBOM!=NULL)
	{
	  cpPlantMBOMStr = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpUIDStr))+1);
	  tc_strcpy(cpPlantMBOMStr,cpUIDStr);
	  cpUserData = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpPlantCode)+tc_strlen(TILT)+tc_strlen(cpCurrentTime)+tc_strlen(PIPE)+tc_strlen(cpPlantMBOMStr))+1);
	  tc_strcpy(cpUserData, cpPlantCode);
	  tc_strcat(cpUserData, TILT);
	  tc_strcat(cpUserData, cpCurrentTime);
	  tc_strcat(cpUserData,PIPE);
	  tc_strcat(cpUserData, cpPlantMBOMStr);
	  TC_write_syslog("\n User Data %s \n",cpUserData);
	  NG5_MEM_TCFREE(cpPlantMBOMStr);

	}
	else
	{
		if(tc_strlen(cpOEMName)>0)
		{
		    cpUserData = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpPlantCode)+tc_strlen(TILT)+tc_strlen(cpCurrentTime)+tc_strlen(BACKSLASH)+tc_strlen(cpOEMName))+1);
		    tc_strcpy(cpUserData, cpPlantCode);
		    tc_strcat(cpUserData, TILT);
		    tc_strcat(cpUserData, cpCurrentTime);
		    tc_strcat(cpUserData, BACKSLASH);
		    tc_strcat(cpUserData, cpOEMName);


		}
		else
			{
			   cpUserData = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpPlantCode)+tc_strlen(TILT)+tc_strlen(cpCurrentTime))+1);
			   tc_strcpy(cpUserData, cpPlantCode);
			   tc_strcat(cpUserData, TILT);
			   tc_strcat(cpUserData, cpCurrentTime);

			}

	    TC_write_syslog("\n User Data %s \n",cpUserData);


	}


    if(tSourceMBOM!=NULL)
    {
    TC_write_syslog("\n Has Source MBOM \n");
	iFail = ME_update_mbom_from_ebom (tSourceMBOM, cpRevRule,NULLTAG, NULL, tMfgPartRevision, tRevRule, -1, ME_SKIP_RELEASED_NODE, cpUserData, NULL, &tCloneMbomNode);
    }
    else
    {
    	TC_write_syslog("\n No Source MBOM  -Normal Cloning\n");
    	iFail = ME_update_mbom_from_ebom (tEbomRevision, cpRevRule,NULLTAG, NULL, tMfgPartRevision, tRevRule, -1, ME_SKIP_RELEASED_NODE, cpUserData, NULL, &tCloneMbomNode);

    }
	iFail = ITEM_ask_latest_rev(tCloneMbomNode,&tLatestRev);
	//ITKCALL(Ng5_getRev2CopyFrom(tCloneMbomNode,&tLatestRev));

	*tPlantMbomRevision = tLatestRev;

	NG5_MEM_TCFREE(cpEbomItemId);
	NG5_MEM_TCFREE(cpPlantMbomItemId);
	NG5_MEM_TCFREE(cpPlantCode);
	NG5_MEM_TCFREE(cpCurrentTime);
	NG5_MEM_TCFREE(cpUserData);
	NG5_MEM_TCFREE(cpRevRule);
	NG5_MEM_TCFREE(cpUIDStr);
	NG5_MEM_TCFREE(cpOEMName);
        TC_write_syslog("\n Exiting Ng5_createPlantMBOMfromEBOM2 \n");

	return iFail;
}



/************************************************************************
Function Name   : Ng5_linkEBOMViewToPlantMBOMView
Description     : Link EBOM View to Plant MBOM View

Creator History:
Sahida Khatun                      July , 2022

************************************************************************/


int Ng5_linkEBOMViewToPlantMBOMView2(tag_t tEbomRevision, tag_t tPlantMbomRevision )
{

	int iFail			  			= ITK_ok;
	int iEbomViewCount 				= 0;
	int iPlantMbomViewCount 		= 0;
	int iEbomCount					= 0;

	tag_t tEbomItem 				= NULLTAG;
	tag_t tPlantMbomItem 			= NULLTAG;
	tag_t tMbomBVEbomBVRel 			= NULLTAG;
	tag_t tEbomMbomRel 				= NULLTAG;


	tag_t * tpEbomviewList			= NULL; //MEM_Free
	tag_t * tpPlantMbomviewList  	= NULL;	//MEM_Free
	int nChild =0;
	char* *cpChildren           = NULL;  //MEM_free
	TC_write_syslog("\n Entering Ng5_linkPlantMBOMViewToEBOMView \n");
	
	ITKCALL( AOM_ask_displayable_values(tEbomRevision,CHILDREN,&nChild,&cpChildren ));
	if(nChild == 0)
	{
		iFail = ITK_ok;
		TC_write_syslog("\n Exiting Ng5_linkPlantMBOMViewToEBOMView \n");
	    return iFail;
	}else
	{
		NG5_MEM_TCFREE(cpChildren);
	}
	

	ITKCALL(ITEM_ask_item_of_rev(tEbomRevision, &tEbomItem ));

	ITKCALL(ITEM_list_bom_views	(tEbomItem, &iEbomViewCount, &tpEbomviewList));

	ITKCALL(ITEM_ask_item_of_rev(tPlantMbomRevision, &tPlantMbomItem ));

	ITKCALL(ITEM_list_bom_views	(tPlantMbomItem, &iPlantMbomViewCount, &tpPlantMbomviewList));

	if ((tpPlantMbomviewList != NULL) || (tpEbomviewList != NULL))
	{
		ITKCALL(GRM_find_relation_type(IMANMETARGET, &tMbomBVEbomBVRel));
		ITKCALL(GRM_create_relation (tpPlantMbomviewList[0], tpEbomviewList[0],tMbomBVEbomBVRel,NULLTAG,&tEbomMbomRel));
		ITKCALL(GRM_save_relation(tEbomMbomRel));
		//ITKCALL(AOM_refresh(tEbomMbomRel,FALSE));
	}



	NG5_MEM_TCFREE(tpEbomviewList);
	NG5_MEM_TCFREE(tpPlantMbomviewList);

	TC_write_syslog("\n Exiting Ng5_linkPlantMBOMViewToEBOMView \n");
	return iFail;

}

/************************************************************************
Function Name   : Ng5_LinkMfgNodesandENodes
Description     : Link MBOM Nodes to Engineering Nodes

Creator History:
Balaji                      Dec 18th ,2021

************************************************************************/

int  Ng5_LinkMfgNodesandENodes(tag_t tEBOMItemRev,tag_t item_revision, char* cpPlantCode)
{
	int iFail			  			= ITK_ok;

	tag_t
        rule                        = NULLTAG,
        window                      = NULLTAG,
        bvr                         = NULLTAG,
        top_line                    = NULLTAG;


	TC_write_syslog("\n Entering Ng5_LinkMfgNodesandENodes \n");
	char
		*cpCustNoReq    = NULL,
		*cpOEMName		= NULL,
		*cpRevRule      = NULL;
	

    ITKCALL(BOM_create_window (&window));
    ITKCALL(PREF_ask_char_value	(MFGREVRULEPREF,0,&cpRevRule));
	ITKCALL(CFM_find(cpRevRule, &rule));

    ITKCALL(BOM_set_window_config_rule(window, rule));
    ITKCALL(BOM_set_window_pack_all(window, TRUE));
    ITKCALL(BOM_set_window_top_line(window, NULLTAG, item_revision, bvr, &top_line));
    //tMCNRev  = Ng5_getMCN(item_revision);
    //Ng5_TransferOwnership(tEBOMItemRev,top_line);
	 int isPackCutReq =1;
	 char* cpisPackRule = NULL;
	 PREF_ask_char_value(MFGPACKLINEREQ,0,&cpisPackRule);
	 if(cpisPackRule != NULL && tc_strcmp(cpisPackRule,"0")==0)
	 {
		isPackCutReq =0;
		MEM_free(cpisPackRule);
	 }
     Ng5_TraverseMfgNodesforLinking(tEBOMItemRev,top_line,cpPlantCode,isPackCutReq);
	 ITKCALL(BOM_save_window(window));
     ITKCALL(BOM_close_window(window));
	 Ng5_setMfgItemIDWithPlantCode(item_revision,cpPlantCode);
	 TC_write_syslog("\n Exiting Ng5_LinkMfgNodesandENodes\n");

    return iFail;

}


int  Ng5_RenameMfgNodes(tag_t item_revision, char *plant_code)
{
	int iFail = ITK_ok;

	tag_t
        rule = NULLTAG,
        window = NULLTAG,
        bvr = NULLTAG,
        top_line = NULLTAG;

	TC_write_syslog("\n Entering Ng5_RenameMfgNodes \n");
	char
		*cpCustNoReq    = NULL,
		*cpOEMName		= NULL,
		*cpRevRule      = NULL;



	ITKCALL(AOM_ask_value_string(item_revision, CUSTOMER,&cpOEMName ));
	ITKCALL(PREF_ask_char_value	(MFGREVRULEPREF,0,&cpRevRule));

    ITKCALL(BOM_create_window (&window));
    ITKCALL(CFM_find(cpRevRule, &rule));

    ITKCALL(BOM_set_window_config_rule(window, rule));
    ITKCALL(BOM_set_window_pack_all(window, TRUE));
    ITKCALL(BOM_set_window_top_line(window, NULLTAG, item_revision, bvr, &top_line));
    //Ng5_setSourType(item_revision);
    Ng5_setMfgItemIDWithPlantCode2(item_revision,plant_code,cpOEMName);
    Ng5_TraverseMfgNodes(top_line, plant_code,cpOEMName);
    ITKCALL(BOM_close_window(window));

	TC_write_syslog("\n Exiting Ng5_RenameMfgNodes \n");

    return iFail;

}

tag_t Ng5_UpdatedPackedLines(tag_t line)
{
	tag_t retBOMLine = line;
	logical isPacked=false;
	tag_t parentLine = NULLTAG;
	char *cpQTY = NULL;
	int iQuantity =0;
	TC_write_syslog("\n Entering Ng5_UpdatedPackedLines \n");
	
	ITKCALL ( BOM_line_is_packed(line, &isPacked ));
	if( true == isPacked)
	{ 
		ITKCALL(BOM_line_look_up_attribute(Ng5_BOMLINE_QTY,&iQuantity));
		AOM_ask_value_string(line, Ng5_BOMLINE_QTY, &cpQTY);
		ITKCALL ( BOM_line_unpack(line));
		tag_t tparentLine = NULLTAG, tPackItemRev= NULLTAG;
		Ng5_get_bline_attr_tag ( line, BOMLINEREVISION, &tPackItemRev);
		Ng5_get_bline_attr_tag ( line, BOMLINEPARENTLINE, &tparentLine);
		TC_write_syslog("\n >>>>>  parentLine  : %d \n",parentLine);
		if(tparentLine != NULLTAG && tPackItemRev != NULLTAG)
		{
			int nBOMLines =0;
			tag_t* pmBOMLines = NULL;
			ITKCALL (BOM_line_ask_child_lines (tparentLine, &nBOMLines, &pmBOMLines));
			int isCut =0;
			for(int bline =0; bline<nBOMLines && pmBOMLines!=NULL;bline++)
			{
				tag_t ttempItemRev = NULLTAG;
				Ng5_get_bline_attr_tag ( pmBOMLines[bline], BOMLINEREVISION, &ttempItemRev);
				if(ttempItemRev == tPackItemRev && isCut==0 && ttempItemRev != NULLTAG)
				{
					ITKCALL(BOM_line_set_attribute_string(pmBOMLines[bline],iQuantity,cpQTY));
					isCut =1;
					retBOMLine = pmBOMLines[bline];
				}else if(ttempItemRev == tPackItemRev && isCut==1 && ttempItemRev != NULLTAG)
				{
					ITKCALL (BOM_line_cut(pmBOMLines[bline]));
				}
					
			}
		}
	}
	return retBOMLine;
}

void Ng5_TraverseMfgNodesforLinking(tag_t tEBOMItemRev,tag_t line, char* cpPlantCode, int isPackCutReq)
{
    int count=0;

    tag_t
        *tChildren = NULL,
        item_revision = NULLTAG,
        tSourceMBOM   = NULLTAG,
        tSourceMBOMItem = NULLTAG;


	char *cpBomlineObjType=NULL;
	char *cpID        	= NULL,
		 *cpIDTemp       = NULL;
		 
	
	TC_write_syslog("\n Entering Ng5_TraverseMfgNodesforLinking \n");
	if(isPackCutReq)line = Ng5_UpdatedPackedLines(line);
	

    ITKCALL(BOM_line_ask_child_lines(line, &count, &tChildren));

	ITKCALL(AOM_ask_value_string(line, BOMLINEOBJTYPE, &cpBomlineObjType ));
	TC_write_syslog("\n Line 644 cpBomlineObjType %s \n",cpBomlineObjType);

	if (tc_strcmp (cpBomlineObjType,  MFGPART) == 0)
	{
		item_revision = Ng5_findItemRevisionFromBOMLine(line);
		tag_t mfgitem = NULLTAG;
		ITKCALL(ITEM_ask_item_of_rev(item_revision, &mfgitem));
		ITKCALL(AOM_ask_value_tag(item_revision,SOURCEMBOM, &tSourceMBOM));

		char* cpItemId = NULL;
		char* cpOriginalID = NULL;

		ITKCALL(ITEM_ask_id2(mfgitem, &cpItemId));
		ITKCALL(AOM_ask_value_string(mfgitem, ORIGINALID, &cpOriginalID ));
		


		int iCount=0;
		cpID  = tc_strtok ( cpItemId , HYPHEN);


			while(iCount < 3)
			{

				cpID = tc_strtok ( NULL , HYPHEN );

				switch (iCount)
				{

					case 1:
					{

						cpIDTemp= (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpID))+1);
						tc_strcpy(cpIDTemp,cpID);
						break;
					}

				}
				iCount++;
			}



			tag_t tERevision = NULLTAG, tEItem = NULLTAG;
			int  nItems  = 0;
		    tag_t*  tEItems = NULLTAG; //MEM Free
		    tag_t  objTypeTag   = NULL;
		    char*   cTypeName   = NULL;
			char*   cpIsTopline = NULL;
			 char*  object_type  =NULL;
		    int n = 0;
		    tag_t relation=NULLTAG;
		    tag_t* secobj=NULL;
		   
		    tag_t jtrelationtype=NULLTAG;
		    tag_t customerrelation=NULLTAG;
		    tag_t iceformrelation=NULLTAG;
		    tag_t tRawMaterial = NULLTAG ;

		    logical   isRawMaterial = false;
            logical   isPackagingPart = false;


            ITKCALL(ITEM_find(cpOriginalID,&nItems,&tEItems));
            for(int iEIx=0;iEIx <nItems;iEIx++)
            {

            	TCTYPE_ask_object_type(tEItems[iEIx],&objTypeTag);
            	TCTYPE_ask_class_name2	(objTypeTag,&cTypeName );
            	if(tc_strcmp(cTypeName,RAW_MATERIAL)==0)
		        {
		        	isRawMaterial =true ;
		        	//tRawMaterial = tEItems[iEIx];
		        	ITKCALL(Ng5_getRev2CopyFrom(tEItems[iEIx],&tERevision));
		        	break;
		        }


            }
            if(!isRawMaterial)
            {
                for(int iEIx=0;iEIx <nItems;iEIx++)
                {

					TCTYPE_ask_object_type(tEItems[iEIx],&objTypeTag);
					TCTYPE_ask_class_name2	(objTypeTag,&cTypeName );

					if(tc_strcmp(cTypeName,PKG_PART)==0)
					{
							 isPackagingPart =true ;
							 //tRawMaterial = tEItems[iEIx];
							 ITKCALL(Ng5_getRev2CopyFrom(tEItems[iEIx],&tERevision));
							 break;
					}

                }
            }
            if(!isRawMaterial  && !isPackagingPart)
            {
            	for(int iEIx=0;iEIx <nItems;iEIx++)
            	{

            	       TCTYPE_ask_object_type(tEItems[iEIx],&objTypeTag);
            	       TCTYPE_ask_class_name2	(objTypeTag,&cTypeName );

            	      if(Ng5_validType2Clone(cTypeName))
            	      {
            		      ITKCALL(Ng5_getRev2CopyFrom(tEItems[iEIx],&tERevision));

            	       }
            	}



            }
			if(tERevision == NULLTAG)
			{
				tERevision = tSourceMBOM;
			}
            Ng5_setSourType(item_revision,tERevision);
            Ng5_linkICEPartForm(item_revision,tERevision);
            Ng5_CopyRevProps(item_revision,tERevision);
			Ng5_setMfgItemIDWithPlantCode(item_revision,cpPlantCode);
			ITKCALL(ITEM_ask_item_of_rev(tERevision, &tEItem));
			//ITKCALL(AOM_ask_value_string(tEItem,BOMLINEOBJTYPE, &cpBomlineObjType ))
			Ng5_createRelation(item_revision,tERevision,HASENGPART2MFGPARREV);
			ITKCALL(AOM_ask_value_string(item_revision,ATTR_IS_TOPLINE,&cpIsTopline ));

		     if(tc_strcmp(cpIsTopline,YES)!=0)
		     {
			      Ng5_createRelation(tEItem,item_revision,HASPLANTBOM);
		     }

			Ng5_TransferOwnership(tEBOMItemRev,line);
			AOM_refresh(item_revision,true);
			AOM_save_without_extensions(item_revision);
			AOM_refresh(item_revision,false);


			NG5_MEM_TCFREE(cpOriginalID);
			NG5_MEM_TCFREE(cpIsTopline);
	}

    for (int ii = 0; ii < count; ii++)
	{

		ITKCALL(AOM_ask_value_string(tChildren[ii],BOMLINEOBJTYPE, &cpBomlineObjType ));
		if (tc_strcmp (cpBomlineObjType,  MFGPART) == 0)
		{
			Ng5_TraverseMfgNodesforLinking(tEBOMItemRev,tChildren[ii],cpPlantCode,isPackCutReq);
		}

	}

	NG5_MEM_TCFREE(tChildren);
    NG5_MEM_TCFREE(cpBomlineObjType);


}

// A recursive function for Traversing all the manufacturing nodes and set the plant code in Item ID
void Ng5_TraverseMfgNodes(tag_t line, char *plant_code, char* szOEMName)
{
    int
        ii, kk,
        count;

    tag_t
        *tChildren = NULL,
        item_revision = NULLTAG;

	char
        *value = NULL,
		*cpBomlineObjType=NULL,
		*item_id=NULL;


	TC_write_syslog("\n Entering Ng5_TraverseMfgNodes \n");



    ITKCALL(BOM_line_ask_child_lines(line, &count, &tChildren));

	ITKCALL(AOM_ask_value_string(line, BOMLINEOBJTYPE, &cpBomlineObjType ));

	if (tc_strcmp (cpBomlineObjType,  MFGPART) == 0)
	{
		item_revision = Ng5_findItemRevisionFromBOMLine(line);
		//Ng5_setSourType(item_revision);
		Ng5_setMfgItemIDWithPlantCode2(item_revision,plant_code,szOEMName);



	}

    for (ii = 0; ii < count; ii++)
	{

		ITKCALL(AOM_ask_value_string(tChildren[ii], BOMLINEOBJTYPE, &cpBomlineObjType ));
		if (tc_strcmp (cpBomlineObjType,  MFGPART) == 0)
		{
			Ng5_TraverseMfgNodes(tChildren[ii], plant_code,szOEMName);
		}

	}
    NG5_MEM_TCFREE(tChildren);
	NG5_MEM_TCFREE(cpBomlineObjType);


}

/*Find Item Revision From BOM Line */
tag_t Ng5_findItemRevisionFromBOMLine(tag_t bom_line)
{
    tag_t tItemRev = NULLTAG;
	int attr_id = 0;   
	ITKCALL( BOM_line_look_up_attribute (BOMLINEREVISION, &attr_id) );
	ITKCALL( BOM_line_ask_attribute_tag ( bom_line, attr_id, &tItemRev) );
   
    return tItemRev;
}

int Ng5_setMfgItemIDWithPlantCode(tag_t item_revision, char *plant_code)
{
	int iFail = ITK_ok;
	char* cpCustNoReq=NULL;
	char* cpOEMName=NULL;

	ITKCALL(AOM_ask_value_string(item_revision, RQRDCUSTPARTNO,&cpCustNoReq ));
	ITKCALL(AOM_ask_value_string(item_revision,CUSTOMER,&cpOEMName ));
	
	if(tc_strcmp(YES,cpCustNoReq)==0 && tc_strlen(cpOEMName)>0)
	{
		iFail = Ng5_setMfgItemIDWithPlantCode2(item_revision,plant_code,cpOEMName);
	}
	NG5_MEM_TCFREE(cpCustNoReq);
	NG5_MEM_TCFREE(cpOEMName);
	return iFail;
}
int Ng5_setMfgItemIDWithPlantCode2(tag_t item_revision, char *plant_code, char* OEMName)
{

	TC_write_syslog("\n >>>>>  entering Ng5_setMfgItemIDWithPlantCode2 %s\n",OEMName);
	int iFail = ITK_ok;

	tag_t
			item = NULLTAG;

		char
			*CustomerPartNo = NULL,
			*cpItemId 		= NULL,
			*cpMfgItemId 	= NULL,
			*cpPrefix     	= NULL,
	        *cpID        	= NULL,
			*cpOriginalID   = NULL,
		    *cpIDTemp       = NULL;

		ITKCALL(ITEM_ask_item_of_rev(item_revision, &item ));
		ITKCALL(ITEM_ask_id2(item, &cpItemId));
		ITKCALL(AOM_ask_value_string(item, ORIGINALID, &cpOriginalID ));

	tag_t tERevision = NULLTAG;
	char* cpEItemRevId = NULL;
	char*  cTypeName  = NULL;
	char*  cpClnType= NULL;
	ITKCALL(AOM_ask_value_string( item_revision, ATTR_ITEM_REV_ID, &cpEItemRevId ));
	int  nItems  = 0;
    tag_t*  tEItems = NULLTAG; //MEM Free
    tag_t  objTypeTag = NULL;

	ITKCALL(ITEM_find(cpOriginalID,&nItems,&tEItems));
	for(int iEIx=0;iEIx <nItems;iEIx++)
	{
		TCTYPE_ask_object_type(tEItems[iEIx],&objTypeTag);

		TCTYPE_ask_class_name2	(objTypeTag,&cTypeName );
		//Need to take from pref
		if(Ng5_validType2Clone(cTypeName))
    	{
    		ITKCALL(Ng5_getRev2CopyFrom(tEItems[iEIx],&tERevision));

    	}
	}



	if(tERevision != NULLTAG)
	{
		char* cpSuffix = NULL;
		Ng5_getMfgCustomPartNum(tERevision, OEMName,&CustomerPartNo);
		ITKCALL(AOM_ask_value_string(item_revision,SUFFIX,&cpSuffix));



		if(CustomerPartNo != NULL && tc_strlen(CustomerPartNo)>0)
		{
				//Need to include suffix also
			    if(tc_strlen(cpSuffix)>0)
			    {

			    	cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(plant_code)+tc_strlen(HYPHEN)+tc_strlen(CustomerPartNo)+tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);
			    	tc_strcpy(cpMfgItemId, MHYPHEN);
			        tc_strcat(cpMfgItemId, plant_code);
			    	tc_strcat(cpMfgItemId, HYPHEN);
			    	tc_strcat(cpMfgItemId, CustomerPartNo);
			    	tc_strcat(cpMfgItemId, HYPHEN);
			    	tc_strcat(cpMfgItemId, cpSuffix);


			    }
			    else
			    {
			    cpMfgItemId= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(plant_code)+tc_strlen(HYPHEN)+tc_strlen(CustomerPartNo))+1);
				tc_strcpy(cpMfgItemId, MHYPHEN);
				tc_strcat(cpMfgItemId, plant_code);
				tc_strcat(cpMfgItemId, HYPHEN);

				tc_strcat(cpMfgItemId, CustomerPartNo);
			    }
			    TC_write_syslog("\n >>>>> Manufacturing Part ID %s\n",cpMfgItemId);





				iFail = AOM_refresh(item, TRUE);
				iFail = AOM_set_value_string(item, ATTR_ITEM_ID, cpMfgItemId);

				iFail = AOM_save_without_extensions(item);
				iFail = AOM_refresh(item,false);

				iFail = AOM_refresh(item_revision, TRUE);
				iFail = AOM_set_value_string(item_revision,RQRDCUSTPARTNO, YES);
				iFail = AOM_set_value_string(item_revision,CUSTOMER,OEMName);
				iFail = AOM_set_value_string(item_revision,SOURCETYPE,OEM);
				iFail = AOM_save_without_extensions(item_revision);
				iFail = AOM_refresh(item_revision, false);
				iFail = Ng5_setBVRName(item,item_revision);

		}
		NG5_MEM_TCFREE(cpSuffix);
	}
	NG5_MEM_TCFREE(cpItemId);
	NG5_MEM_TCFREE(cpMfgItemId);
	NG5_MEM_TCFREE(cpIDTemp);
	NG5_MEM_TCFREE(cpOriginalID);


    return iFail;
}

int Ng5_find_rev(char *item_id, char *rev_id, tag_t *rev)
{
    int
        n = 0;
    tag_t
        *items;
    const char
        *names[1] = { ATTR_ITEM_ID },
        *values[1] = { item_id };

    ITKCALL(ITEM_find_item_revs_by_key_attributes(1, names, values, rev_id, &n, &items));
    if (n > 0)
	*rev = items[0];

	if (items) MEM_free(items);

    return 0;
}

/*Function to get current time stamp
 *
 */

int Ng5_current_get_time_stamp(char* format, char** timestamp)
{
	int retcode       = ITK_ok;
	date_t currentTime;
	struct tm* newTime = NULL;
	time_t localTime;
	time(&localTime);
	newTime = localtime(&localTime);
	currentTime.month = newTime->tm_mon;
	currentTime.year = newTime->tm_year + 1900;
	currentTime.day = newTime->tm_mday;
	currentTime.hour = newTime->tm_hour;
	currentTime.minute = newTime->tm_min;
	currentTime.second = newTime->tm_sec;

	DATE_date_to_string(currentTime, format, timestamp);
	return retcode;
}

/*Function Name : Ng5_setSourType
 *Description   : Function to set Source Type Attribute
 *Creation History : Sahida Khatun , July 2022
 *
*/
int Ng5_setSourType(tag_t item_revision,tag_t tERevision)
{
    char* cpRcustName      = NULL; //OF
    char* cpCustName       = NULL; //OF
    char* cpCustomerPartNo = NULL; //OF
	

    TC_write_syslog("\n Entering Ng5_setSourType\n");
	ITKCALL(AOM_ask_value_string(item_revision,RQRDCUSTPARTNO,&cpRcustName));
	ITKCALL(AOM_ask_value_string(item_revision,CUSTOMER,&cpCustName));


	ITKCALL(AOM_refresh(item_revision,true));
	if(tc_strcmp(cpRcustName,YES)==0 )
	{
       if(tc_strlen(cpCustName)>0)
		{

    	    Ng5_getMfgCustomPartNum(tERevision, cpCustName,&cpCustomerPartNo);
			if(tc_strlen(cpCustomerPartNo)>0)
			 {
			     ITKCALL( AOM_set_value_string(item_revision,SOURCETYPE,OEM));
			  }
			NG5_MEM_TCFREE(cpCustomerPartNo);

	    }
	}
	else
	{
        int    prefCount     = 0;
        char** prefValues    = NULL;
        char*  cprefObjType  = NULL;
        char*  cpEObjType    = NULL;
        char*  sourceType    = NULL;
        tag_t  tObjType      = NULLTAG;
		ITKCALL(PREF_ask_char_values(SOURCETYPEPREF,&prefCount,&prefValues));
		ITKCALL(TCTYPE_ask_object_type(tERevision,&tObjType));
		ITKCALL(TCTYPE_ask_name2(tObjType,&cpEObjType));

		for(int iprx =0 ; iprx<prefCount;iprx++)
		{
			   cprefObjType = tc_strtok(prefValues[iprx],COLON);
			   TC_write_syslog("\n Line Number 1099 %s : %s \n",cprefObjType,cpEObjType);
			   if(tc_strcmp(cprefObjType,cpEObjType)==0)
			   {
			    	sourceType = tc_strtok(NULL,COLON);
			    	TC_write_syslog("\n Source Type %s\n",sourceType );

			    	ITKCALL( AOM_set_value_string(item_revision,SOURCETYPE,sourceType));
			    	break;
			   }
		}


	}
	ITKCALL(AOM_save_without_extensions(item_revision));
	ITKCALL(AOM_refresh(item_revision,false));
	NG5_MEM_TCFREE(cpRcustName);
	NG5_MEM_TCFREE(cpCustName);
    TC_write_syslog("\n Exiting  Ng5_setSourType\n");
	return ITK_ok;
}

/*Function Name : Ng5_CopyProps
 *Description   : Function to Copy Properties and relations from EBOM topline to MBOM topline
 *Creation History : Sahida Khatun , July 2022
 *
*/
int Ng5_CopyProps(tag_t item_revision,tag_t tERevision)
{
    char*  cpRcustName       = NULL; //OF
    char*  cpCustName        = NULL; //OF
    char*  cpCustomerPartNo  = NULL; //OF
    char** cpPrefVal         = NULL;

    char*  cpAttributes      = NULL;
    char*  cpAttribute2Copy  = NULL;
    char*  cpObj2Cpyfrom     = NULL;
    char*  cpPropTypeName    = NULL;
    char*  cpPropStringVal   = NULL;
    char*  cpRelationName    = NULL;
    char*  cpObjType         = NULL;
    char*  cpObjName         = NULL;
    tag_t   tEItem           = NULLTAG;
    tag_t   tMItem           = NULLTAG;
    tag_t   tPropTag         = NULLTAG;
    tag_t   tRelType         = NULLTAG;
    tag_t*  tSecObjs         = NULL;
    tag_t   tObjType         = NULLTAG;
    tag_t   tMfgRel          = NULLTAG;
    PROP_type_t 	propType     ;
    int    iPrefCount        = 0;
    int    iRelCount         = 0;
    char* frmItemId = NULL;
	char* toItemId = NULL;

    ITEM_ask_item_of_rev	(tERevision,&tEItem );
    ITEM_ask_item_of_rev	(item_revision,&tMItem );
	if(tEItem != NULLTAG && tMItem != NULLTAG)
	{
		ITKCALL(AOM_ask_value_string(tEItem,ATTR_ITEM_ID,&frmItemId));
		ITKCALL(AOM_ask_value_string(tMItem,ATTR_ITEM_ID,&toItemId));
		
		 TC_write_syslog("\n Entering Ng5_CopyProps  from %s to %s\n",frmItemId,toItemId );
		 NG5_MEM_TCFREE(frmItemId);
		 NG5_MEM_TCFREE(toItemId);
	}
	else
	{
		 TC_write_syslog("\n Leaving Ng5_CopyProps\n");
		 return ITK_ok;
	}


   
    PREF_ask_char_values(EBOM2MBOMCOPYPREF,&iPrefCount,&cpPrefVal);


    for(int ipfx = 0; ipfx < iPrefCount; ipfx++)
    {

    	cpObj2Cpyfrom = tc_strtok(cpPrefVal[ipfx],COLON);
        cpAttributes = tc_strtok(NULL,COLON);

        cpAttribute2Copy = tc_strtok(cpAttributes,COMMA);
        while(cpAttribute2Copy!=NULL)
        {
        TC_write_syslog("\nProperty to copy from EBOM %s",cpAttribute2Copy);
        if(tc_strcmp(cpObj2Cpyfrom,ITEM)==0)
        {
        	 AOM_ask_property_type( tEItem,cpAttribute2Copy,&propType,&cpPropTypeName);

        	 if(tc_strcmp(cpPropTypeName,ATTR)==0)
        	 {
				 char* cptoValue = NULL;	
				 ITKCALL(AOM_ask_value_string( tMItem,cpAttribute2Copy,&cptoValue));
				 if(cptoValue != NULL && tc_strlen(cptoValue)>0)
				 {
					 NG5_MEM_TCFREE(cptoValue);
				 }
				 else 
			     {
					ITKCALL(AOM_ask_value_string( tEItem,cpAttribute2Copy,&cpPropStringVal));
					if(cpPropStringVal!=NULL && tc_strlen(cpPropStringVal)>0)
					{
						 char* tempProp= NULL;
						 ITKCALL(AOM_ask_value_string(tMItem,cpAttribute2Copy,&tempProp));
						 if(tempProp != NULL && tc_strlen(tempProp)>0)
						 {
							 NG5_MEM_TCFREE(tempProp);
							 
						 }else
						 {
						 
							 ITKCALL(AOM_refresh(tMItem,true));
							 ITKCALL(AOM_set_value_string(tMItem,cpAttribute2Copy,cpPropStringVal));
							 ITKCALL(AOM_save_without_extensions(tMItem));
							 ITKCALL(AOM_refresh(tMItem,false));
						 }
					 }
				 }
        	 }
        	 if(tc_strcmp(cpPropTypeName,REF)==0)
        	        	 {
        		            tag_t attr_id_tag = NULLTAG;
        		            POM_attr_id_of_attr(cpAttribute2Copy, ITEM, &attr_id_tag);
        		            ITKCALL(AOM_ask_value_tag( tEItem,cpAttribute2Copy,&tPropTag ));


        	        		 if(tPropTag !=NULLTAG)
        	        		 {

        	        			 ITKCALL(POM_refresh_instances(1, &tMItem, NULLTAG, POM_modify_lock););
        	        			 ITKCALL(POM_set_attr_tag(1, &tMItem, attr_id_tag, tPropTag ));
        	        			 ITKCALL( POM_save_instances(1, &tMItem, true));
        	        			 ITKCALL(POM_refresh_instances(1, &tMItem, NULLTAG, POM_no_lock););
        	        			 //ITKCALL(AOM_refresh(tMItem,false));


        	        		 }
        	        	 }



        }
        else if(tc_strcmp(cpObj2Cpyfrom,REV)==0)
        {
        	 AOM_ask_property_type( tERevision,cpAttribute2Copy,&propType,&cpPropTypeName);
        	 if(tc_strcmp(cpPropTypeName,ATTR)==0)
        	 {
				 
        		 ITKCALL(AOM_ask_value_string( tERevision,cpAttribute2Copy,&cpPropStringVal));
        		 if(cpPropStringVal!=NULL && tc_strlen(cpPropStringVal)>0)
        		 {
	                 char* tempProp= NULL;
					 ITKCALL(AOM_ask_value_string(item_revision,cpAttribute2Copy,&tempProp));
					 if(tempProp != NULL && tc_strlen(tempProp)>0)
					 {
						 NG5_MEM_TCFREE(tempProp);
						 
					 }else
					 {
        			    ITKCALL(AOM_set_value_string(item_revision,cpAttribute2Copy,cpPropStringVal));
					 }


        		 }
        	 }
        	 if(tc_strcmp(cpPropTypeName,REF)==0)
        	        	 {
        	        		 ITKCALL(AOM_ask_value_tag( tERevision,cpAttribute2Copy,&tPropTag ));
        	        		 if(tPropTag!=NULLTAG)
        	        		 {

        	        			 ITKCALL(AOM_set_value_tag(item_revision,cpAttribute2Copy,tPropTag));


        	        		 }
        	        	 }



        }
        else if(tc_strcmp(cpObj2Cpyfrom,ITEMRELATION)==0)
		{
        	cpRelationName = tc_strtok(cpAttribute2Copy,HYPHEN);
        	TC_write_syslog("\nRelation to Copy %s",cpRelationName);

        	cpObjType = tc_strtok(NULL,HYPHEN);
			ITKCALL(GRM_find_relation_type(cpRelationName,&tRelType));
			ITKCALL(GRM_list_secondary_objects_only(tEItem,tRelType,&iRelCount,&tSecObjs));
			for(int iRelx = 0; iRelx<iRelCount;iRelx++)
			{
				ITKCALL(TCTYPE_ask_object_type(tSecObjs[iRelx],&tObjType));
				ITKCALL(TCTYPE_ask_name2	(tObjType,&cpObjName));
				if(tc_strcmp(cpObjName,cpObjType)==0)
				{
				  GRM_find_relation(tMItem,tSecObjs[iRelx],tRelType,&tMfgRel);
                  if(tMfgRel!=NULLTAG )
                    {
                            TC_write_syslog("\nRelation allready exists");
                    }
                    else
                     {
                    	TC_write_syslog("\nCreate Relation");
                    	ITKCALL(GRM_create_relation(tMItem,tSecObjs[iRelx],tRelType,NULLTAG,&tMfgRel));
                        ITKCALL(GRM_save_relation(tMfgRel));
                     }
				}



			}


		}
        else if(tc_strcmp(cpObj2Cpyfrom,REVRELATION)==0)
        		{
        	        cpRelationName = tc_strtok(cpAttribute2Copy,HYPHEN);
        	        TC_write_syslog("\nRelation to Copy %s",cpRelationName);
        	        cpObjType = tc_strtok(NULL,HYPHEN);

        	        ITKCALL(GRM_find_relation_type(cpAttribute2Copy,&tRelType));
        			ITKCALL(GRM_list_secondary_objects_only(tERevision,tRelType,&iRelCount,&tSecObjs));
        			for(int iRelx = 0; iRelx<iRelCount;iRelx++)
        			{
        				ITKCALL(TCTYPE_ask_object_type(tSecObjs[iRelx],&tObjType));
        				ITKCALL(TCTYPE_ask_name2	(tObjType,&cpObjName));
        				if(tc_strcmp(cpObjName,cpObjType)==0)
        			    {

        				ITKCALL(GRM_create_relation	(item_revision,tSecObjs[iRelx],tRelType,NULLTAG,&tMfgRel));
        				ITKCALL(GRM_save_relation(tMfgRel));
        			    }




        			}


        		}
        cpAttribute2Copy = tc_strtok(NULL,COMMA);
        }


    }


  	NG5_MEM_TCFREE(cpPropStringVal);
	NG5_MEM_TCFREE(cpPrefVal);
	NG5_MEM_TCFREE(cpPropTypeName);
	NG5_MEM_TCFREE(tSecObjs);

    TC_write_syslog("\n Exiting Ng5_CopyProps\n");
	return ITK_ok;
}

/*Function Name : Ng5_CopyRev Props
 *Description   : Function to set Rev Props
 *Creation History : Sahida Khatun , July 2022
 *
*/
int Ng5_CopyRevProps(tag_t item_revision,tag_t tERevision)
{
    char*  cpRcustName       = NULL; //OF
    char*  cpCustName        = NULL; //OF
    char*  cpCustomerPartNo  = NULL; //OF
    char** cpPrefVal         = NULL; //OF

    char*  cpAttributes      = NULL;//OF
    char*  cpAttribute2Copy  = NULL;
    char*  cpObj2Cpyfrom     = NULL;
    char*  cpPropTypeName    = NULL;
    char*  cpPropStringVal   = NULL;
    char*  cpRelationName    = NULL;
    char*  cpObjType         = NULL;
    char*  cpObjName         = NULL;
    tag_t   tEItem           = NULLTAG;
    tag_t   tMItem           = NULLTAG;
    tag_t   tPropTag         = NULLTAG;
    tag_t   tRelType         = NULLTAG;
    tag_t   tObjType         = NULLTAG;
    tag_t   tMfgRel          = NULLTAG;
    PROP_type_t 	propType     ;
    int    iPrefCount        = 0;
    int    iRelCount         = 0;
	char* frmItemId = NULL;
	char* toItemId = NULL;

    ITEM_ask_item_of_rev	(tERevision,&tEItem );
    ITEM_ask_item_of_rev	(item_revision,&tMItem );
	
	if(tEItem != NULLTAG && tMItem != NULLTAG)
	{
		ITKCALL(AOM_ask_value_string(tEItem,ATTR_ITEM_ID,&frmItemId));
		ITKCALL(AOM_ask_value_string(tMItem,ATTR_ITEM_ID,&toItemId));
		
		 TC_write_syslog("\n Entering Ng5_CopyRevProps  from %s to %s\n",frmItemId,toItemId );
		 NG5_MEM_TCFREE(frmItemId);
		 NG5_MEM_TCFREE(toItemId);
	}
	else
	{
		 TC_write_syslog("\n Leaving Ng5_CopyRevProps\n");
		 return ITK_ok;
	}


    PREF_ask_char_values(EBOM2MBOMCOPYPREF,&iPrefCount,&cpPrefVal);


    for(int ipfx = 0; ipfx < iPrefCount; ipfx++)
    {

    	cpObj2Cpyfrom = tc_strtok(cpPrefVal[ipfx],COLON);
        cpAttributes = tc_strtok(NULL,COLON);

        cpAttribute2Copy = tc_strtok(cpAttributes,COMMA);
        while(cpAttribute2Copy!=NULL)
        {
         TC_write_syslog("\nProperty to copy from EBOM %s",cpAttribute2Copy);
         if(tc_strcmp(cpObj2Cpyfrom,REV)==0)
         {
        	 AOM_ask_property_type( tERevision,cpAttribute2Copy,&propType,&cpPropTypeName);
        	 if(tc_strcmp(cpPropTypeName,ATTR)==0)
        	 {
				 char* cptoValue = NULL;	
				 ITKCALL(AOM_ask_value_string( item_revision,cpAttribute2Copy,&cptoValue));
				 TC_write_syslog("\nProperty to copy from MBOM  %s : %s",cpAttribute2Copy,cptoValue);
				 if(cptoValue != NULL && tc_strlen(cptoValue)>0)
				 {
					 NG5_MEM_TCFREE(cptoValue);
				 }
				 else 
				 {
					 ITKCALL(AOM_ask_value_string( tERevision,cpAttribute2Copy,&cpPropStringVal));
					 if(cpPropStringVal!=NULL && tc_strlen(cpPropStringVal)>0)
					 {
						 ITKCALL(AOM_refresh(item_revision,true));
						 ITKCALL(AOM_set_value_string(item_revision,cpAttribute2Copy,cpPropStringVal));
						 ITKCALL(AOM_save_without_extensions(item_revision));
						 ITKCALL(AOM_refresh(item_revision,false));
					 }
				 }
        	 }
        	 if(tc_strcmp(cpPropTypeName,REF)==0)
        	        	 {
        	        		 ITKCALL(AOM_ask_value_tag( tERevision,cpAttribute2Copy,&tPropTag ));
        	        		 if(tPropTag!=NULLTAG)
        	        		 {
        	        			 ITKCALL(AOM_refresh(item_revision,true));
        	        			 ITKCALL(AOM_set_value_tag(item_revision,cpAttribute2Copy,tPropTag));
        	        			 ITKCALL(AOM_save_without_extensions(item_revision));
        	        			 ITKCALL(AOM_refresh(item_revision,false));



        	        		 }
        	        	 }



        }
        cpAttribute2Copy = tc_strtok(NULL,COMMA);
        }


    }

	NG5_MEM_TCFREE(cpPropStringVal);
	NG5_MEM_TCFREE(cpPropTypeName);
	NG5_MEM_TCFREE(cpPrefVal);


    TC_write_syslog("\n Exiting Ng5_CopyRevProps\n");
	return ITK_ok;
}

int Ng5_linkICEPartForm(tag_t tMBOMRev, tag_t tEBOMrev)
{

	int    iMBOMSecObjs      = 0;
	int    iEBOMSecObjs      = 0;

	tag_t   tRelType         = NULLTAG;
	tag_t*  tMBOMSecObjs     = NULL;
	tag_t*  tEBOMSecObjs     = NULL;
	tag_t   tEBOMItem        = NULLTAG;
	tag_t   tMBOMItem        = NULLTAG;
	tag_t   tRelation        = NULLTAG;
	tag_t   tNewRelation     = NULLTAG;


	TC_write_syslog("\n Entering Link ICEPart Form\n");
	 ITKCALL(ITEM_ask_item_of_rev	(tEBOMrev,&tEBOMItem));
	 ITKCALL(ITEM_ask_item_of_rev	(tMBOMRev,&tMBOMItem));

	ITKCALL(GRM_find_relation_type(HASICEPARTFORM,&tRelType));
	ITKCALL(GRM_list_secondary_objects_only(tMBOMItem,tRelType,&iMBOMSecObjs,&tMBOMSecObjs));

	for(int iSec = 0;iSec <iMBOMSecObjs; iSec++)
	{

		 GRM_find_relation(tEBOMItem,tMBOMSecObjs[iSec],tRelType,&tRelation);

		 if(tRelation ==NULLTAG)
		 {
			 GRM_create_relation(tEBOMItem,tMBOMSecObjs[iSec],tRelType,NULLTAG,&tNewRelation);
			 GRM_save_relation(tNewRelation);

		 }
	}
	TC_write_syslog("\n Exiting Link ICEPart Form\n");
	return ITK_ok;
	}

//Function to Transfer Ownership for masscloning
int Ng5_TransferOwnership(tag_t tEbomRevision,tag_t tMBOMLine)


{
	        tag_t  tOwningGroup     = NULLTAG;
	        tag_t  tMBOMRevision    = NULLTAG;

	    	 tag_t  tMCNOwningGroup = NULLTAG;
	    	 tag_t  tMCNRevision    = NULLTAG;
	    	 tag_t* tPrimaryObjs    = NULLTAG;
	    	 tag_t  tRelationType   = NULLTAG;
	    	 tag_t  tMBOMItem       = NULLTAG;
	    	 tag_t  tEBOMItem       = NULLTAG;

	    	 char*  cpMCNPlants    = NULL;
	    	 char*  cpMfgPlants   =  NULL;
                 char*  cpObjString     = NULL;


	    	 int   iCount           = 0;
	    	    TC_write_syslog("\n Entering Transfer OWnership\n");
	            ITKCALL(GRM_find_relation_type(EBOM_ITEMS,&tRelationType));
	            tMBOMRevision = Ng5_findItemRevisionFromBOMLine(tMBOMLine);
	            AOM_ask_value_string(tMBOMRevision,ATTR_OBJECT_STRING,&cpObjString);
	            AOM_ask_value_string(tMBOMRevision,PLANTS,&cpMfgPlants);
	            ITEM_ask_item_of_rev	(tMBOMRevision ,&tMBOMItem);
	           // ITEM_ask_item_of_rev	(tEbomRevision ,&tEBOMItem );

	            ITKCALL(GRM_list_primary_objects_only(tEbomRevision,tRelationType,&iCount,&tPrimaryObjs));
	            TC_write_syslog("\n Primary iCount %d\n",iCount);
	     	    ITKCALL(AOM_ask_group(tMBOMRevision,&tOwningGroup));

	     	    for(int iPrimaryX =0 ;iPrimaryX < iCount; iPrimaryX++)
	     	    {
	     	    	AOM_ask_value_string(tPrimaryObjs[iPrimaryX],PLANTS,&cpMCNPlants);
	     	    	if(tc_strcmp(cpMCNPlants,cpMfgPlants)==0)
	     	    	{
	     	    		tMCNRevision = tPrimaryObjs[iPrimaryX];
	     	    		break;
	     	    	}

	     	    }


	    	    	if(tMCNRevision!=NULLTAG)
	    	    	{
	    	    		 ITKCALL(AOM_ask_group(tMCNRevision,&tMCNOwningGroup));
	    	    		 if(tOwningGroup!=tMCNOwningGroup)
	    	    		 {
	    	    			 int iBOMViewCount = 0;
	    	    			 tag_t* tBVList    = NULL;
	    	    			 tag_t  tMBOMView  = NULLTAG;
	    	    			 TC_write_syslog("\n Owning Group Not Matching\n");
	    	    			 TC_write_syslog("\n Started Trasfer Ownership for %s\n",cpObjString);
	    	    			 tag_t tOwningUser = NULLTAG;
	    	    			 ITKCALL(AOM_ask_owner(tMCNRevision,&tOwningUser));
	    	    			 ITKCALL(AOM_refresh(tMBOMRevision,true));
	    	    			 ITKCALL(AOM_set_ownership(tMBOMRevision,tOwningUser,tMCNOwningGroup));
	    	    			 ITKCALL(AOM_save_without_extensions(tMBOMRevision));
                             ITKCALL(AOM_refresh(tMBOMRevision,false));


                             ITKCALL(AOM_refresh(tMBOMItem,true));
                             ITKCALL(AOM_set_ownership(tMBOMItem,tOwningUser,tMCNOwningGroup));
                             ITKCALL(AOM_save_without_extensions(tMBOMItem));
                             ITKCALL(AOM_refresh(tMBOMItem,false));


                             ITEM_list_bom_views(tMBOMItem,&iBOMViewCount,&tBVList);
                              if(iBOMViewCount >0)
                              {


                              TC_write_syslog("\n setting the ownership of BOMView\n");
                             tMBOMView  = tBVList[0];
                             ITKCALL(AOM_refresh(tBVList[0],true));
                             ITKCALL(AOM_set_ownership(tBVList[0],tOwningUser,tMCNOwningGroup));
                             ITKCALL(AOM_save_without_extensions(tBVList[0]));
                             ITKCALL(AOM_refresh(tBVList[0],false));
                             
                             NG5_MEM_TCFREE(tBVList);
                              }


	    	    		 }

	    	    	}



	    	    NG5_MEM_TCFREE(cpMCNPlants);
	    	    NG5_MEM_TCFREE(cpMfgPlants);
	    	    NG5_MEM_TCFREE(tPrimaryObjs);
		    NG5_MEM_TCFREE(cpObjString);


	    	    TC_write_syslog("\n Exiting Transfer OWnership\n");
				return ITK_ok;
}

int Ng5_setBVRName(tag_t item,tag_t item_revision)
{

	 int iBOMViewCount = 0;
	 int iBVRCount     = 0;
	 int iFail         = ITK_ok;
	 tag_t* tBVList    = NULL;
	 tag_t* tBVRList   = NULL;
	 tag_t  tMBOMView  = NULLTAG;
	 char*  cpItemID   = NULL;
	 char*  cpRevID    = NULL;
	 char*  cpBVName   = NULL;
	 char*  cpBVRName  = NULL;
	 AOM_ask_value_string(item,ATTR_ITEM_ID,&cpItemID);
	 AOM_ask_value_string(item_revision,ATTR_ITEM_REV_ID,&cpRevID);
	 cpBVName = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpItemID)+tc_strlen(HYPHEN)+tc_strlen("View"))+1);
	 tc_strcpy(cpBVName,cpItemID);
	 tc_strcat(cpBVName,HYPHEN);
	 tc_strcat(cpBVName,"View");

	 cpBVRName = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cpItemID)+tc_strlen(BACKSLASH)+tc_strlen(cpRevID)+tc_strlen(HYPHEN)+tc_strlen("View"))+1);
	 iFail =ITEM_list_bom_views(item,&iBOMViewCount,&tBVList);
	 tc_strcpy(cpBVRName,cpItemID);
	 tc_strcat(cpBVRName,BACKSLASH);
	 tc_strcat(cpBVRName,cpRevID);
     tc_strcat(cpBVRName,HYPHEN);
	 tc_strcat(cpBVRName,"View");
	  if(iBOMViewCount >0)
      {


            TC_write_syslog("\n setting the ownership of BOMView\n");
            tMBOMView  = tBVList[0];
            ITKCALL(AOM_refresh(tBVList[0],true));

            ITKCALL(AOM_set_value_string(tBVList[0],OBJECT_NAME,cpBVName));
            ITKCALL(AOM_save_without_extensions(tBVList[0]));
            ITKCALL(AOM_refresh(tBVList[0],false));


     }

	iFail = ITEM_rev_list_all_bom_view_revs	(item_revision,&iBVRCount,&tBVRList );
	 if(iBVRCount >0)
      {


            TC_write_syslog("\n setting the ownership of BOMView\n");
            tMBOMView  = tBVRList[0];
            ITKCALL(AOM_refresh(tBVRList[0],true));

            ITKCALL(AOM_set_value_string(tBVRList[0],OBJECT_NAME,cpBVRName));
            ITKCALL(AOM_save_without_extensions(tBVRList[0]));
            ITKCALL(AOM_refresh(tBVRList[0],false));


     }


	 NG5_MEM_TCFREE(tBVList);
	 NG5_MEM_TCFREE(tBVRList);
	 NG5_MEM_TCFREE(cpItemID);
	 NG5_MEM_TCFREE(cpRevID);
	 return iFail;


}
