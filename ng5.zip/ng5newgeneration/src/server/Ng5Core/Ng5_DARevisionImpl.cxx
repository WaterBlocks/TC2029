//@<COPYRIGHT>@

//==================================================

//Copyright $2017.

//Siemens Product Lifecycle Management Software Inc.

//All Rights Reserved.

//==================================================

//@<COPYRIGHT>@



// 

//  @file

//  This file contains the implementation for the Business Object Ng5_DARevisionImpl

//



#include <Ng5Core/Ng5_DARevisionImpl.hxx>

#include <Ng5Core/Ng5Core_Std_Defines.h>

#include <fclasses/tc_string.h>

#include <fclasses/tc_date.h>

#include <tc/tc.h>
#include <Ng5Core/Ng5_CommonUtils.hxx>


using namespace ng5newgeneration;



//----------------------------------------------------------------------------------

// Ng5_DARevisionImpl::Ng5_DARevisionImpl(Ng5_DARevision& busObj)

// Constructor for the class

//----------------------------------------------------------------------------------

Ng5_DARevisionImpl::Ng5_DARevisionImpl( Ng5_DARevision& busObj )

   : Ng5_DARevisionGenImpl( busObj )

{

}



//----------------------------------------------------------------------------------

// Ng5_DARevisionImpl::~Ng5_DARevisionImpl()

// Destructor for the class

//----------------------------------------------------------------------------------

Ng5_DARevisionImpl::~Ng5_DARevisionImpl()

{

}



//----------------------------------------------------------------------------------

// Ng5_DARevisionImpl::initializeClass

// This method is used to initialize this Class

//----------------------------------------------------------------------------------

int Ng5_DARevisionImpl::initializeClass()

{

    int ifail = ITK_ok;

    static bool initialized = false;



    if( !initialized )

    {

        ifail = Ng5_DARevisionGenImpl::initializeClass( );

        if ( ifail == ITK_ok )

        {

            initialized = true;

        }

    }

    return ifail;

}


/// ng5_da_state Runtime property implementation

/// @Author - Sree Harsha C

/// This is a Runtime property on DA Revision which sets DA State property to Closed when

/// DA is expired

///

int  Ng5_DARevisionImpl::getNg5_da_stateBase( std::string & value, bool & /*isNull*/ ) const

{

	int ifail = ITK_ok;

	// Your Implementation

	/*int 	     iclosediffdate			    = 	ITK_ok;

	int 	     iextendiffdate			    = 	ITK_ok;
	
	int 		 retValue = 0;

	int          is_released                =   0;

	char *       chCurrentState             =    NULL;

	char *       chCurrentDate              =    NULL;

	tag_t        tDARev 				    =    NULLTAG;

	date_t       tCurrentDate               =    NULLDATE;

	date_t       dtStartDate 				= 	 NULLDATE;

	date_t       dtEndDate					= 	 NULLDATE;

	date_t       dtExtEndDate 				=    NULLDATE;

	logical      bIsValidDate 				=    false;
	
	int 		 retValue1 = 0;

	Ng5_DARevision *bo = getNg5_DARevision();

	tDARev = ((Teamcenter::BusinessObject*)bo)->getTag();

	ITK(EPM_ask_if_released	(	tDARev,  &is_released     ));

	ITK(AOM_ask_value_string(tDARev, ATTR_CHANGE_STATE, &chCurrentState));

	ITK(ITK_ask_default_date_format(&chCurrentDate));

	ITK( DATE_string_to_date_t(chCurrentDate,&bIsValidDate,&tCurrentDate) );
	
	ITK(AOM_ask_value_date(tDARev, ATTR_TARGET_COMPLETION_DATE, &dtEndDate));

	ITK( POM_compare_dates(dtEndDate, tCurrentDate, &iclosediffdate));

	//If current system date crosses the DA end date then value is set to Closed

	if((tc_strcmp(chCurrentState,"Extended") != 0) && (tc_strcmp(chCurrentState,"Canceled") != 0) && (is_released) && (iclosediffdate == -1))
	{
		
		if((iclosediffdate == -1))
		{
			   // CLOSED_STATE constant is defined in the header file and not maintained since it is impacting the performance
				value = CLOSED_STATE;
				TC_write_syslog("\n DA end date is less than current date setting ng5_changestate to Closed\n");
				retValue = Ng5_CommonUtils::setNg5_ChangeState(tDARev);
				retValue1 = Ng5_CommonUtils::setNg5_UpdateDAProperty(tDARev);

		}
		else if((iclosediffdate == 1) || (iclosediffdate == 0))
		{
				value = chCurrentState;
		}
	}

	//If current system date not crossed the DA end date and the DA is extended
	else if((tc_strcmp(chCurrentState,"Extended") == 0))
	{
		ITK(AOM_ask_value_date(tDARev, ATTR_EXTENSION_DATE, &dtExtEndDate));

		ITK( POM_compare_dates(dtExtEndDate, tCurrentDate, &iextendiffdate));

		//If current system date crosses the DA extend end date then value is set to Closed
		if((iextendiffdate == -1))
		{
			value = CLOSED_STATE;
			TC_write_syslog("\n DA extension date is less than current date setting ng5_changestate to Closed\n");
			retValue = Ng5_CommonUtils::setNg5_ChangeState(tDARev);
			retValue1 = Ng5_CommonUtils::setNg5_UpdateDAProperty(tDARev);
		}
		else if((iextendiffdate == 1) || (iextendiffdate == 0))
		{
			value = chCurrentState;
		}
	}

	//If PM closed the DA before the DA end date then the value is set to Closed
	else if(tc_strcmp(chCurrentState,CLOSED_STATE ) == 0)
	{
		value = CLOSED_STATE;
	}

	//If DA is not expired then the value is set by the same value of Change State property

	else
	{
		value = chCurrentState;
	}

	NG5_MEM_TCFREE( chCurrentState );
	NG5_MEM_TCFREE( chCurrentDate );*/

	return ifail;

}



