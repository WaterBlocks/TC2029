//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_RawMaterialImpl
//

#include <Ng5Core/Ng5_RawMaterialImpl.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <stdarg.h>
#include <string>
#include <sstream>

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_RawMaterialImpl::Ng5_RawMaterialImpl(Ng5_RawMaterial& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_RawMaterialImpl::Ng5_RawMaterialImpl( Ng5_RawMaterial& busObj )
   : Ng5_RawMaterialGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_RawMaterialImpl::~Ng5_RawMaterialImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_RawMaterialImpl::~Ng5_RawMaterialImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_RawMaterialImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_RawMaterialImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_RawMaterialGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

/*
 * **
 * Created By	:	Anil Kumar G
 * Created Date	:	24-Feb-2017
 *
 * Functionality:	Setter for a string Property
 * 					@param value - Value to be set for the parameter
 * 					@param isNull - If true, set the parameter value to null
 * 					@return - Status. 0 if successful
 * 					This Getter method get the objects copied with Ng5_rHasReplacedbyRel
 * 					And array will be stored in Ng5_replacement_for runtime property.
 */

///
/// Getter for a Tag Array Property
/// @param values - Parameter value
/// @param isNull - Returns true for an array element if the parameter value at that location is null
/// @return - Status. 0 if successful
///
/*int  Ng5_RawMaterialImpl::getNg5_replacement_forBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const
{
	int ifail = ITK_ok;

	    		int         iRefs           =       0;
	        	int         *ipLevels       =       NULL;
	        	char        **sz2Rels       =       NULL;
	        	tag_t       tPR                     =       NULLTAG;
	        	tag_t       *tpRefs         =       NULL;
	        	TC_write_syslog("\n\t Entering Ng5_RawMaterialImpl::getNg5_replacement_forBase \n");

	        	//Get the Part  Tag
	        	Ng5_RawMaterial *bo = getNg5_RawMaterial();
	        	tPR = ((Teamcenter::BusinessObject*)bo)->getTag();

	        	std::vector<tag_t>      vTagValues;
	        	std::vector<int>        vIsNullLocal;

	        	vTagValues.clear();

	        	//Getting all where referenced secondary objects
	        	ITK( WSOM_where_referenced( tPR, 1, &iRefs, &ipLevels, &tpRefs, &sz2Rels) );

	        	for(int iWhere=0; iWhere<iRefs; iWhere++)
	        	{
	        		if( sz2Rels[iWhere] != NULL)
	        		{
	        			if(NULLTAG != tpRefs[iWhere])
	        			{
	        				char    cObjectType[WSO_name_size_c+1]    =       {'\0'};
	        				char    cRelationName[WSO_name_size_c+1]  =       {'\0'};
	        				ITK( WSOM_ask_object_type(tpRefs[iWhere], cObjectType) );
	        				if (tc_strcpy(cRelationName,sz2Rels[iWhere]) == 0);
	        				{
	        					//Checking if referenced type is a Raw Material and relation as Ng5_rHasReplacedByrel
	        					if(( tc_strcmp(RAW_MATERIAL, cObjectType) == 0) && (tc_strcmp(PartToPart_ReplacedBy_Rel,cRelationName) == 0))
	        					{
	        						vTagValues.push_back(tpRefs[iWhere]);
	        						vIsNullLocal.push_back(false);
	        					}
	        				}
	        			}

	        		}
	        	}
	        	if(vTagValues.size() > 0)
	        	{
	        		values.clear();
	        		values.swap(vTagValues);
	        	}
	        	if(vIsNullLocal.size() > 0)
	        	{
	        		isNull.clear();
	        		isNull.swap(vIsNullLocal);
	        	}

	        	if(ipLevels != NULL)
	        		MEM_TCFREE(ipLevels);
	        	if(sz2Rels != NULL)
	        		MEM_TCFREE(sz2Rels);
	        	if(tpRefs != NULL)
	        		MEM_TCFREE(tpRefs);

	    return ifail;
}*/

