//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object ChangeItemRevisionImpl
//

#ifndef NG5__NG5NEWGENERATION__CHANGEITEMREVISIONIMPL_HXX
#define NG5__NG5NEWGENERATION__CHANGEITEMREVISIONIMPL_HXX

#include <Ng5Core/ChangeItemRevisionGenImplExt.hxx>
#include "Ng5_CommonUtils.hxx"
#include <Ng5Core/libng5core_exports.h>



namespace ng5
{
    namespace ng5newgeneration
    {
        class ChangeItemRevisionImpl; 
        class ChangeItemRevisionDelegate;
    }
}

class  NG5CORE_API ng5::ng5newgeneration::ChangeItemRevisionImpl
    : public ng5::ng5newgeneration::ChangeItemRevisionGenImpl
{
public:

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_change_typeBase( const std::string &value, bool isNull );


protected:
    ///
    /// Constructor for a ChangeItemRevision
    explicit ChangeItemRevisionImpl( ChangeItemRevision& busObj );

    ///
    /// Destructor
    virtual ~ChangeItemRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    ChangeItemRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    ChangeItemRevisionImpl( const ChangeItemRevisionImpl& );

    ///
    /// Copy constructor
    ChangeItemRevisionImpl& operator=( const ChangeItemRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5::ng5newgeneration::ChangeItemRevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5__NG5NEWGENERATION__CHANGEITEMREVISIONIMPL_HXX
