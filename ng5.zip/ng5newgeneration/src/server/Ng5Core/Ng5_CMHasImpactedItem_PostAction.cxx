//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_CMHasImpactedItem_PostAction
 *
 */
#include <Ng5Core/Ng5_CMHasImpactedItem_PostAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

/****************************************************************************************************
*Function Name : Ng5_rHasMBOMItemPostAction
*Description   : This function Pastes the first Revision of an Mfg ITEM when trying to paste ITEM or other revision object on Mass Update Revsion with relation Impacted
*****************************************************************************************************/
int Ng5_CMHasImpactedItem_PostAction( METHOD_message_t * msg, va_list args )
{
	TC_write_syslog("\n Entering Ng5_CMHasImpactedItem_PostAction \n");
	int iFail 			= ITK_ok;
	tag_t tDevAuthRev 	= NULLTAG;
	tag_t tPartRev  	= NULLTAG;
	tag_t tRelationType = NULLTAG;
	tag_t tRelation 	= NULLTAG;
	tag_t tHasEngRel 	= NULLTAG;
	tag_t tTargetRev 	= NULLTAG;
	tag_t tItem 		= NULLTAG;
	char* cObjectType 	= NULL;
	char* cObjectType1 	= NULL;
	char* cRevID		= NULL;
	char* cItemID		= NULL;	
	tDevAuthRev   = va_arg(args, tag_t);
	tPartRev      = va_arg(args, tag_t);
	tRelationType = va_arg(args, tag_t);
	if (NULLTAG != tDevAuthRev && NULLTAG != tPartRev && NULLTAG != tRelationType) 
	{		
	/*	Added check to verify object type = Eng Part rev or Raw Material rev only.
		For rest of the types, code will skip the execution.*/
		NG5_ITK_CALL(AOM_ask_value_string(tPartRev,ATTR_OBJECT_TYPE, &cObjectType));
		NG5_ITK_CALL(AOM_ask_value_string(tDevAuthRev,ATTR_OBJECT_TYPE, &cObjectType1));
		if(tc_strcmp(cObjectType1, MASSUPDATERev) == 0)
		{
			//iFail = Ng5_associatePartRevtoDARev(tPartRev,tDevAuthRev);
			if(tc_strcmp(cObjectType, MFGPART) == 0 )
			{
				iFail = Ng5_DeleteRelation11(tDevAuthRev,tPartRev,rIMPACTED);
				tTargetRev = Ng5_Find_First_Revision12(tPartRev);
				iFail = GRM_find_relation_type(rIMPACTED, &tRelationType);
				iFail = GRM_find_relation(tDevAuthRev, tTargetRev, tRelationType, &tRelation);
				if (iFail == ITK_ok && tRelation == NULLTAG)
				{
					iFail = GRM_create_relation(tDevAuthRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
					iFail = GRM_save_relation(tHasEngRel);
				}
			}
			if(tc_strcmp(cObjectType, MFGPARTRev) == 0 )
			{
				iFail = AOM_ask_value_string(tPartRev,ITEM_REV_ID, &cRevID);
				if(tc_strcmp(cRevID, "01") == 0 ||tc_strcmp(cRevID, "A") == 0  )
				{
					TC_write_syslog("\n Doing nothing as it is expected revison \n");
					// Do nothing
				} 
				else
				{
					iFail = AOM_ask_value_string(tPartRev,ITEM_ID, &cItemID);
					iFail= Ng5_find_Item(cItemID,MFGPART,&tItem);
					tTargetRev = Ng5_Find_First_Revision12(tItem);
					iFail = Ng5_DeleteRelation11(tDevAuthRev,tPartRev,rIMPACTED);
					iFail = GRM_find_relation_type(rIMPACTED, &tRelationType);
					iFail = GRM_find_relation(tDevAuthRev, tTargetRev, tRelationType, &tRelation);
					if (iFail == ITK_ok && tRelation == NULLTAG)
					{
						iFail = GRM_create_relation(tDevAuthRev, tTargetRev, tRelationType, NULL, &tHasEngRel);
						iFail = GRM_save_relation(tHasEngRel);
					}
				}

			}
		}
		MEM_TCFREE(cObjectType);
		MEM_TCFREE(cObjectType1);
		MEM_TCFREE(cRevID);
		MEM_TCFREE(cItemID);
	}
	TC_write_syslog("\n Exiting Ng5_CMHasImpactedItem_PostAction \n");
	return iFail;
}
