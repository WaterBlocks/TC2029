//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_Create_SSOFolders
 *
 */
 
#ifndef NG5_CREATE_SSOFOLDERS_HXX
#define NG5_CREATE_SSOFOLDERS_HXX
#include <tccore/method.h>
#include <ug_va_copy.h>
#include <tccore/tctype.h>
#include <tccore/workspaceobject.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/item.h>
#include <tccore/grm.h>
#include <lov/lov.h>
#include <tc/preferences.h>
#include <fclasses/tc_string.h>
#include <Ng5Core/libng5core_exports.h>

#define Ng5_SSOPkg									"Ng5_SSOPkg"
#define object_name									"object_name"
#define Ng5_Gate_DV_Start_Folders 					"Ng5_Gate_DV_Start_Folders"
#define Ng5_Gate_DV_Release_Folders 				"Ng5_Gate_DV_Release_Folders"
#define Ng5_Gate_Final_Prod_Release_Folders 		"Ng5_Gate_Final_Prod_Release_Folders"
#define Ng5_Gate_Customer_Part_Approval_Folders 	"Ng5_Gate_Customer_Part_Approval_Folders"

#define Ng5_Gate_Post_Launch 	                    "Ng5_Gate_Post_Launch"
#define Ng5_Gate_Production 	                    "Ng5_Gate_Production"
#define Ng5_Gate_End_of_Production 	                "Ng5_Gate_End_of_Production"


#define Ng5_rHasSSOFolders							"Ng5_rHasSSOFolders"
#define Ng5_SSOFolders 								"Ng5_SSOFolders"
#define retn_date1									"7"
#define retn_date2									"30"
#define ng5_retn_date								"ng5_retn_date"

#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_Create_SSOFolders(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_CREATE_SSOFOLDERS_HXX
