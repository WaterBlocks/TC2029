//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_setOccurrenceEffectivity
 *
 */
#include <Ng5Core/Ng5_setOccurrenceEffectivity.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_setOccurrenceEffectivity( METHOD_message_t *msg, va_list args)
{

		int 		ifail 		  			= 0;
		int 		iBomRevCount 		  	= 0;
		int			iEffsCount				= 0;
		int			iDateCount				= 0;


		char 		*chTypeName   			= NULL;
		tag_t     	*tBomRevs      			= NULL;

		tag_t     	tBOMLine      			= NULLTAG;
		tag_t 	  	tObjType   	  			= NULLTAG;
	    tag_t 		tMfgItemparentRevTag 	= NULLTAG;
	    tag_t 		tBlOcc 					= NULLTAG;

	    int 	  	iBlOccurrence 			= 0;
		int 	  	iBlPlants	 			= 0;
	    char		*cpParentname 			= NULL;
	    char		*cpParentItemID 		= NULL;
	    tag_t		*tEffs					= NULL;
		tag_t		tMfgPartRevision		= NULLTAG;

		char		*start_date_str			= NULL;
		char		*end_date_str			= NULL;
		char		*cpPlantStr 			= NULL;


		date_t*			start_end_values			= NULL;
		date_t 		start_eff_apac_value;
		date_t 		end_eff_apac_value;
		int				open_ended_or_stock_out		= 0;
		char*			date_range_str				= NULL;


		TC_write_syslog("\n Entering Ng5_setOccurrenceEffectivity");

		va_list largs;
		va_copy(largs,args);
		tBOMLine =  msg->object_tag;
		va_end( largs );

		TC_write_syslog("\n Tag of BOM Line = %d \n ", tBOMLine);
		if (NULLTAG != tBOMLine)
		{
	        TCTYPE_ask_object_type(tBOMLine,&tObjType);
			TC_write_syslog("\n Type tag of BOM Line = %d \n ", tObjType);
	        TCTYPE_ask_name2 (tObjType,&chTypeName);
			TC_write_syslog("\n Object Type = %s \n ", chTypeName);
		    BOM_line_look_up_attribute( "bl_occurrence", &iBlOccurrence);
			BOM_line_ask_attribute_tag(tBOMLine, iBlOccurrence, &tBlOcc);

			tag_t parentLine = NULLTAG;
			 Ng5_get_bline_attr ( tBOMLine, BOMLINEPARENTLINE, &parentLine);
			TC_write_syslog("\n >>>>>  parentLine  : %d ",parentLine);
			if(parentLine != NULLTAG)
			{
				Ng5_get_bline_attr ( parentLine, BOMLINEREVISION, &tMfgItemparentRevTag);
			}
			TC_write_syslog("\n >>>>>  tMfgItemparentRevTag  : %d ",tMfgItemparentRevTag);
			ITEM_rev_list_bom_view_revs(tMfgItemparentRevTag, &iBomRevCount, &tBomRevs);

			ifail = PS_occ_eff_ask_effs(tBomRevs[0],tBlOcc,&iEffsCount,&tEffs);
			//ifail = PS_occ_eff_ask_dates(tBomRevs[0],tBOMLine,&iDateCount,&start_end_values,&open_ended_or_stock_out);
			if (iEffsCount > 0)
			{
				TC_write_syslog("\n n_effs  value %d  \n",iEffsCount);
				ifail = PS_occ_eff_ask_dates(tBomRevs[0],tBlOcc,tEffs[0],&iDateCount,&start_end_values,&open_ended_or_stock_out);
				TC_write_syslog("\n n_dates  value >>>> %d  \n",iDateCount);
				TC_write_syslog("\n Open Ended >>>> %d  \n",open_ended_or_stock_out);
				
				tMfgPartRevision = Ng5_findItemRevisionFromBOMLine1 (tBOMLine);				
				ifail = AOM_ask_value_string(tMfgPartRevision, PLANTS, &cpPlantStr);		
				TC_write_syslog("\n PLANT = %s  \n",cpPlantStr);
			
				if (iDateCount == 1 && open_ended_or_stock_out == 1 )
				{
					if (Ng5_isPlantTZ_GT_ServTRZ (cpPlantStr))
					{
						start_eff_apac_value = getTomorrowDate(start_end_values[0]);
						ifail = DATE_date_to_string(start_eff_apac_value,"%d-%b-%y",&start_date_str);
						TC_write_syslog("\n Start Effectivity APAC Date= %s  \n",start_date_str);
						
					}
					else
					{
						ifail = DATE_date_to_string(start_end_values[0],"%d-%b-%y",&start_date_str);
						TC_write_syslog("\n Start Effectivity Date= %s  \n",start_date_str);
					}
					
					date_range_str = (char*)MEM_alloc(sizeof(char) * ((int)strlen(start_date_str)+strlen(" 12:00")+strlen(" to ")+strlen(Ng5_UP_DATE)+1));
					tc_strcat(date_range_str,start_date_str);
					tc_strcat(date_range_str," 12:00");
					tc_strcat(date_range_str," to ");
					tc_strcat(date_range_str,Ng5_UP_DATE);
					TC_write_syslog("\n#######date_range_str  value Line 85:%s  \n",date_range_str);
					ifail = AOM_refresh(tEffs[0], TRUE);
					ifail = PS_occ_eff_set_date_range(tBomRevs[0],tBlOcc,tEffs[0],date_range_str,false);
					ifail = AOM_save(tEffs[0]);
					ifail = AOM_refresh(tEffs[0], FALSE);
				}
				if (iDateCount == 2 && open_ended_or_stock_out != 1 )
				{

					if (Ng5_isPlantTZ_GT_ServTRZ (cpPlantStr))
					{
						start_eff_apac_value = getTomorrowDate(start_end_values[0]);
						ifail = DATE_date_to_string(start_eff_apac_value,"%d-%b-%y",&start_date_str);
						TC_write_syslog("\n Start Effectivity APAC Date= %s  \n",start_date_str);
						end_eff_apac_value = getTomorrowDate(start_end_values[1]);
						ifail = DATE_date_to_string(end_eff_apac_value,"%d-%b-%y",&end_date_str);
						TC_write_syslog("\n End Effectivity APAC Date= %s  \n",end_date_str);	
						
					}
					else
					{
						ifail = DATE_date_to_string(start_end_values[0],"%d-%b-%y",&start_date_str);
						TC_write_syslog("\n Start Date= %s  \n",start_date_str);
						ifail = DATE_date_to_string(start_end_values[1],"%d-%b-%y",&end_date_str);
						TC_write_syslog("\n End Date= %s  \n",end_date_str);				
					}
					
					date_range_str = (char*)MEM_alloc(sizeof(char) * ((int)strlen(start_date_str)+strlen(" 12:00")+strlen(" to ")+strlen(end_date_str)+strlen(" 12:00")+1));
					tc_strcat(date_range_str,start_date_str);
					tc_strcat(date_range_str," 12:00");
					tc_strcat(date_range_str," to ");
					tc_strcat(date_range_str,end_date_str);
					tc_strcat(date_range_str," 12:00");
					TC_write_syslog("\n#######date_range_str  value Line 106 :%s  \n",date_range_str);
					ifail = AOM_refresh(tEffs[0], TRUE);
					ifail = PS_occ_eff_set_date_range(tBomRevs[0],tBlOcc,tEffs[0],date_range_str,false);
					ifail = AOM_save(tEffs[0]);
					ifail = AOM_refresh(tEffs[0], FALSE);
				}
			}
		}

		NG5_MEM_TCFREE(chTypeName);
		NG5_MEM_TCFREE(cpParentname);
		NG5_MEM_TCFREE(tBomRevs);
		NG5_MEM_TCFREE(tEffs);
		NG5_MEM_TCFREE(start_date_str);
		NG5_MEM_TCFREE(end_date_str);
		NG5_MEM_TCFREE(date_range_str);
		NG5_MEM_TCFREE(cpPlantStr);


		TC_write_syslog("\n Existing Ng5_setOccurrenceEffectivity");
		return ifail;
 
}

/******************************************************************************
*get_bline_attr_tag ()
*Utility function to get a 'tag' type attribute in a BOM Line.
*
* Parameters
* bline_t : tag_t : BOM line tag whose attribute is to be obtained
* attr : char* : Attribute name
* attr_t : tag* : Return tag value
*
* Returns
* ITK_ok  : int : Success
* !ITK_ok : int : Failure
*
******************************************************************************/

int Ng5_get_bline_attr(
      tag_t bline_t,      /* <I> */
      char  *attr,        /* <I> */
      tag_t *attr_t       /* <O> */
      )
{

  int attr_id = 0;   /* a random invalid mode */
  ITKCALL ( BOM_line_look_up_attribute (attr, &attr_id) );
  ITKCALL ( BOM_line_ask_attribute_tag ( bline_t, attr_id, attr_t) );
  return ITK_ok;

}


date_t getTomorrowDate(date_t d)
{

	char* clastModdate2= NULL;
		DATE_date_to_string(d,"%dd-%mm-%yy",&clastModdate2);

		TC_write_syslog("\n Date Before Conversion :%s \n",clastModdate2);
	    if(d.day==31 || d.day==30 || d.day ==29 || d.day==28 )
		{
			// months which have 30 days in previous month
			TC_write_syslog("D Day %d \n",d.day);
			TC_write_syslog("D Month %d \n",d.month);
			//JAN, MAR, MAY, AUG, OCT
	        if(d.month== 0 || d.month==2 || d.month==4 || d.month== 6 || d.month==7 || d.month==9)
			{
	            if(d.day == 31)
	            {
	                d.day=1;
	                d.month++;
	            }
	           else if(d.day==28)
	           {
	                d.day=29;
	           }
	           else if(d.day==29)
	           	{
	           	    d.day=30;
	           	}

	           else if(d.day==30)
	          	{
	          	   d.day=31;
	          	 }

	        }

			//FEB
	        else if(d.month==1)
			{
				TC_write_syslog("\n line number 207 \n");
	            if(((d.year%4)==0 && (d.year % 100!= 0)) || (d.year%400 == 0))
				{
	            	if(d.day==29)
	            	{
	            					d.day=1;
	            					d.month++;
	            	}
	            	 else
	            	{
	            					d.day=29;
	            	}
				}
	            else
	            {
					d.day=1;
					d.month++;
	            }

	        }
			//DEC
	        else if(d.month==11)
			{

	        	 if(d.day == 31)
	        	 {

	        	      d.day=1;
	        	      d.month=0;
	        	      d.year++;
	        	      TC_write_syslog("d.day = %d",d.day);
	        	      TC_write_syslog("d.month = %d",d.month);
	        	      TC_write_syslog("d.year = %d",d.year);
	        	  }
	        	 else if(d.day==28)
	        	 {
	        		   d.day=29;
	        	 }
	        	 else if(d.day==29)
	        	 {
	        		    d.day=30;
	        	 }

	        	 else if(d.day==30)
	        	 {
	        		   d.day=31;
	        	 }
	        	 TC_write_syslog("line 283 \n %d",d.day);
	        }

			// APR, JUNE, SEPT, NOV
	        else
			{

	        	if(d.day == 30)
	        	{
	        		   d.day=1;
	        		   d.month++;
	        	}

	        	else if(d.day==28)
	        	{
	        		 d.day=29;
	        	}
	        	else if(d.day==29)
	        	{
	        		 d.day=30;
	        	}
	        }
	    }
	    else
		{
	        d.day++;
	    }
	    DATE_date_to_string(d,"%dd-%mm-%yy",&clastModdate2);
		//DATE_date_to_string(d,"%d-%b-%y",&clastModdate2);
	    TC_write_syslog("\n Day After Conversion:%s \n",clastModdate2);
	    return d;

}

bool Ng5_isPlantTZ_GT_ServTRZ (char* cpPlantStr)
{
	int 		ifail 				= 0;
	int			iPlants				= 0;
	char		**cpPrefValues 		= NULL;
	bool		isPlantTZGTServTZ	= false;

	ifail = PREF_ask_char_values(PREF_PLANT_TZ_GT_SERVTZ,&iPlants,&cpPrefValues);
					
	for(int iCnt = 0;iCnt< iPlants;iCnt++)
	{
		if(tc_strcasecmp(cpPrefValues[iCnt],cpPlantStr)==0)
		{
			isPlantTZGTServTZ = true;
		}
	}
	
	NG5_MEM_TCFREE(cpPrefValues);
	return isPlantTZGTServTZ;
}

/*Find Item Revision From BOM Line */
tag_t Ng5_findItemRevisionFromBOMLine1(tag_t bom_line)
{
    tag_t
        tItemRev = NULLTAG;
    char
        *cItemID = NULL,
        *cRevID = NULL;

    ITKCALL(AOM_ask_value_string(bom_line, BOMLIMEITEMID, &cItemID ));
    ITKCALL(AOM_ask_value_string(bom_line, BOMLINEREVID, &cRevID));
    ITKCALL( Ng5_find_rev1(cItemID, cRevID, &tItemRev));

	NG5_MEM_TCFREE(cItemID);
	NG5_MEM_TCFREE(cRevID);
    return tItemRev;
}

int Ng5_find_rev1(char *item_id, char *rev_id, tag_t *rev)
{
    int
        n = 0;
    tag_t
        *items;
    const char
        *names[1] = { ATTR_ITEM_ID },
        *values[1] = { item_id };

    ITKCALL(ITEM_find_item_revs_by_key_attributes(1, names, values, rev_id, &n, &items));
    if (n > 0)
	*rev = items[0];

	if (items) MEM_free(items);

    return 0;
}