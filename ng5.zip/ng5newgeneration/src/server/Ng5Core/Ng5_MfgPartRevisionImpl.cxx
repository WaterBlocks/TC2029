//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_MfgPartImpl
//Creation History
//Created By - Sahida Khatun  August 2022

#include <Ng5Core/Ng5_MfgPartRevisionImpl.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include <tc/tc.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <algorithm>    // std::sort
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <sstream>

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_MfgPartImpl::Ng5_MfgPartImpl(Ng5_MfgPart& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_MfgPartRevisionImpl::Ng5_MfgPartRevisionImpl( Ng5_MfgPartRevision& busObj )
   : Ng5_MfgPartRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_MfgPartImpl::~Ng5_MfgPartImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_MfgPartRevisionImpl::~Ng5_MfgPartRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_MfgPartImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_MfgPartRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_MfgPartRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// Description for the Finalize Create Input
/// @param creInput - desc for  creInput parameter
/// @return - Return desc for Initialize for Create
///
int  Ng5_MfgPartRevisionImpl::finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput )
{
    int ifail = ITK_ok;

    // Call the parent Implementation
    //ifail = super_finalizeCreateInputBase(  creInput );

    //int ifail = ITK_ok;
        int     nItems          = 0;
        int     nPrimarycount   = 0;
        int     nItemCount      = 0;
        bool	isItemIDNull	=	true;
        bool	isItemTypeNull	=	true;
        bool	isMFKNull	=	true;
        bool    isReqCustPartNull = true;
        bool    isOEMNameNull     = true;
        bool    isItemNull        = true ;
        bool    isSuffixNull      = true;
        bool    isPlantsNULL      = true;
        bool    isIDFromEngItem   = false;
        char*   cpItemID          = NULL;
        char*   cpSuffix          = NULL;
        char*   cpMfgItemID       = NULL;
        char*   cpWithSuffixID    = NULL;
        char*    cpTypeName       = NULL;
        char*    cPrimaryID       = NULL; //OF
        char*    cpOriginalID      = NULL;
        tag_t*  tEItems           = NULL;
        tag_t*  tMItems           = NULL;
        tag_t    objTypeTag       = NULLTAG;
        tag_t  tERevision         = NULLTAG;
        tag_t  tRelationType      = NULLTAG;
        tag_t*  tPrimaryObjs      = NULL;
        tag_t  tMfgItemRev        = NULLTAG;

        // Call the parent Implementation
        ifail = super_finalizeCreateInputBase(  creInput );
		if((Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_ADMIN)|| Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_DBA)))
		{
    		//Skipping all Business rules for Admin and dba Group
			TC_write_syslog("\n Skipping Checks for Admin and dba Group ");
			return ITK_ok;
		}
        // Your Implementation
        TC_write_syslog("Entering method finalizeCreateInputBase \n");

        tag_t tItemTag = NULLTAG ;
    	std::string	sItemID;

    	//std::string sItemType;
    	//std::string sMfkCounter;
    	std::string sReqCustPart;
    	std::string sOEMName;
    	std::string sSuffix ;
    	std::string sPlants ;

    	//Get the Item ID and Design Sub-type from the  Design being created
    	//creInput->getString(ATTR_ITEM_ID, sItemID, isItemIDNull);

    	creInput->getString(RQRDCUSTPARTNO,  sReqCustPart, isReqCustPartNull);
    	creInput->getString(ATTR_CUST_NAME, sOEMName, isOEMNameNull);
    	creInput->getString(SUFFIX, sSuffix, isSuffixNull);
    	creInput->getString(PLANTS, sPlants, isPlantsNULL);
    	creInput->getTag(ITEMSTAG,tItemTag,isItemNull);
    	ITKCALL(AOM_ask_value_string(tItemTag,ATTR_ITEM_ID,&cpItemID));
    	ITKCALL(AOM_ask_value_string(tItemTag,ORIGINALID,&cpOriginalID));

    	TC_write_syslog("\n Create with Customer Part? %s", sReqCustPart.c_str());
    	TC_write_syslog("\nOEM name %s", sOEMName.c_str());
    	TC_write_syslog("\nSuffix is %s", sSuffix.c_str());
    	TC_write_syslog("\nPlant is %s", sPlants.c_str());
    	TC_write_syslog("\nItem ID is %s", cpItemID);
    	TC_write_syslog("\nOriginal Item ID is %s", cpOriginalID);


    	if(tc_strlen(cpOriginalID)==0)
    	{
    		int    nEItems   = 0 ;

    		char*  cETypeName = NULL;

    		tag_t* tEItems   = NULL;
    		tag_t  tTypeTag  = NULL;
    		ITKCALL(ITEM_find(cpItemID,&nEItems,&tEItems));
    		for(int iEItemX =0 ;iEItemX< nEItems;iEItemX++)
    		{
    			tag_t tTypeTag = NULLTAG;
    			TCTYPE_ask_object_type	(tEItems[iEItemX],&tTypeTag);
    			TCTYPE_ask_name2(tTypeTag,&cETypeName);
    			if(tc_strcmp(cETypeName, ENG_PART) == 0 || tc_strcmp(cETypeName, PKG_PART) == 0 || tc_strcmp(cETypeName,RAW_MATERIAL) == 0||tc_strcmp(cETypeName, PHANTOM_PART) == 0)
    			{
    				EMH_store_error_s2(EMH_severity_error,ErrorExistingItem,cETypeName,cpItemID);
    				return ErrorExistingItem ;
    				return ITK_ok ;
    			}



    		}

    	}
       NG5_MEM_TCFREE(cpOriginalID);
       cpSuffix = (char*)MEM_alloc(sizeof(char)*(tc_strlen(sSuffix.c_str()))+1);

    	tc_strcpy(cpSuffix,sSuffix.c_str());

				
    	if((tc_strlen(cpSuffix)>0) && (!Ng5_validSpecChar(cpSuffix)))
    	{
    		EMH_store_error_s1(EMH_severity_error,ErrorSuffixInvalidChar,cpSuffix);
    		return ErrorSuffixInvalidChar ;

    	}
    	if(tc_strcmp(sReqCustPart.c_str(),YES)==0)
    	{
    		if(tc_strlen(sOEMName.c_str())==0)
    		{
    			EMH_store_error(EMH_severity_error,ErrorCodeNoOEMError );

                return ErrorCodeNoOEMError ;




    		  }


    	}
		if(sPlants.length()>0)
		{
			
			cpMfgItemID= (char*)MEM_alloc(sizeof(char)*(tc_strlen(MHYPHEN)+tc_strlen(sPlants.c_str())+tc_strlen(HYPHEN)+tc_strlen(cpItemID)+tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);
			cpWithSuffixID =(char*)MEM_alloc(sizeof(char)*(tc_strlen(cpItemID)+tc_strlen(HYPHEN)+tc_strlen(cpSuffix))+1);
			tc_strcpy(cpMfgItemID,MHYPHEN);
			tc_strcat(cpMfgItemID,sPlants.c_str());
			tc_strcat(cpMfgItemID,HYPHEN);
			std::string tempcheck ="M-";
			tempcheck.append(sPlants.c_str());
			tempcheck.append("-");
			
			if(tc_strstr(cpItemID,tempcheck.c_str()) == NULL)
			{
			   tc_strcpy(cpWithSuffixID,cpItemID);
			   if(tc_strlen(cpSuffix)>0)
			   {

				TC_write_syslog("\n 2 Suffix ID: %s\n",cpSuffix);
				  tc_strcat(cpWithSuffixID,HYPHEN);
				  tc_strcat(cpWithSuffixID,cpSuffix);

				}
				tc_strcat(cpMfgItemID,cpWithSuffixID);
				TC_write_syslog("\n Manufacturing ID 11111: %s\n", cpMfgItemID);
				if(tc_strlen(cpMfgItemID)>25)
				{
					EMH_store_error_s1(EMH_severity_error,ErrorLongItemID,cpWithSuffixID );
					 return ErrorLongItemID ;
				  }
				ITKCALL(ITEM_find(cpItemID,&nItems,&tEItems))



				//ITKCALL(ITEM_find(cpItemID,&nItems,&tEItems));
				for(int iEIx=0;iEIx <nItems;iEIx++)
				{
							TCTYPE_ask_object_type(tEItems[iEIx],&objTypeTag);
							TCTYPE_ask_class_name2(objTypeTag,&cpTypeName);
							if(Ng5_validType2Clone(cpTypeName)&& tc_strcmp(cpTypeName,MFGPART)!=0 )
							{
								isIDFromEngItem = true;
								ITKCALL(Ng5_getRev2CopyFrom(tEItems[iEIx],&tERevision));
								ITKCALL(GRM_find_relation_type(HASENGPART2MFGPARREV,&tRelationType));
								ITKCALL(GRM_list_primary_objects_only(tERevision,tRelationType,&nPrimarycount,&tPrimaryObjs));
								for(int iPx=0 ; iPx < nPrimarycount;iPx++)
								{
								ITKCALL(AOM_ask_value_string( tPrimaryObjs[iPx], ATTR_ITEM_ID, &cPrimaryID));
								if(tc_strcmp(cPrimaryID,cpMfgItemID)==0)
								{

										   EMH_store_error_s2(EMH_severity_error,ErrorSameMfgID,sPlants.c_str(),cpMfgItemID);

										   return ErrorSameMfgID ;
								}
								else
								{
									char* cPrimaryOEM           = NULL;
									char* cPCreateWithCustomer  = NULL;
									char* cPrimaryPlant         = NULL;
									char* cPrimarySuffix        = NULL;


									ITKCALL(AOM_ask_value_string( tPrimaryObjs[iPx], ATTR_CUST_NAME, &cPrimaryOEM));
									ITKCALL(AOM_ask_value_string( tPrimaryObjs[iPx], RQRDCUSTPARTNO, &cPCreateWithCustomer));
									ITKCALL(AOM_ask_value_string( tPrimaryObjs[iPx], PLANTS, &cPrimaryPlant));
									ITKCALL(AOM_ask_value_string( tPrimaryObjs[iPx], SUFFIX, &cPrimarySuffix ));

									    	TC_write_syslog("\n Primary : OEM name %s", cPrimaryOEM);
									    	TC_write_syslog("\n Primary: Suffix is %s", cPrimarySuffix );



	                                if((tc_strcmp(cPrimaryOEM,sOEMName.c_str())==0) && (tc_strcmp(cPrimaryPlant,sPlants.c_str())==0) && (tc_strcmp(cPCreateWithCustomer,YES)==0)&& (tc_strcmp(cPrimarySuffix,cpSuffix)==0))
	                                {
	                                	//ITKCALL(AOM_ask_value_string( tPrimaryObjs[iPx], ATTR_PLANT_CODE, &cPrimaryPlant));
	                                	EMH_store_error_s2(EMH_severity_error,ErrorSameMfgID,sPlants.c_str(),cPrimaryID);

	                                	return ErrorSameMfgID ;

	                                }
									else if(tc_strlen(cPrimaryOEM)>0 && tc_strlen(sOEMName.c_str())==0 && (tc_strcmp(cPrimaryPlant,sPlants.c_str())==0))
									{
									   	EMH_store_error_s2(EMH_severity_error,ErrorSameMfgID,sPlants.c_str(),cPrimaryID);

	                                	return ErrorSameMfgID ;
									}
	                                NG5_MEM_TCFREE(cPrimaryOEM);
	                                NG5_MEM_TCFREE(cPCreateWithCustomer);
	                                NG5_MEM_TCFREE(cPrimaryPlant);
	                                NG5_MEM_TCFREE(cPrimarySuffix);


								}

								}
							}



				}
				if(tc_strlen(sOEMName.c_str())>0)
				{
					isIDFromEngItem = true;
				}
				ITKCALL(ITEM_find(cpMfgItemID,&nItems,&tMItems))

				for(int iMIx=0;iMIx <nItems;iMIx++)
				{
						TCTYPE_ask_object_type(tMItems[iMIx],&objTypeTag);
						TCTYPE_ask_class_name2(objTypeTag,&cpTypeName);

						if(tc_strcmp(cpTypeName,MFGPART)==0)
						{



							   EMH_store_error_s2(EMH_severity_error,ErrorSameMfgID,sPlants.c_str(),cpMfgItemID);

							   return ErrorSameMfgID ;
						}





				}

				if(!isIDFromEngItem && !Ng5_MfgPartRevisionImpl::Ng5_validItemID(cpItemID))
				 {

					EMH_store_error_s1(EMH_severity_error,ErrorIDNotAlphaNumeric,cpItemID);

					return ErrorIDNotAlphaNumeric ;
				   }


			}
		}
    	 NG5_MEM_TCFREE(cpItemID);
    	 NG5_MEM_TCFREE(cpSuffix);
    	 NG5_MEM_TCFREE(cpTypeName);
    	 NG5_MEM_TCFREE(cPrimaryID);
		NG5_MEM_TCFREE(tMItems);
    // Your Implementation
    	TC_write_syslog("Exiting method finalizeCreateInputBase \n");

    return ifail;
}


//Function to validate special characters in Suffix
logical Ng5_MfgPartRevisionImpl::Ng5_validItemID(char* cpSuffix)
{
	logical validSpecChar = false;

			int     iValues       = 0;
			char* cpSpecChars   = NULL;

			 ITKCALL(PREF_ask_char_value(MFG_SPEC_CHAR_PREF,0,&cpSpecChars));

				for(int idx=0;idx<tc_strlen(cpSuffix);idx++)
				{
					if(!isalnum(cpSuffix[idx]) or isspace(cpSuffix[idx]))
					{
						int isMatched = 0;
						for(int iValx=0;iValx<tc_strlen(cpSpecChars);iValx++)
						{
		                  if(cpSuffix[idx]==cpSpecChars[iValx] or cpSuffix[idx]==' ')
		                  {

							isMatched =1;

							break;
		                  }

						}
						if(isMatched >0)
						{
							validSpecChar = true;

						}
						else
						{
							validSpecChar = false;
							return validSpecChar;
						}
					}
					else
					{
						validSpecChar = true;
					}
				}

				return validSpecChar ;
}
