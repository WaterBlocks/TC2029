/*********************************************************************************************
** File Name:         Ng5_DeleteOldNXJTNR.cxx
**
** File Description:
*   This file contains the implementation for the Extension Ng5_DeleteOldNXJTNR
**
** History:
**   mm/dd/yyyy      Name                  Comments
**   ----------  ------------- -------------------------
**   06/006/2017  Siva Sundararaj      Initial Version
**                                        Added Extension is added on Import file post action for Direct Model Dataset.
**                                        For Revisions having UGMaters Dataset in it, this extension checks Named references of Direct Model and if old named Reference is present **                                      with name ItemId_RevID, that named reference file is removed.
**    1/08/2018    Pradnya Hingankar        1. Added detailed description of extension
**                                        2. Added detailed Header to Functions
**                                        3. Replaced MEM_free with MEM_TCFREE
**    17/10/2018     Manjula Tirunagari        Added code for handling multiple named references
**
*********************************************************************************************/

#include <Ng5Core/Ng5_DeleteOldNXJTNR.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdarg.h>
#include <string>
#include <sstream>
#include <fclasses/tc_string.h>
#include <Ng5Core/Ng5_CommonUtils.hxx>
using namespace ng5newgeneration;

/**  
 * Function Name      :   Ng5_CheckLatestBasedOnDateSeconds
 * Description        :   This function is to check the latest modified Named reference and 
 *                        returns flag = true indicating Second object is latest.
 * Parameters         :   tFirstNamedRef            first Object Tag (I)
 *                        tSecNamedRef              second Object Tag (I)
 *                        char* cpDateAttribute     date property to compare first & second Object (I)
 * Return Type        :   logical
 * History            :
 * Date             |      AGM   |    Name                  |    Comments
 * ------------------------------------------------------------------------------------------------
 *  17-Oct-2018     |            |    Manjula Tirunagari    | This function finds the latest modified Named Reference
 *
 */
logical Ng5_CheckLatestBasedOnDateSeconds(tag_t tFirstNamedRef,    tag_t tSecNamedRef, char* cpDateAttribute)
{

date_t  dSecond_date=NULLDATE; 
date_t  dfirst_date=NULLDATE; 

logical lFlag = false;
TC_write_syslog("\n Entering Ng5_CheckLatestBasedOnDateSeconds ");

if((tFirstNamedRef != NULLTAG) &&(cpDateAttribute!= NULL)&& (tSecNamedRef != NULLTAG))
{

    ITK(AOM_ask_value_date(tFirstNamedRef, cpDateAttribute, &dfirst_date));

    ITK(AOM_ask_value_date(tSecNamedRef, cpDateAttribute, &dSecond_date));
    
    if((dfirst_date.year!=0) && (dSecond_date.year!= 0))
    {
        /*checking tFirstNamedRef's date with tSecNamedRef's date*/                
        if(dfirst_date.year < dSecond_date.year)
        {
            lFlag = true;
        }
        else if (dfirst_date.year == dSecond_date.year)
        {
            if(dfirst_date.month < dSecond_date.month )
            {
                lFlag = true;
            }
            else if(dfirst_date.month == dSecond_date.month )
            {
                if(dfirst_date.day < dSecond_date.day)
                {
                    lFlag = true;
                }
                else if(dfirst_date.day == dSecond_date.day)
                {    
                    if(dfirst_date.hour < dSecond_date.hour)
                    {
                        lFlag = true;
                    }
                    else if(dfirst_date.hour == dSecond_date.hour)
                    {
                        if(dfirst_date.minute < dSecond_date.minute)
                        {
                            lFlag = true;
                        }
                        else if(dfirst_date.minute==dSecond_date.minute)
                        {
                            if(dfirst_date.second <= dSecond_date.second)
                            {
                                lFlag = true;
                            }
                        
                        }
                    }
                }
            }    
        }

    }
}
TC_write_syslog("\n Exiting Ng5_CheckLatestBasedOnDateSeconds ");
return lFlag;
}
/**
 * Function Name     :    Ng5_addNametoJTNamedRef
 * Description       :    This function will add the name to JT named reference (with out mfk - ItemId_revID_Name.jt, if mfk counter available then ItemId_mfk_revID_Name.jt )
 * History           :
 * Date             |      AGM   |    Name               |    Comments
 * ------------------------------------------------------------------------------------------------
 *  12-Jan-2023     |            |    Dharmanna Jugal    | add the name to DirectModel named Reference
 */

int Ng5_addNametoJTNamedRef(tag_t tItemRev, char* cpObjType, tag_t tpNamedRefs)
{
	char    *cmfkCounter    =    NULL;
	char    finalName[256+1]    =    "";

	TC_write_syslog("\n Entering Ng5_addNametoJTNamedRef");

	    char    *cpItemId    =    NULL;
	    ITK(AOM_ask_value_string(tItemRev, ATTR_ITEM_ID, &cpItemId));

	    if(NULL != cpItemId)
	    {
	        char    *cpRevId    =    NULL;
	        ITK(AOM_ask_value_string(tItemRev, ATTR_ITEM_REV_ID, &cpRevId));
	        if(NULL != cpRevId)
	        {
	            char    *cpRevName    =    NULL;
	            char    *cpName    =    NULL;
	            tag_t  tItemtag =NULLTAG;
	            ITK(AOM_ask_value_string(tItemRev, OBJECT_NAME, &cpRevName));
	            if(NULL != cpRevName)
	            {
	            	//this fuction will convert special characters to under score
	            	cpName = Ng5_CommonUtils::convertSpecialCharacters(cpRevName);

					if((tc_strcmp(cpObjType, ITEM_EXTERNAL_PART_REVISION)==0) || (tc_strcmp(cpObjType, ITEM_SUPPORT_DESIGN_REVISION)==0) )
					{
						ITK( ITEM_ask_item_of_rev(tItemRev,&tItemtag));
						ITK(AOM_ask_value_string(tItemtag, ATTR_MFK_COUNTER, &cmfkCounter));
					}

					if(cmfkCounter != 0)
					{
						sprintf(finalName, "%s_%s_%s_%s.jt", cpItemId,cmfkCounter,cpRevId,cpName);
					}

					else
					{
						sprintf(finalName, "%s_%s_%s.jt", cpItemId,cpRevId,cpName);
					}

					TC_write_syslog(" \n finalName  : %s\n",finalName);
					ITK(AOM_refresh(tpNamedRefs, TRUE));
					ITK(IMF_set_original_file_name2(tpNamedRefs, finalName));
					ITK(AOM_save_with_extensions(tpNamedRefs));
					ITK(AOM_refresh(tpNamedRefs, FALSE));

                }
                MEM_TCFREE(cpRevName);
            }
            MEM_TCFREE(cpRevId);
        }
        MEM_TCFREE(cpItemId);

        TC_write_syslog("\n Exiting Ng5_addNametoJTNamedRef");
  return ITK_ok;


}

/**
 * Function Name     :    Ng5_removeOldNamedRef
 * Description       :    This function checks the named references of dataset given in input. If Dataset contains Named reference file having name as ItemID_RevID then that named
 *                        reference is removed from the dataset
 * Parameters        :    tDataset    Tag of Dataset (I)
 *                        tItemRev Tag of Item Revision (I)
 * Return Type       :     int
 *
 * History           :
 * Date             |      AGM   |    Name               |    Comments
 * ------------------------------------------------------------------------------------------------
 *  06-Jun-2017     |            |    Siva Sundararaj    | This function removes old Named Refs
 *  01-Aug-2018     |            |   Pradnya Hingankar   | Added this function header
 *  17-Oct-2018     |            |   Manjula Tirunagari  | Modified the code for handling multiple references
 *
 */
int Ng5_removeOldNamedRef( tag_t tDataset, tag_t tItemRev, char* cpObjType)
{

	    int        retCode            = ITK_ok;
		int        iNamedRefs        =    0;
		tag_t    *tpNamedRefs    =    NULL;

	    TC_write_syslog("\n Entering Ng5_removeOldNamedRef");
		ITK( AE_ask_dataset_named_refs(tDataset, &iNamedRefs, &tpNamedRefs) );

                if(NULL != tpNamedRefs)
                {
                    if(iNamedRefs == 1)
                    {
                        if(NULLTAG != tpNamedRefs[0])
                        {
                            char    *cpRefName    =    NULL;
                            AE_reference_type_t    sRefType;
                            tag_t    tRefObj    =    NULLTAG;                            

                            ITK(AE_find_dataset_named_ref2(tDataset, 0, &cpRefName, &sRefType, &tRefObj));    

					if(NULL != cpRefName)
					{
						Ng5_addNametoJTNamedRef (tItemRev,cpObjType,tpNamedRefs[0]);
						MEM_TCFREE(cpRefName);
					}
				}
			}
			else if(iNamedRefs > 1)
			{
				char    *cpRefName    =    NULL;
				AE_reference_type_t    sRefType;
				tag_t    tRefObj    =    NULLTAG;
				logical lFlag = false;

				tag_t latestNamedRefTag = NULLTAG;

				latestNamedRefTag= tpNamedRefs[iNamedRefs-1];

				for (int i = 0; i < iNamedRefs; i++)
				{
					lFlag = false;
					char    *cpOrigFileName    =    NULL;
					ITK(AOM_ask_value_string(tpNamedRefs[i], ATTR_ORIG_FILE_NAME, &cpOrigFileName));

					lFlag = Ng5_CheckLatestBasedOnDateSeconds(latestNamedRefTag,tpNamedRefs[i], ATTR_LAST_MODIFIED_DATE);
					if(lFlag == true)
					{
						latestNamedRefTag = tpNamedRefs[i];
					}
				}

				for(int iRef=0; iRef<iNamedRefs; iRef++)
				{
					if(tpNamedRefs[iRef] != latestNamedRefTag)
					{
						ITK(AE_find_dataset_named_ref2(tDataset, iRef, &cpRefName, &sRefType, &tRefObj));
						char    *cpOrigFileName    =    NULL;
						if(NULL != cpRefName)
						{
							ITK(AOM_ask_value_string(tpNamedRefs[iRef], ATTR_ORIG_FILE_NAME, &cpOrigFileName));
						}

						ITK(AE_remove_dataset_named_ref_by_tag2(tDataset, cpRefName, tpNamedRefs[iRef]));
						AE_save_myself(tDataset);
						MEM_TCFREE(cpOrigFileName);
						MEM_TCFREE(cpRefName);
					}

				}
				Ng5_addNametoJTNamedRef (tItemRev,cpObjType,latestNamedRefTag);

			}
			MEM_TCFREE(tpNamedRefs);

}

    TC_write_syslog("\n Exiting Ng5_removeOldNamedRef");

    return retCode;
}

/**
 * Function Name     :    Ng5_DeleteOldNXJTNR
 * Description        :    For Revisions having UGMaters Dataset in it, this extension checks Named references of Direct Model and if old named Reference is present with name
 *                        ItemId_RevID, that named reference file is removed.
 *                         reference is removed from the dataset
 * Parameters        :    METHOD_message_t * msg    (I)
 *                         va_list args (I)
 * Return Type        :     int
 *
 * History            :
 * Date                |      AGM        |    Name                  |    Comments
 * ------------------------------------------------------------------------------------------------
 *  06-Jun-2017     |            |    Siva Sundararaj        | This function removes old Named Refs
 *  01-Aug-2018     |            |   Pradnya Hingankar   | Added this function header
 *
 */
int Ng5_DeleteOldNXJTNR( METHOD_message_t * msg, va_list args )
{
    int        retCode            = ITK_ok;
    TC_write_syslog("\n Entering Ng5_DeleteOldNXJTNR");

    va_list largs;
    va_copy(largs,args);
    tag_t        tDataset = va_arg(largs, tag_t);

    TC_write_syslog("\n tDataset: %d", tDataset);
    if (NULLTAG != tDataset)
    {
        logical        lDatVerdict    =    false;
        ITK( AM_check_privilege (tDataset, ACCESS_WRITE, &lDatVerdict) ); //Allow only if the logged in user has write access to Secondary object

        TC_write_syslog("\n lDatVerdict: %d", lDatVerdict);

        if(true == lDatVerdict)
        {
            tag_t    tDatType    =    NULLTAG;
            ITK( TCTYPE_ask_object_type(tDataset, &tDatType) );

            TC_write_syslog("\n tDatType: %d", tDatType);
            if(NULLTAG != tDatType)
            {
                char    *cpDatTypeName    = NULL;
                ITK( TCTYPE_ask_name2 ( tDatType, &cpDatTypeName) ); // Get Dataset type name

                if(NULL != cpDatTypeName)
                {
                    TC_write_syslog("\n cpDatTypeName: %s", cpDatTypeName);
                    if(tc_strcmp (cpDatTypeName, DATASET_DIRECTMODEL ) == 0)
                    {
                        //Find the Item Revision to which this Dataset is attached to
                        tag_t tRendRel             = NULLTAG;
                        ITK (GRM_find_relation_type (REL_RENDERING, &tRendRel));

                        if(NULLTAG != tRendRel)
                        {
                            int        iPrimary        =    0;
                            tag_t    *tpPrimaryObjs    =    NULL;

                            ITK (GRM_list_primary_objects_only (tDataset, tRendRel, &iPrimary, &tpPrimaryObjs ));

                            if (( NULL != tpPrimaryObjs) && ( iPrimary > 0 ))
                            {
                            TC_write_syslog("\n iPrimary= %d \n", iPrimary);
                            
                              for (int i =0; i< iPrimary; i++)
                                {
                                  tag_t    tPrimType    =    NULLTAG;
                                  ITK( TCTYPE_ask_object_type(tpPrimaryObjs[i], &tPrimType) );
                                  char    *cpPrimObjTypeName    = NULL;
                                  if(NULLTAG != tPrimType)
                                  {                    
                                    ITK( TCTYPE_ask_name2 ( tPrimType, &cpPrimObjTypeName) );
                                  }
                                  
                                  //Check if the Primary Object is of Types Ng5_EngPartRevision/Ng5_NonEngPartRevision/Ng5_SupportPartRevision/Ng5_NonEngSupPrtRevision
                                  if(NULLTAG != tpPrimaryObjs[i]  && ( (tc_strcmp(cpPrimObjTypeName, ITEM_ENGINEERED_PART_REVISION)==0) 
                                      || (tc_strcmp(cpPrimObjTypeName, ITEM_EXTERNAL_PART_REVISION)==0) || (tc_strcmp(cpPrimObjTypeName, ITEM_SUPPORT_DESIGN_REVISION)==0)  
                                        ||    (tc_strcmp(cpPrimObjTypeName, ITEM_EXTERNAL_SUPPORT_DESIGN_REVISION)==0) ))
                                      
                                    {
                                        //Get the secondary of Item Revision and allow only if there is a UGMASTER
                                        tag_t tSpecRel             = NULLTAG;
                                        ITK (GRM_find_relation_type (REL_SPECIFICATION, &tSpecRel));

                                        if(NULLTAG != tSpecRel)
                                        {
                                            int        iSecondary            =    0;
                                            tag_t    *tpSecondaryObjs    =    NULL;

                                            ITK (GRM_list_secondary_objects_only (tpPrimaryObjs[i], tSpecRel, &iSecondary, &tpSecondaryObjs ));

                                            if (( NULL != tpSecondaryObjs) && ( iSecondary > 0 ))
                                            {                                    
                                                //Scan through each Secondary object
                                                for(int iSec=0; iSec<iSecondary; iSec++)
                                                {
                                                    if(NULLTAG != tpSecondaryObjs[iSec])
                                                    {
                                                        //Allow only if the logged in user has WRITE access to the Secondary Object
                                                        logical        lSecVerdict    =    false;
                                                        ITK( AM_check_privilege (tpSecondaryObjs[iSec], ACCESS_WRITE, &lSecVerdict) );
                                                        

                                                    if(true == lSecVerdict)
                                                    {
                                                        //Find the Object Type of Secondary Object
                                                        tag_t    tSecType    =    NULLTAG;
                                                        ITK( TCTYPE_ask_object_type(tpSecondaryObjs[iSec], &tSecType) );

                                                            if(NULLTAG != tSecType)
                                                            {
                                                                char    *cpSecObjTypeName    = NULL;
                                                                ITK( TCTYPE_ask_name2 ( tSecType, &cpSecObjTypeName) ); // Get Secondary object Type name

                                                                if(NULL != cpSecObjTypeName)
                                                                {
                                                                    //Proceed only if the type is UGMASTER
                                                                    if(tc_strcmp (cpSecObjTypeName, DATASET_UGMASTER ) == 0)
                                                                    {
                                                                        Ng5_removeOldNamedRef(tDataset, tpPrimaryObjs[i],cpPrimObjTypeName);
                                                                        MEM_TCFREE(cpSecObjTypeName);
                                                                        break;
                                                                    }
                                                                    MEM_TCFREE(cpSecObjTypeName);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                MEM_TCFREE(tpSecondaryObjs);
                                            }
                                        }
                                    }
                                }
                                MEM_TCFREE(tpPrimaryObjs);
                            }
                        }
                    }
                    MEM_TCFREE(cpDatTypeName);
                }
            }
        }
    }

    TC_write_syslog("\n Exiting Ng5_DeleteOldNXJTNR");
    return retCode;

}
