/*********************************************************************************************
** File Name:         Ng5_rHasSSOPackage_Create_PreCondition.hxx
**
** File Description:
*   This file contains the declaration for the Extension Ng5_rHasSSOPackage_Create_PreCondition
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   29/07/2020  Monali Nakil      Initial Version
								   Added implementation for Defect 397007: SSO Package creation possible even without assignment to Project


*********************************************************************************************/

#ifndef NG5_RHASSSOPACKAGE_CREATE_PRECONDITION_HXX
#define NG5_RHASSSOPACKAGE_CREATE_PRECONDITION_HXX
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <tccore/method.h>
#include <ug_va_copy.h>
#include <tccore/item.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/project.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <sa/group.h>
#include <sa/groupmember.h>
#include <sa/user.h>
#include <sa/role.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <Ng5Core/libng5core_exports.h>



#define Ng5_launchprg_masterprg					"ng5_launchprg_masterprg"
#define ITEM_ID									"item_id"
#define OBJECT_TYPE								"object_type"
#define LAUNCHPRG								"Ng5_LaunchPrg"

#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_rHasSSOPackage_Create_PreCondition(METHOD_message_t* msg, va_list args);

static int validate_sso_pkg( const tag_t ssoPkgRev, const tag_t tLaunchPrg );

                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_RHASSSOPACKAGE_CREATE_PRECONDITION_HXX
