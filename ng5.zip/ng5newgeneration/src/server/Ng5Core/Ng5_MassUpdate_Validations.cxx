//@<COPYRIGHT>@
//==================================================
//Copyright $2023.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_MassUpdate_Validations
 *
 */
#include <Ng5Core/Ng5_MassUpdate_Validations.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include <tc/tc.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>


int Ng5_MassUpdate_Validations( METHOD_message_t * /*msg*/, va_list args)
{
	int ifail = ITK_ok;
	tag_t tMassUpdateRev=NULLTAG;
	char* sMassUpdateType = NULL;
	date_t dtStartDate = NULLDATE;
		date_t dtEndDate = NULLDATE;
		int 				result 									= 2;
 
	tMassUpdateRev = va_arg(args, tag_t);

	TC_write_syslog("\n entering Mass Update Validation \n");

			ITK(AOM_ask_value_string(tMassUpdateRev,NG5_MASS_UPDATE_TYPE,&sMassUpdateType));
			ITK(AOM_ask_value_date(tMassUpdateRev, NG5_START_EFFECTIVITY, &dtStartDate));
			ITK(AOM_ask_value_date(tMassUpdateRev, NG5_END_EFFECTIVITY, &dtEndDate));
			if(tc_strcmp(sMassUpdateType,NG5_ADD)==0 || tc_strcmp(sMassUpdateType,NG5_ADD_WITH_SIBLING)==0 ||tc_strcmp(sMassUpdateType,NG5_REPLACE)==0 || tc_strcmp(sMassUpdateType,NG5_REMOVE)==0|| tc_strcmp(sMassUpdateType,NG5_REMOVE_WITH_SIBLING)==0|| tc_strcmp(sMassUpdateType,NG5_MODIFY)==0)
			{
					
					if(!DATE_IS_NULL(dtStartDate)==1 && !DATE_IS_NULL(dtEndDate)==1)
					{

						ifail=POM_compare_dates(dtStartDate,dtEndDate,&result);
						
						if(result==1)
						{
							TC_write_syslog("\n inside if line56 \n");

							EMH_store_initial_error_s1(EMH_severity_error,NG5_START_END_EFFECTIVITY," ");
							return NG5_START_END_EFFECTIVITY ;
						}
					}
			}


			TC_write_syslog("\n existing Mass Update Validation \n");
MEM_free(sMassUpdateType);
 return ifail;


}
