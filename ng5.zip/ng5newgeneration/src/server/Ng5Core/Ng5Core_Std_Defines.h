/*********************************************************************************************
** File Name:        Ng5Core_Std_Defines.h

**
** File Description: This file contains the #defines, macros and error codes for the JCI project
**
**
** History			:
** 		Date	|  	AGM		|	Name          	|	Comments
** ------------------------------------------------------------------------------------------------
**  12/01/2016	|			|Sree Harsha C		|	Initial Version
**
**  12/09/2016 	|			|Pradnya Hingankar	|	Added constants for Tooling Maturity - Use case 2745
**
**  07/31/2017	|			|Rampaul Jayapaul	|	Added constants for Drawing Rev Property - Defect 1610
**
**  01/08/2017	|			|Meenaksi			|	Added constants for Supplier part form
**
**  01/08/2018	|			|Arjun				|	1. updated the history with new format.
**  			|			|					|	2. Added constants for type_string Property - AGM#
**
**	01/08/2018	|			|Pradnya Hingankar	|	Added constant ATTR_OWNING_SITE for owning site attribute

**	01/08/2018	|			|Manjula Tirunagari	|	Added Macro NG5_MEM_TCFREE_ARRAY for freeing char ** and added constants 

**	17/10/2018	|			|Manjula Tirunagari	|	Added constant ATTR_LAST_MODIFIED_DATE for last modified date
**
**  04/15/2020  |           |Padma Cherukumilli |   Added constants for ICE Part Form
**  07/03/2022  |           |Jogesh Fulsunge    |   Added Error code constant for Multiple SSO Creation
****  14/04/2022  |			|Jogesh Fulsunge	|	Added Constants RELATED_ENGG_PARTS
**  05/17/2022  |           | Sahida Khatun     |   Modified for Change Management Improvement Revise Scenario Change
**  7/20/2022    |          | Sahida Khatun     |   Mdified for EBOMMBOM  Cloning User stories (US#266216,US#262218,US#262217,US#262220)
*********************************************************************************************/

#ifdef __cplusplus
extern "C"
{
#endif
	#include <unidefs.h>
	#include <epm/epm_toolkit_tc_utils.h>
	#include <res/res_itk.h>
	#include <sa/tcfile_cache.h>
	#include <sa/tcvolume.h>
	#include <tc/tc.h>
	#include <tccore/item.h>
	#include <tccore/aom.h>
	#include <base_utils/Mem.h>
	#include <sa/sa.h>
	#include <tc/emh.h>
	#include <property/nr.h>
	#include <property/nr_errors.h>
	#include <server_exits/user_server_exits.h>
	#include <server_exits/user_server_exits.h>
	#include <tccore/custom.h>
	#include <ss/ss_const.h>
	#include <lov/lov.h>
	#include <fclasses/tc_string.h>
	#include <tccore/item.h>
	#include <sa/am.h>
	#include <tccore/workspaceobject.h>
	#include <tccore/aom_prop.h>
	#include <me/me.h>
	#include <tccore/grm.h>
	#include <user_exits/epm_toolkit_utils.h>
	#include <property/nr.h>
	#include <tccore/part.h>
	#include <tccore/uom.h>
	#include <tc/tc_startup.h>
	#include <tc/tc_macros.h>
	#include <tc/emh.h>
	#include <pom/pom/pom.h>
	#include <fclasses/tc_string.h>
    #include <user_exits/epm_toolkit_utils.h>
	#include <stdio.h>
	#include <tc/folder.h>
	#include <tccore/item.h>
	#include <tccore/grm.h>
	#include <ae/ae.h>
	#include <string.h>
	#include <tccore/item_msg.h>
	#include <tc/preferences.h>
	#include <common/emh_const.h>
	#include <tccore/aom.h>
	#include <tccore/aom_prop.h>
	#include <itk/bmf.h>
	#include <user_exits/user_exits.h>
	#include <tc/tc_util.h>
	#include <ict/ict_userservice.h>
	#include <tccore/tctype.h>
	#include <time.h>
	#include <itk/te.h>
	#include <ps/ps.h>
	#include <tccore/project.h>
	#include <bom/bom.h>
	#include <sa/site.h>
	#include <publication/iir_itk.h>
	#include <publication/ods_errors.h>
	#include <publication/ods_itk.h>
	#include <ae/datasettype.h>
	#include <cfm/cfm.h>
	#include <ae/dataset.h>
	#include <ecm/ecm.h>
	#include <epm/epm.h>
	#include <epm/cr_action_handlers.h>
    #include <epm/epm_task_template_itk.h>

	#include <epm/epm_errors.h>
	#include <sa/user.h>
	#include <sa/role.h>
	#include <sa/group.h>
	#include <sa/groupmember.h>
	#include <ss/ss_errors.h>
	#include <stdlib.h>
	#include <user_exits/epm_action_handlers.h>
	#include <user_exits/epm_rule_handlers.h>
	#include <user_exits/user_exit_msg.h>
	#include <pie/pie.h>
	#include <tccore/workspaceobject.h>
	#include <tccore/releasestatus.h>
	#include <form/form.h>
	#include <property/prop.h>
  	#include <tccore/tctype_msg.h>
    #include <fclasses/tc_date.h>


#ifdef __cplusplus
} /* closing brace for extern "C" */
#endif




#define NG5_MEM_TCFREE(pMem) \
{\
	if (pMem != NULL) \
{\
	MEM_free(pMem);\
	pMem = NULL;\
}\
}


#define NG5_MEM_TCFREE_ARRAY(pMem , length) \
 {\
	if ( pMem != NULL ) \
 {\
 for (int i=0; i<length; i++) \
 {\
	 if ( pMem[i] != NULL ) \
	 MEM_free((void*) pMem[i]); \
 }\
 MEM_free(pMem); \
 pMem = NULL; \
 }\
}
 
#define NG5_ITK_CALL(x) {                                                 \
    if( (iFail = (x)) != ITK_ok)                           \
    {                                                                 \
        char  itk_error_message[256], *itk_error_string=NULL;         \
        EMH_ask_error_text (iFail, &itk_error_string);     \
        sprintf (itk_error_message,				      \
         "ERROR: %d ERROR MSG: %s.\nFunction: %s FILE: %s LINE: %d\n",\
         iFail, itk_error_string,#x, __FILE__, __LINE__);  \
        printf("%s",itk_error_message);\
        TC_write_syslog(itk_error_message);\
        if(itk_error_string) MEM_free(itk_error_string); \
     }								      \
}

#define NG5_ITK_CALL_THROW(x) {                                                 \
    if( (iFail = (x)) != ITK_ok)                           \
    {                                                                 \
        char  itk_error_message[256], *itk_error_string=NULL;         \
        EMH_ask_error_text (iFail, &itk_error_string);     \
        sprintf (itk_error_message,				      \
         "ERROR: %d ERROR MSG: %s.\nFunction: %s FILE: %s LINE: %d\n",\
         iFail, itk_error_string,#x, __FILE__, __LINE__);  \
        printf("%s",itk_error_message);\
        TC_write_syslog(itk_error_message);\
        if(itk_error_string) MEM_free(itk_error_string); \
        throw iFail;   \
     }								      \
}

/*MEM_TCFREE
* Function which used to free the memory of any variable type
* @note
* @param[in]  pMem        variable name which need to be memory free in code
* Creator History:
* Siemens		Initial Creation         Dec 6th,2012.
*/
#define MEM_TCFREE(pMem) {\
    if (pMem != NULL) {\
    MEM_free(pMem);\
    pMem = NULL;\
        }\
        }

#define PROGRAM    "ng5_launchprg_masterprg"
#define NAME_SEPERATOR " / "
#define MODEL_YR "ng5_oem_model_year"
#define OEM_NAME "ng5_oem_name"
#define OEM_ENV  "ng5_oem_env"
#define NX_ENV  "fnd0Environment"
#define DC_LAUNCHST_RGN "ng5_dc_launch_site_rgn"
#define DC_NAME "ng5_dc_name"
#define MODEL_CODE "ng5_oem_model_code"
#define VEHICLE_NAME "ng5_oem_vehicle_name"
#define PRODUCT_LINE "ng5_product_line"
#define PRODUCT_AREA "ng5_product_area"
#define KISS_COMMENT "ng5_kiss_comment"
#define REV_ID "item_revision_id"
#define ARRAY_SEPERATOR ","
#define NG5_PROGRAM_PLMXML_EXPORT_LOC        "Ng5_Program_Plmxml_Export_Loc"
#define Relation_Type 		"Ng5_ProgToProject"
#define NG5_MASTERPROGRAM_PLMXML_TRANSFER_MODE     "Ng5_MasterPrg_Plmxml_Transfer_Mode"
#define NG5_LAUNCH_PRG_REVISION  "Ng5_LaunchPrgRevision"
#define NG5_MASTER_PRG_REVISION	  "Ng5_MasterPrgRevision"
#define NG5_PROGRAM_PLMXML_EXPORT_CHECK "Ng5_Program_Plmxml_Export_Check"
#define PREF_PROGRAM_SECURITY "Ng5_ProgramSecurity"
#define CMImplements_Type 		"CMImplements"
#define CopyParticipant 		"ng5_copy_cr_participant"
#define PRIMARY_OBJECT			"primary_object"
#define SECONDARY_OBJECT		"secondary_object"
#define OBJECT_NAME				"object_name"
#define DATASET                 "Dataset"
#define DATASET_CATPART                "CATPart"
#define DATASET_CATPRODUCT             "CATProduct"
#define DATASET_CATDRAWING             "CATDrawing"
#define DATASET_UGMASTER		       "UGMASTER"
#define DATASET_UGPART                 "UGPART"
#define NAMEDREF_IMANFILE				"ImanFile"
#define DATASET_DIRECTMODEL				"DirectModel"
#define REL_CATIAV5MML			      "catiaV5_MML"
#define REL_CATIAV5MMLASSY		      "catiaV5_MMLAssy"
#define REL_CATIAV5DWGLINK		      "catiaV5_DWGLink"
#define REL_ENGDWGREL		      	      "Ng5_rHasEngDwgRel"
#define REL_EXTDWGREL		      	      "Ng5_rHasExtDwgRel"
#define REL_ICEPARTFORM              "Ng5_rHasICEPartForm"
#define REL_MATLMSTR              "Ng5_rHasMatlMstr"
#define REL_SPECIFICATION		      "IMAN_specification"
#define REL_REFERENCE		      		"IMAN_reference"
#define REL_RENDERING		      		"IMAN_Rendering"
#define REL_MANIFESTATION	      		"IMAN_manifestation"
#define REL_NX_TCDWGUSING				"TC_DrawingUsing"
#define STRUCTURE_REVISION				"structure_revisions"
#define MIRRORED_HANDED				    "Ng5_rHasMirroredHandedRel"
#define ATTR_MM_TRANS				    "ng5_mm_transferred"
#define ATTR_PLANT_CODE	                "ng5_plant_code"
#define ATTR_REQ_CUSTPART               "n5_reqcustpart"
#define ATTR_CUST_NAME                  "ng5_customer"

#define ITEM_ENGINEERED_DRAWING_REVISION      "Ng5_DrawingRevision"
#define ITEM_EXTERNAL_DRAWING_REVISION        "Ng5_NonEngDwgRevision"
#define ITEM_ENGINEERED_PART_REVISION         "Ng5_EngPartRevision"
#define ITEM_SUPPORT_DESIGN_REVISION          "Ng5_SupportPartRevision"
#define ITEM_EXTERNAL_PART_REVISION           "Ng5_NonEngPartRevision"
#define ITEM_EXTERNAL_PART                     "Ng5_NonEngPart"
#define ITEM_EXTERNAL_SUPPORT_DESIGN_REVISION  "Ng5_NonEngSupPrtRevision"
#define NG5_PROGRAM_CONCAT_PROPERTY    "Ng5_Prg_Concatenation_Property"
#define PROBLEM_REPORT_REVISION                "Ng5_PRRevision"
#define CHANGE_REQUEST_REVISION                "Ng5_CRRevision"
#define CMHasProblemItem_rel                   "CMHasProblemItem"
#define EC_Solution_Item_REL                   "CMHasSolutionItem"
#define CHANGE_NOTICE_REVISION                  "Ng5_CNRevision"
#define CMProposedChanges_rel                "Ng5_ProposedChanges"
#define REL_ENDITEMLIST							"Ng5_EndItemList"
#define DEVIATION_AUTHORIZATION_PROPERTY		"ng5_DeviationAuthorization"
#define DESIGN_FREEZE_PROPERTY					"ng5_DesignFreeze"
#define ICEPART_FORM                            "Ng5_ICEPartForm"
#define PLANT	"Ng5_Plants"
#define NG5_START_EFFECTIVITY           "ng5_Start_Effectivity"
#define NG5_END_EFFECTIVITY           "ng5_End_Effectivity"
#define NG5_EFFECTIVE_DATE			  "ng5_Effective_Date"

#define DATE_FORMAT_STR       "%Y-%m-%d-%H-%M-%S"

#define Ng5_IMPORTED "Ng5_Imported"
#define Ng5_MFGTOENG_PRIMARY_REL 			   "Ng5_rHasEngPartToMfgPartRev"
#define Ng5_MFGTOENG_PRIMARY_TYPE			   "Ng5_MfgPartRevision"
#define Ng5_BOMLINE_QTY    						"bl_quantity"
#define Ng5_UP_DATE  						"31-Dec-2049 12:00"

#define ITK( argument )						                                		\
{									                                        		\
        int retcode = argument;                                                     \
		char* s = NULL;                                                        		\
		if ( retcode != ITK_ok )													\
		{																			\
			TC_write_syslog( " "#argument "\n" );                                   \
			TC_write_syslog( "  returns [%d] \n", retcode );						\
			if (s != 0) 															\
			{																	    \
			MEM_free (s);                                                           \
			s = 0;																	\
			}																		\
            return retcode ;                                                        \
		}                                                                   		\
																				    \
}

#define ATTR_ITEM_ID	                "item_id"
#define ATTR_OBJECT_NAME				"object_name"
#define ATTR_TOOLING_MATURITY 			"ng5_tooling_maturity"
#define ATTR_TOOL_MATURITY 				"ng5_tool_maturity"
#define ATTR_ORIG_FILE_NAME				"original_file_name"
#define ATTR_LAST_MODIFIED_DATE			"last_mod_date"
#define PartToPart_ReplacedBy_Rel		"Ng5_rHasReplacedByRel"
#define PrtrevToPrtrevDerivedFrom_Rel	"Ng5_rHasDerivedFromRel"
#define ATTR_ITEM_REV_ID 				"item_revision_id"
#define ProgToProj_Relation_Type 		"Ng5_rHasProject"
#define ProgToChange_Relation_Type 		"Ng5_rHasChange"
#define Project_Class_Name              "TC_Project"
#define CONST_PROTOTYPE					"Prototype"
#define CONST_PRODUCTION				"Production"
#define CONST_DEVELOPMENT				"Development"
#define BASELINE_STATUS					"TC Baselined"
#define REVISION                        "revision"


#define CUSTOMER_PART_NUMBER  			"ng5_customer_part_form_num"
#define CUSTOMER_PART_REVISION 			"ng5_customer_part_revision"
#define CUSTOMER_NAME          			"ng5_customer"
#define CUSTOMER_MASTER_ID      		"ng5_customer_master_id"
#define SUPPLIER_PART_NUMBER  			"ng5_supplier_part_form_num"
#define SUPPLIER_PART_REVISION 			"ng5_supplier_part_revision"
#define SUPPLIER_NAME          			"ng5_supplier_name"
#define SUPPLIER_MASTER_ID   		    "ng5_supplier_master_id"
#define HYPHEN							"-"
#define MHYPHEN                         "M-"
#define DOT                             "."
#define ENG_PART                        "Ng5_EngPart"
#define RAW_MATERIAL                    "Ng5_RawMaterial"
#define PHANTOM_PART               		"Ng5_PhantomPart"
#define PKG_PART	               		"Ng5_PackagingPrt"
#define ENG_PART_REVISION               "Ng5_EngPartRevision"
#define RAW_MATERIAL_REVISION           "Ng5_RawMaterialRevision"
#define CONTROL_DOCUMENT_REVISION        "Ng5_CntlDocRevision"
#define CONTROL_DOCUMENT       			"Ng5_CntlDoc"
#define ENG_DRAWING_REVISION            "Ng5_DrawingRevision"
#define ENG_DRAWING		                "Ng5_Drawing"
#define ENG_PART_REVISION               "Ng5_EngPartRevision"
#define RAW_MATERIAL_REVISION           "Ng5_RawMaterialRevision"
#define RAW_MATERIAL                    "Ng5_RawMaterial"
#define HAS_RAW_MATERIAL_RELATION       "Has Raw Material"
#define ATTR_RAWMATERIAL_NAME			"object_string"
#define ATTR_RAWMATERIAL_QTY			"ng5_raw_material_qty"
#define ATTR_ENGPARTREV_RAWMATINFO		"ng5_raw_material_info"
#define RAW_MATERIAL_UOM_TAG			"ng5_raw_material_uom"
#define ITEMS_TAG						"items_tag"
#define ATTR_TARGET_START_DATE			"ng5_target_impl_date"
#define ATTR_TARGET_COMPLETION_DATE		"ng5_target_cmpltn_date"
#define ATTR_CHANGE_STATE    			"ng5_ChangeState"
#define CLOSED_STATE        			"Closed"
#define ATTR_EXTENSION_DATE             "ng5_extension_date"
#define ATTR_MIRRORED_HANDED_PRIMARY	"ng5_mirrored_handed_primary"
#define CHANGE_ITEM_REVISION		     "ChangeItemRevision"
#define ATTR_STATUS_INDICATOR            "ng5_status_indicator"
#define ATTR_ORIGINATING_SITE 			"ng5_originating_site"
#define ATTR_VALUE_STATUS_INDICATOR      "Latest"
#define ATTR_OBJECT_STRING               "object_string"
#define ATTR_MFK_CTR               		 "ng5_mfk_counter"
#define ATTR_OBJECT_TYPE                 "object_type"
#define ATTR_OBJECT_DESC                 "object_desc"
#define ATTR_OWNING_GROUP                 "owning_group"
#define ATTR_TYPE_STRING				"type_string"
#define ATTR_OWNING_SITE 				"owning_site"
#define HAS_PARTICIPANTS_TYPE            "HasParticipant"
#define NG5_USER_GROUP_ROLE 			"Ng5_UserGroupRole"
#define PROPOSED_CHANGES 				"Ng5_ProposedChanges"
#define MATL_MASTER                 "Ng5_MatlMaster"
#define MATL_MASTER_REV                 "Ng5_MatlMasterRevision"
#define PROP_CONT_IS_EDITABLE			"Ng5_IsEditable"
#define CLS_FORM						"Form"
#define REL_PLANTFORM                 "Ng5_rHasPlantForm"
#define ICEPARTFORM_STORAGE			"Ng5_ICEPartFormStorage"
#define PLANTFORM_STORAGE			"Ng5_PlantFormStorage"
#define PLANTFORM                 "Ng5_PlantForm"
#define ATTR_MFG_DSC                "ng5_mfg_desc"
#define ATTR_SAP_UOM                 "ng5_sap_weight_uom"
#define ATTR_PLANT_UOM                 "ng5_plant_weightuom"
#define ATTR_PLANT_WT	                "ng5_plant_netweight"
#define ATTR_ITEM_TYPE	                "ng5_item_type"
#define ATTR_COUNTRY_OF_ORIGIN          "ng5_country_of_origin"
#define ATTR_SAP_WT					"ng5_sap_net_weight"
#define ATTR_ADR_DAN_GOOD			"ng5_adr_dangerous_good"
#define ATTR_SYNC_REQ              "ng5_is_sync_required"
#define ATTR_MATL_TYPE					"ng5_material_type"
#define ATTR_MATL_GRP					"ng5_material_group"
#define ATTR_PROD_HIERARCHY					"ng5_prod_hierarchy"
#define ATTR_ENT_SOURC_DESC					"ng5_ent_sourc_dec"
#define ATTR_PROD_CODE					"ng5_prod_code"
#define ATTR_PROD_ATTR					"ng5_prod_attr"
#define ATTR_CREATION_DATE                "creation_date"
#define PREF_WEIGHT_CONVERSIONS		"Ng5_Weight_conversion_values"
#define UNDERSCORE							"_"
#define FROZEN                           "Ng5_Frozen"   //CM Improvement
#define STATUS_INDICATOR              "ng5_status_indicator"  //CM Improvement
#define DATE_RELEASED                  "date_released"
#define LATEST_REV                      "Latest" //CM Improvement
#define OBSOLETE_REV                    "Obsolete"
#define FROZEN_CUTOFF_DATE_PREF        "Ng5_Frozen_Cutoff_Date" //CM Improvement
#define RELEASED                       "Ng5_Released"  //EBOM2MBOM
#define HASCUSTPARTFORM                "Ng5_rPartHasCustomerPrtForm" //EBOM2MBOM
#define CUSTOMER                       "ng5_customer"//EBOM2MBOM
#define CUSTPARTNUM                     "ng5_customer_part_form_num"
#define PLANTS                           "ng5_plants"
#define MFGPARTTYPE                      "ng5_mfgpart_type"
#define TOPLINEMBOM                     "MBOM Topline"
#define HASPLANTBOM                    "Ng5_rHasPlantMBOM"
#define HASENGPART2MFGPARREV           "Ng5_rHasEngPartToMfgPartRev"
#define RQRDCUSTPARTNO                 "ng5_reqcustpartno"
#define SUFFIX                         "ng5_suffix"
#define TILT                           "~"
#define ITEMSTAG                         "items_tag"
#define ATTR_CREATE_IPF                   "ng5_create_ipf"
#define ATTR_IS_TOPLINE                  "ng5_is_topline"

#define BOMLINEOBJTYPE                 "bl_item_object_type"
#define MFGPART                        "Ng5_MfgPart"
#define MFGPARTREV                     "Ng5_MfgPartRevision"
#define BOMLIMEITEMID                  "bl_item_item_id"
#define BOMLINEREVID             	   "bl_rev_item_revision_id"
#define MFGREVRULEPREF                 "Ng5_mfg_rev_rule"
#define MFGPACKLINEREQ                 "Ng5_isPackLines_Cut_Required"
#define EBOM2MBOMCLONPREF               "Ng5_EBOM2MBOM_Cloning_Pref"
#define IMANMETARGET                   "IMAN_METarget"
#define BOMLINEHASCHILD                 "bl_has_children"
#define BOMLINELEVEL0                   "bl_level_starting_0"
#define SEMIFINISHED                   "SemiFinished Good"
#define COMPONENT                       "Component"
#define CLONE                           "Clone"
#define COLON                           ":"
#define COMMA                           ","
#define COPY                            "Copy"
#define SOURCETYPE                      "ng5_sourceType"
#define OEM                             "OEM"
#define ENG                              "Eng Part"
#define ORIGINALID                      "ng5_original_id"
#define COLOR_MAPPING_TABLE              "ng5_Color_Mapping"
#define OLD_SUFFIX                       "ng5_oldSuffix"
#define NEW_SUFFIX                       "ng5_newSuffix"
#define PIPE                             "|"
#define BACKSLASH                        "/"
#define SOURCEMBOM                      "ng5_Source_MBOM"
#define BACKGROUNDCLONING               "ng5_cloning_bgrd"
#define WF_PROCESS_BACKGROUNDCLONING     "MBOM Background Cloning"
#define COLON_SPACE                      ": "
#define EBOM_ITEMS                       "Ng5_rHasEBOM"

#define NG5_COPY_PREFIX "Ng5_Propagate";
#define NG5_PROCESSPRIATTR "Primary Attributes";
#define NG5_PROCESSSECATTR "Secondary Attributes";
#define NG5_PROCESSPRIPART "Primary Participants";
#define NG5_PROCESSSECPART "Secondary Participants";
#define NG5_PROCESSPRIRELATION "Primary Relations";
#define NG5_PROCESSSECRELATION "Secondary Relations";
#define NG5_ATTRIBUTE_PREFIX "Ng5_CopyAttributes";
#define NG5_PARTICIPANT_PREFIX "Ng5_CopyParticipants";
#define NG5_RELATION_PREFIX "Ng5_CopyRelations";
#define ATTR_ASSIGNEE "assignee";
#define ROLE_TOKEN	"/"

#define GROUP_ADMIN 					"Admin"
#define GROUP_DBA 						"dba"
#define GROUP_MIGRATION					"Migration"
#define ATTR_MFK_COUNTER				"ng5_mfk_counter"
#define MFK_COUNTER_INITIAL_VALUE		"0000"

#define SUPPORT_DESIGN					"Ng5_SupportPart"
#define SUPPORT_DESIGN_REV              "Ng5_SupportPartRevision"

#define CATIA_MODEL_ATTRIBUTE_WEIGHT    		"weight"
#define DESIGN_WEIGHT					"ng5_design_weight"
#define	PREF_BYPASSOWNINGGROUP					"Ng5_ByPassCheckForOwningGrp"
#define REV_TYPE					"ng5_rev_type"
#define NX_DWG_TO_ENGPART           "ng5_nxdwglink_parts"
#define DERIVED_FROM_PARTS           "ng5_derived_from_parts"
#define REPLACEMENT_FOR_PARTS        "ng5_replacement_for_parts"
#define ITEM_CREATE_REV_EVENT        "__Item_Rev_Create"
#define ITEM_ATTACH_EVENT             "__Attach"
#define ASSIGN_STATUS                 "__Attained_Release_Status"
#define MAIL_NOTIFICATION            "IMAN_Smtp_Mail_Notify"
#define UGPART_ATTR_FORM             "UGPartAttributesForm"
#define UGPART_MASS_FORM             "UGPartMassPropsForm"
#define MASS             			 "mass"
#define DESIGN_WEIGHT             	 "ng5_design_weight"
#define RELEASE_STATUS_LIST           "release_status_list"

#define MAJOR					"Major"
#define MINOR				"Minor"
#define IS_INITIAL_REV      "ng5_is_initial_absrev"
#define VALIDATION_ERROR    "Validation Failed"
#define ITEM_CREATE_REV_MSG "ITEM_create_rev"
#define YES					"Yes"
#define NO					"No"
#define ACCESS_WRITE		"WRITE"
#define ORIGINATING_SITE    "ng5_originating_site"
#define FPDM_EU             "FPDM.EU"
#define CN_REVISION         "Ng5_CNRevision"
#define ATTR_CHANGE_STATE   "ng5_ChangeState"
#define INITIATED           "Initiated"
#define EXTERNAL_PART       "Ng5_NonEngPart"
#define EXTERNAL_DWG       "Ng5_NonEngDwg"
#define FILE_CATPART		".CATPart"
#define FILE_CATPRODUCT		".CATProduct"
#define FILE_CATDRAWING		".CATDrawing"
#define FILE_UGMASTER		".prt"
#define CATIA_DATASET_Prefix "Cat"
#define NX_DATASETPrefix     "UG"
#define IMAN_SPEC           "IMAN_specification"
#define RELATED_ENGG_PARTS	"ng5_related_engg_parts"
#define COMPONENT            "Component"
#define MFG_SPEC_CHAR_PREF   "Ng5_Mfg_Allowed_Spec_Chars"
#define HAS_CUSTOMER_PART_FORM "Ng5_rPartHasCustomerPrtForm"
#define EBOM2MBOMCOPYPREF      "Ng5_EBOM2MBOM_Copy_pref"
#define ITEM                    "Item"
#define ATTR                    "Attribute"
#define REF                     "Reference"
#define REV                     "Revision"
#define ITEMRELATION            "ItemRelation"
#define REVRELATION             "RevRelation"
#define CHILDREN                 "ps_children"
#define CRRevision          "Ng5_CRRevision"
#define ChangeType          "ng5_change_type"
#define HASICEPARTFORM      "Ng5_rHasICEPartForm"
#define SOURCETYPEPREF       "Ng5_EBOM2MBOM_SourceType_Pref"
#define BOMOCCURRENCE			"bl_occ_effectivity"
#define BOMFINDNO 				"bl_sequence_no"
#define BOMPacked  				"bl_is_packed"
#define BOMLINEPARENT        "bl_formatted_parent_name"
#define CN_CHANGE_STATE_IMPLEMENTED "Implemented"
#define ENGUSER_COND            "Ng5_isEngUser"
#define BOMLINEPARENTLINE        "bl_parent"
#define BOMLINEREVISION		  "bl_revision"
#define PREF_PLANT_TZ_GT_SERVTZ  "Ng5_PlantTimeZone_GT_ServerTimeZone"
#define BOMLINEPLANT  		"ng5_bl_plants"
#define HASVALIDATIONREPORT "Ng5_rHasValidationReport"
#define HTML                "HTML"

#define ErrorBase                                 919000
#define ErrorCodeForToolingMaturity				  ErrorBase + 1908
#define ErrorCodeForNoContextProgram              ErrorBase + 1909
#define ErrorCodeInvalidRevisionId				  ErrorBase + 1910
#define ErrorCodeOnlyOneWorkingMajor			  ErrorBase + 1911
#define ErrorCodeForCustomerPartForm			  ErrorBase + 1912
#define ErrorCodeForMHPrimary                     ErrorBase + 1913
#define ErrorCodeForMHSecondary                   ErrorBase + 1957
#define ErrorCodeForDADatesValidation             ErrorBase + 1921
#define ErrorCodeForDADatesValidation2            ErrorBase + 1922
#define ErrorCodeForProgramCreation				  ErrorBase + 1931
#define ErrorCodeMismatchGroup					  ErrorBase + 1940
#define ErrorCodeForRevise			  			  ErrorBase + 1951
#define ErrorCodeEngPartDeleteMatMaster			  ErrorBase + 1952
#define ErrorICEAttributesLocked				  ErrorBase + 1920
#define ErrorCodeForNotProjectMember			  ErrorBase + 1958
#define ErrorPlantWeightLocked					  ErrorBase + 1923
#define ErrorMultipleCADTool                      ErrorBase + 1959
#define ErrorCodeForMultipleSSOPackage            ErrorBase + 1960
#define ErrorPreviousMajorRevInCMProcess          ErrorBase + 1935
#define ErrorCodeNoOEMError                       ErrorBase + 2126
#define ErrorSameMfgID                            ErrorBase + 2127
#define ErrorLongItemID                           ErrorBase + 2128
#define ErrorSuffixInvalidChar                    ErrorBase  + 2129
#define ErrorIDNotAlphaNumeric                    ErrorBase  + 2130
#define ErrorEditBaselinedRev                     ErrorBase  + 2131
#define ErrorInReferencesCutOnImplementedCN       ErrorBase  + 2132
#define ErrorDOC                                  ErrorBase + 1971
#define ErrorBOMLineCutRestrict                   ErrorBase  + 1995
#define ErrorBOMLineCutRestrict1                  ErrorBase  + 1996
#define ErrorCNType								  ErrorBase  + 1973
#define ErrorPlantNotMatch						  ErrorBase  + 2136
#define ErrorExistingItem                         ErrorBase  + 2138
#define ErrorSameSuffixSameID                     ErrorBase  + 2139
