//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//@file
//This file contains the implementation for the Business Object Ng5_ICEPartFormImpl.
//Property Setters for ng5_mfg_desc, ng5_sap_net_weight and ng5_sap_weight_uom.
// 13 May 2021 - Added property setters for ng5_adr_dangerous_good, ng5_material_type, ng5_material_group, ng5_prod_hierarchy, ng5_ent_sourc_dec, ng5_prod_code // and ng5_prod_attr.
// 05 July 2021 -TC12 Upgrade

#include <Ng5Core/Ng5_ICEPartFormImpl.hxx>
#include <math.h>
#include <iomanip>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <sa/sa_errors.h>
#include <ug_va_copy.h>
#include <ce/ce.h>
#include <constants/constants.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>

#include <base_utils/ScopedSmPtr.hxx>
#include <stdarg.h>
#include <string>
#include <sstream>
#include <fclasses/tc_string.h>

#include "Ng5_CommonUtils.hxx"

#define SA_insufficient_privileges (ErrorICEAttributesLocked)
#define BMF_artifact_not_found (SA_ERROR_BASE + 10002)

logical ng5_editable_condition(tag_t tObject, char* sClassName, char* sAttrName);

using namespace std;
using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_ICEPartFormImpl::Ng5_ICEPartFormImpl(Ng5_ICEPartForm& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_ICEPartFormImpl::Ng5_ICEPartFormImpl( Ng5_ICEPartForm& busObj )
   : Ng5_ICEPartFormGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_ICEPartFormImpl::~Ng5_ICEPartFormImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_ICEPartFormImpl::~Ng5_ICEPartFormImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_ICEPartFormImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_ICEPartFormImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_ICEPartFormGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

logical ng5_editable_condition(tag_t tObject, char* sClassName, char* sAttrName)
{
		int ifail = ITK_ok;
		tag_t   tFormTypeTag 	= NULLTAG;
		tag_t   condTag 		= NULLTAG;
		tag_t   tUserSession 	= NULLTAG;
		tag_t   *parm_tags 		= 0;
		char*   constName;
		char*   type_name       = NULL;
		logical result 			= false;
		logical lverdict 		= false;

		TC_write_syslog("\n Entering function - ng5_editable_condition\n");

		TCTYPE_ask_object_type(tObject, &tFormTypeTag);

	    TCTYPE_ask_name2( tFormTypeTag,&type_name);//TC12 Upgrade
	    ifail = CONSTANTS_get_property_constant_value(PROP_CONT_IS_EDITABLE, type_name, sAttrName, &constName);
		if (constName == NULL)
		{
			//TC_write_syslog("Given property constant '%s' is not correct.\n", "SL2IsEditable");
			return BMF_artifact_not_found;
		}

		ifail = CE_find_condition( constName, &condTag );
		if (ifail != ITK_ok)
		{
		   //TC_write_syslog("\nCE_find_condition = false\n");
		   return ifail;
		}

		if (condTag == null_tag)
		{
			//TC_write_syslog("Condition is not found for the given property constant '%s'.\n", constName);
			return BMF_artifact_not_found;
		}

		CE_current_user_session_tag(&tUserSession);

		int num_parms = 2;
		parm_tags = (tag_t *) MEM_alloc( sizeof( tag_t) * num_parms );
		parm_tags[0] = tObject;
		parm_tags[1] = tUserSession;

		ifail = CE_evaluate_condition (condTag, num_parms, parm_tags, &result);

		TC_write_syslog("\n CE_evaluate_condition: result = %d\n",result);

		NG5_MEM_TCFREE (parm_tags);
		NG5_MEM_TCFREE (constName);
        NG5_MEM_TCFREE (type_name);
		return (result);
}

///
/// Setter for a Boolean Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_adr_dangerous_goodBase( bool  value, bool  isNull )
{
    int ifail = ITK_ok;
    isNull = false;
    tag_t   tAdrAttrTag   = NULLTAG;
    tag_t	tSyncAttrTag  = NULLTAG;
    tag_t   tAdrObject    = NULLTAG;
    tag_t 	inst_class_id = NULLTAG;
    char* 	classname 	  = NULL;

    TC_write_syslog("\n Entering setNg5_adr_dangerous_goodBase\n");
    tAdrObject = this->getNg5_ICEPartForm()->getTag();

    if (!ng5_editable_condition(tAdrObject, ICEPARTFORM_STORAGE, ATTR_ADR_DAN_GOOD))
    	{
    		TC_write_syslog("\nCondition evaluated to False\n");
    		ifail = SA_insufficient_privileges;
    		EMH_store_initial_error_s1(EMH_severity_error, ErrorICEAttributesLocked , "ADR Dangerous Good, Manufacturing Description1, SAP Net Weight and SAP Weight UoM are locked for modification after transfer of Material Master." );
    		return ifail;
    	 }
    	ITKCALL(POM_class_of_instance(tAdrObject,&inst_class_id));
        ITKCALL(POM_name_of_class(inst_class_id,&classname));

    	if(Ng5_CommonUtils::is_descendant_of_Form(tAdrObject))
    	{
    		//TC_write_syslog("\n   -->After is_descendant_of_Form\n");
    		tag_t form_tag = tAdrObject;
    		tAdrObject = NULLTAG;
    		ITKCALL(FORM_ask_pom_instance(form_tag, &tAdrObject));
    	}

    	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tAdrObject, ICEPARTFORM_STORAGE, ATTR_ADR_DAN_GOOD, &tAdrAttrTag));
    	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tAdrObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

    	if (tAdrAttrTag != NULLTAG || tSyncAttrTag != NULLTAG)
    	{
    		//TC_write_syslog("\n -->set ng5_adr_dangerous_good \n");
    		ITKCALL (AOM_refresh(tAdrObject, true));
    		ITKCALL (AttributeAccessor::setLogicalValue (tAdrObject, tAdrAttrTag, value ,isNull ));
    		ITKCALL (AttributeAccessor::setStringValue (tAdrObject, tSyncAttrTag, "Yes" ,isNull ));
    		ITKCALL (AOM_save_with_extensions(tAdrObject));
    		ITKCALL (AOM_refresh(tAdrObject, false));
    	}
    return ifail;
}

///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_material_typeBase( const std::string & value, bool  isNull )
{
    int ifail = ITK_ok;
    isNull = false;
	tag_t   tMatlTypeAttrTag   = NULLTAG;
	tag_t	tSyncAttrTag	= NULLTAG;
	tag_t   tMatlTypeObject    = NULLTAG;
	tag_t 	inst_class_id   = NULLTAG;
	char* 	classname 		= NULL;

	TC_write_syslog("\n Entering setNg5_material_typeBase\n");
	tMatlTypeObject = this->getNg5_ICEPartForm()->getTag();

	ITKCALL(POM_class_of_instance(tMatlTypeObject,&inst_class_id));
    ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tMatlTypeObject))
	{
		//TC_write_syslog("\n   -->After is_descendant_of_Form\n");
		tag_t form_tag = tMatlTypeObject;
		tMatlTypeObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tMatlTypeObject));
	}

	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tMatlTypeObject, ICEPARTFORM_STORAGE, ATTR_MATL_TYPE, &tMatlTypeAttrTag));
	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tMatlTypeObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

	ITKCALL (AOM_refresh(tMatlTypeObject, true));
	ITKCALL (AttributeAccessor::setStringValue (tMatlTypeObject, tMatlTypeAttrTag, value ,isNull ));
	ITKCALL (AttributeAccessor::setStringValue (tMatlTypeObject, tSyncAttrTag, "Yes", isNull ));
	ITKCALL (AOM_save_with_extensions(tMatlTypeObject));
	ITKCALL (AOM_refresh(tMatlTypeObject, false));

	NG5_MEM_TCFREE (classname);
    return ifail;
}

///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_material_groupBase( const std::string & value, bool  isNull )
{
    int ifail = ITK_ok;
    isNull = false;
	tag_t   tMatlGrpAttrTag   = NULLTAG;
	tag_t	tSyncAttrTag	= NULLTAG;
	tag_t   tMatlGrpObject    = NULLTAG;
	tag_t 	inst_class_id   = NULLTAG;
	char* 	classname 		= NULL;

	TC_write_syslog("\n Entering setNg5_material_typeBase\n");
	tMatlGrpObject = this->getNg5_ICEPartForm()->getTag();

	ITKCALL(POM_class_of_instance(tMatlGrpObject,&inst_class_id));
    ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tMatlGrpObject))
	{
		//TC_write_syslog("\n   -->After is_descendant_of_Form\n");
		tag_t form_tag = tMatlGrpObject;
		tMatlGrpObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tMatlGrpObject));
	}

	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tMatlGrpObject, ICEPARTFORM_STORAGE, ATTR_MATL_GRP, &tMatlGrpAttrTag));
	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tMatlGrpObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

	if (tMatlGrpAttrTag != NULLTAG || tSyncAttrTag != NULLTAG)
	{
		//TC_write_syslog("\n     -->set ng5_material_group \n");
		ITKCALL (AOM_refresh(tMatlGrpObject, true));
		ITKCALL (AttributeAccessor::setStringValue (tMatlGrpObject, tMatlGrpAttrTag, value ,isNull ));
		ITKCALL (AttributeAccessor::setStringValue (tMatlGrpObject, tSyncAttrTag, "Yes", isNull ));
		ITKCALL (AOM_save_with_extensions(tMatlGrpObject));
		ITKCALL (AOM_refresh(tMatlGrpObject, false));
	}
	NG5_MEM_TCFREE (classname);
    return ifail;
}

///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_ent_sourc_decBase( const std::string & value, bool  isNull )
{
    int ifail = ITK_ok;
    isNull = false;
	tag_t   tEntSrcDecAttrTag   = NULLTAG;
	tag_t	tSyncAttrTag	= NULLTAG;
	tag_t   tEntSrcDecObject    = NULLTAG;
	tag_t 	inst_class_id   = NULLTAG;
	char* 	classname 		= NULL;

	TC_write_syslog("\n Entering setNg5_ent_sourc_decBase\n");
	tEntSrcDecObject = this->getNg5_ICEPartForm()->getTag();

	ITKCALL(POM_class_of_instance(tEntSrcDecObject,&inst_class_id));
    ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tEntSrcDecObject))
	{
		//TC_write_syslog("\n   -->After is_descendant_of_Form\n");
		tag_t form_tag = tEntSrcDecObject;
		tEntSrcDecObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tEntSrcDecObject));
	}

	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tEntSrcDecObject, ICEPARTFORM_STORAGE, ATTR_ENT_SOURC_DESC, &tEntSrcDecAttrTag));
	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tEntSrcDecObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

	if (tEntSrcDecAttrTag != NULLTAG || tSyncAttrTag != NULLTAG)
	{
		//TC_write_syslog("\n     -->set ng5_ent_sourc_dec \n");
		ITKCALL (AOM_refresh(tEntSrcDecObject, true));
		ITKCALL (AttributeAccessor::setStringValue (tEntSrcDecObject, tEntSrcDecAttrTag, value ,isNull ));
		ITKCALL (AttributeAccessor::setStringValue (tEntSrcDecObject, tSyncAttrTag, "Yes", isNull ));
		ITKCALL (AOM_save_with_extensions(tEntSrcDecObject));
		ITKCALL (AOM_refresh(tEntSrcDecObject, false));
	}
	NG5_MEM_TCFREE (classname);
    return ifail;
}

///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_prod_attrBase( const std::string & value, bool  isNull )
{
    int ifail = ITK_ok;
    isNull = false;
	tag_t   tProdAttrAttrTag   = NULLTAG;
	tag_t	tSyncAttrTag	= NULLTAG;
	tag_t   tProdAttrObject    = NULLTAG;
	tag_t 	inst_class_id   = NULLTAG;
	char* 	classname 		= NULL;

	TC_write_syslog("\n Entering setNg5_prod_attrBase\n");
	tProdAttrObject = this->getNg5_ICEPartForm()->getTag();

	ITKCALL(POM_class_of_instance(tProdAttrObject,&inst_class_id));
    ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tProdAttrObject))
	{
		//TC_write_syslog("\n   -->After is_descendant_of_Form\n");
		tag_t form_tag = tProdAttrObject;
		tProdAttrObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tProdAttrObject));
	}

	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tProdAttrObject, ICEPARTFORM_STORAGE, ATTR_PROD_ATTR, &tProdAttrAttrTag));
	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tProdAttrObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

	if (tProdAttrAttrTag != NULLTAG || tSyncAttrTag != NULLTAG)
	{
		//TC_write_syslog("\n     -->set ng5_prod_attr \n");
		ITKCALL (AOM_refresh(tProdAttrObject, true));
		ITKCALL (AttributeAccessor::setStringValue (tProdAttrObject, tProdAttrAttrTag, value ,isNull ));
		ITKCALL (AttributeAccessor::setStringValue (tProdAttrObject, tSyncAttrTag, "Yes", isNull ));
		ITKCALL (AOM_save_with_extensions(tProdAttrObject));
		ITKCALL (AOM_refresh(tProdAttrObject, false));
	}
	NG5_MEM_TCFREE (classname);
    return ifail;
    return ifail;
}

///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_prod_codeBase( const std::string & value, bool  isNull )
{
    int ifail = ITK_ok;
    isNull = false;
    tag_t   tProdCodeAttrTag   = NULLTAG;
    tag_t	tSyncAttrTag	= NULLTAG;
    tag_t   tProdCodeObject    = NULLTAG;
    tag_t 	inst_class_id   = NULLTAG;
    char* 	classname 		= NULL;

    TC_write_syslog("\n Entering setNg5_prod_codeBase\n");
    tProdCodeObject = this->getNg5_ICEPartForm()->getTag();

    ITKCALL(POM_class_of_instance(tProdCodeObject,&inst_class_id));
    ITKCALL(POM_name_of_class(inst_class_id,&classname));

    if(Ng5_CommonUtils::is_descendant_of_Form(tProdCodeObject))
    	{
    	//TC_write_syslog("\n   -->After is_descendant_of_Form\n");
    	tag_t form_tag = tProdCodeObject;
    	tProdCodeObject = NULLTAG;
    	ITKCALL(FORM_ask_pom_instance(form_tag, &tProdCodeObject));
    	}

    	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tProdCodeObject, ICEPARTFORM_STORAGE, ATTR_PROD_CODE, &tProdCodeAttrTag));
    	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tProdCodeObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

    	if (tProdCodeAttrTag != NULLTAG || tSyncAttrTag != NULLTAG)
    	{
    		//TC_write_syslog("\n     -->set ng5_prod_code \n");
    		ITKCALL (AOM_refresh(tProdCodeObject, true));
    		ITKCALL (AttributeAccessor::setStringValue (tProdCodeObject, tProdCodeAttrTag, value ,isNull ));
    		ITKCALL (AttributeAccessor::setStringValue (tProdCodeObject, tSyncAttrTag, "Yes", isNull ));
    		ITKCALL (AOM_save_with_extensions(tProdCodeObject));
    		ITKCALL (AOM_refresh(tProdCodeObject, false));
    	}
    NG5_MEM_TCFREE (classname);
    return ifail;
}

///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_prod_hierarchyBase( const std::string & value, bool  isNull )
{
    int ifail = ITK_ok;
    isNull = false;
	tag_t   tProdHierAttrTag   = NULLTAG;
	tag_t	tSyncAttrTag	= NULLTAG;
	tag_t   tProdHierObject    = NULLTAG;
	tag_t 	inst_class_id   = NULLTAG;
	char* 	classname 		= NULL;

	TC_write_syslog("\n Entering setNg5_prod_hierarchyBase\n");
	tProdHierObject = this->getNg5_ICEPartForm()->getTag();

	ITKCALL(POM_class_of_instance(tProdHierObject,&inst_class_id));
    ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tProdHierObject))
	{
		//TC_write_syslog("\n   -->After is_descendant_of_Form\n");
		tag_t form_tag = tProdHierObject;
		tProdHierObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tProdHierObject));
	}

	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tProdHierObject, ICEPARTFORM_STORAGE, ATTR_PROD_HIERARCHY, &tProdHierAttrTag));
	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tProdHierObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

	if (tProdHierAttrTag != NULLTAG || tSyncAttrTag != NULLTAG)
	{
		//TC_write_syslog("\n     -->set ng5_prod_hierarchy \n");
		ITKCALL (AOM_refresh(tProdHierObject, true));
		ITKCALL (AttributeAccessor::setStringValue (tProdHierObject, tProdHierAttrTag, value ,isNull ));
		ITKCALL (AttributeAccessor::setStringValue (tProdHierObject, tSyncAttrTag, "Yes", isNull ));
		ITKCALL (AOM_save_with_extensions(tProdHierObject));
		ITKCALL (AOM_refresh(tProdHierObject, false));
	}
	NG5_MEM_TCFREE (classname);
    return ifail;
}

///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_mfg_descBase( const std::string & value, bool  isNull )
{
    int ifail = ITK_ok;
    isNull = false;
	tag_t   tMfgDescAttrTag = NULLTAG;
	tag_t	tSyncAttrTag	= NULLTAG;
	tag_t   tMfgDescObject  = NULLTAG;
	tag_t 	inst_class_id   = NULLTAG;
	char* 	classname 		= NULL;

	TC_write_syslog("\n Entering setNg5_mfg_descBase\n");
	tMfgDescObject = this->getNg5_ICEPartForm()->getTag();

	if (!ng5_editable_condition(tMfgDescObject, ICEPARTFORM_STORAGE, ATTR_MFG_DSC))
	{
		TC_write_syslog("\nCondition evaluated to False\n");
		ifail = SA_insufficient_privileges;
		EMH_store_initial_error_s1(EMH_severity_error, ErrorICEAttributesLocked , "ADR Dangerous Good, Manufacturing Description1, SAP Net Weight and SAP Weight UoM are locked for modification after transfer of Material Master." );
		return ifail;
	 }

	ITKCALL(POM_class_of_instance(tMfgDescObject,&inst_class_id));
    ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tMfgDescObject))
	{
		//TC_write_syslog("\n   -->After is_descendant_of_Form\n");
		tag_t form_tag = tMfgDescObject;
		tMfgDescObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tMfgDescObject));
	}

	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tMfgDescObject, ICEPARTFORM_STORAGE, ATTR_MFG_DSC, &tMfgDescAttrTag));
	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tMfgDescObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

	if (tMfgDescAttrTag != NULLTAG || tSyncAttrTag != NULLTAG)
	{
		//TC_write_syslog("\n     -->set ng5_mfg_desc \n");
		ITKCALL (AOM_refresh(tMfgDescObject, true));
		ITKCALL (AttributeAccessor::setStringValue (tMfgDescObject, tMfgDescAttrTag, value, isNull ));
		ITKCALL (AttributeAccessor::setStringValue (tMfgDescObject, tSyncAttrTag, "Yes", isNull ));
		ITKCALL (AOM_save_with_extensions(tMfgDescObject));
		ITKCALL (AOM_refresh(tMfgDescObject, false));
	}
	NG5_MEM_TCFREE (classname);
    return ifail;
}

///
/// Setter for a Double Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_sap_net_weightBase( double  value, bool  isNull )
{
    int ifail = ITK_ok;

    isNull = false;

	char    type_name[TCTYPE_name_size_c+1];
	tag_t   tObject       	= NULLTAG;
	tag_t   tStorageID  	= NULLTAG;
	tag_t   tFormObj       	= NULLTAG;
	tag_t   *parm_tags 		= 0;
	tag_t   condTag 		= NULLTAG;
	tag_t   tFormTypeTag 	= NULLTAG;
	tag_t   tUserSession 	= NULLTAG;
	tag_t   tAttrTag     	= NULLTAG;
	tag_t   tDataFileTag 	= NULLTAG;
	tag_t 	inst_class_id   = NULLTAG;
	tag_t 	tTagValue 		= NULLTAG;
	tag_t	tSyncAttrTag	= NULLTAG;
	bool 	isTagNull 		= false;
	char* 	classname 		= NULL;
	logical result 			= false;
	logical lverdict 		= false;
	double roundedSAPWt		= 0.0;

	tObject = this->getNg5_ICEPartForm()->getTag();
	TC_write_syslog("\n Entering setNg5_sap_net_weightBase\n");

	if (!ng5_editable_condition(tObject, ICEPARTFORM_STORAGE, ATTR_SAP_WT))
	{
		TC_write_syslog("\nCondition evaluated to False\n");
		ifail = SA_insufficient_privileges;
		EMH_store_initial_error_s1(EMH_severity_error, ErrorICEAttributesLocked , "ADR Dangerous Good, Manufacturing Description1, SAP Net Weight and SAP Weight UoM are locked for modification after transfer of Material Master." );
		return ifail;
	 }

	TC_write_syslog("\n Entering setNg5_sap_net_weightBase\n");
	ITKCALL(POM_class_of_instance(tObject,&inst_class_id));
    ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tObject))
	{
		//TC_write_syslog("\n After is_descendant_of_Form\n");
		tag_t form_tag = tObject;
		tObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tObject));
	}

	if (tObject != NULLTAG)
	{
		ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, ICEPARTFORM_STORAGE, ATTR_SAP_WT, &tAttrTag));
		ITKCALL (Ng5_CommonUtils::getAttrIDTag (tObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

		roundedSAPWt = (Ng5_CommonUtils::roundTo5Places(value));
		TC_write_syslog("\n **** setNg5_sap_net_weightBase:roundedSAPWt= %f \n",roundedSAPWt);

		if (tAttrTag != NULLTAG || tSyncAttrTag != NULLTAG)
		{
			ITKCALL (AOM_refresh(tObject, true));
			ITKCALL (AttributeAccessor::setDoubleValue (tObject, tAttrTag, roundedSAPWt ,isNull ));
			ITKCALL (AttributeAccessor::setStringValue (tObject, tSyncAttrTag, "Yes" ,isNull ));
			//TC_write_syslog("\n setNg5_sap_net_weightBase: dSAPWt = %f \n", value);
			ITKCALL (AOM_save_with_extensions(tObject));
			ITKCALL (AOM_refresh(tObject, false));
		}
		else {
			TC_write_syslog("\n ** tAttrTag Tag Value is Empty **\n");
		}
	}
    //TC_write_syslog("\n setNg5_sap_net_weightBase: End of Implementation **\n");
    ifail = ITK_ok;
	NG5_MEM_TCFREE (classname);
    return ifail;
}

///
/// Setter for a string Property
/// @param value - Value to be set for the parameter
/// @param isNull - If true, set the parameter value to null
/// @return - Status. 0 if successful
///
int  Ng5_ICEPartFormImpl::setNg5_sap_weight_uomBase( const std::string & value, bool  isNull )
{
    int ifail = ITK_ok;
    isNull = false;
	tag_t   tUOMAttrTag   = NULLTAG;
	tag_t   tSyncAttrTag   = NULLTAG;
	tag_t   tUOMObject    = NULLTAG;
	tag_t 	inst_class_id   = NULLTAG;
	char* 	classname 		= NULL;

	TC_write_syslog("\n Entering setNg5_sap_weight_uomBase\n");
	tUOMObject = this->getNg5_ICEPartForm()->getTag();

    if (!ng5_editable_condition(tUOMObject, ICEPARTFORM_STORAGE, ATTR_SAP_UOM))
	{
		//TC_write_syslog("\nCondition evaluated to False\n");
		ifail = SA_insufficient_privileges;
		EMH_store_initial_error_s1(EMH_severity_error, ErrorICEAttributesLocked , "ADR Dangerous Good, Manufacturing Description1, SAP Net Weight and SAP Weight UoM are locked for modification after transfer of Material Master." );
		return ifail;
	 }

	ITKCALL(POM_class_of_instance(tUOMObject,&inst_class_id));
    ITKCALL(POM_name_of_class(inst_class_id,&classname));

	if(Ng5_CommonUtils::is_descendant_of_Form(tUOMObject))
	{
		//TC_write_syslog("\n 	--> After is_descendant_of_Form\n");
		tag_t form_tag = tUOMObject;
		tUOMObject = NULLTAG;
		ITKCALL(FORM_ask_pom_instance(form_tag, &tUOMObject));
	}

    ITKCALL (Ng5_CommonUtils::getAttrIDTag (tUOMObject, ICEPARTFORM_STORAGE, ATTR_SAP_UOM, &tUOMAttrTag));
	ITKCALL (Ng5_CommonUtils::getAttrIDTag (tUOMObject, ICEPARTFORM_STORAGE, ATTR_SYNC_REQ, &tSyncAttrTag));

	if (tUOMAttrTag != NULLTAG || tSyncAttrTag != NULLTAG)
	{
		//TC_write_syslog("\n     -->set ng5_sap_weight_uom \n");
		ITKCALL (AOM_refresh(tUOMObject, true));
		ITKCALL (AttributeAccessor::setStringValue (tUOMObject, tUOMAttrTag, value ,isNull ));
		ITKCALL (AttributeAccessor::setStringValue (tUOMObject, tSyncAttrTag, "Yes" ,isNull ));
		ITKCALL (AOM_save_with_extensions(tUOMObject));
		ITKCALL (AOM_refresh(tUOMObject, false));
	}
	NG5_MEM_TCFREE (classname);
    return ifail;
}
