/* File Name:  Ng5_SupplierPartFormCreatePost.cxx
 *
 * File Description:
 * This file contains the implementation for the Extension Ng5_SupplierPartFormCreatePost added on createPost & saveAsPost operations of Ng5_SupplierPartForm
 * to update the Supplier Master ID which is a concatenation of Supplier Part Number, Supplier Part Revision & Supplier.
 *
 * History			:
** 		Date	|  	AGM		|	Name          	|	Comments
** ------------------------------------------------------------------------------------------------
**  08/02/2018 	|			|Meenakshi Shenoy	|	Added functionality details in  File description
**  05/07/2021  |           |Balaji             |   TC12 Upgrade
**
*********************************************************************************************/

#include <Ng5Core/Ng5_SupplierPartFormCreatePost.hxx>
#include <tccore/method.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>

using namespace std;

int Ng5_SupplierPartFormCreatePost( METHOD_message_t * msg, va_list args )
{
	TC_write_syslog("Entering method Ng5_SupplierPartFormCreatePost \n");
	tag_t tForm = msg->object_tag;

	if(tForm != NULLTAG)
	{
		char* cPartMasterID = NULL;
		char* cCustomerPartRevision = NULL;
		char* cCustomer = NULL;
		char* cCustomerPartNumber = NULL;

		ITK(AOM_ask_value_string(tForm, SUPPLIER_PART_NUMBER, &cCustomerPartNumber));
		ITK(AOM_ask_value_string(tForm, SUPPLIER_PART_REVISION, &cCustomerPartRevision));
		ITK(AOM_ask_value_string(tForm, SUPPLIER_NAME, &cCustomer));
		cPartMasterID = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cCustomerPartNumber) + tc_strlen(cCustomerPartRevision) + tc_strlen(cCustomer) + 10));
		tc_strcpy(cPartMasterID, cCustomerPartNumber);

		tc_strcat(cPartMasterID, HYPHEN);
		tc_strcat(cPartMasterID, cCustomerPartRevision);
		tc_strcat(cPartMasterID, HYPHEN);
		tc_strcat(cPartMasterID, cCustomer);

		ITK(AOM_set_value_string(tForm, SUPPLIER_MASTER_ID, cPartMasterID));
		ITK(AOM_save_with_extensions(tForm)); //TC 12 Upgrade

		MEM_free(cPartMasterID);
		MEM_free(cCustomerPartNumber);
		MEM_free(cCustomerPartRevision);
		MEM_free(cCustomer);
	}
	TC_write_syslog("Exiting method Ng5_SupplierPartFormCreatePost \n");
	return ITK_ok;

	//return 0;

}
