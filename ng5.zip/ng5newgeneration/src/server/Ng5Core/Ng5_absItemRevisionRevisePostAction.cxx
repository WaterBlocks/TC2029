/*********************************************************************************************
** File Name:         Ng5_absItemRevisionRevisePostAction.cxx
**
** File Description:
	This file contains the implementation to post action on revise and create new revision operation.
	This Extension sets the value of major/minor for the new revision created and updates the initial revision during value
	during creation of new Item. It also updates the value of initial revison to Yes for migrated parts.
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   2/27/2017  Shibabrata Jena      Initial Version
**   09/23/2019 Venkat Konda         Modified code for Defect 321032
**   05/07/2021     Balaji           TC12 Upgrade
**   22/09/2021     Sushma             Reverted back   to TC11 Bug-245903

*********************************************************************************************/
#include <Ng5Core/Ng5_EngPartRevisionRevisePostAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>

#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <tccore/method.h>
using namespace ng5newgeneration;

//-----------------------------------------------------------------------------------------------------
// int Ng5_absItemRevisionRevisePostAction( METHOD_message_t * msg, va_list args )
// implementation for the extension on post action of Item_Copy_rev operation of Eng part revision
// and update the custom properties ng5_rev_type and ng5_is_initial_rev
//------------------------------------------------------------------------------------------------------
#include <Ng5Core/Ng5_absItemRevisionRevisePostAction.hxx>

int Ng5_absItemRevisionRevisePostAction( METHOD_message_t * msg, va_list args )
{



	TC_write_syslog("\n Entering Ng5_absItemRevisionRevisePostAction  \n");

	int iFail = ITK_ok;
	tag_t tNewItemOrRev = va_arg(args, tag_t);
	const char* rev_id = va_arg(args, char*);
	tag_t *tNewRevision = va_arg(args, tag_t*);// New  Revision tag

	METHOD_id_t messageMethod = msg->method;
	//void * iMethodId =  messageMethod.id;
	//iMethodId = messageMethod->id;

	try
	{
			if (tNewRevision != NULL )
			{
				if (tNewRevision[0] != NULLTAG)
				{

					logical lValidTag = false;

					tag_t tLatestRev = tNewRevision[0];

					// Checking weather tag is valid for setting up latest icon
					ITK(POM_is_tag_valid (tLatestRev,&lValidTag ));

					if (lValidTag == true)
					{
						//check if Rev is major or minor
						//ask object_type
						char*cObjectType = NULL;
						ITK(AOM_ask_value_string(tLatestRev,ATTR_OBJECT_TYPE, &cObjectType));

		                TC_write_syslog("\n object type is %s\n", cObjectType);
						ITK(AOM_refresh(tLatestRev,true));
						if(tc_strcmp(cObjectType, ENG_PART_REVISION) == 0 ||tc_strcmp(cObjectType, ENG_DRAWING_REVISION) == 0 || tc_strcmp(cObjectType, ITEM_SUPPORT_DESIGN_REVISION) == 0)
						{

							//ITK(AOM_refresh(tLatestRev,true)); //EBOM_MBOM Bug-264569
							
							logical isMinorRev = false;

							isMinorRev = Ng5_CommonUtils::isMinorRevision((char*)rev_id);
							if(!isMinorRev)

							{

							ITK(AOM_set_value_string(tLatestRev, REV_TYPE, MAJOR));
							}
							else if(isMinorRev)
							{
								ITK(AOM_set_value_string(tLatestRev, REV_TYPE, MINOR));
							}
		                //check if the extension is ITEM_COPY_MSG or ITEM_CREATE_REV_msg
						}

						char *cOriginationgSite = NULL;
						char*cObjectTypeSource = NULL;

						ITK(AOM_ask_value_string(tNewItemOrRev, ATTR_OBJECT_TYPE, &cObjectTypeSource));
						if(tc_strcmp(cObjectTypeSource, ENG_PART_REVISION)==0 ||tc_strcmp(cObjectTypeSource, ENG_DRAWING_REVISION) == 0 || tc_strcmp(cObjectTypeSource, ITEM_SUPPORT_DESIGN_REVISION) == 0 ||tc_strcmp(cObjectTypeSource, ITEM_EXTERNAL_DRAWING_REVISION) == 0 ||tc_strcmp(cObjectTypeSource, ITEM_EXTERNAL_PART_REVISION) == 0 ||tc_strcmp(cObjectTypeSource, ITEM_EXTERNAL_SUPPORT_DESIGN_REVISION) == 0 ||tc_strcmp(cObjectTypeSource, RAW_MATERIAL_REVISION) == 0 ||tc_strcmp(cObjectTypeSource, MATL_MASTER_REV) == 0)
						{

							ITK(AOM_ask_value_string(tNewItemOrRev, ATTR_ORIGINATING_SITE, &cOriginationgSite));
						//}
							if(tc_strlen(cOriginationgSite) > 1 )
							{
								ITK(AOM_set_value_string(tLatestRev, IS_INITIAL_REV, YES));

							}
						}
						//Modified code for Defect 321032, instead of comparing the method id checking revs count.
						//when we create part in NX the method Ids are not matching
						tag_t tItemTag = NULLTAG;
						int iRevs =0;
						tag_t *ptRevTags =NULL;

						ITK(ITEM_ask_item_of_rev(tLatestRev, &tItemTag));
						ITK(ITEM_list_all_revs(tItemTag, &iRevs, &ptRevTags));
		                /*METHOD_id_t methodIdCreateRev;
		                METHOD_find_method(cObjectType,ITEM_CREATE_REV_MSG,&methodIdCreateRev);
		                /*char * cMessageName = NULL;
		                METHOD_get_message_name(messageMethod.id, &cMessageName);*/
		               // TC_write_syslog("\n Message id is  %d  \n", messageMethod.id);
		                //if(methodIdCreateRev.id == messageMethod.id)
						if(iRevs<=1)
		                {
		                	ITK(AOM_set_value_string(tLatestRev, IS_INITIAL_REV, YES));
		                }

						ITK(AOM_save_with_extensions(tLatestRev));//TC12 Upgrade

						//ITK(AOM_refresh(tLatestRev,false));//check for Catia Issue
						MEM_TCFREE(cObjectType);
						MEM_TCFREE(cObjectTypeSource);
						MEM_TCFREE(cOriginationgSite);
					}
				}
			}
	}
	catch (...)
	{

	}



	TC_write_syslog("\n Exiting Ng5_absItemRevisionRevisePostAction \n");

	return iFail;


}
