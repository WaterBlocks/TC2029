/*********************************************************************************************
 ** File Name:         Ng5_Save_RawMaterial_Info.cxx
 **
 ** File Description:
 ** This file contains the implementation for the Extension Ng5_Save_RawMaterial_Info
 **
 ** History:
 **
 **   mm/dd/yyyy  Name          Comments
 **   ----------  ------------- -------------------------
 **   20/1/2017	 Anil Gummareddypura      Initial Version
 **   05/07/2021 Balaji                   TC12 Upgrade

 ** This Extension is to capture the Raw Material information on Engineered Part Rev about Raw Material associated with Engineered Part Rev.
 ** 1. Capturing of Raw Material object String
 ** 2. Capturing of Raw Material Quantity
 ** 3. Capturing of Raw Material Unit of Measure
 ** 4. On Creation Raw Materials details has to concatenated
 ** 5. On Modifications of RAw Material & Has Raw Material Relation properties has to sync with existing information
 ** 6. Raw Material info located on Engineered Part revision has to persistantly capture the details in Teamcenter application
 ** 7. Data Model is going to capture the constraints object properties
 *********************************************************************************************/

#include <Ng5Core/Ng5_Save_RawMaterial_Info.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <iostream>
#include <string>

using namespace std;

int Ng5_Save_RawMaterial_Info( METHOD_message_t * msg, va_list args ){

	TC_write_syslog ("\n\t Entering  Ng5_Save_RawMaterial_Info...\n" );

	/*Varaibles Initializing, Copying and Parsing of extension triggered arguments*/

	int			iFail	= ITK_ok;
	tag_t  		tPrimaryObjectrev      	= NULLTAG;
	tag_t  		tSecondaryObjectrev    	= NULLTAG;
	tag_t  		tRelationTag           	= NULLTAG;

	va_list largs;
	va_copy(largs,args);
	tRelationTag = va_arg(largs, tag_t);

	tag_t  		tRelationTypeTag  	  	= NULLTAG;
	char   		*robjType  			  	= NULL ;
	int    		inoofGRMObjs			= 0;
	GRM_relation_t  *tGRMObjs      		= NULLTAG;
	char 		*strtmp 				= NULL;
	char 		*chPrimaryobjType		= NULL;
	logical		lFlag 				  	= false;

	if( tRelationTag != NULLTAG){

		NG5_ITK_CALL(GRM_ask_relation_type (tRelationTag,&tRelationTypeTag));

		NG5_ITK_CALL( AOM_ask_value_string (tRelationTag, ATTR_TYPE_STRING, &robjType) );

		/* Finding Primary & Secondary object*/

		if (robjType != NULL && tc_strlen(robjType) > 0 && tc_strcmp ( robjType,HAS_RAW_MATERIAL_RELATION) == 0){

			NG5_ITK_CALL(GRM_ask_primary (tRelationTag,&tPrimaryObjectrev));

			NG5_ITK_CALL(GRM_list_secondary_objects (tPrimaryObjectrev,tRelationTypeTag,&inoofGRMObjs,&tGRMObjs));

			for (int icount =0 ; icount <inoofGRMObjs; icount++){

				char 	*rgrmrelobjType  		= NULL ;
				tag_t   tPIobjTag  				= NULLTAG;
				tag_t   tUOMobjTag  			= NULLTAG;
				char* 	strRawMatUOMVal 		= NULL;
				double 	strRawMatQtyVal     	= 0.00;
				char* 	strRawMatNameVal 		= NULL;
				std::size_t iIntialStrlen 		= 0;
				char   	*rawmatinfo 			= NULL;

				strRawMatUOMVal = (char * ) MEM_alloc ( sizeof(char) * 8);

				/*Capturing the Raw Material requried information*/

				NG5_ITK_CALL( AOM_ask_value_tag (tGRMObjs[icount].secondary,(const char *) ITEMS_TAG, &tPIobjTag) );

				NG5_ITK_CALL(ITEM_ask_unit_of_measure(tPIobjTag,&tUOMobjTag));

				if (tUOMobjTag != NULLTAG) {

					NG5_ITK_CALL (UOM_ask_symbol (tUOMobjTag, &strRawMatUOMVal));

					TC_write_syslog("\n\t UOM value: <%s> ...",strRawMatUOMVal);

				}	else {

					tc_strcpy (strRawMatUOMVal, "each");

				}

				NG5_ITK_CALL( AOM_ask_value_double ( tGRMObjs[icount].the_relation, (const char *) ATTR_RAWMATERIAL_QTY, &strRawMatQtyVal) );

				NG5_ITK_CALL( AOM_ask_value_string ( tGRMObjs[icount].secondary, (const char *) ATTR_RAWMATERIAL_NAME, &strRawMatNameVal) );

				/* Concatinating Raw Material Details and Associating with Raw Material Info located on Enginnered Part Rev*/

				iIntialStrlen = (tc_strlen(strRawMatNameVal) + sizeof(double) + tc_strlen(strRawMatUOMVal)+tc_strlen("|")+1);

				rawmatinfo = (char *) MEM_alloc ( sizeof (char ) * iIntialStrlen);

				snprintf(rawmatinfo, (sizeof (char )* iIntialStrlen) , "%s~%.3f~%s", strRawMatNameVal,strRawMatQtyVal,strRawMatUOMVal);

				tc_strcat(rawmatinfo,"|");

				/* If Raw Material properties are intial capture Raw Material details*/

				if (tc_strcmp(strtmp,NULL)==0 && icount == 0 ){

					strtmp = (char *) MEM_alloc((tc_strlen(rawmatinfo) + 1)*sizeof(char));

					tc_strcpy(strtmp,rawmatinfo);

				} else {  /* If Raw Material properties are already available appened to existing Raw Material details*/

					strtmp = (char *) MEM_realloc(strtmp,(tc_strlen(rawmatinfo) + tc_strlen(strtmp)+ 1)*sizeof(char));

					tc_strcat(strtmp,rawmatinfo);

				}

				NG5_MEM_TCFREE (rawmatinfo);
				NG5_MEM_TCFREE (strRawMatNameVal);
				NG5_MEM_TCFREE (strRawMatUOMVal);

			}   /*Validate and update the Raw Material info on Engineering Part Rev*/
			if (tc_strcmp(strtmp,NULL)!=0){

				TC_write_syslog("\n\t Saved RawMaterial Info: <%s> ...",strtmp);

				NG5_ITK_CALL(WSOM_ask_object_type2(tPrimaryObjectrev,&chPrimaryobjType));

				NG5_ITK_CALL(AM_check_privilege (tPrimaryObjectrev, ACCESS_WRITE, &lFlag));

				if(true == lFlag && (tc_strcmp ( chPrimaryobjType,ENG_PART_REVISION ) == 0)){
					int isNewlyCreated = 0;
					NG5_ITK_CALL(POM_ask_instance_lock(tPrimaryObjectrev,&isNewlyCreated));
					if(!(isNewlyCreated == POM_modify_lock || isNewlyCreated == POM_inst_newly_created))
					{

						NG5_ITK_CALL(AOM_refresh(tPrimaryObjectrev,true));
					}				


					NG5_ITK_CALL(AOM_UIF_set_value ( tPrimaryObjectrev, ATTR_ENGPARTREV_RAWMATINFO, strtmp));

					NG5_ITK_CALL(AOM_save_with_extensions(tPrimaryObjectrev)); //TC 12 Upgrade

					if(!(isNewlyCreated == POM_modify_lock || isNewlyCreated == POM_inst_newly_created))
					{

						NG5_ITK_CALL(AOM_refresh(tPrimaryObjectrev,false));
					}
				}
				NG5_MEM_TCFREE (chPrimaryobjType);
			}
			NG5_MEM_TCFREE (tGRMObjs);
			NG5_MEM_TCFREE (strtmp);
		}
		NG5_MEM_TCFREE (robjType);
	}
	return iFail;
}
