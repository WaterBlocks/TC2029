//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_NonEngPartRevisionImpl
//

#ifndef NG5NEWGENERATION__NG5_NONENGPARTREVISIONIMPL_HXX
#define NG5NEWGENERATION__NG5_NONENGPARTREVISIONIMPL_HXX

#include <Ng5Core/Ng5_NonEngPartRevisionGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_NonEngPartRevisionImpl; 
    class Ng5_NonEngPartRevisionDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_NonEngPartRevisionImpl
    : public ng5newgeneration::Ng5_NonEngPartRevisionGenImpl
{
public:

    ///
    /// Getter for a Tag Array Property
    /// @param values - Parameter value
    /// @param isNull - Returns true for an array element if the parameter value at that location is null
    /// @return - Status. 0 if successful
    ///
    int  getNg5_relatedEngPartRevsBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;

    ///
    /// Setter for a Tag Array Property
    /// @param values - Values to be set for the parameter
    /// @param isNull - If array element is true, set the parameter value at that location as null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_relatedEngPartRevsBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );


protected:
    ///
    /// Constructor for a Ng5_NonEngPartRevision
    explicit Ng5_NonEngPartRevisionImpl( Ng5_NonEngPartRevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_NonEngPartRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_NonEngPartRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_NonEngPartRevisionImpl( const Ng5_NonEngPartRevisionImpl& );

    ///
    /// Copy constructor
    Ng5_NonEngPartRevisionImpl& operator=( const Ng5_NonEngPartRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_NonEngPartRevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_NONENGPARTREVISIONIMPL_HXX
