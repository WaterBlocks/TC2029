//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_rHasLaunch_create_postaction
 *
 */
 
#ifndef NG5_RHASLAUNCH_CREATE_POSTACTION_HXX
#define NG5_RHASLAUNCH_CREATE_POSTACTION_HXX
#include <tccore/method.h>
#include <ug_va_copy.h>
#include <tccore/item.h>
#include <tccore/aom.h>
#include <tccore/aom_prop.h>
#include <tccore/project.h>
#include <fclasses/tc_string.h>
#include <tccore/grm.h>
#include <Ng5Core/libng5core_exports.h>

#define Ng5_SSOPkgRevision 						"Ng5_SSOPkgRevision"
#define object_type								"object_type"
#define Ng5_rHasSSOPackage						"Ng5_rHasSSOPackage"
#define item_id									"item_id"

#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_rHasLaunch_create_postaction(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_RHASLAUNCH_CREATE_POSTACTION_HXX
