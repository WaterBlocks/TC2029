//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_CNRevisionImpl
//

#ifndef NG5NEWGENERATION__NG5_CNREVISIONIMPL_HXX
#define NG5NEWGENERATION__NG5_CNREVISIONIMPL_HXX

#include <Ng5Core/Ng5_CNRevisionGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_CNRevisionImpl; 
    class Ng5_CNRevisionDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_CNRevisionImpl
    : public ng5newgeneration::Ng5_CNRevisionGenImpl
{
public:


    ///
    /// desc for validate for create
    /// @param creInput - desc for creInput parameter
    /// @return - ret desc for validate for create
    ///
    int  validateCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a Ng5_CNRevision
    explicit Ng5_CNRevisionImpl( Ng5_CNRevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_CNRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_CNRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_CNRevisionImpl( const Ng5_CNRevisionImpl& );

    ///
    /// Copy constructor
    Ng5_CNRevisionImpl& operator=( const Ng5_CNRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_CNRevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_CNREVISIONIMPL_HXX
