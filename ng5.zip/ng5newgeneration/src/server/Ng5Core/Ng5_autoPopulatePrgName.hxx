//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*
 * @file
 *
 *   This file contains the declaration for the Extension Ng5_AutoPopulatePrgName
 *
 */

#ifndef NG5_AUTOPOPULATEPRGNAME_HXX
#define NG5_AUTOPOPULATEPRGNAME_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#include <string>

#define ADD_USER_AS_ADMIN "add_user_as_admin"
#define TC_PROJ_ADMIN_ROLE "Program Executive"
#define TC_PROJ_ADMIN_GROUP "Program Management.Internal"
#define TC_PROJ_ADMIN_USER "tcprojadmin"

#ifdef __cplusplus
         extern "C"{
#endif

extern NG5CORE_API int Ng5_autoPopulatePrgName(METHOD_message_t* msg, va_list args);
std::string Ng5_validateProjectName(std::string projectName);
int associate_to_program(tag_t project , tag_t program);
int Ng5_addStatus(char* cStatusName, tag_t tWorkspaceObject);
int Ng5_assignTeamAdmintoProject(tag_t tProjectTag);
int Ng5_add_user_to_project(tag_t tProjTag,tag_t tGrpMemberTag,tag_t tUserIdTag,std::string strUserType,bool isForceAssign,int iMemberCnt,tag_t* tMember,int iAdminUsrCnt,tag_t* tAdminUsr,int iPrivUsrCnt,tag_t* tPrivUsr );
int NG5_pouplate_product_launch(tag_t tProgramItem);
#ifdef __cplusplus
                   }
#endif

#include <Ng5Core/libng5core_undef.h>

#endif  // NG5_AUTOPOPULATEPRGNAME_HXX
