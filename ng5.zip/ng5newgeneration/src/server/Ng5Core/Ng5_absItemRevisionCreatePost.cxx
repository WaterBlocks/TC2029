/*********************************************************************************************
** File Name:        Ng5_absItemRevisionCreatePost.cxx

**
** File Description: This file contains the #defines, macros and error codes for the Adient project
**
**
** History:
** mm/dd/yyyy     Name                  Comments
** ----------          -------               -------------------------
** 12/19/2016  Atish Misal      Initial Creation (AGM ID : 3860	Status Indicator - Differenciate latest and non-latest revisions)
** 05/07/2021  Balaji           TC12 Upgrade

*********************************************************************************************/

#include <Ng5Core/Ng5_absItemRevisionCreatePost.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

using namespace std;

/* This is extension implementation for Item revision (Eng Part, ext Part etc) when create operation is performed.
*  Latest revision overlay icon will be set only for major and minor revisions while revision creation.
*/

int Ng5_absItemRevisionCreatePost( METHOD_message_t *msg, va_list args )
{
 
	    TC_write_syslog("\n Entering Ng5_absItemRevisionCreatePost  \n");
		int iFail = ITK_ok;
		tag_t tNewItem = va_arg(args, tag_t);
		const char* rev_id = va_arg(args, char*);
		tag_t *tNewRevision = va_arg(args, tag_t*);// New  Revision tag

try
{
		if (tNewRevision != NULL )
		{
			if (tNewRevision[0] != NULLTAG)
			{

				logical lValidTag = false;

				tag_t tLatestRev = tNewRevision[0];
                
				// Checking weather tag is valid for setting up latest icon
				ITK(POM_is_tag_valid (tLatestRev,&lValidTag ));

				if (lValidTag == true)
				{

	                ITK(AOM_refresh(tLatestRev,true));

	                ITK(AOM_set_value_string(tLatestRev,ATTR_STATUS_INDICATOR ,ATTR_VALUE_STATUS_INDICATOR));

					ITK(AOM_save_with_extensions(tLatestRev));//TC12 Upgrade

					ITK(AOM_refresh(tLatestRev,false));
				}
			}
		}
}

catch (...)
{

}
		TC_write_syslog("\n Exiting Ng5_absItemRevisionCreatePost \n");
		return iFail;


}
