//@<COPYRIGHT>@
//==================================================
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_NonEngPartImpl( External Design )
//
/*
** File Name:         Ng5_NonEngPartImpl.cxx
**
**   This file contains the implementation for overriding the finalizeCreateInputBase where the mfk counter is initialized
**
**
** History:
**   mm/dd/yyyy  Name           Comments
**   ----------  -------------  -------------------------
**   08/16/2017 Shibabrata Jena Initial Version
*/
#include <Ng5Core/Ng5_NonEngPartImpl.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <tccore/item.h>
#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <vector>
#include <algorithm>    // std::sort
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <sstream>
#include <fclasses/tc_string.h>

using namespace std;
using namespace ng5newgeneration;

#include <fclasses/tc_string.h>
#include <tc/tc.h>

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_NonEngPartImpl::Ng5_NonEngPartImpl(Ng5_NonEngPart& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_NonEngPartImpl::Ng5_NonEngPartImpl( Ng5_NonEngPart& busObj )
   : Ng5_NonEngPartGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_NonEngPartImpl::~Ng5_NonEngPartImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_NonEngPartImpl::~Ng5_NonEngPartImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_NonEngPartImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_NonEngPartImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_NonEngPartGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// Description for the Finalize Create Input
/// @param creInput - desc for  creInput parameter
/// @return - Return desc for Initialize for Create
///
int  Ng5_NonEngPartImpl::finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput )
{
    int ifail = ITK_ok;
    bool	isItemIDNull	=	true;
    bool	isItemTypeNull	=	true;
    bool	isMFKNull	=	true;

    // Call the parent Implementation
    ifail = super_finalizeCreateInputBase(  creInput );
    /*if((Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_ADMIN)||Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_DBA)))
    {
    		//Skipping all Business rules for Admin and dba Group
    	TC_write_syslog("\n Skipping incrementing mfk counter");
    	return ITK_ok;
    }*/

	TC_write_syslog("Entering method finalizeCreateInputBase \n");


	std::string	sItemID;
	std::string sItemType;
	std::string sMfkCounter;

	//Get the Item ID and Design Sub-type from the Design being created
	creInput->getString(ATTR_ITEM_ID, sItemID, isItemIDNull);
	creInput->getString(ATTR_OBJECT_TYPE, sItemType, isItemTypeNull);
	creInput->getString(ATTR_MFK_CTR, sMfkCounter, isMFKNull);

	if(!isMFKNull)
	{
		char** cSearchAttributesParts = NULL;
		char **cSearchAttrcSearchAttributesPartsVals    = NULL;

		int nExtDesgn= 0;
		tag_t *tExtDesgnTags = NULL;

		cSearchAttributesParts = ( char **) MEM_alloc(3 * sizeof(char *));
		cSearchAttrcSearchAttributesPartsVals = ( char **) MEM_alloc(3 * sizeof(char *));
		cSearchAttributesParts[0] = ( char *)MEM_alloc(sizeof(char)*((int) strlen (ATTR_ITEM_ID)+1));
		cSearchAttributesParts[1] = ( char *)MEM_alloc(sizeof(char)*((int) strlen (ATTR_OBJECT_TYPE)+1));
		cSearchAttributesParts[2] = ( char *)MEM_alloc(sizeof(char)*((int) strlen (ATTR_MFK_CTR)+1));

		cSearchAttrcSearchAttributesPartsVals[0]  = ( char *)MEM_alloc(sizeof(char)*((int)strlen (sItemID.c_str())+1));
		cSearchAttrcSearchAttributesPartsVals[1]  = ( char *)MEM_alloc(sizeof(char)*((int)strlen (sItemType.c_str())+1));
		cSearchAttrcSearchAttributesPartsVals[2]  = ( char *)MEM_alloc(sizeof(char)*((int)strlen (sMfkCounter.c_str())+1));

		tc_strcpy((char*)cSearchAttributesParts[0], ATTR_ITEM_ID);
		tc_strcpy((char*)cSearchAttributesParts[1], ATTR_OBJECT_TYPE);
		tc_strcpy((char*)cSearchAttributesParts[2], ATTR_MFK_CTR);

		tc_strcpy((char*)cSearchAttrcSearchAttributesPartsVals[0]  ,sItemID.c_str());
		tc_strcpy((char*)cSearchAttrcSearchAttributesPartsVals[1], SUPPORT_DESIGN);
		tc_strcpy((char*)cSearchAttrcSearchAttributesPartsVals[2], sMfkCounter.c_str());

		ITK(ITEM_find_items_by_key_attributes( 3, (const char**)cSearchAttributesParts, (const char**)cSearchAttrcSearchAttributesPartsVals, &nExtDesgn, &tExtDesgnTags));
		TC_write_syslog("\n No of items found is %d",nExtDesgn);

		NG5_MEM_TCFREE_ARRAY ( cSearchAttributesParts , 3);
		NG5_MEM_TCFREE_ARRAY ( cSearchAttrcSearchAttributesPartsVals, 3);

		if(nExtDesgn > 0)
		{
			if (!isItemIDNull)
				{
					char** cSearchAttributes = NULL;
					char** cSearchAttrVals    = NULL;

					int nItems = 0;
					tag_t *tItemTags = NULL;

					cSearchAttributes = ( char **) MEM_alloc(2 * sizeof(char *));
					cSearchAttrVals   = ( char **) MEM_alloc(2 * sizeof(char *));
					cSearchAttributes[0] = ( char *)MEM_alloc(sizeof(char)*((int) strlen (ATTR_ITEM_ID)+1));
					cSearchAttributes[1] = ( char *)MEM_alloc(sizeof(char)*((int) strlen (ATTR_OBJECT_TYPE)+1));

					cSearchAttrVals[0]  = ( char *)MEM_alloc(sizeof(char)*((int)strlen (sItemID.c_str())+1));
					cSearchAttrVals[1]  = ( char *)MEM_alloc(sizeof(char)*((int)strlen (sItemType.c_str())+1));


					tc_strcpy(cSearchAttributes[0], ATTR_ITEM_ID);
					tc_strcpy(cSearchAttributes[1], ATTR_OBJECT_TYPE);

					tc_strcpy(cSearchAttrVals[0]  ,sItemID.c_str());
					tc_strcpy(cSearchAttrVals[1], SUPPORT_DESIGN);

					ITK(ITEM_find_items_by_key_attributes( 2, (const char**)cSearchAttributes, (const char **)cSearchAttrVals, &nItems, &tItemTags));
					TC_write_syslog("\n No of items found is %d",nItems);

					NG5_MEM_TCFREE_ARRAY ( cSearchAttributes , 2);
					NG5_MEM_TCFREE_ARRAY ( cSearchAttrVals, 2);

					if (nItems > 0 && tItemTags != NULL)
					{
						vector <string> vMfkCounter;
						for(int iNx = 0; iNx< nItems; iNx++ )
						{
							char * cMfkCounter = NULL;
							ITK(AOM_ask_value_string(tItemTags[iNx], ATTR_MFK_COUNTER, &cMfkCounter));
							TC_write_syslog("\n mfk counter is is %s",cMfkCounter);

							if(cMfkCounter != NULL)
							{
								vMfkCounter.push_back(cMfkCounter);
							}

						}
						// sort the vector
						string s1;
						std::sort (vMfkCounter.begin(), vMfkCounter.end());
						for (std::vector<string>::iterator it=vMfkCounter.begin(); it!=vMfkCounter.end(); ++it)
						{
							std::cout << ' ' << *it;
							s1 = *it;
							TC_write_syslog("\n Sorted Vector value %s",s1.c_str());
						}
						TC_write_syslog("\n Sorted Vector Last value %s",s1.c_str());

						 //increment the mfk counter
						int iNewMfk = atoi(s1.c_str());
						iNewMfk += 1;
						string sNewMfkCtr = Ng5_CommonUtils::ZeroPadNumber(iNewMfk);
						TC_write_syslog("\n Sorted Vector Last value %s",sNewMfkCtr.c_str());
						if(tc_strlen(sNewMfkCtr.c_str())> 1)
						{
							logical isNull = false;
							creInput->setString(ATTR_MFK_COUNTER, sNewMfkCtr.c_str(), isNull);
						}
					}

					else
					{
						creInput->setString(ATTR_MFK_COUNTER, MFK_COUNTER_INITIAL_VALUE, false);

					}
					NG5_MEM_TCFREE(tItemTags);

				}
		}
		NG5_MEM_TCFREE(tExtDesgnTags);

	}


	// find the items with the same object type

	else if (!isItemIDNull)
	{
		const char** cSearchAttributes = NULL;
		const char **cSearchAttrVals    = NULL;

		int nItems = 0;
		tag_t *tItemTags = NULL;

		cSearchAttributes = (const char **) MEM_alloc(2 * sizeof(char *));
		cSearchAttrVals = (const char **) MEM_alloc(2 * sizeof(char *));
		cSearchAttributes[0] = (const char *)MEM_alloc(sizeof(char)*((int) strlen (ATTR_ITEM_ID)+1));
		cSearchAttributes[1] = (const char *)MEM_alloc(sizeof(char)*((int) strlen (ATTR_OBJECT_TYPE)+1));

		cSearchAttrVals[0]  = (const char *)MEM_alloc(sizeof(char)*((int)strlen (sItemID.c_str())+1));
		cSearchAttrVals[1]  = (const char *)MEM_alloc(sizeof(char)*((int)strlen (sItemType.c_str())+1));

		cSearchAttributes[0] = ATTR_ITEM_ID;
		cSearchAttributes[1] = ATTR_OBJECT_TYPE;

		cSearchAttrVals[0]  = sItemID.c_str();
		cSearchAttrVals[1]  = EXTERNAL_PART;

		ITK(ITEM_find_items_by_key_attributes( 2, cSearchAttributes, cSearchAttrVals, &nItems, &tItemTags));

		MEM_free(cSearchAttributes);
		MEM_free(cSearchAttrVals);
		TC_write_syslog("\n No of items found is %d",nItems);
		if (nItems > 0 && tItemTags != NULL)
		{
			vector <string> vMfkCounter;
			for(int iNx = 0; iNx< nItems; iNx++ )
			{

				char * cMfkCounter = NULL;
				ITK(AOM_ask_value_string(tItemTags[iNx], ATTR_MFK_COUNTER, &cMfkCounter));
				TC_write_syslog("\n mfk counter is is %s",cMfkCounter);

				if(cMfkCounter != NULL)
				{
					vMfkCounter.push_back(cMfkCounter);
				}

			}
			// sort the vector
			string s1;
			std::sort (vMfkCounter.begin(), vMfkCounter.end());
			 for (std::vector<string>::iterator it=vMfkCounter.begin(); it!=vMfkCounter.end(); ++it)
			 {
					std::cout << ' ' << *it;
					s1 = *it;
					TC_write_syslog("\n Sorted Vector value %s",s1.c_str());
			 }
			 TC_write_syslog("\n Sorted Vector Last value %s",s1.c_str());
			 //increment the mfk counter
			 int iNewMfk = atoi(s1.c_str());
			 iNewMfk += 1;
			 string sNewMfkCtr = Ng5_CommonUtils::ZeroPadNumber(iNewMfk);
			 TC_write_syslog("\n Sorted Vector Last value %s",sNewMfkCtr.c_str());
			 if(tc_strlen(sNewMfkCtr.c_str())> 1)
			 {
				 logical isNull = false;
				 creInput->setString(ATTR_MFK_COUNTER, sNewMfkCtr.c_str(), isNull);
			 }

		}
		else
		{
			creInput->setString(ATTR_MFK_COUNTER, "0000", false);

		}
		MEM_TCFREE(tItemTags);
    }
    TC_write_syslog("Exiting method finalizeCreateInputBase \n");

    return ifail;
}
