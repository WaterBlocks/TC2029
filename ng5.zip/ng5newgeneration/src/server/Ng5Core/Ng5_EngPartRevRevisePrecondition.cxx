/*********************************************************************************************
** File Name:         Ng5_EngPartRevRevisePrecondition.cxx
**
** File Description:
	This file contains the implementation to validate the Revise revise operation and allow revise
	only when the previous revision is already part of Proposed changes of a Change Notice
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   2/27/2017  Shibabrata Jena      Initial Version

*********************************************************************************************/
#include <Ng5Core/Ng5_EngPartRevRevisePrecondition.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <tccore/grm.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>


using namespace ng5newgeneration;
//-----------------------------------------------------------------------------------------------------
// int Ng5_EngPartRevRevisePrecondition( METHOD_message_t * msg, va_list args )
// implementation for the extension on precondition of Item_Copy_rev operation of Eng part revision
// and check whether previous revision is part of proposed changes of Change Notice
//------------------------------------------------------------------------------------------------------
int Ng5_EngPartRevRevisePrecondition( METHOD_message_t * msg, va_list args)
{
	int iFail = ITK_ok;
	/*if((Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_ADMIN)||Ng5_CommonUtils::Ng5_isCurrentGroup(GROUP_DBA)))
	{
		//skipping for DBA and Admin
		TC_write_syslog("\n Skipping  Revise precondition Validation for dba and admin");
		return ITK_ok;
	}

	TC_write_syslog("\n Entering Ng5_EngPartRevRevisePrecondition  \n");
	int iFail = ITK_ok;

	tag_t tSourceRev = va_arg(args, tag_t);
	const char* cRevId = va_arg(args, char*);
	tag_t *tNewRevision = va_arg(args, tag_t*);


	try
	{
		// New  Revision tag
		if(tSourceRev != NULLTAG)
		{
			char *cOriginationgSite = NULL;
			ITK(AOM_ask_value_string(tSourceRev, ORIGINATING_SITE, &cOriginationgSite));

			TC_write_syslog("\n Originating system is %s  \n", cOriginationgSite);
			if(tc_strlen(cOriginationgSite) < 1  || (tc_strcmp(cOriginationgSite, FPDM_EU) == 0 ))
			{
				if(cRevId != NULL)
				{
					//check if revision is minor rev
					logical isMinorRev = false;

					isMinorRev = Ng5_CommonUtils::isMinorRevision((char*)cRevId);
					if(!isMinorRev)
					{
						logical isCNInitiated = false;
						tag_t trelType = NULLTAG;
						int iPrimCN = 0;
						tag_t *tPrimCNs = NULL;
						ITK(GRM_find_relation_type(PROPOSED_CHANGES, &trelType));
						ITK(GRM_list_primary_objects_only(tSourceRev, trelType, &iPrimCN, &tPrimCNs));
						if(iPrimCN > 0 && tPrimCNs != NULL)
						{
							int iCNCount = 0;

							for(int iNx= 0; iNx< iPrimCN; iNx++)
							{
								char*cObjType = NULL;
								AOM_ask_value_string(tPrimCNs[iNx], ATTR_OBJECT_TYPE, &cObjType);

								TC_write_syslog("\n Change object type is %s  \n", cObjType);

								if(tc_strcmp(cObjType, CN_REVISION) == 0)
								{
									// CN found
									//iSCNFound = true;
									// check ChangeState attribute on CN

									iCNCount +=1;
									char * cChangeState = NULL;
									ITK(AOM_ask_value_string(tPrimCNs[iNx], ATTR_CHANGE_STATE, &cChangeState));
									if(tc_strcmp(cChangeState, INITIATED) == 0)
									{
										//do nothing
										isCNInitiated = true;
									}/*
									else
									{
										ITK(EMH_store_error_s1(EMH_severity_error, ErrorCodeForRevise, VALIDATION_ERROR));
										return ErrorCodeForRevise;
									}
									MEM_TCFREE(cChangeState)

								}
								MEM_TCFREE(cObjType);
							}
							if(!isCNInitiated)
										{
											ITK(EMH_store_error_s1(EMH_severity_error, ErrorCodeForRevise, VALIDATION_ERROR));
											return ErrorCodeForRevise;
										}
												
							else if(iCNCount ==0)
							{
								 ITK(EMH_store_error_s1(EMH_severity_error, ErrorCodeForRevise, VALIDATION_ERROR));
								 return ErrorCodeForRevise;
							}
						}
						else
						{

							 ITK(EMH_store_error_s1(EMH_severity_error, ErrorCodeForRevise, VALIDATION_ERROR));
							 return ErrorCodeForRevise;
						}
					}
				}
			}
		}


	}

	catch (...)
	{

	}

	TC_write_syslog("\n Exiting Ng5_EngPartRevRevisePrecondition \n");*/
	return iFail;

}
