//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_RawMaterialImpl
//

#ifndef NG5NEWGENERATION__NG5_RAWMATERIALIMPL_HXX
#define NG5NEWGENERATION__NG5_RAWMATERIALIMPL_HXX

#include <Ng5Core/Ng5_RawMaterialGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_RawMaterialImpl; 
    class Ng5_RawMaterialDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_RawMaterialImpl
    : public ng5newgeneration::Ng5_RawMaterialGenImpl
{
public:

    ///
    /// Getter for a Tag Array Property
    /// @param values - Parameter value
    /// @param isNull - Returns true for an array element if the parameter value at that location is null
    /// @return - Status. 0 if successful
    ///
   // int  getNg5_replacement_forBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;


protected:
    ///
    /// Constructor for a Ng5_RawMaterial
    explicit Ng5_RawMaterialImpl( Ng5_RawMaterial& busObj );

    ///
    /// Destructor
    virtual ~Ng5_RawMaterialImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_RawMaterialImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_RawMaterialImpl( const Ng5_RawMaterialImpl& );

    ///
    /// Copy constructor
    Ng5_RawMaterialImpl& operator=( const Ng5_RawMaterialImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_RawMaterialDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_RAWMATERIALIMPL_HXX
