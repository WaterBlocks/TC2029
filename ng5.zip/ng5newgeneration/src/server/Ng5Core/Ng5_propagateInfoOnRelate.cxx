//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


/*****************************************************************************
Function: 	Ng5_propagateInfoOnRelate

Summary

The code will synch attributes, and dynamic participants
between the Primary and Secondary objects upon creation of a relationship.

The following preferences are used to configure the code:

---------------------------------------------------------------------------------------------
Preference Name: 	Ng5_Propagate<Relation Type>
Purpose:			Used to define what direction attributes and/or participants are to be copied

Format of Values:	<Primary Type>_<Secondary Type>:Secondary Attributes
                    (To copy Secondary attributes to Primary Object)

                    <Primary Type>_<Secondary Type>:Primary Attributes
                    (To copy Primary attributes to Secondary Object)

                    <Primary Type>_<Secondary Type>:Secondary Participants
                    (To copy Secondary participants to Primary Object)

                    <Primary Type>_<Secondary Type>:Primary Participants
                    (To copy Primary participants to Primary Object)

                    <Primary Type>_<Secondary Type>:Secondary Relations
                    (To copy Secondary Relations to Primary Object)

                    <Primary Type>_<Secondary Type>:Primary Relations
                    (To copy Primary Relations to Primary Object)

----------------------------------------------------------------------------------------------
Preference Name:	Ng5_CopyAttributesSec<Relation Type>_<Primary Type>_<Secondary Type>
Purpose:			Used to define what attributes get copied from the Secondary Object to the Primary Object
Format of Values	<Attribute Name>

Preference Name:	Ng5_CopyAttributesPri<Relation Type>_<Primary Type>_<Secondary Type>
Purpose:			Used to define what attributes get copied from the Primary Object to the Secondary Object
Format of Values	<Attribute Name>

Preference Name:	Ng5_CopyParticipantsSec<Relation Type>_<Primary Type>_<Secondary Type>
Purpose:			Used to define what participants get copied from the Secondary Object to the Primary Object
Format of Values	<Participant Type>:<Flag>
(For instances where the From and To Participant are the same)
<From Participant Type>/<To Participant Type>:<Flag>
(For instances where the From and To Participant are NOT the same)
Flag = "A" or "O" or "C"		Where:A=Append; O=Override; C=Clear
Append: Appends the Participants list from the source object to target object
Override: Clears the existing the Participants list from the target object, then adds the Participants list from the source object to target object
Clear: Clears the Participants list from the target object

Preference Name:	Ng5_CopyParticipantsPri<Relation Type>_<Primary Type>_<Secondary Type>
Purpose:			Used to define what participants get copied from the Primary Object to the Secondary Object
Format of Values	<Participant Type>:<Flag>
(For instances where the From and To Participant are the same)
<From Participant Type>/<To Participant Type>:<Flag>
(For instances where the From and To Participant are NOT the same)
Flag = "A" or "O" or "C"		Where:A=Append; O=Override; C=Clear
Append: Appends the Participants list from the source object to target object
Override: Clears the existing the Participants list from the target object, then adds the Participants list from the source object to target object
Clear: Clears the Participants list from the target object

Preference Name:	Ng5_CopyRelationsSec<Relation Type>_<Primary Type>_<Secondary Type>
Purpose:			Used to define what relations get copied from the Secondary Object to the Primary Object
Format of Values	<Relations Type>

Preference Name:	Ng5_CopyAttributesPri<Relation Type>_<Primary Type>_<Secondary Type>
Purpose:			Used to define what relations get copied from the Primary Object to the Secondary Object
Format of Values	<Relations Type>


----------------------------------------------------------------------------------------------

* Operation-Attachment : GRM_create - Post Action

Currently used on CMImplements Relation Objects

Change History
Date		Name					Comments
04/11/2012	Daniel Atherton			Created
08/13/2014	Anand Prasad Raja       Modified to copy relations
11/01/2017  Vijayakumar Bala		Modified Function int ng5_copyParticipant(tag_t sourceObject, tag_t targetObject,  string strPrefValue)
                                     Flag = "A" or "O" or "C"		Where:A=Append; O=Override; C=Clear
                                     Append: Appends the Participants list from the source object to target object
                                     Override: Clears the existing the Participants list from the target object, then adds the Participants list from the source object to target object
                                     Clear: Clears the Participants list from the target object

06/30/2021  Balaji 			  		Modified function Ng5_propagateInfoOnRelate shifted the logic to propagate participant
									from CR to CN and PRG to CN from Ng5_propagateCRParticipantsOnCN
**************************************************************************************/


#include <Ng5Core/Ng5_propagateInfoOnRelate.hxx>
#include <Ng5Core/Ng5_propagateCRParticipantsOnCN.hxx>
#include "Ng5_CommonUtils.hxx"

#include <base_utils/ScopedSmPtr.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include "string.h"
#include <sstream>
#include <vector>


using namespace std;
using namespace Teamcenter;
using namespace ng5newgeneration;
tag_t tCRRevionTag = NULLTAG;
int Ng5_propagateInfoOnRelate( METHOD_message_t * /*msg*/, va_list args )
{
    int iFail  = ITK_ok;
    int iLoop = 0;
    int iPrefValues = 0;
    int iCheckPropertyResult = 0;
    int iCopyPrimaryAttributes = 0;
    int iCopySecondaryAttributes = 0;
    int iCopyPrimaryParticipants = 0;
    int iCopySecondaryParticipants = 0;
	int iCopyPrimaryRelations = 0;
	int iCopySecondaryRelations = 0;
	int iRelatedObjCount = 0;
	int isTargetSec = 1;
	int iVal = 0;

    scoped_smptr<char>  pcPrimaryObjectTypeName;
    scoped_smptr<char>  pcSecondaryObjectTypeName;
    scoped_smptr<char>  pcRelationTypeName;

    scoped_smptr<char*> pcPreferenceValues;

	logical lAlreadyHasRelation = false;
    string strErrorText = "";
    string strTempString = "";
    string strPreferenceName = "";
	tag_t* tRelatedObejcts = NULL;
	string szPreferenceName = "";

    /* Arguements sent to the message */
    tag_t  tPrimaryObject      = va_arg(args, tag_t);
    tag_t  tSecondaryObject    = va_arg(args, tag_t);
    tag_t  tRelationType       = va_arg(args, tag_t);
    tag_t  tUserData           = va_arg(args, tag_t);
    tag_t  *tNewRelation       = va_arg(args, tag_t*);
    TC_write_syslog("\n tNewRelation %d",tNewRelation[0]);

//    TC_preference_search_scope_t old_scope;
    NG5_ITK_CALL(WSOM_ask_object_type2(tPrimaryObject, &pcPrimaryObjectTypeName));
    TC_write_syslog("\n pcPrimaryObjectTypeName %s", string(pcPrimaryObjectTypeName.getString()).c_str());
    if (iFail != ITK_ok){return iFail;}

    NG5_ITK_CALL(WSOM_ask_object_type2(tSecondaryObject, &pcSecondaryObjectTypeName));
    TC_write_syslog("\n pcSecondaryObjectTypeName %s", string(pcSecondaryObjectTypeName.getString()).c_str());
    if (iFail != ITK_ok){return iFail;}

    NG5_ITK_CALL(TCTYPE_ask_name2(tRelationType, &pcRelationTypeName));
    TC_write_syslog("\n pcRelationTypeName %s", string(pcRelationTypeName.getString()).c_str());
    if (iFail != ITK_ok){return iFail;}

    strPreferenceName = NG5_COPY_PREFIX;
    strPreferenceName += string(pcRelationTypeName.getString());

    TC_write_syslog("\nPreference Name %s", strPreferenceName.c_str());
    // The following code determines what should be copied between the objects
	iFail = PREF_ask_char_values_at_location( (const char*) strPreferenceName.c_str(), TC_preference_site, &iPrefValues, &pcPreferenceValues);

	if(iFail != ITK_ok)
	{
		return ITK_ok;
	}

    for(iLoop = 0; iLoop < iPrefValues ; iLoop++)
        {
    	strTempString = string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString()) + ":" + NG5_PROCESSPRIATTR;
        if (string(pcPreferenceValues.get()[iLoop]) == strTempString)
            {
            iCopyPrimaryAttributes = 1;
            }
		strTempString = string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString()) + ":" + NG5_PROCESSSECATTR;
        if (string(pcPreferenceValues.get()[iLoop]) == strTempString)
            {
            iCopySecondaryAttributes = 1;
            }
		strTempString = string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString()) + ":" + NG5_PROCESSPRIPART;
        if (string(pcPreferenceValues.get()[iLoop]) == strTempString)
            {
            iCopyPrimaryParticipants = 1;
            }
		strTempString = string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString()) + ":" + NG5_PROCESSSECPART;
        if (string(pcPreferenceValues.get()[iLoop]) == strTempString)
            {
            iCopySecondaryParticipants = 1;
            }
		strTempString = string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString()) + ":" + NG5_PROCESSPRIRELATION;
        if (string(pcPreferenceValues.get()[iLoop]) == strTempString)
            {
            iCopyPrimaryRelations = 1;
            }
		strTempString = string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString()) + ":" + NG5_PROCESSSECRELATION;
        if (string(pcPreferenceValues.get()[iLoop]) == strTempString)
            {
            iCopySecondaryRelations = 1;
            }
        }
    /*
    The following set of code will copy attributes from the secondary object to the primary object
    This is a typical requirement for deriving a change for example if a CN is derived from a CR
    Customers Typically want attributes to go from the CR to the CN.
    For an Implements relationsip, the CR is Secondary and the CN is Primary.
    */

    if ( iCopySecondaryAttributes == 1)
        {
        // Find the Preference name and then the preference values
		strPreferenceName = NG5_ATTRIBUTE_PREFIX;
		strPreferenceName += "Sec" + string(pcRelationTypeName.getString()) + "_" + string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString());

		iFail = PREF_ask_char_values_at_location( (const char*)strPreferenceName.c_str(), TC_preference_site, &iPrefValues, &pcPreferenceValues);

        if(iPrefValues > 0 && iFail == ITK_ok)
            {
            for(iLoop = 0; iLoop < iPrefValues ; iLoop++)
                {
                // Find out if the value is already set.  If it is, do not set the value.
                iCheckPropertyResult = ng5_checkProperty( tSecondaryObject, tPrimaryObject, string(pcPreferenceValues.get()[iLoop]));
                if (iCheckPropertyResult == 1)
                    {
                    continue;
                    }
                else
                    {
                    if (iCheckPropertyResult == 0)
                        {
                    	NG5_ITK_CALL(ng5_copyProperty( tSecondaryObject, tPrimaryObject, string(pcPreferenceValues.get()[iLoop])));
                        if (iFail != ITK_ok)
                            {
                        	strErrorText = "Error Copying Attributes from " + string(pcSecondaryObjectTypeName.getString()) + " to " + string(pcPrimaryObjectTypeName.getString()) + " for Preference Entry " + string(pcPreferenceValues.get()[iLoop]) + "\n";
                        	ng5_propagate_errors (iFail, strErrorText, 1);
                            }
                        }
                    else
                        {
                        strErrorText = "Error Copying Attributes from " + string(pcSecondaryObjectTypeName.getString()) + " to " + string(pcPrimaryObjectTypeName.getString()) + " for Preference Entry " + string(pcPreferenceValues.get()[iLoop]) + "\n";
                        ng5_propagate_errors (iCheckPropertyResult,strErrorText,1);
                        continue;
                        }
                    }
                }
            }
        }
    /*
    The following set of code will copy attributes from the primary object to the secondary object.
    This will allow for extended use cases.  For example this may be used for copying attributes between Parts
    And Designs.
    */
    if ( iCopyPrimaryAttributes == 1)
        {
        // Find the Preference name and then the preference values
		strPreferenceName = NG5_ATTRIBUTE_PREFIX;
		strPreferenceName += "Pri" + string(pcRelationTypeName.getString()) + "_" + string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString());

		iFail = PREF_ask_char_values_at_location( (const char*)strPreferenceName.c_str(), TC_preference_site, &iPrefValues, &pcPreferenceValues);

        if(iPrefValues > 0 && iFail == ITK_ok)
            {
            for(iLoop = 0; iLoop < iPrefValues ; iLoop++)
                {
                // Find out if the value is already set.  If it is, do not set the value.
                iCheckPropertyResult = ng5_checkProperty( tPrimaryObject, tSecondaryObject, string(pcPreferenceValues.get()[iLoop]));

                if (iCheckPropertyResult == 1)
                    {
                    continue;
                    }
                else
                    {
                    if (iCheckPropertyResult == 0)
                        {
                    	NG5_ITK_CALL(ng5_copyProperty( tPrimaryObject, tSecondaryObject, string(pcPreferenceValues.get()[iLoop])));
                        if (iFail != ITK_ok)
                            {
                        	strErrorText = "Error Copying Attributes from " + string(pcPrimaryObjectTypeName.getString()) + " to " + string(pcSecondaryObjectTypeName.getString()) + " for Preference Entry " + string(pcPreferenceValues.get()[iLoop]) + "\n";
                            ng5_propagate_errors (iFail,strErrorText,1);
                            }
                        }
                    else
                        {
                    	strErrorText = "Error Copying Attributes from " + string(pcPrimaryObjectTypeName.getString()) + " to " + string(pcSecondaryObjectTypeName.getString()) + " for Preference Entry " + string(pcPreferenceValues.get()[iLoop]) + "\n";
                        ng5_propagate_errors (iCheckPropertyResult,strErrorText,1);
                        continue;
                        }
                    }
                }
            }
        }

    /*
    The following set of code will copy participants from the secondary object to the primary object
    This is a typical requirement for deriving a change for example if a CN is derived from a CR
    Customers Typically want the users who participate in the CR to participate in the CN.
    For an Implements relationsip, the CR is Secondary and the CN is Primary.
    */
    if ( iCopySecondaryParticipants == 1)
        {
		int iRelatedCount = 0;
		GRM_relation_t* tRelatedObject;
		NG5_ITK_CALL(GRM_list_all_related_objects(tPrimaryObject, &iRelatedCount, &tRelatedObject));

		for (int iIndex = 0; iIndex < iRelatedCount; iIndex++)
		{
			if (tRelatedObject[iIndex].relation_type == tRelationType)
			{
				if (tRelatedObject[iIndex].secondary != NULLTAG )
				{
					lAlreadyHasRelation = true;
					break;
				}
			}
		}
		strPreferenceName = NG5_PARTICIPANT_PREFIX;
		strPreferenceName += "Sec" + string(pcRelationTypeName.getString())+ "_" + string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString());

		iFail = PREF_ask_char_values_at_location( (const char*)strPreferenceName.c_str(), TC_preference_site, &iPrefValues, &pcPreferenceValues );

        if(iPrefValues > 0  && iFail == ITK_ok)
            {
            for(iLoop = 0; iLoop < iPrefValues  ; iLoop++)
                {
            	NG5_ITK_CALL(ng5_copyParticipant(tSecondaryObject, tPrimaryObject, string(pcPreferenceValues.get()[iLoop]), lAlreadyHasRelation));
                if (iFail != ITK_ok)
                    {
                	strErrorText = "Error Copying Participants from " + string(pcSecondaryObjectTypeName.getString()) + " to " + string(pcPrimaryObjectTypeName.getString()) + " for Preference Entry " + string(pcPreferenceValues.get()[iLoop]) + "\n";
                    ng5_propagate_errors (iFail,strErrorText,1);
                    }
                }

            }
        }
    /*
    The following set of code will copy participants from the primary object to the secondary object.
    */
    if ( iCopyPrimaryParticipants == 1)
        {
		int iRelatedCount = 0;
		GRM_relation_t* tRelatedObject;
		NG5_ITK_CALL(GRM_list_all_related_objects(tPrimaryObject, &iRelatedCount, &tRelatedObject));

		for (int iIndex = 0; iIndex < iRelatedCount; iIndex++)
		{
			if (tRelatedObject[iIndex].relation_type == tRelationType)
			{
				if (tRelatedObject[iIndex].primary != NULLTAG )
				{
					lAlreadyHasRelation = true;
					break;
				}
			}
		}

		strPreferenceName = NG5_PARTICIPANT_PREFIX;
		strPreferenceName += "Pri" + string(pcRelationTypeName.getString()) + "_" + string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString());

		iFail = PREF_ask_char_values_at_location( (const char*)strPreferenceName.c_str(),TC_preference_site, &iPrefValues, &pcPreferenceValues );

        if(iPrefValues > 0)
            {
            for(iLoop = 0; iLoop < iPrefValues  ; iLoop++)
                {
                NG5_ITK_CALL(ng5_copyParticipant(tPrimaryObject, tSecondaryObject, string(pcPreferenceValues.get()[iLoop]), lAlreadyHasRelation));
                if (iFail != ITK_ok)
                    {
                	strErrorText = "Error Copying Participants from " + string(pcPrimaryObjectTypeName.getString()) + " to " + string(pcSecondaryObjectTypeName.getString()) + " for Preference Entry " + string(pcPreferenceValues.get()[iLoop]) + "\n";
                    ng5_propagate_errors (iFail,strErrorText,1);
                    }
                }
            }
        }

	    /*
    The following set of code will copy relations from the primary object to the secondary object.
    */
	if ( iCopyPrimaryRelations == 1)
	{
		strPreferenceName = NG5_RELATION_PREFIX;
		strPreferenceName += "Pri" + string(pcRelationTypeName.getString()) + "_" + string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString());

		iFail = PREF_ask_char_values_at_location( (const char*)strPreferenceName.c_str(), TC_preference_site, &iPrefValues, &pcPreferenceValues );

		if(iPrefValues > 0)
		{
			for(iLoop = 0; iLoop < iPrefValues  ; iLoop++)
			{
				//Getting all the related objects
				tRelatedObejcts = ng5_getRelatedObjects(tPrimaryObject, string(pcPreferenceValues.get()[iLoop]), &iRelatedObjCount ,&isTargetSec);

				if(iRelatedObjCount > 0)
				{
					for(iVal = 0 ; iVal <iRelatedObjCount;iVal++)
					{
						NG5_ITK_CALL(ng5_copyRelations(tRelatedObejcts[iVal], tSecondaryObject, string(pcPreferenceValues.get()[iLoop]) , isTargetSec));

					}
				}
				iRelatedObjCount = 0;
				isTargetSec = 1;
				tRelatedObejcts = NULL;

				if (iFail != ITK_ok)
				{
					strErrorText = "Error Copying Relations from " + string(pcPrimaryObjectTypeName.getString()) + " to " + string(pcSecondaryObjectTypeName.getString()) + " for Preference Entry " + string(pcPreferenceValues.get()[iLoop]) + "\n";
					ng5_propagate_errors (iFail,strErrorText,1);
				}
			}

		}
	}

	 /*
    The following set of code will copy relations from the secondary object to the primary object */
	if ( iCopySecondaryRelations == 1)
	{
		strPreferenceName = NG5_RELATION_PREFIX;
		strPreferenceName += "Sec" + string(pcRelationTypeName.getString()) + "_" + string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString());

		iFail = PREF_ask_char_values_at_location( (const char*)strPreferenceName.c_str(), TC_preference_site, &iPrefValues, &pcPreferenceValues );

		if(iPrefValues > 0)
		{
			for(iLoop = 0; iLoop < iPrefValues  ; iLoop++)
			{
				tRelatedObejcts = ng5_getRelatedObjects(tSecondaryObject, string(pcPreferenceValues.get()[iLoop]), &iRelatedObjCount ,&isTargetSec);
				if(iRelatedObjCount > 0)
				{
					for(iVal = 0 ; iVal <iRelatedObjCount;iVal++)
					{
						NG5_ITK_CALL(ng5_copyRelations(tRelatedObejcts[iVal], tPrimaryObject,  string(pcPreferenceValues.get()[iLoop]) , isTargetSec));
					}
				}

				iRelatedObjCount = 0;
				isTargetSec = 1;
				tRelatedObejcts = NULL;

				if (iFail != ITK_ok)
				{
					strErrorText = "Error Copying Relations from " + string(pcPrimaryObjectTypeName.getString()) + " to " + string(pcSecondaryObjectTypeName.getString()) + " for Preference Entry " + string(pcPreferenceValues.get()[iLoop]) + "\n";
					ng5_propagate_errors (iFail,strErrorText,1);
				}
			}

		}
	}

	/* Changes Added By Balaji */


	    TC_write_syslog("\n Starting New Code Added ......................................");
		char *szIsCRParticipant = NULL;
		char* objecttype=NULL;
		WSOM_ask_object_type2(tPrimaryObject,&objecttype);
if(tc_strcmp(objecttype,"Ng5_MMTransferRevision")!=0)
	{
		NG5_ITK_CALL(AOM_ask_value_string(tPrimaryObject,CopyParticipant, &szIsCRParticipant));
	    TC_write_syslog("\n szIsCRParticipant : %s......................................",szIsCRParticipant);

		if( tc_strcmp(szIsCRParticipant,"Yes")== 0)
		{
			// Copy CR Participants set to YES
			tag_t* tChangeRequest = NULL;
			int iCRCount =0;

			NG5_ITK_CALL(GRM_list_secondary_objects_only(tPrimaryObject,NULLTAG,&iCRCount,&tChangeRequest));

			TC_write_syslog("\n -----------iCRCount %d------\n", iCRCount);
			int iAttPrg_Count=0;
			for( int iL = 0; iL < iCRCount  ; iL++)
			{
				scoped_smptr<char> szObjtype;
				tag_t tObjtype = NULLTAG;

				NG5_ITK_CALL(TCTYPE_ask_object_type(tChangeRequest[iL], &tObjtype));
				if(tObjtype != NULLTAG) NG5_ITK_CALL(TCTYPE_ask_name2(tObjtype, &szObjtype));
				TC_write_syslog("\n -----------tChangeRequest[iL]  szObjtype : %s------\n", string(szObjtype.getString()).c_str());

				if((tc_strcmp(CHANGE_REQUEST_REVISION,string(szObjtype.getString()).c_str())==0   &&  tChangeRequest[iL] != tSecondaryObject) || (tCRRevionTag == tPrimaryObject))
				{
					lAlreadyHasRelation =true;
					break;

				}

			}
			if(!lAlreadyHasRelation)
			{
				tCRRevionTag = tPrimaryObject;
			}
			MEM_TCFREE(szIsCRParticipant);
			MEM_free(tChangeRequest);
			szPreferenceName = string(pcPrimaryObjectTypeName.getString()) + "_" + string(pcSecondaryObjectTypeName.getString()) + "_ParticipantsMap";
			int iPrefValues = 0;
			scoped_smptr<char*> pcPreferenceValues;
			iFail = PREF_ask_char_values_at_location((const char*)szPreferenceName.c_str(), TC_preference_site, &iPrefValues, &pcPreferenceValues);
			if(iPrefValues > 0  && iFail == ITK_ok)
			{
				for(int iLoop = 0; iLoop < iPrefValues  ; iLoop++)
				{
					 TC_write_syslog("\n -----------pcPreferenceValues[%d]  : %s------\n",iLoop, string(pcPreferenceValues.get()[iLoop]).c_str());
					if(lAlreadyHasRelation)
					{
						vector<string> vecPropSplit= Ng5_CommonUtils::splitStringToVector(string(pcPreferenceValues.get()[iLoop]), ":");
						NG5_ITK_CALL(ng5_remove_participants(tPrimaryObject, vecPropSplit[0]));

					}else
					{
						vector<string> vecPropSplit= Ng5_CommonUtils::splitStringToVector(string(pcPreferenceValues.get()[iLoop]), ":");
						NG5_ITK_CALL(ng5_remove_participants(tPrimaryObject, vecPropSplit[0]));

						NG5_ITK_CALL(ng5_copyParticipant(tSecondaryObject, tPrimaryObject, string(pcPreferenceValues.get()[iLoop]), false));

					}
				}

			}

		}
		/* End of Changes Added By Balaji */
	}
    return ITK_ok;
    }

/**********************************************************************
Function: 	ng5_getRelatedObjects

Summary

This code will return the related objects , count and the relation is
creted between  primary to secondary or secondary to primary

isTargetSec = 0 - Traversed and return secondary objects
isTargetSec = 1 - Traversed and return primary objects


Change History
Date		Name					Comments
08/12/2014	Anand Prasad Raja	     Created
***********************************************************************/



tag_t* ng5_getRelatedObjects(tag_t tObject , string strRelationName , int *iRelatedObjectsCount , int* isTargetSec )
{

	tag_t*   tRelatedObjects   = NULL;
	tag_t    tRelationTag      = NULLTAG;
	int iRelObjCount = 0;
	int iFail = ITK_ok;


	NG5_ITK_CALL(GRM_find_relation_type((const char*)strRelationName.c_str(),&tRelationTag));


	if(tRelationTag != NULLTAG)
	{
		NG5_ITK_CALL(GRM_list_primary_objects_only( tObject, tRelationTag, &iRelObjCount, &tRelatedObjects ));

		if((iRelatedObjectsCount == 0) || (tRelatedObjects == NULL))
		{
			NG5_ITK_CALL(GRM_list_secondary_objects_only( tObject, tRelationTag,& iRelObjCount, &tRelatedObjects ));
			*isTargetSec = 0;
		}
	 *iRelatedObjectsCount = iRelObjCount;

	}

	return tRelatedObjects;
}

/**********************************************************************
Function: 	ng5_copyRelations

Summary

This code will create relation between two objects

isTargetSec = 0 - Traverse and create relation to secondary objects
isTargetSec = 1 - Traverse and creare relation to primary objects


Change History
Date		Name					Comments
08/12/2014	Anand Prasad Raja	     Created
***********************************************************************/

int ng5_copyRelations(tag_t sourceObject, tag_t targetObject,  string strRelationName , int isTargetSec)
{

	tag_t tRelationTag = NULLTAG;
	tag_t tExistingRel = NULLTAG;
	tag_t tNewRelation = NULLTAG;
	int iFail = ITK_ok;

	if(tc_strcmp(strRelationName.c_str(),HASVALIDATIONREPORT)==0)
	{
	  char* datasetType = NULL;
      if(isTargetSec==1)
      {
    	  WSOM_ask_object_type2	(targetObject,&datasetType);

      }
      else
      {
    	  WSOM_ask_object_type2	(sourceObject,&datasetType);

      }
      if(tc_strcmp(datasetType,HTML)!=0)
      {
    	  return iFail;
      }
      NG5_MEM_TCFREE (datasetType);
	}
	NG5_ITK_CALL(GRM_find_relation_type((const char*)strRelationName.c_str(),&tRelationTag));
	if (iFail != ITK_ok){ return iFail;}

	if(tRelationTag != NULLTAG)
	{
		if(isTargetSec == 1)
		{
			NG5_ITK_CALL(GRM_find_relation( sourceObject,targetObject, tRelationTag, &tExistingRel ));
			if( tExistingRel == NULLTAG)
			{
				NG5_ITK_CALL(GRM_create_relation( sourceObject, targetObject, tRelationTag, NULLTAG, &tNewRelation ));
				NG5_ITK_CALL(GRM_save_relation( tNewRelation ));
			}

		}
		else if(isTargetSec == 0)
		{
			NG5_ITK_CALL(GRM_find_relation(targetObject, sourceObject, tRelationTag, &tExistingRel ));
			if( tExistingRel == NULLTAG)
			{
				NG5_ITK_CALL(GRM_create_relation( targetObject, sourceObject, tRelationTag, NULLTAG, &tNewRelation ));
				NG5_ITK_CALL (GRM_save_relation( tNewRelation ));
			}
		}
	}

	return iFail;
}



/**********************************************************************
Function: 	ng5_copyProperty

Summary

This code will copy an attribute values from the source object to
the target object.

Change History
Date		Name					Comments
04/11/2012	Daniel Atherton			Created
***********************************************************************/

int ng5_copyProperty(tag_t tSourceObject, tag_t  tTargetObject, string strPropName)
    {
    int iFail = ITK_ok;
    int iIntegerValues = 0;
    int num = 0;

    double dblDoubleValues = 0.0;
    scoped_smptr<char> pcPropertyTypeName;
    scoped_smptr<char> pcValueTypeName;
    scoped_smptr<char*> pcStringValues;
    scoped_smptr<tag_t>  tagValues;
    PROP_type_t proptype;
    PROP_value_type_t  valtype;
    date_t dtDateValues;
    logical lLogicalValues = FALSE;
	tag_t tRelationType = NULLTAG;

    //TC_write_syslog("Copying Property %s",propName);

    //Check whether the attribute exists
    NG5_ITK_CALL(AOM_ask_property_type(tSourceObject, (const char*)strPropName.c_str(), &proptype, &pcPropertyTypeName));
    if (iFail != ITK_ok){ return iFail;}

    //Proceed if the Attribute exists
    if(proptype != PROP_unknown)
        {
        NG5_ITK_CALL(AOM_ask_value_type(tSourceObject, (const char*)strPropName.c_str(), &valtype, &pcValueTypeName));
        if (iFail != ITK_ok){ return iFail;}

        NG5_ITK_CALL(AOM_lock(tTargetObject));
        if (iFail != ITK_ok){ return iFail;}

        //Set the value using calls that are attribute type dependent
        switch(valtype)
            {
            case PROP_int:
                NG5_ITK_CALL(AOM_ask_value_int(tSourceObject,(const char*)strPropName.c_str(),&iIntegerValues));
                if (iFail != ITK_ok){ return iFail;}
                NG5_ITK_CALL(AOM_set_value_int(tTargetObject,(const char*)strPropName.c_str(),iIntegerValues));
                if (iFail != ITK_ok){ return iFail;}
                break;

            case PROP_float:
                NG5_ITK_CALL(AOM_ask_value_double(tSourceObject, (const char*)strPropName.c_str(),&dblDoubleValues));
                if (iFail != ITK_ok){ return iFail;}
                NG5_ITK_CALL(AOM_set_value_double(tTargetObject,(const char*)strPropName.c_str(),dblDoubleValues));
                if (iFail != ITK_ok){ return iFail;}
                break;

            case PROP_double:
                NG5_ITK_CALL(AOM_ask_value_double(tSourceObject,(const char*)strPropName.c_str(),&dblDoubleValues));
                if (iFail != ITK_ok){ return iFail;}
                NG5_ITK_CALL(AOM_set_value_double(tTargetObject,(const char*)strPropName.c_str(),dblDoubleValues));
                if (iFail != ITK_ok){ return iFail;}
                break;

            case PROP_string:
                NG5_ITK_CALL(AOM_ask_value_strings(tSourceObject,(const char*)strPropName.c_str(),&num, &pcStringValues));
                if (iFail != ITK_ok){ return iFail;}
                NG5_ITK_CALL(AOM_set_value_strings(tTargetObject,(const char*)strPropName.c_str(),num, pcStringValues.get()));
                if (iFail != ITK_ok){ return iFail;}
                break;

            case PROP_date:
                NG5_ITK_CALL(AOM_ask_value_date(tSourceObject,(const char*)strPropName.c_str(),&dtDateValues));
                if (iFail != ITK_ok){ return iFail;}
                NG5_ITK_CALL(AOM_set_value_date(tTargetObject,(const char*)strPropName.c_str(),dtDateValues));
                if (iFail != ITK_ok){ return iFail;}
                break;

            case PROP_logical:
                NG5_ITK_CALL(AOM_ask_value_logical(tSourceObject,(const char*)strPropName.c_str(),&lLogicalValues));
                if (iFail != ITK_ok){ return iFail;}
                NG5_ITK_CALL(AOM_set_value_logical(tTargetObject,(const char*)strPropName.c_str(),lLogicalValues));
                if (iFail != ITK_ok){ return iFail;}
                break;

            case PROP_short:
                NG5_ITK_CALL(AOM_ask_value_int(tSourceObject,(const char*)strPropName.c_str(),&iIntegerValues));
                if (iFail != ITK_ok){ return iFail;}
                NG5_ITK_CALL(AOM_set_value_int(tTargetObject,(const char*)strPropName.c_str(),iIntegerValues));
                if (iFail != ITK_ok){ return iFail;}
                break;

            case PROP_typed_reference:
                NG5_ITK_CALL(AOM_ask_value_tags(tSourceObject,(const char*)strPropName.c_str(),&num,&tagValues));
                if (iFail != ITK_ok){ return iFail;}
                NG5_ITK_CALL(AOM_set_value_tags(tTargetObject,(const char*)strPropName.c_str(),num, tagValues.get()));
                if (iFail != ITK_ok){ return iFail;}
                break;

            case PROP_untyped_reference:
                NG5_ITK_CALL(AOM_ask_value_tags(tSourceObject,(const char*)strPropName.c_str(),&num,&tagValues));
                if (iFail != ITK_ok){ return iFail;}
                NG5_ITK_CALL(AOM_set_value_tags(tTargetObject,(const char*)strPropName.c_str(),num, tagValues.get()));
                if (iFail != ITK_ok){ return iFail;}
                break;

            }
        NG5_ITK_CALL(AOM_save_with_extensions(tTargetObject));//TC 12 Upgrade
        }

    return (iFail);
    }


/**********************************************************************
Function: 	ng5_checkProperty

Summary

This code will check to see whether the properties need to be copied.
If the source attribute is null, or if the target attribute already
has a value, there is no need to copy the attribute.

Change History
Date		Name					Comments
04/11/2012	Daniel Atherton			Created
***********************************************************************/

int ng5_checkProperty(tag_t sourceObject, tag_t targetObject, string strPropName)
    {
    int iFail = ITK_ok;
    scoped_smptr<char> targetValue;
    scoped_smptr<char> sourceValue;

    NG5_ITK_CALL(AOM_UIF_ask_value (sourceObject, (const char*)strPropName.c_str(), &sourceValue));
    if (iFail != ITK_ok)
        {
        return iFail;
        }

    NG5_ITK_CALL(AOM_UIF_ask_value (targetObject, (const char*)strPropName.c_str(), &targetValue));
    if (iFail != ITK_ok)
        {
        return iFail;
        }


    if (string(targetValue.getString()) == "")
        {
        if (string(sourceValue.getString()) == "" )
            {
            return 1;
            }
        else
            {
            return 0;
            }
        }
    else
        {
        return 1;
        }
    return 0;
    }


/**********************************************************************
Function: 	ng5_copyParticipant

Summary

This code will copy a participant from the source object to
the target object.

Change History
Date		Name					Comments
04/11/2012	Daniel Atherton			Created
***********************************************************************/

int ng5_copyParticipant(tag_t sourceObject, tag_t targetObject,  string strPrefValue, logical lAlreadyHasRelation)
    {
    int iFail = ITK_ok;
    int iLoop = 0;

    vector<string> vecPropSplit;
    int participantCount = 0;
    scoped_smptr<tag_t> participant_list;
    tag_t primary_participant = NULLTAG;
    tag_t secondaryRoleTag = NULLTAG;
    tag_t primaryRoleTag = NULLTAG;
    tag_t group_member = NULLTAG;
    scoped_smptr<tag_t> ptpntListPrim;
    int ptpntCountPrim = 0;
	vector<tag_t> vecTrgtGrpMemberTag;
	vector<tag_t> secGrpMember;

	//Split the prefValue ..
	vecPropSplit = Ng5_CommonUtils::splitStringToVector(strPrefValue, ":");

	if (vecPropSplit[(vecPropSplit.size() - 1)] == "A")
	{
		NG5_ITK_CALL(ng5_update_participants(sourceObject, targetObject, vecPropSplit[0] ));
	}

	else if (vecPropSplit[(vecPropSplit.size() - 1)] == "C")
	{
		if (lAlreadyHasRelation)
		{
			NG5_ITK_CALL(ng5_remove_participants(targetObject, vecPropSplit[0]));
		}
		else
		{
			NG5_ITK_CALL(ng5_update_participants(sourceObject, targetObject, vecPropSplit[0] ));
		}
	}

	else if (vecPropSplit[(vecPropSplit.size() - 1)] == "O")
	{
		NG5_ITK_CALL(ng5_remove_participants(targetObject, vecPropSplit[0]));
		NG5_ITK_CALL(ng5_update_participants(sourceObject, targetObject, vecPropSplit[0] ));
	}

	return (iFail);
}

int ng5_remove_participants(tag_t tTargetObject, string strParticipant) 
{
	int iFail = ITK_ok;
	int ptpntCountPrim = 0;
	vector < string > vecTrgtGrpMemberTag;
	tag_t primaryRoleTag = NULLTAG;
	scoped_smptr<tag_t> ptpntListPrim;

	vecTrgtGrpMemberTag = Ng5_CommonUtils::splitStringToVector(strParticipant, "/");

	NG5_ITK_CALL(EPM_get_participanttype ((char*)(vecTrgtGrpMemberTag[0]).c_str(), &primaryRoleTag));
	if (iFail != ITK_ok) {return iFail;}
	NG5_ITK_CALL(ITEM_rev_ask_participants (tTargetObject,primaryRoleTag,&ptpntCountPrim,&ptpntListPrim));
	if (iFail != ITK_ok) {return iFail;}

	for (int i = 0; i < ptpntCountPrim; i++) {
		NG5_ITK_CALL(ITEM_rev_remove_participant(tTargetObject, ptpntListPrim[i]));
	}
	return iFail;
}

int ng5_update_participants(tag_t tSourceObject, tag_t tTargetObject, string strParticipant) 
{
	int iFail = ITK_ok;
	int participantCount = 0;
	int ptpntCountPrim = 0;

	logical lIsExist = false;

	vector < string > vecStrPropSplit;

	tag_t primaryRoleTag = NULLTAG;
	tag_t secondaryRoleTag = NULLTAG;

	scoped_smptr<tag_t> participant_list;
	scoped_smptr<tag_t> ptpntListPrim;

	vecStrPropSplit = Ng5_CommonUtils::splitStringToVector(strParticipant, "/");
	NG5_ITK_CALL(EPM_get_participanttype ((char*)(vecStrPropSplit[0]).c_str(), &primaryRoleTag));
	if (iFail != ITK_ok) {return iFail;}
	NG5_ITK_CALL(EPM_get_participanttype ((char*)(vecStrPropSplit.size() > 1? (vecStrPropSplit[1]).c_str() : (vecStrPropSplit[0]).c_str()), &secondaryRoleTag));
	if (iFail != ITK_ok) {return iFail;}

	NG5_ITK_CALL(ITEM_rev_ask_participants (tSourceObject,secondaryRoleTag,&participantCount,&participant_list));
	if (iFail != ITK_ok) {return iFail;}
	NG5_ITK_CALL(ITEM_rev_ask_participants (tTargetObject,primaryRoleTag,&ptpntCountPrim,&ptpntListPrim));
	if (iFail != ITK_ok) {return iFail;}

	if (participantCount > 0) 
	{
		if (vecStrPropSplit.size() > 1 && (vecStrPropSplit[0]).c_str() != (vecStrPropSplit[1]).c_str()) 
		{
			for (int iLoop = 0; iLoop < participantCount; iLoop++) 
			{
				int iPartiPrsnt = 0;
				tag_t tGroupMember = NULLTAG;
				tag_t tPrimParticipant = NULLTAG;

				NG5_ITK_CALL(AOM_ask_value_tag (participant_list.get()[iLoop], "assignee", &tGroupMember));
				if (iFail != ITK_ok) {return iFail;}

				for (int iTarCount = 0; iTarCount < ptpntCountPrim; iTarCount++) 
				{
					tag_t tTrgtGroupMmbr = NULLTAG;
					NG5_ITK_CALL(AOM_ask_value_tag (ptpntListPrim.get()[iTarCount], "assignee", &tTrgtGroupMmbr));
					if (iFail != ITK_ok) {return iFail;}
					if (tGroupMember == tTrgtGroupMmbr) 
					{
						lIsExist = true;
						break;
					}
				}

				if (!lIsExist) 
				{
					NG5_ITK_CALL(EPM_create_participant(tGroupMember, primaryRoleTag, &tPrimParticipant));
					if (iFail != ITK_ok) {return iFail;}

					NG5_ITK_CALL(ITEM_rev_add_participant ( tTargetObject, tPrimParticipant));
					if (iFail != ITK_ok) {return iFail;}
				}
			}
		} else {
			for (int iLoop = 0; iLoop < participantCount; iLoop++) 
			{
				tag_t tGroupMember = NULLTAG;
				NG5_ITK_CALL(AOM_ask_value_tag (participant_list.get()[iLoop], "assignee", &tGroupMember));
				if (iFail != ITK_ok) {return iFail;}

				for (int iTarCount = 0; iTarCount < ptpntCountPrim; iTarCount++)
				{
					tag_t tTrgtGroupMmbr = NULLTAG;
					NG5_ITK_CALL(AOM_ask_value_tag (ptpntListPrim.get()[iTarCount], "assignee", &tTrgtGroupMmbr));
					if (iFail != ITK_ok) {return iFail;}
					if (tGroupMember == tTrgtGroupMmbr)
					{
						lIsExist = true;
						break;
					}
				}

				if (!lIsExist)
				{
					NG5_ITK_CALL(ITEM_rev_add_participant ( tTargetObject, participant_list[iLoop]));
					if (iFail != ITK_ok) {return iFail;}
				}
			}
		}
	}
	return iFail;
}

/**********************************************************************
Function: 	ng5_propagate_errors

Summary

This code will log error messages to the syslog.

Change History
Date		Name					Comments
04/11/2012	Daniel Atherton			Created
***********************************************************************/
void ng5_propagate_errors( int status, string strErrorString, int iClearErrors )
    {
    int  i, iErrors;
    const int* piSeverities;
    const int* piStatuses;
    const char** pcMessages;

    if(status != ITK_ok)
        {
        EMH_ask_errors( &iErrors, &piSeverities, &piStatuses, &pcMessages );
        TC_write_syslog  ( "\nError Found While Propagating Attribute(s) and/or Participants(s): \n");
        TC_write_syslog  ( "    Method = NG5_PropagateInfoOnRelate \n");
        TC_write_syslog  ( "    %s\n",strErrorString.c_str());
        for (i = 0; i < iErrors; i++) {
            TC_write_syslog( "    %6d: %s\n", piStatuses[i], pcMessages[i] );
            }
        }

    // If specified, clear the error stack
    if (iClearErrors ==1)
        {
        TC_write_syslog ("    Clearing Error Stack\n");
        EMH_clear_errors();
        }
    }
