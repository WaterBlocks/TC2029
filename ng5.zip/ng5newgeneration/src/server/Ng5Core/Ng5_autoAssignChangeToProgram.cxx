/*****************************************************************************
 * File Name:         Ng5_autoAssignChangeToProgram.cxx
 *
 * File Description:  This file contains the code for associting Change Object Revisions
 * - PR, CR, CN & DA to Master Program with relationship Has Change
 *
 * The extension is being called on below scenarios:
 **************************************************************************
 *      Operation			*	Business Object
 **************************************************************************
 *      ITEM_create_rev			*	ChangeItemRevision
 *************************************************************************
 * History:
 *  mm/dd/yyyy  Name                 Comments
 *  ----------  ---------------      -------------------------
 *  12/04/2016  Vivek Nalawade	    Initial Creation
 *  12/05/2016  Sree Harsha C	    Continued the development for creating Change Objects under Master Program
 ******************************************************************************/
#include <Ng5Core/Ng5_autoAssignChangeToProgram.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <stdarg.h>
#include <string>
#include <sstream>
#include <fclasses/tc_string.h>
//#include <tccore/project.h>

using namespace std;



int Ng5_autoAssignChangeToProgram( METHOD_message_t *msg, va_list args )
{

	int          iFail                                 = ITK_ok;
	int          nMasterPrg                            = 0;

	tag_t          tCurrentproject                     = NULLTAG;
	tag_t          tProjRelType                        = NULLTAG;
	tag_t          tcurrent_member_tag                 = NULLTAG;
	tag_t          tcurrentuser_tag                    = NULLTAG;
	tag_t          tMasterPrgRev                       = NULLTAG;
	tag_t          tMasterPrg                          = NULLTAG;
	tag_t          tChangeLatest_rev                   = NULLTAG;
	tag_t          *new_rev = NULL;
	tag_t          *tpMasterPrgs                       = NULL;
	char           *masterProgramId                    = NULL;
	char            *projID                            = NULL;

	logical      isPrivileged                          = false;

	TC_write_syslog("\n ---->Entering Ng5_autoAssignChangeToProgram\n");

	tag_t                         tChangeitem                         =     va_arg(args, tag_t);
	const char*         iChange_rev_id                                =      va_arg(args, char*);
	new_rev   =        va_arg(args, tag_t*);
	tChangeLatest_rev = *new_rev;

	NG5_ITK_CALL( SA_ask_current_project(&tCurrentproject) );

	if (tCurrentproject != NULLTAG)
	{
		NG5_ITK_CALL(SA_ask_current_groupmember (&tcurrent_member_tag));
		NG5_ITK_CALL(SA_ask_groupmember_user(tcurrent_member_tag, &tcurrentuser_tag));
		NG5_ITK_CALL(PROJ_is_user_a_privileged_member(tCurrentproject,tcurrentuser_tag,&isPrivileged));

		if (isPrivileged)
		{

			NG5_ITK_CALL( PROJ_ask_id2(tCurrentproject,&projID));
			if (projID != NULL)
			{
				NG5_ITK_CALL( GRM_find_relation_type( ProgToProj_Relation_Type, &tProjRelType ));
				if(NULLTAG != tProjRelType)
				{
					NG5_ITK_CALL(GRM_list_primary_objects_only(tCurrentproject, tProjRelType, &nMasterPrg, &tpMasterPrgs));
					if (nMasterPrg > 0)
					{
						tMasterPrg = tpMasterPrgs[0];
						//NG5_LOGFILE_REPORT(ITEM_ask_item_of_rev(tMasterPrg,&tMasterPrgRev));

						NG5_ITK_CALL(ITEM_ask_id2(tMasterPrg,&masterProgramId));
						if(tc_strcmp(projID,masterProgramId)==0)
						{

							NG5_ITK_CALL(ITEM_ask_id2(tChangeitem,&masterProgramId));

							NG5_ITK_CALL( associate_change_to_program(tMasterPrg ,tChangeLatest_rev));
						}else
						{
							TC_write_syslog("\n ---->No Program Project Match");
						}
					}else {
						TC_write_syslog("\n ---->No Program Object Found");
					}

				}

			}
			NG5_MEM_TCFREE( projID );
			NG5_MEM_TCFREE( masterProgramId );
			NG5_MEM_TCFREE( tpMasterPrgs );
		}
	}
	TC_write_syslog("\n ---->Exited Ng5_autoAssignChangeToProgram\n");
	return iFail;

}

int associate_change_to_program(tag_t tMasterPrgItem , tag_t tChangeItemRev)
{
	int iFail = ITK_ok;

	tag_t tProgToChangeRelation                          = NULLTAG;
	tag_t tProgToChangeRelationType                      = NULLTAG;
	tag_t tRel											 = NULLTAG;
	char  *revName										 = NULL;

	if (tChangeItemRev != NULLTAG)
	{
		//NG5_ITK_CALL(AOM_refresh(tMasterPrgItem, true));
		ITEM_ask_rev_name2 (tChangeItemRev, &revName);
		NG5_ITK_CALL(GRM_find_relation_type(ProgToChange_Relation_Type, &tProgToChangeRelationType));
		NG5_ITK_CALL(GRM_create_relation(tMasterPrgItem,tChangeItemRev,tProgToChangeRelationType,NULLTAG,&tProgToChangeRelation));
		TC_write_syslog("\n ---->After Create Relation\n");
		NG5_ITK_CALL(GRM_save_relation(tProgToChangeRelation));
		//NG5_ITK_CALL(AOM_refresh(tMasterPrgItem, false));

	}else {
		TC_write_syslog("\n ---->Change Item is NULL");
	}

	return iFail;
}
