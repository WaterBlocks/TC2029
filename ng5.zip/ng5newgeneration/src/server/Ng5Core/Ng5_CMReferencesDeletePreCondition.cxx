//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_CMReferencesDeletePreCondition
 *
 *   History:
 *   mm/dd/yyyy      Name              Comments
 *   ----------  ----------------  -------------------------
 *   11/02/2022  Rohan Survase     Initial Version
 */
#include <Ng5Core/Ng5_CMReferencesDeletePreCondition.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_CMReferencesDeletePreCondition( METHOD_message_t * msg, va_list args )
{
	int iFail = ITK_ok;
	TC_write_syslog("\nNg5_INFO:: Entering Ng5_CMReferencesDeletePreCondition Extension.\n");

	tag_t tRelation = NULLTAG;
	tRelation = msg->object_tag;

	if ( tRelation == NULLTAG )
	{
		return iFail;
	}

	tag_t tChangeItemRevision = NULLTAG;
	NG5_ITK_CALL( GRM_ask_primary( tRelation, &tChangeItemRevision ) );

	if ( tChangeItemRevision != NULLTAG )
	{
		char* cObjectType = NULL;
		NG5_ITK_CALL( AOM_ask_value_string( tChangeItemRevision, ATTR_OBJECT_TYPE, &cObjectType ) );
		TC_write_syslog("\nNg5_INFO:: Object Type is %s\n", cObjectType);

		if( tc_strcmp( cObjectType, CN_REVISION ) == 0 )
		{
			char* szChangeState = NULL;
			NG5_ITK_CALL( AOM_ask_value_string( tChangeItemRevision, ATTR_CHANGE_STATE, &szChangeState ) );
			TC_write_syslog("\nNg5_INFO:: Change State is %s\n", szChangeState );

			if( tc_strcmp( szChangeState, CN_CHANGE_STATE_IMPLEMENTED ) == 0 )
			{
				MEM_TCFREE( szChangeState );
				EMH_store_error_s1( EMH_severity_error, ErrorInReferencesCutOnImplementedCN, "No Access to remove References from Implemented CN Revision" );
				return ErrorInReferencesCutOnImplementedCN;
			}
			MEM_TCFREE( szChangeState );
		}
		MEM_TCFREE( cObjectType );
	}
	TC_write_syslog("\nNg5_INFO:: Exiting from Ng5_CMReferencesDeletePreCondition Extension with return code %d.\n", iFail );
	return ITK_ok;
}
