//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_rHasMBOMItemPostAction
 *
 */
 
#ifndef NG5_RHASMBOMITEMPOSTACTION_HXX
#define NG5_RHASMBOMITEMPOSTACTION_HXX
#include <tccore/method.h>
#include <Ng5Core/Ng5_CMHasProblemItemCreatePostAction.hxx>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_rHasMBOMItemPostAction( METHOD_message_t *msg, va_list args);
tag_t Ng5_Find_First_Revision11(tag_t Item);
int Ng5_DeleteRelation1(tag_t tTargetObject ,char* cp2RelationNames);
int Ng5_DeleteRelation2(tag_t tPrimay,tag_t tSecondary,char* cp2RelationNames);
#define rMBOMITEM                         "Ng5_rHasMBOMItem"
#define MFG_CNRev                         "Ng5_MfgCNRevision"
#define MFGPART                           "Ng5_MfgPart"
#define MFGPARTRev                        "Ng5_MfgPartRevision"
#define ITEM_ID                        	  "item_id"
#define ITEM_REV_ID                       "item_revision_id"
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_RHASMBOMITEMPOSTACTION_HXX
