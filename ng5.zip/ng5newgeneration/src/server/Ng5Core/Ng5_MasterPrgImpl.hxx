//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_MasterPrgImpl
//

#ifndef NG5NEWGENERATION__NG5_MASTERPRGIMPL_HXX
#define NG5NEWGENERATION__NG5_MASTERPRGIMPL_HXX

#include <Ng5Core/Ng5_MasterPrgGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_MasterPrgImpl; 
    class Ng5_MasterPrgDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_MasterPrgImpl
    : public ng5newgeneration::Ng5_MasterPrgGenImpl
{
public:


    ///
    /// desc for validate for create
    /// @param creInput - desc for creInput parameter
    /// @return - ret desc for validate for create
    ///
    int  validateCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a Ng5_MasterPrg
    explicit Ng5_MasterPrgImpl( Ng5_MasterPrg& busObj );

    ///
    /// Destructor
    virtual ~Ng5_MasterPrgImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_MasterPrgImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_MasterPrgImpl( const Ng5_MasterPrgImpl& );

    ///
    /// Copy constructor
    Ng5_MasterPrgImpl& operator=( const Ng5_MasterPrgImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_MasterPrgDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_MASTERPRGIMPL_HXX
