//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_MfgCNRevisionImpl
//

#include <Ng5Core/Ng5_MfgCNRevisionImpl.hxx>

#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include <tc/tc.h>
#include <tccore/item.h>
#include <tc/tc.h>
#include <tccore/aom_prop.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_MfgCNRevisionImpl::Ng5_MfgCNRevisionImpl(Ng5_MfgCNRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_MfgCNRevisionImpl::Ng5_MfgCNRevisionImpl( Ng5_MfgCNRevision& busObj )
   : Ng5_MfgCNRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_MfgCNRevisionImpl::~Ng5_MfgCNRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_MfgCNRevisionImpl::~Ng5_MfgCNRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_MfgCNRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_MfgCNRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_MfgCNRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// Description for the Finalize Create Input
/// @param creInput - desc for  creInput parameter
/// @return - Return desc for Initialize for Create
///
int  Ng5_MfgCNRevisionImpl::finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput )
{
    int ifail = ITK_ok;
    tag_t tCurrentGroupmember	= NULLTAG;
        tag_t tCurrentGroup 		= NULLTAG;
        char* szCurrentGroupName 	= NULL;
        std::string cptokendigit;
        bool    isReqCustPartNull = true;
        bool    isOEMNameNull     = true;
        std::string sReqCustPart;
        std::string sOEMName;
        ifail = super_finalizeCreateInputBase(  creInput );

        TC_write_syslog("Entering method Ng5_MfgCNRevisionImpl finalizeCreateInputBase \n");
    // Call the parent Implementation
        ITK( SA_ask_current_groupmember  ( &tCurrentGroupmember ) );
    	   if ( tCurrentGroupmember != NULLTAG )
    	    {

    		   ITK( SA_ask_groupmember_group  ( tCurrentGroupmember, &tCurrentGroup ) );
    		   ITK( SA_ask_group_full_name (tCurrentGroup, &szCurrentGroupName) );
    		   cptokendigit=tc_strtok(szCurrentGroupName,".");

    		   creInput->setString(PLANTS, cptokendigit, false);

    	    }
    	   creInput->getString(RQRDCUSTPARTNO,  sReqCustPart, isReqCustPartNull);
    	   creInput->getString(ATTR_CUST_NAME, sOEMName, isOEMNameNull);
    	   if(tc_strcmp(sReqCustPart.c_str(),YES)==0)
    	   {
    	       		if(tc_strlen(sOEMName.c_str())==0)
    	       		{
    	       			EMH_store_error(EMH_severity_error,ErrorCodeNoOEMError );

    	                   return ErrorCodeNoOEMError ;

    	       		}
    	    }
    	   TC_write_syslog("Exiting method Ng5_MfgCNRevisionImpl finalizeCreateInputBase \n");
    // Your Implementation
    	  // AOM_refresh(tCurrentGroup,TRUE);
    	   NG5_MEM_TCFREE(szCurrentGroupName);
    return ifail;
}
