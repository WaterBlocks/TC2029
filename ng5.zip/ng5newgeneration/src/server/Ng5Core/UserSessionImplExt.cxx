/*********************************************************************************************
** File Name:         UserSessionImplExt.cxx
**
** File Description:
** This file contains the implementation for OOTB Business object Usersession
**
** History:
**
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   04/14/2017	 Rukmini Ramachandran      Initial Version

*********************************************************************************************/
#include <Ng5Core/UserSessionImplExt.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <sa/site.h>
#include <sa/groupmember.h>
#include <string.h>
#include <pom/pom/pom.h>
#include "Ng5_CommonUtils.hxx"

using namespace ng5::ng5newgeneration;

//----------------------------------------------------------------------------------
// UserSessionImpl::UserSessionImpl(UserSession& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
UserSessionImpl::UserSessionImpl( UserSession& busObj )
   : UserSessionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// UserSessionImpl::~UserSessionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
UserSessionImpl::~UserSessionImpl()
{
}

//----------------------------------------------------------------------------------
// UserSessionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int UserSessionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = UserSessionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


///
///
/// @param ng5_isBurSite -
/// @return -
///

    int  UserSessionImpl::ng5_isBurSiteBase( bool *ng5_isBurSite )
    {
    	int ifail = 0;
        int iValCnt =0;
        logical * values= NULL;

        ITK(PREF_ask_logical_values("NG5_PROGRAM_CREATABLE",&iValCnt,&values));

        if (iValCnt!= 0)
        {
        	if (values[0]==false)
        	{
        		*ng5_isBurSite= false;
    		}
    		else
    		{
    			*ng5_isBurSite=true;

    		}
        }
        MEM_TCFREE(values);

        return ifail;
    }
///
///
/// @param ng5_isXBOMApplicable -
/// @return
///

int  UserSessionImpl::ng5_isXBOMApplicableBase(bool *ng5_isXBOMApplicable )
{
	int ifail = 0;
    int iValCnt =0;
    logical * values= NULL;

    ITK(PREF_ask_logical_values("Ng5_XBOM_Applicable",&iValCnt,&values));

    if (iValCnt!= 0)
    {
    	if (values[0]==false)
    	{
    		*ng5_isXBOMApplicable= false;
		}
		else
		{
			*ng5_isXBOMApplicable=true;
		}
    }
    MEM_TCFREE(values);

    return ifail;
}

///
///
/// @param ng5_isLiveSourceApplicable -
/// @return
int  UserSessionImpl::ng5_isLiveSourceApplicableBase(bool *ng5_isLiveSourceApplicable )
{
	int ifail = 0;
    int iValCnt =0;
    logical * values= NULL;
    ITK(PREF_ask_logical_values("Ng5_LiveSource_Applicable",&iValCnt,&values));
    
    if (iValCnt!= 0)
    {
    	if (values[0]==false)
    	{
    		*ng5_isLiveSourceApplicable= false;
    	
		}
		else
		{
			*ng5_isLiveSourceApplicable=true;
		
		}
    }
    MEM_TCFREE(values);
    
    return ifail;
}

///
///
/// @param ng5_bypass_rules -
/// @return -
///
int  UserSessionImpl::ng5_bypass_rulesBase( bool *isbypass )
{
	int ifail = 0;
    int iValCnt =0;
    logical  value= false;
	
    //306081: Correcting Ng5_rules_bypass code as part of 19.06 release
    ITK(PREF_ask_logical_value("NG5_RULES_BYPASS",0,&value));

       if (value ==false)
    	{
    		*isbypass= false;
		}
		else
		{
			*isbypass=true;

		}

   //MEM_TCFREE(values);

    return ifail;
}

