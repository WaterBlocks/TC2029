//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_ValidatePlant_PreCondition
 *
 */
 
#ifndef NG5_VALIDATEPLANT_PRECONDITION_HXX
#define NG5_VALIDATEPLANT_PRECONDITION_HXX
#include <Ng5Core/Ng5_CMHasProblemItemCreatePostAction.hxx>
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
#define ErrorBase                                 919000
#define ErrorPlantMatchError					  ErrorBase  + 2133
#define PLANTS                           "ng5_plants"
#define MASSUPDATE_PLANTS                           "ng5_Plants"
#define MASSUPDATERev                         "Ng5_MassUpdateRevision"
#define MFGPART                         	  "Ng5_MfgPart"
#define MFGPARTRev                            "Ng5_MfgPartRevision"
#define ITEM_ID                        	  	  "item_id"
#define ITEM_REV_ID                           "item_revision_id"
#define rSIBLING_PART                         "Ng5_Sibling_Part"

extern NG5CORE_API int Ng5_ValidatePlant_PreCondition(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_VALIDATEPLANT_PRECONDITION_HXX
