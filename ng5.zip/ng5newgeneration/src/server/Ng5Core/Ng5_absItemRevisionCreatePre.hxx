/*********************************************************************************************
** File Name:         Ng5_absItemRevisionCreatePre.hxx
**
** File Description:
*   This file contains the declaration for the Extension Ng5_absItemRevisionCreatePre
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   12/09/2016  Pradnya Hingankar      Initial Version
										Added declarations for use case 3502 -To allow many in-process (WIP) alternative revisions at a time.
**  05/18/2022  Sahida Khatun             Modified as part of CM Improvement Project
*********************************************************************************************/

 
#ifndef NG5_ABSITEMREVISIONCREATEPRE_HXX
#define NG5_ABSITEMREVISIONCREATEPRE_HXX
#include <tccore/method.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <tc/tc.h>
#include <fclasses/tc_ctype.h>
#include <fclasses/tc_date.h>
#include "Ng5_CommonUtils.hxx"
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5CORE_API int Ng5_absItemRevisionCreatePre(METHOD_message_t* msg, va_list args);
tag_t  Ng5_GetLatestMajor(tag_t tCurrentRevision);

logical  Ng5_FrozenAfterCutoffDate(tag_t tPreviousRevision);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_ABSITEMREVISIONCREATEPRE_HXX
