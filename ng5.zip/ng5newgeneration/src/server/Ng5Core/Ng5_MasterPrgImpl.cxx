//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_MasterPrgImpl
//


#include <Ng5Core/Ng5_MasterPrgImpl.hxx>
#include "Ng5_CommonUtils.hxx"
#include <base_utils/ScopedSmPtr.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

#define PROJECTADMIN_PRIVILEGE_GROUP 0

using namespace std;
using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_MasterPrgImpl::Ng5_MasterPrgImpl(Ng5_MasterPrg& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_MasterPrgImpl::Ng5_MasterPrgImpl( Ng5_MasterPrg& busObj )
	: Ng5_MasterPrgGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_MasterPrgImpl::~Ng5_MasterPrgImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_MasterPrgImpl::~Ng5_MasterPrgImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_MasterPrgImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_MasterPrgImpl::initializeClass()
{
	int ifail = ITK_ok;
	static bool initialized = false;

	if( !initialized )
	{
		ifail = Ng5_MasterPrgGenImpl::initializeClass( );
		if ( ifail == ITK_ok )
		{
			initialized = true;
		}
	}
	return ifail;
}



///
/// desc for validate for create
/// @param creInput - desc for creInput parameter
/// @return - ret desc for validate for create
///
/*****************************************************************************
Function: 	validateCreateInputBase

Summary

The code will fetch the group and role values from preference.
check the logged in user is a member of group and role mentioned in the preference

The following preferences are used to configure the code:

---------------------------------------------------------------------------------------------
Preference Name: 	Ng5_UserGroupRole
Purpose:			Used to get the group and role to be checked for the current logged in user

Format of Values:	<Group>/<Role>
(Complete name of Group / Complete name of Role)

* Operation-Override : validateCreateInput -

Currently used for User creating Program should be a member of Project Administration as Project gets created at backend

Change History
Date		Name					Comments
07/02/2017	Somashekar M			Initial Creation
**************************************************************************************/
int  Ng5_MasterPrgImpl::validateCreateInputBase( ::Teamcenter::CreateInput *creInput )
{
	int ifail = ITK_ok;
	tag_t tcurrent_member = NULLTAG;
	tag_t tuser_tag = NULLTAG;
	char *  cpUserid = NULL;
	vector<string> vecPrefSplit;
	char* pcPreferenceValues = NULL;

	int inumber_found = 0;
	tag_t * tpUserlist= NULLTAG;

	// Call the parent Implementation
	ifail = super_validateCreateInputBase(  creInput );

	// Your Implementation

	//    TC_write_syslog("\n Inside  validateCreateInputBase for Program creation extension\n");
	//    printf("\nInside  validateCreateInputBase for Program creation extension\n");

	ITK(PREF_ask_char_value_at_location(NG5_USER_GROUP_ROLE,TC_preference_site,PROJECTADMIN_PRIVILEGE_GROUP,&pcPreferenceValues));

	TC_write_syslog("\nPreference value of user Group/Role to check = %s \n", pcPreferenceValues);
	vecPrefSplit = Ng5_CommonUtils::splitStringToVector(string(pcPreferenceValues), "/");

	//    for(int i=0;i<vecPrefSplit.size();i++)
	//    	TC_write_syslog("\n vector values = %s", vecPrefSplit[i].c_str());


	ITK(SA_ask_current_groupmember (&tcurrent_member));
	ITK(SA_ask_groupmember_user(tcurrent_member,&tuser_tag));
	ITK(POM_ask_user_id  ( tuser_tag,&cpUserid));


	ITK(SA_find_groupmember_by_rolename  ((const char*)vecPrefSplit[1].c_str(),(const char*)vecPrefSplit[0].c_str(), cpUserid, &inumber_found, &tpUserlist));


	if(inumber_found==0)
	{
		printf("\nERROR  - User id %s NOT present in Project Administrator Role \n",cpUserid);
		TC_write_syslog("\nERROR  - User id %s NOT present in Project Administrator Role \n",cpUserid);

		ITK( EMH_store_initial_error_s1( EMH_severity_error , ErrorCodeForProgramCreation, "Current User is not a member of project administrator Role" ));
		ifail = ErrorCodeForProgramCreation;
	}


	MEM_free(pcPreferenceValues);
	MEM_free(tpUserlist);
	MEM_free(cpUserid);
	return ifail;
}
