//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_CNRevisionImpl
//

#include <Ng5Core/Ng5_CNRevisionImpl.hxx>

#include <fclasses/tc_string.h>
#include <tcinit/tcinit.h>
#include <ce/ce.h>
#include <string.h>
#include <sstream>
#include <fclasses/tc_string.h>
#include <sa/role.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>


#define SA_insufficient_privileges (ErrorCNType)
#define BMF_artifact_not_found (SA_ERROR_BASE + 10020)

using namespace std;
using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_CNRevisionImpl::Ng5_CNRevisionImpl(Ng5_CNRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_CNRevisionImpl::Ng5_CNRevisionImpl( Ng5_CNRevision& busObj )
   : Ng5_CNRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_CNRevisionImpl::~Ng5_CNRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_CNRevisionImpl::~Ng5_CNRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_CNRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_CNRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_CNRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}



///
/// desc for validate for create
/// @param creInput - desc for creInput parameter
/// @return - ret desc for validate for create
///
int  Ng5_CNRevisionImpl::validateCreateInputBase( ::Teamcenter::CreateInput *creInput )
{
	int ifail = ITK_ok;

	// Call the parent Implementation
	ifail = super_validateCreateInputBase(  creInput );

	// Your Implementation
	TC_write_syslog("\nEntering method validateCreateInputBase for Ng5_CNRevision.\n");

	bool  isItemNull = true ;
	tag_t tItemTag = NULLTAG;
	creInput->getTag(ITEMSTAG,tItemTag,isItemNull);



	std::string cChgType;
	bool isChgTypeNull = true;
	creInput->getString(ChangeType, cChgType, isChgTypeNull);

	TC_write_syslog("\n Change Type is: %s", cChgType.c_str());

	tag_t   condTag = NULLTAG;
	ifail = CE_find_condition( ENGUSER_COND, &condTag );
	if (ifail != ITK_ok)
	{
		TC_write_syslog("\n CE_find_condition = false\n");
		return ifail;
	}

	if (condTag == null_tag)
	{
		TC_write_syslog("\n Condition tag is not found '%s'.\n");
		return BMF_artifact_not_found;
	}

	tag_t   tUserSession 	= NULLTAG;
	CE_current_user_session_tag(&tUserSession);

	int num_parms = 1;
	tag_t *parm_tags 	= 0;
	parm_tags = (tag_t *) MEM_alloc( sizeof( tag_t) * num_parms );
	parm_tags[0] = tUserSession;


	logical result 			= false;
	ifail = CE_evaluate_condition ( condTag, num_parms, parm_tags, &result );

	TC_write_syslog("\n Ng5_isEngUser CE_evaluate_condition: result = %d\n",result);

	if ( result && (cChgType == "Typical Change" || cChgType == "Drawing Only Change"))
	{
		TC_write_syslog("\n Ng5_isEngUser Condition evaluated to False. Allows this operation only if user has Designer or Engineering Executive or Engineering Manager or Product Engineer role.\n");
		ifail = SA_insufficient_privileges;
		EMH_store_initial_error_s1( EMH_severity_error, ErrorCNType , "CN Type wrong for the User in session" );
		return ifail;
	}

	NG5_MEM_TCFREE (parm_tags);
	TC_write_syslog( "\nExiting method validateCreateInputBase for Ng5_CNRevision with return code:%d.\n", ifail );
	return ifail;
}
