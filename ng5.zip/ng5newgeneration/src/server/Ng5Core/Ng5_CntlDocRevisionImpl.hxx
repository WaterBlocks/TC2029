//@<COPYRIGHT>@
//==================================================
//Copyright $2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_CntlDocRevisionImpl
//

#ifndef NG5NEWGENERATION__NG5_CNTLDOCREVISIONIMPL_HXX
#define NG5NEWGENERATION__NG5_CNTLDOCREVISIONIMPL_HXX

#include <Ng5Core/Ng5_CntlDocRevisionGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_CntlDocRevisionImpl; 
    class Ng5_CntlDocRevisionDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_CntlDocRevisionImpl
    : public ng5newgeneration::Ng5_CntlDocRevisionGenImpl
{
public:

    ///
    /// Getter for a Tag Array Property
    /// @param values - Parameter value
    /// @param isNull - Returns true for an array element if the parameter value at that location is null
    /// @return - Status. 0 if successful
    ///
    int  getNg5_associated_partrevsBase( std::vector<tag_t> &values, std::vector<int> &isNull ) const;

    ///
    /// Setter for a Tag Array Property
    /// @param values - Values to be set for the parameter
    /// @param isNull - If array element is true, set the parameter value at that location as null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_associated_partrevsBase( const std::vector<tag_t> &values, const std::vector<int> *isNull );


protected:
    ///
    /// Constructor for a Ng5_CntlDocRevision
    explicit Ng5_CntlDocRevisionImpl( Ng5_CntlDocRevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_CntlDocRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_CntlDocRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_CntlDocRevisionImpl( const Ng5_CntlDocRevisionImpl& );

    ///
    /// Copy constructor
    Ng5_CntlDocRevisionImpl& operator=( const Ng5_CntlDocRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_CntlDocRevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_CNTLDOCREVISIONIMPL_HXX
