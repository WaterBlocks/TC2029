/*********************************************************************************************
** File Name:         Ng5_PartHasCustomerPartFormRelationPreCondition.hxx
**
** File Description:
	This file contains the declaration for the extension named Ng5_Update_Master_ID
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   12/09/2016  Shibabrata Jena      Initial Version

*********************************************************************************************/
 
#ifndef NG5_PARTHASCUSTOMERPARTFORMRELATIONPRECONDITION_HXX
#define NG5_PARTHASCUSTOMERPARTFORMRELATIONPRECONDITION_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
//-----------------------------------------------------------------------------------------------------
// int Ng5_PartHasCustomerPartFormRelationPreCondition( METHOD_message_t * msg, va_list args )
// definition  of the extension on GRM Create of Relation pre condition of Ng5_rPartHasCustomerPrtForm
// relation to allow the customer part form to represent only One part
//------------------------------------------------------------------------------------------------------
extern NG5CORE_API int Ng5_PartHasCustomerPartFormRelationPreCondition(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_PARTHASCUSTOMERPARTFORMRELATIONPRECONDITION_HXX
