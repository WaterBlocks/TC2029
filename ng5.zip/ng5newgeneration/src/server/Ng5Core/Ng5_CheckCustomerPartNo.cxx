//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_Validate_Mfg_CreateInput
 *   History
 *   Syed Suleman       Initial Creation     July ,2022
 *
 */
#include <Ng5Core/Ng5_CheckCustomerPartNo.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include<ctype.h>

 /*Function Name :  Ng5_Validate_Mfg_CreateInput
 *   Description   :  This is the PreCondition on IMAN_save of Manufacturing CN Revision to check if
 *                    OEM is filled or not
 *   History
 *   Syed Suleman       Initial Creation     July ,2022*/

int Ng5_CheckCustomerPartNo( METHOD_message_t * msg, va_list args )
{
			tag_t tMfgCNRev               = va_arg (args, tag_t);
			char* cpReCustPartNo = NULL; //OF
			char* cpOEMName      = NULL; //OF

			ITKCALL(AOM_ask_value_string( tMfgCNRev, RQRDCUSTPARTNO, &cpReCustPartNo));

			TC_write_syslog("\n Create With Customer Part No  ? %s\n", cpReCustPartNo);

			ITKCALL(AOM_ask_value_string( tMfgCNRev, CUSTOMER, &cpOEMName ));

			TC_write_syslog("\n OEM Name: %s\n", cpOEMName);

			if(tc_strcmp(cpReCustPartNo,YES)==0)
			{
				if(cpOEMName==NULL || tc_strcmp(cpOEMName,"")==0)
				{

					EMH_store_error(EMH_severity_error,ErrorCodeNoOEMError );
					return ErrorCodeNoOEMError ;
				}


			}
			NG5_MEM_TCFREE(cpReCustPartNo);
			NG5_MEM_TCFREE(cpOEMName);
 
 return 0;

}
