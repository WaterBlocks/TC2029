/*********************************************************************************************
** File Name:         Ng5_absItemRevisionFormCreatePost.cxx
**
** File Description:
	This file contains the declaration for the extension named Ng5_absItemRevisionFormCreatePost
	This Method will copy the Design Weight value from catia_model_attribute form to Eng Part Revison
	during tcic save.
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   1/12/2017  Shibabrata Jena      Initial Version
**   8/1/2018   Shibabrata Jena		 Added MEM_TCFREE
**   17/07/2019	Naresh Chinnam		 304074- Replaced AOM_refresh with POM_refresh as lock didn't work for AOM_refresh

**   27/07/2021  Datta Bambal		 Change catia_assebly_attributes relation to REL_REFERENCE because we required ng5_design_weight should be updated on Design Parts.
**   05/07/2021  Sahida              TC12 Upgrade
*********************************************************************************************/
#include <Ng5Core/Ng5_absItemRevisionFormCreatePost.hxx>
#include <tccore/method.h>
#include <tccore/aom_prop.h>
#include <tccore/aom.h>
#include <tccore/grm.h>
#include <fclasses/tc_string.h>
#include <fclasses/tc_stdio.h>
#include <string.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
//-----------------------------------------------------------------------------------------------------
// int Ng5_absItemRevisionFormCreatePost( METHOD_message_t * msg, va_list args )
// definition  of the extension on IMAN_save of catia_assebly_model_attributes post action
// to update the design weight on the part revision
//------------------------------------------------------------------------------------------------------


int Ng5_absItemRevisionFormCreatePost( METHOD_message_t * msg, va_list args )
{
	TC_write_syslog("Entering method Ng5_absItemRevisionFormCreatePost \n");
	tag_t tForm = msg->object_tag;

	if(tForm != NULLTAG)
	{
		TC_write_syslog("Form found \n");
		double dNetWeight = 0;
		ITK(AOM_ask_value_double(tForm, CATIA_MODEL_ATTRIBUTE_WEIGHT, &dNetWeight));
		tag_t tRelTypeTag = NULLTAG;
		//ITK(GRM_find_relation_type(REL_SPECIFICATION, &tRelTypeTag));
		  ITK(GRM_find_relation_type(REL_REFERENCE, &tRelTypeTag));  //Change catia_assebly_attributes relation to REL_REFERENCE By Datta Bambal 
		//find the primary objects
		if(tRelTypeTag != NULLTAG)
		{
			int iPartRevs = 0;
			tag_t *tPartRevs = NULL;
			ITK(GRM_list_primary_objects_only(tForm, tRelTypeTag, &iPartRevs, &tPartRevs));

			if(iPartRevs > 0 && tPartRevs != NULL)
			{
				for(int iNx = 0; iNx < iPartRevs; iNx++)
				{
					char*cObjectType = NULL;
					ITK(AOM_ask_value_string(tPartRevs[iNx],ATTR_OBJECT_TYPE, &cObjectType));

					TC_write_syslog("\n object type is %s\n", cObjectType);
					if(tc_strcmp(cObjectType, ENG_PART_REVISION) == 0 ||tc_strcmp(cObjectType, ITEM_EXTERNAL_PART_REVISION ) == 0 || tc_strcmp(cObjectType, ITEM_SUPPORT_DESIGN_REVISION) == 0 || tc_strcmp(cObjectType,  ITEM_EXTERNAL_SUPPORT_DESIGN_REVISION) == 0)
					{
						TC_write_syslog("Part revision found \n");
						AM__set_application_bypass(true); // Added this bypass function
						
						ITK(POM_refresh_instances (1, tPartRevs,NULLTAG, POM_modify_lock));
						//ITK(AOM_refresh(tPartRevs[iNx], POM_modify_lock));replaced with POM_refresh_instances for production defect 304074
						ITK(AOM_set_value_double(tPartRevs[iNx], DESIGN_WEIGHT,dNetWeight));
						ITK(AOM_save_with_extensions(tPartRevs[iNx]));//TC 12 Upgrade
						ITK(AOM_refresh(tPartRevs[iNx], POM_no_lock));
						
						AM__set_application_bypass(false); // // Added this bypass function for false
					}
					MEM_TCFREE(cObjectType);
				}
			}
			MEM_TCFREE(tPartRevs);
		}
	}
	TC_write_syslog("Exiting method Ng5_absItemRevisionFormCreatePost \n");


 return ITK_ok;

}
