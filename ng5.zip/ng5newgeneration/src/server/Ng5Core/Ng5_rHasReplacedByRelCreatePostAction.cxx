//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasReplacedByRelCreatePostAction
 *  Function will get called whenever the Relationship is created between Engineered Part
 *   and Engineered Part with the Relation 'Has Replaced By'.
 *   It checks for the Engineering Part attached to Engineering Part (with which it is replaced by) & the typed
 *   reference property ng5_replacement_for_parts gets updated by adding the Engineered Part
 *   to this property.
 *   Similarly, it will work  whenever the Relationship is created between Raw Material
 *   and Raw Material with the Relation 'Has Replaced By'.
 *   For other object types, code will not get executed.
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   05/31/2018  Meenakshi Shenoy  Initial Version
 *   07/05/2021  Balaji            TC12 Upgrade
 */

#include <Ng5Core/Ng5_rHasReplacedByRelCreatePostAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_rHasReplacedByRelCreatePostAction(METHOD_message_t *msg, va_list args) {

	int iFail = ITK_ok;

	tag_t tPart = NULLTAG;
	tag_t tEngPart = NULLTAG;
	tag_t tRelationType = NULLTAG;

	TC_write_syslog("\n Entering Ng5_rHasReplacedByRelCreatePostAction \n");
	tPart = va_arg(args, tag_t);
	tEngPart = va_arg(args, tag_t);
	tRelationType = va_arg(args, tag_t);

	if (NULLTAG != tPart && NULLTAG != tEngPart && NULLTAG != tRelationType) {

		char* cObjectType = NULL;
		//Added check to verify object type = Eng Part or Raw Material only.
		//For rest of the types, code will skip the execution.
		NG5_ITK_CALL(AOM_ask_value_string(tPart,ATTR_OBJECT_TYPE, &cObjectType));

		TC_write_syslog("\n object type is %s\n", cObjectType);
		if(tc_strcmp(cObjectType, ENG_PART) == 0 ||tc_strcmp(cObjectType, RAW_MATERIAL) == 0 )
		{
			int numofEngPrt = 0;

			tag_t *tagPrtValues = NULLTAG;

			logical engPartExist = false;

			logical lPriVerdict = false;

			NG5_ITK_CALL(AOM_ask_value_tags(tEngPart,REPLACEMENT_FOR_PARTS,&numofEngPrt,&tagPrtValues));
			//Checking if the Part count is more than 0
			if (numofEngPrt > 0 && tagPrtValues != NULL) {
				for (int indxEngPrt = 0; indxEngPrt < numofEngPrt; indxEngPrt++) {
					//Checking if the Engineered Part is already attached to ng5_replacement_for_parts Property
					if (tagPrtValues[indxEngPrt] == tPart) {
						engPartExist = true;
					}
				}

			}

			//Setting the ng5_replacement_for_parts Property by adding the Eng Part rev to it

			NG5_ITK_CALL( AM_check_privilege (tEngPart, ACCESS_WRITE, &lPriVerdict));

			//Allow only if the logged in user has write access to Primary object
			if (true == lPriVerdict) {
				//If the Part Does not exist or Property value count is 0
				if (engPartExist == false || numofEngPrt == 0) {
					NG5_ITK_CALL(AOM_refresh(tEngPart,TRUE));
					NG5_ITK_CALL(AOM_set_value_tag_at(tEngPart,REPLACEMENT_FOR_PARTS,numofEngPrt, tPart));
					TC_write_syslog("\n Setting Property ng5_replacement_for_parts \n");
					NG5_ITK_CALL(AOM_save_with_extensions(tEngPart)); //TC 12 Upgrade
					NG5_ITK_CALL(AOM_refresh(tEngPart,FALSE));
					if (iFail != ITK_ok) {
						return iFail;
					}
				}
			} else {
				logical lPriVerdict1 = false;
				// if the part is released, bypass is set to update the property
				AM__set_application_bypass(true);
				NG5_ITK_CALL(AM_check_privilege (tEngPart, ACCESS_WRITE, &lPriVerdict1));
				if (lPriVerdict1) {
					TC_write_syslog("\n access obtained \n");
					NG5_ITK_CALL(AOM_refresh(tEngPart,TRUE));
					NG5_ITK_CALL(AOM_set_value_tag_at(tEngPart,REPLACEMENT_FOR_PARTS,numofEngPrt, tPart));
					TC_write_syslog("\n Setting Property ng5_replacement_for_parts \n");
					NG5_ITK_CALL(AOM_save_with_extensions(tEngPart));//TC12 Upgrade
					NG5_ITK_CALL(AOM_refresh(tEngPart,FALSE));
				} else {
					TC_write_syslog("\n access not obtained \n");
				}

				AM__set_application_bypass(false);

			}
			MEM_TCFREE(tagPrtValues);
		}



		TC_write_syslog("\n Leaving Ng5_rHasReplacedByRelCreatePostAction \n");

		MEM_TCFREE(cObjectType);

	}
	return iFail;

}
