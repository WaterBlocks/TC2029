//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the declaration for the Business Object Ng5_AbsItemRevisionImpl
//

#ifndef NG5NEWGENERATION__NG5_ABSITEMREVISIONIMPL_HXX
#define NG5NEWGENERATION__NG5_ABSITEMREVISIONIMPL_HXX

#include <Ng5Core/Ng5_AbsItemRevisionGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_AbsItemRevisionImpl; 
    class Ng5_AbsItemRevisionDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_AbsItemRevisionImpl
    : public ng5newgeneration::Ng5_AbsItemRevisionGenImpl
{
public:

    ///
    /// Setter for a Double Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_design_weightBase( double value, bool isNull );

    ///
    /// Setter for a string Property
    /// @param value - Value to be set for the parameter
    /// @param isNull - If true, set the parameter value to null
    /// @return - Status. 0 if successful
    ///
    int  setNg5_tool_maturityBase( const std::string &value, bool isNull );


protected:
    ///
    /// Constructor for a Ng5_AbsItemRevision
    explicit Ng5_AbsItemRevisionImpl( Ng5_AbsItemRevision& busObj );

    ///
    /// Destructor
    virtual ~Ng5_AbsItemRevisionImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_AbsItemRevisionImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_AbsItemRevisionImpl( const Ng5_AbsItemRevisionImpl& );

    ///
    /// Copy constructor
    Ng5_AbsItemRevisionImpl& operator=( const Ng5_AbsItemRevisionImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_AbsItemRevisionDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_ABSITEMREVISIONIMPL_HXX
