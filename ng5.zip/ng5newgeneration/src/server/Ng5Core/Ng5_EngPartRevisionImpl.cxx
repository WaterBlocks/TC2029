/*********************************************************************************************
** File Name:         Ng5_EngPartRevisionImpl.cxx
**
** File Description:
	This file contains the implementation for the Business Object Ng5_EngPartRevisionImpl
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   12/09/2016  Pradnya Hingankar      Initial Version
										Added method setNg5_tooling_maturityBase( const std::string & value, bool  isNull )
     DEC/27/16   Thirupathy Natesan 	First revision
	 	 	 	 	 	 	 	 	 	Added method setNg5_derivedBase
     02/02/17   Sachin Rampure    	    Getter method  for Displaying relationship between Eng Part Revision and
	 	 	 	 	 	 	 	 	 	Engineering Drawing	
     07/05/21	Balaji					TC12 Upgrade				
*********************************************************************************************/


#include <Ng5Core/Ng5_EngPartRevisionImpl.hxx>

#include <fclasses/tc_string.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <tc/tc.h>
#include "Ng5_CommonUtils.hxx"

using namespace ng5newgeneration;


//----------------------------------------------------------------------------------
// Ng5_EngPartRevisionImpl::Ng5_EngPartRevisionImpl(Ng5_EngPartRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_EngPartRevisionImpl::Ng5_EngPartRevisionImpl( Ng5_EngPartRevision& busObj )
   : Ng5_EngPartRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_EngPartRevisionImpl::~Ng5_EngPartRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_EngPartRevisionImpl::~Ng5_EngPartRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_EngPartRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_EngPartRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_EngPartRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}


/*
 * **
 * Created By	:	Pradnya Hingankar
 * Created Date	:	09-Dec-2016
 *
 * Functionality:	Setter for a string Property
 * 					@param value - Value to be set for the parameter
 * 					@param isNull - If true, set the parameter value to null
 * 					@return - Status. 0 if successful
 * 					This setter method performs validations on the value of ng5_tooling_maturity property before setting the value.
 * 					Previous revision of Engineering Part can't have tooling maturity at higher level than the current revision.
 */

int  Ng5_EngPartRevisionImpl::setNg5_tooling_maturityBase( const std::string & value, bool  isNull )
{
    int ifail 					= ITK_ok;

    //Removed the business logic for this attribute set, added same logic on ng5_tool_maturity attribute on Ng5_AbsItemRevision

	if(ifail == ITK_ok)//if the value if tooling maturity is as per the business validations then set the value
	{
		ifail = Ng5_EngPartRevisionGenImpl::setNg5_tooling_maturityBase( value, isNull );

	}
	return ifail;
}

/// 
/// Getter for a Tag Array Property
/// @param values - Parameter value
/// @param isNull - Returns true for an array element if the parameter value at that location is null
/// @return - Status. 0 if successful
///	This Method is to get the list of objects for a given relation Ng5_rHasDerivedFromRel
///	using the runtime property ng5_derived

/*int  Ng5_EngPartRevisionImpl::getNg5_derivedBase( std::vector<tag_t> &values, std::vector<int> & isNull ) const
{
    int ifail = ITK_ok;

    int         iRefs           =       0;
    int         *ipLevels       =       NULL;
    char        **sz2Rels       =       NULL;
    tag_t       tPR                     =       NULLTAG;
    tag_t       *tpRefs         =       NULL;
    TC_write_syslog("\n\t Entering Ng5_EngPartRevisionImpl::getNg5_derivedBase \n");

    //Get the Part Revision Tag
    Ng5_EngPartRevision *bo = getNg5_EngPartRevision();
    tPR = ((Teamcenter::BusinessObject*)bo)->getTag();

    std::vector<tag_t>      vTagValues;
    std::vector<int>        vIsNullLocal;

    vTagValues.clear();

    //Getting where referenced objects
    ITK( WSOM_where_referenced( tPR, 1, &iRefs, &ipLevels, &tpRefs, &sz2Rels) );

    	for(int iWhere=0; iWhere<iRefs; iWhere++)
    	{
    		if( sz2Rels[iWhere] != NULL )
    		{
    			if(NULLTAG != tpRefs[iWhere])
    			{
    				char    cObjectTypeRev[WSO_name_size_c+1]    =       {'\0'};
    				char    cRelationNameRev[WSO_name_size_c+1]    =       {'\0'};
    				ITK( WSOM_ask_object_type(tpRefs[iWhere], cObjectTypeRev) );
    				if (tc_strcpy(cRelationNameRev,sz2Rels[iWhere]) == 0);
    				{
    				//Checking if referenced type is a Eng Part Revision and relation as Ng5_rHasDerivedFromRel
    				if(( tc_strcmp(ENG_PART_REVISION, cObjectTypeRev) == 0 ) && (tc_strcmp(PrtrevToPrtrevDerivedFrom_Rel,cRelationNameRev) == 0))
    					{
    						vTagValues.push_back(tpRefs[iWhere]);
    						vIsNullLocal.push_back(false);
    					}
    				}
    			}
    		}
    	}
    	if(vTagValues.size() > 0)
    	{
    		values.clear();
    		values.swap(vTagValues);
    	}
    	if(vIsNullLocal.size() > 0)
    	{
    		isNull.clear();
    		isNull.swap(vIsNullLocal);
    	}

    	if(ipLevels != NULL)
    		MEM_TCFREE(ipLevels);
    	if(sz2Rels != NULL)
    		MEM_TCFREE(sz2Rels);
    	if(tpRefs != NULL)
    		MEM_TCFREE(tpRefs);
    return ifail;

}*/

///
/// Setter for a Tag Array Property
/// @param values - Values to be set for the parameter
/// @param isNull - If array element is true, set the parameter value at that location as null
/// @return - Status. 0 if successful
///
/*int  Ng5_EngPartRevisionImpl::setNg5_derivedBase( const std::vector<tag_t> & values, const std::vector<int> * isNull )
{
    int ifail = ITK_ok;

    // Your Implementation

    return ifail;
}*/
///
/// Setter for a Tag Array Property
/// @param values - Values to be set for the parameter
/// @param isNull - If array element is true, set the parameter value at that location as null
/// @return - Status. 0 if successful
///
int  Ng5_EngPartRevisionImpl::setNg5_ChangeRequestBase( const std::vector<tag_t> & /*values*/, const std::vector<int> * /*isNull*/ )
{
    int ifail = ITK_ok;

    // Your Implementation

    return ifail;
}
///
/// Getter for a Tag Array Property
/// @param values - Parameter value
/// @param isNull - Returns true for an array element if the parameter value at that location is null
/// @return - Status. 0 if successful
///
int  Ng5_EngPartRevisionImpl::getNg5_ProblemReportBase( std::vector<tag_t> & values, std::vector<int> & isNull ) const
{
    int ifail = ITK_ok;





            int         ipriObjCount           =       0;

            tag_t       tPR                     =       NULLTAG;
            tag_t       *tPrimaryObjects         =       NULL;
            TC_write_syslog("\n\t Entering Ng5_EngPartRevisionImpl::getNg5_ProblemReportBase \n");

            //Get the Part Revision Tag
            Ng5_EngPartRevision *bo = getNg5_EngPartRevision();
            tPR = ((Teamcenter::BusinessObject*)bo)->getTag();

            std::vector<tag_t>      vTagValues;
            std::vector<int>        vIsNullLocal;

            vTagValues.clear();

            //Getting where referenced objects

            Ng5_CommonUtils::Find_All_Primary_Object(tPR,CMHasProblemItem_rel,&ipriObjCount,&tPrimaryObjects);
            	for(int inx=0; inx<ipriObjCount; inx++)
            	{

            			if(NULLTAG != tPrimaryObjects[inx])
            			{
            				char    *cObjectTypeRev = NULL;
            				char    cRelationNameRev[WSO_name_size_c+1]    =       {'\0'};
            				//TC12 Upgrade
            				ITK( WSOM_ask_object_type2 (tPrimaryObjects[inx], &cObjectTypeRev) );

            				//Checking if referenced type is a Eng Part Revision and relation as Ng5_rHasDerivedFromRel
            				if( tc_strcmp(PROBLEM_REPORT_REVISION, cObjectTypeRev) == 0 )
            					{
            						vTagValues.push_back(tPrimaryObjects[inx]);
            						vIsNullLocal.push_back(false);
            					}
							MEM_TCFREE(cObjectTypeRev);
            			}

            	}
            	if(vTagValues.size() > 0)
            	{
            		values.clear();
            		values.swap(vTagValues);
            	}
            	if(vIsNullLocal.size() > 0)
            	{
            		isNull.clear();
            		isNull.swap(vIsNullLocal);
            	}

            	if(tPrimaryObjects != NULL)
            		MEM_TCFREE(tPrimaryObjects);


    TC_write_syslog("\n\t Exiting Ng5_EngPartRevisionImpl::getNg5_ProblemReportBase \n");

    return ifail;
}

///
/// Setter for a Tag Array Property
/// @param values - Values to be set for the parameter
/// @param isNull - If array element is true, set the parameter value at that location as null
/// @return - Status. 0 if successful
///
int  Ng5_EngPartRevisionImpl::setNg5_ProblemReportBase( const std::vector<tag_t> & /*values*/, const std::vector<int> * /*isNull*/ )
{
    int ifail = ITK_ok;

    // Your Implementation

    return ifail;
}



///
/// Getter for a Tag Array Property
/// @param values - Parameter value
/// @param isNull - Returns true for an array element if the parameter value at that location is null
/// @return - Status. 0 if successful
///
int  Ng5_EngPartRevisionImpl::getNg5_ChangeNoticeBase( std::vector<tag_t> & values, std::vector<int> & isNull ) const
{
    int ifail = ITK_ok;

    // Your Implementation


    int         ipriObjCount           =       0;

    tag_t       tPR                     =       NULLTAG;
    tag_t       *tPrimaryObjects         =       NULL;
    TC_write_syslog("\n\t Entering Ng5_EngPartRevisionImpl::getNg5_ChangeNoticeBase \n");

    //Get the Part Revision Tag
    Ng5_EngPartRevision *bo = getNg5_EngPartRevision();
    tPR = ((Teamcenter::BusinessObject*)bo)->getTag();

    std::vector<tag_t>      vTagValues;
    std::vector<int>        vIsNullLocal;

    vTagValues.clear();

    //Getting where referenced objects

    Ng5_CommonUtils::Find_All_Primary_Object(tPR,EC_Solution_Item_REL,&ipriObjCount,&tPrimaryObjects);
    	for(int inx=0; inx<ipriObjCount; inx++)
    	{

    			if(NULLTAG != tPrimaryObjects[inx])
    			{
    				char    *cObjectTypeRev = NULL;
    				char    cRelationNameRev[WSO_name_size_c+1]    =       {'\0'};
    				//TC12 Upgrade, clean up the variable
    				ITK( WSOM_ask_object_type2 (tPrimaryObjects[inx], &cObjectTypeRev) );

    				//Checking if referenced type is a Eng Part Revision and relation as Ng5_rHasDerivedFromRel
    				if( tc_strcmp(CHANGE_NOTICE_REVISION, cObjectTypeRev) == 0 )
    					{
    						vTagValues.push_back(tPrimaryObjects[inx]);
    						vIsNullLocal.push_back(false);
    					}
					MEM_TCFREE(cObjectTypeRev);
    			}

    	}
    	if(vTagValues.size() > 0)
    	{
    		values.clear();
    		values.swap(vTagValues);
    	}
    	if(vIsNullLocal.size() > 0)
    	{
    		isNull.clear();
    		isNull.swap(vIsNullLocal);
    	}

    	if(tPrimaryObjects != NULL)
    		MEM_TCFREE(tPrimaryObjects);
    TC_write_syslog("\n\t Exiting Ng5_EngPartRevisionImpl::getNg5_ChangeNoticeBase \n");

    return ifail;
}int  Ng5_EngPartRevisionImpl::getNg5_ChangeRequestBase( std::vector<tag_t> & values, std::vector<int> & isNull ) const
{
           int ifail                          = ITK_ok;
           int         ipriObjCount           = 0;

            tag_t       tPR                   = NULLTAG;
            tag_t       *tPrimaryObjects      = NULL;
            TC_write_syslog("\n\t Entering Ng5_EngPartRevisionImpl::getNg5_ChangeRequestBase \n");

            //Get the Part Revision Tag
            Ng5_EngPartRevision *bo = getNg5_EngPartRevision();
            tPR = ((Teamcenter::BusinessObject*)bo)->getTag();

            std::vector<tag_t>      vTagValues;
            std::vector<int>        vIsNullLocal;

            vTagValues.clear();

            //Getting where referenced objects
 		
	Ng5_CommonUtils::Find_All_Primary_Object(tPR,EC_Solution_Item_REL,&ipriObjCount,&tPrimaryObjects);

           for(int inx=0; inx<ipriObjCount; inx++)
            	{

            			if(NULLTAG != tPrimaryObjects[inx])
            			{
            				char    *cObjectTypeRev = NULL;
            				char    cRelationNameRev[WSO_name_size_c+1]    =       {'\0'};
            				//TC12 Upgrade, cleanup the variable
            				ITK( WSOM_ask_object_type2 (tPrimaryObjects[inx], &cObjectTypeRev) );

            				//Checking if referenced type is a Eng Part Revision and relation as Ng5_rHasDerivedFromRel
            				if( tc_strcmp(CHANGE_REQUEST_REVISION, cObjectTypeRev) == 0 )
            					{
            						vTagValues.push_back(tPrimaryObjects[inx]);
            						vIsNullLocal.push_back(false);
            					}
							MEM_TCFREE(cObjectTypeRev);
            			}

            	}
            	if(vTagValues.size() > 0)
            	{
            		values.clear();
            		values.swap(vTagValues);
            	}
            	if(vIsNullLocal.size() > 0)
            	{
            		isNull.clear();
            		isNull.swap(vIsNullLocal);
            	}

            	if(tPrimaryObjects != NULL)
            		MEM_TCFREE(tPrimaryObjects);


    //TC_write_syslog("\n\t Exiting Ng5_EngPartRevisionImpl::getNg5_ProblemReportBase \n");

    return ifail;
}
///
/// Setter for a Tag Array Property
/// @param values - Values to be set for the parameter
/// @param isNull - If array element is true, set the parameter value at that location as null
/// @return - Status. 0 if successful
///
int  Ng5_EngPartRevisionImpl::setNg5_ChangeNoticeBase( const std::vector<tag_t> & /*values*/, const std::vector<int> * /*isNull*/ )
{
    int ifail = ITK_ok;

    // Your Implementation

    return ifail;
}
