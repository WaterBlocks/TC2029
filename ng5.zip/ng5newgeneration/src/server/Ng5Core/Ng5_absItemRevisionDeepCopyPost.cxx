/*********************************************************************************************
** File Name:        Ng5_absItemRevisionDeepCopyPost.cxx

**
** File Description: This file contains implementation of extension Ng5_absItemRevisionDeepCopyPost. This extension is added on Post action of Deep copy operation of Abstract Item
**					 Revision. This extension set ng5_status_indicator attribute on new revision created after Revise and saved as to indicate Overlay icon of latest revision as
**					 green. Also it resets the value of ng5_status_indicator on earlier latest revision to show that revision is no longer the latest.
**
**
** History:
** mm/dd/yyyy     		Name                  Comments
** ----------          -------               -------------------------
** 12/22/2016  			Atish Misal      	Initial Creation (AGM ID : 3860	Status Indicator - Differenciate latest and non-latest revisions)
** 1/08/2018  		    Pradnya Hingankar	Added MEM_TCFREE(ptRevList);
** 24/06/2019           Venkat Konda        301062: It appears minor revision gets latest green circle on part icon, but should not
** 05/07/2021            Balaji              TC12 Upgrade
*********************************************************************************************/
#include <Ng5Core/Ng5_absItemRevisionDeepCopyPost.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

using namespace std;
using namespace ng5newgeneration;

/* This is extension implementation for Item revision (Eng Part, ext Part etc) when revise / save as operation is performed.
*  We are not considering baseline as revision for setting up latest overlay icon, icon will be set only for major and minor revisions
*/
int Ng5_absItemRevisionDeepCopyPost( METHOD_message_t *msg, va_list args )
{
 

	TC_write_syslog("\n\t Entering Ng5_absItemRevisionDeepCopyPost..... \n");
	int iFail = ITK_ok;
	va_list largs;
	va_copy( largs, args );

	tag_t    tNewRev = NULLTAG;
	tag_t    tSourceRev = NULLTAG;
	char     *cOperation = NULL;
	char *pcOriginatingSite = NULL;
	tag_t tNewItem = NULLTAG;


	tNewRev = va_arg (largs, tag_t);
	cOperation = va_arg (largs,  char*);
	tSourceRev = va_arg (largs, tag_t);

	try
	{

    if ( tc_strcmp ( cOperation,  ITEM_revise_operation) == 0)
	{

	    //Code for Reset Overlay Icon attribute

		bool bIsLegacy = false;

		//If Originating Site is blank then skip validations for setting Status Indicator and set it on next revision
		//(This is for legacy data, as we don't have any revision id Pattern fixed for Legacy Data)
		ITK(AOM_ask_value_string(tSourceRev,ATTR_ORIGINATING_SITE,&pcOriginatingSite));

		if(!(tc_strcmp(pcOriginatingSite,"")==0))
		{
			bIsLegacy = true;
		}
		char *pcMinorRevId   = NULL;
		char *pcRevID        = NULL;
		char *pcOverlyStatus = NULL;
		char *cRevId         = NULL;
		int iMaxNum          = 3;
		int iRevSize         = 0;
		bool bIsRevise       = false;
		char* szObjectType	 = NULL;

		ITK(POM_set_env_info(POM_bypass_attr_update,true,0,0.0,NULLTAG,NULL));

		ITK( AOM_ask_value_string (tNewRev,ATTR_OBJECT_TYPE,&szObjectType) );

		if( szObjectType != NULL && tc_strlen(szObjectType) > 0 &&  (tc_strcmp ( szObjectType,ITEM_EXTERNAL_PART_REVISION ) == 0) )
		{
			//For External Part Revision objects no need to do validation for Minor/Major/Baseline
			bIsRevise = true;
		}

		else
		{
			ITK(AOM_ask_value_string(tNewRev,ATTR_STATUS_INDICATOR,&pcOverlyStatus));

			ITK(ITEM_ask_rev_id2 ( tNewRev, &cRevId )); //TC12 upgrade
			iRevSize = strlen(cRevId);
			// Checking Rev ID size if it's less than or equal to 3 means this is Revise operation not a Baseline operation.
			if (iRevSize <= iMaxNum  )
			{
				//This is major revision
				bIsRevise = true;
			} 
			else if (iRevSize <= 6) 
			{
				
				// Tokanise Revision Id to find out Major /Minor / Baseline Id
				pcRevID = tc_strtok(cRevId, ".");
				//AAaa  =  minor
				//AA = Major
				pcMinorRevId = tc_strtok(NULL, ".");
				if (iMaxNum < tc_strlen(pcMinorRevId))
				{
					//Setting flag true for Only Revise operation
					//if pcMinorRevId is greater than 3 means its a minor revision
					bIsRevise = true;
				}
			}
		}

		//This is check for baseline operation. For baseline we dont want to set overlay icon.
			
		if (bIsRevise == false )
		{
			if ((tc_strcmp(pcOverlyStatus, ATTR_VALUE_STATUS_INDICATOR) == 0))
			{
				AM__set_application_bypass(true);
				//Business logic to set the property value
					
				ITK(AOM_refresh(tNewRev,true));
		        //Set blank string on baseline revision
					
				ITK(AOM_set_value_string(tNewRev,ATTR_STATUS_INDICATOR,""));

				ITK(AOM_save_with_extensions (tNewRev));//TC12 Upgrade

				//ITK(AOM_refresh(tNewRev,false));

				//set the bypass rule to false again
				AM__set_application_bypass(false);
			}
		}
		// If it is a revise operation
		if (bIsRevise == true )
		{
			int iRevCounter = 0;
			int iRevCount = 0;
			tag_t *ptRevList = NULL;
			tag_t tItemTag = NULLTAG;
			char *pcObsolteClosed = NULL;

			ITK(ITEM_ask_item_of_rev (tNewRev,&tItemTag));
			/*	if (tNewRev != NULLTAG)
			{
				AM__set_application_bypass(true);
				ITK(AOM_refresh(tNewRev,true));
				ITK(AOM_set_value_string(tNewRev,ATTR_STATUS_INDICATOR,ATTR_VALUE_STATUS_INDICATOR));
				ITK(AOM_save_with_extensions (tNewRev)); //TC12 Upgrade
				ITK(AOM_refresh(tNewRev,false));
				//set the bypass rule to false again
				AM__set_application_bypass(false);
			} */

			ITK(ITEM_list_all_revs(tItemTag,&iRevCount,&ptRevList));
			for (int iRevCounter = 0; iRevCounter < iRevCount; iRevCounter++)
			{
				tag_t tCurrentItemRev = ptRevList[iRevCounter];
				char *pcOverlay = NULL;

				ITK(AOM_ask_value_string(tNewRev,ATTR_STATUS_INDICATOR,&pcOverlay));
				ITK(AOM_ask_value_string(tCurrentItemRev,ATTR_STATUS_INDICATOR,&pcObsolteClosed));

				if (tNewRev != tCurrentItemRev && (tc_strcmp(pcObsolteClosed, ATTR_VALUE_STATUS_INDICATOR) == 0))
				{
					AM__set_application_bypass(true);

					ITK(AOM_refresh(tCurrentItemRev,true));

					ITK(AOM_set_value_string(tCurrentItemRev,ATTR_STATUS_INDICATOR,""));

					ITK(AOM_save_with_extensions (tCurrentItemRev));//TC12 Upgrade

					ITK(AOM_refresh(tCurrentItemRev,false));

					//set the bypass rule to false again
					AM__set_application_bypass(false);

				}

				if (tNewRev == tCurrentItemRev && (tc_strcmp(pcOverlay,	"") == 0))
				{

					AM__set_application_bypass(true);

					ITK(AOM_refresh(tCurrentItemRev,true));

					ITK(AOM_set_value_string(tCurrentItemRev,ATTR_STATUS_INDICATOR,ATTR_VALUE_STATUS_INDICATOR));

					ITK(AOM_save_with_extensions (tCurrentItemRev));//TC12 Upgrade

					//ITK(AOM_refresh(tCurrentItemRev,false));

					//set the bypass rule to false again
					AM__set_application_bypass(false);
				}
				MEM_TCFREE(pcOverlay);
				MEM_TCFREE(pcObsolteClosed);
			}
			MEM_TCFREE(ptRevList);
		}
		MEM_TCFREE (cRevId); //tc12 upgrade
		MEM_TCFREE( pcOverlyStatus ); //tc12 upgrade
		MEM_TCFREE( szObjectType );
	}
	else if (tc_strcmp ( cOperation,  ITEM_saveas_operation) == 0)  //Save As
	{

		AM__set_application_bypass(true);

	 	//Business logic to set the property value
		//Not unlocking the Item Revision as it is being refered internally by TC or any other extension functionality
		//Defect 622 - Latest revision icon incdicator does not appear when Sava As operation done on Minor revision

		 ITK(AOM_refresh(tNewRev, true));
		  ITK(AOM_set_value_string(tNewRev,ATTR_STATUS_INDICATOR,ATTR_VALUE_STATUS_INDICATOR));
		  ITK(AOM_set_value_string(tNewRev, IS_INITIAL_REV, YES));
		  char *cObjectType = NULL;
		  ITK(AOM_ask_value_string(tNewRev, ATTR_OBJECT_TYPE, &cObjectType));
		  if(tc_strcmp(cObjectType, ENG_PART_REVISION)== 0 ||tc_strcmp(cObjectType, ENG_DRAWING_REVISION)== 0 ||tc_strcmp(cObjectType, SUPPORT_DESIGN_REV)== 0 )
		  {
			  ITK(AOM_set_value_string(tNewRev, REV_TYPE, MAJOR));
		  }

		  ITK(AOM_save_with_extensions (tNewRev));//TC 12 upgrade
		  MEM_TCFREE(cObjectType);

		 //set the bypass rule to false again
		  AM__set_application_bypass(false);

    }

}
catch (...)

{

}

 TC_write_syslog("\n\t Exiting Ng5_absItemRevisionDeepCopyPost..... \n");
 return iFail;

}


