//@<COPYRIGHT>@
//==================================================
//Copyright $2017.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

// 
//  @file
//  This file contains the implementation for the Business Object Ng5_RawMaterialRevisionImpl
//

#include <Ng5Core/Ng5_RawMaterialRevisionImpl.hxx>

#include <fclasses/tc_string.h>
#include <tc/tc.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include "Ng5_CommonUtils.hxx"

using namespace ng5newgeneration;

//----------------------------------------------------------------------------------
// Ng5_RawMaterialRevisionImpl::Ng5_RawMaterialRevisionImpl(Ng5_RawMaterialRevision& busObj)
// Constructor for the class
//----------------------------------------------------------------------------------
Ng5_RawMaterialRevisionImpl::Ng5_RawMaterialRevisionImpl( Ng5_RawMaterialRevision& busObj )
   : Ng5_RawMaterialRevisionGenImpl( busObj )
{
}

//----------------------------------------------------------------------------------
// Ng5_RawMaterialRevisionImpl::~Ng5_RawMaterialRevisionImpl()
// Destructor for the class
//----------------------------------------------------------------------------------
Ng5_RawMaterialRevisionImpl::~Ng5_RawMaterialRevisionImpl()
{
}

//----------------------------------------------------------------------------------
// Ng5_RawMaterialRevisionImpl::initializeClass
// This method is used to initialize this Class
//----------------------------------------------------------------------------------
int Ng5_RawMaterialRevisionImpl::initializeClass()
{
    int ifail = ITK_ok;
    static bool initialized = false;

    if( !initialized )
    {
        ifail = Ng5_RawMaterialRevisionGenImpl::initializeClass( );
        if ( ifail == ITK_ok )
        {
            initialized = true;
        }
    }
    return ifail;
}

/*
 * **
 * Created By	:	Anil Kumar G
 * Created Date	:	22-Feb-2017
 *
 * Functionality:	Setter for a string Property
 * 					@param value - Value to be set for the parameter
 * 					@param isNull - If true, set the parameter value to null
 * 					@return - Status. 0 if successful
 *					This Method is to get the list of objects for a given relation Ng5_rHasDerivedFromRel
 *					using the runtime property ng5_derived
 */

///
/// Getter for a Tag Array Property
/// @param values - Parameter value
/// @param isNull - Returns true for an array element if the parameter value at that location is null
/// @return - Status. 0 if successful
///
/*int  Ng5_RawMaterialRevisionImpl::getNg5_derivedBase( std::vector<tag_t> &values, std::vector<int> & isNull ) const
{
    int ifail = ITK_ok;

    int         iRefs           =       0;
    int         *ipLevels       =       NULL;
    char        **sz2Rels       =       NULL;
    tag_t       tPR            =       NULLTAG;
    tag_t       *tpRefs         =       NULL;
    TC_write_syslog("\n\t Entering Ng5_RawMaterialRevisionImpl::getNg5_derivedBase \n");

    //Get the Part Revision Tag
    Ng5_RawMaterialRevision *bo = getNg5_RawMaterialRevision();
    tPR = ((Teamcenter::BusinessObject*)bo)->getTag();

    std::vector<tag_t>      vTagValues;
    std::vector<int>        vIsNullLocal;

    vTagValues.clear();

    //Getting where referenced objects
    ITK( WSOM_where_referenced( tPR, 1, &iRefs, &ipLevels, &tpRefs, &sz2Rels) );

    	for(int iWhere=0; iWhere<iRefs; iWhere++)
    	{
    		if( sz2Rels[iWhere] != NULL )
    		{
    			if(NULLTAG != tpRefs[iWhere])
    			{
    				char    cObjectTypeRev[WSO_name_size_c+1]    =       {'\0'};
    				char    cRelationNameRev[WSO_name_size_c+1]    =       {'\0'};
    				ITK( WSOM_ask_object_type(tpRefs[iWhere], cObjectTypeRev) );
    				if (tc_strcpy(cRelationNameRev,sz2Rels[iWhere]) == 0);
    				{
    				//Checking if referenced type is a Eng Part Revision and relation as Ng5_rHasDerivedFromRel
    				if(( tc_strcmp(RAW_MATERIAL_REVISION, cObjectTypeRev) == 0 ) && (tc_strcmp(PrtrevToPrtrevDerivedFrom_Rel,cRelationNameRev) == 0))
    					{
    						vTagValues.push_back(tpRefs[iWhere]);
    						vIsNullLocal.push_back(false);
    					}
    				}
    			}
    		}
    	}
    	if(vTagValues.size() > 0)
    	{
    		values.clear();
    		values.swap(vTagValues);
    	}
    	if(vIsNullLocal.size() > 0)
    	{
    		isNull.clear();
    		isNull.swap(vIsNullLocal);
    	}

    	if(ipLevels != NULL)
    		MEM_TCFREE(ipLevels);
    	if(sz2Rels != NULL)
    		MEM_TCFREE(sz2Rels);
    	if(tpRefs != NULL)
    		MEM_TCFREE(tpRefs);
    return ifail;

}*/

