/*********************************************************************************************
** File Name:         Ng5_EngPartRevisionRevisePostAction.cxx
**
** File Description:
	This file contains the implementation to post action on revise and create new revision operation.
	The method is responsible for setting the initial revision and major /minor revision of Eng Part
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   2/27/2017  Shibabrata Jena      Initial Version
**   5/07/2021  Balaji               TC12 Upgrade
*********************************************************************************************/
#include <Ng5Core/Ng5_EngPartRevisionSavePostAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>

#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <tccore/method.h>
#include <curl/curl.h>

using namespace ng5newgeneration;

//-----------------------------------------------------------------------------------------------------
// int Ng5_EngPartRevisionRevisePostAction( METHOD_message_t * msg, va_list args )
// implementation for the extension on post action of Item_Copy_rev operation of Eng part revision
// and update the custom properties ng5_rev_type and ng5_is_initial_rev
//------------------------------------------------------------------------------------------------------

int Ng5_EngPartRevisionSavePostAction( METHOD_message_t * msg, va_list args )
{
 
	TC_write_syslog("\n Entering Ng5_EngPartRevisionSavePostAction  \n");
	int iFail = ITK_ok;
	char* cpIsTDP = NULL;
	char* cpReadiness =  NULL;
	logical lValidTag =false;

	tag_t tLatestRev = va_arg(args, tag_t);

	METHOD_id_t messageMethod = msg->method;
	//void * iMethodId =  messageMethod.id;
	//iMethodId = messageMethod->id;

	try
	{



					// Checking weather tag is valid for setting up latest icon
					ITK(POM_is_tag_valid (tLatestRev,&lValidTag ));

					if (lValidTag)
					{
						//check if Rev is major or minor
                        AOM_ask_value_string(tLatestRev,"ng5_is_tdp",&cpIsTDP);
                        AOM_ask_value_string(tLatestRev,"ng5_readiness",&cpReadiness);
                        TC_write_syslog("\n TDP:%s,Readiness:%s",cpIsTDP,cpReadiness);
		                ITK(AOM_refresh(tLatestRev,true));
		                //
		                //ogical isMinorRev = false;

						//isMinorRev = Ng5_CommonUtils::isMinorRevision((char*)rev_id);
						if(tc_strcmp(cpIsTDP,"Yes")==0)

		                {

		                  ITK(AOM_set_value_string(tLatestRev, "ng5_tdp","TDP"));

		                }
						else
						{
							ITK(AOM_set_value_string(tLatestRev, "ng5_tdp",""));
						}

		                //check if the extension is ITEM_COPY_MSG or ITEM_CREATE_REV_msg



						ITK(AOM_save_without_extensions(tLatestRev)); //TC 12 Upgrade

						//ITK(AOM_refresh(tLatestRev,false)); //Fix-Complex Property Fix issue
					}


	}
	catch (...)
	{

	}

	TC_write_syslog("\n Exiting Ng5_EngPartRevisionSavePostAction \n");
	return iFail;

}
