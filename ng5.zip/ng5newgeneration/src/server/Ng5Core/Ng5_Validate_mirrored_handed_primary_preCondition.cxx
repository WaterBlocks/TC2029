 /*********************************************************************************************
** File Name:         Ng5_Validate_mirrored_handed_primary_preCondition.cxx
**
** File Description:
** This file contains the implementation for the Extension Ng5_Validate_mirrored_handed_primary_preCondition
** This extension will check if Mirrored Handed Relation is getting created in reverse direction.Error is thrown if the Mirror handed relation is already created between two parts ** and now is being created in reverse direction.
**
** History:
**
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   08/01/2018  Manjula Tirunagari    Added constant for hard coded values
**   08/20/2018  Pradnya Hingankar     Reconstruct entire code to remove CATIA Specific (MML Link) , check for cyclic Mirror handed Relation creation. Code is modified to check
**										if Mirrored Handed Relation is getting created in reverse direction, irresecptive of CATIA or NX datasets present in Revision.
**   07/05/2021  Balaji                TC12 Upgrade   

*********************************************************************************************/
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include <Ng5Core/Ng5_Validate_mirrored_handed_primary_preCondition.hxx>
#include <tc/tc_arguments.h>
#include <tccore/aom_prop.h>


int Ng5_Validate_mirrored_handed_primary_preCondition( METHOD_message_t * msg, va_list args )
{
	int ifail =ITK_ok;

	TC_write_syslog("Entering method Ng5_Validate_mirrored_handed_primary_preCondition \n");

	tag_t tPropTag = va_arg(args, tag_t);
	int iNoOfPrimObjects  = va_arg(args, int);
	const tag_t *tPrimaryObjects = va_arg(args, tag_t*);
	tag_t tSecondaryPartRev = msg->object_tag;

	if(tSecondaryPartRev == NULLTAG )
	{
		TC_write_syslog("Secondary Tag not found\n");
		return ITK_ok;

	}
	if(iNoOfPrimObjects == 0 || tPrimaryObjects == NULL)
	{
		TC_write_syslog("Primary Tag not found\n");
		return ITK_ok;
	}


	if(tPrimaryObjects != NULL)
	{

		char	caPrimaryType[WSO_name_size_c+1]   =	{'\0'};
		char *cSecItemId = NULL;
		char *cSecItemRevId = NULL;
		char* szSecObjStr= NULL;
		char *caSecondaryType = NULL;;
		int iNumberOfMirrorHandedPrimary = 0;
		tag_t *ptMirrorHandedPrimaryTags = NULL;

		ITK(AOM_ask_value_string(tSecondaryPartRev, ATTR_ITEM_ID, &cSecItemId));
		ITK(AOM_ask_value_string(tSecondaryPartRev, ATTR_ITEM_REV_ID, &cSecItemRevId));
		//TC12 Upgrade, cleanup the variable
		ITK( WSOM_ask_object_type2 (tSecondaryPartRev, &caSecondaryType) );

		szSecObjStr = (char *)MEM_alloc(tc_strlen(cSecItemId) + tc_strlen(cSecItemRevId) + tc_strlen("/")+ 1);

		tc_strcpy(szSecObjStr,cSecItemId);
		tc_strcat(szSecObjStr,"/");
		tc_strcat(szSecObjStr,cSecItemRevId);



		for(int iCount=0;iCount<iNoOfPrimObjects;iCount++)
		{
			ITK(AOM_ask_value_tags(tPrimaryObjects[iCount],ATTR_MIRRORED_HANDED_PRIMARY,&iNumberOfMirrorHandedPrimary,&ptMirrorHandedPrimaryTags));
			for(int ii=0;ii<iNumberOfMirrorHandedPrimary;ii++)
			{
				char* szPrimaryItemID = NULL;
				char* szPrimaryRevId= NULL;

				char* szPriObjStr= NULL;

				ITK(AOM_ask_value_string(tPrimaryObjects[iCount], ATTR_ITEM_ID, &szPrimaryItemID));
				ITK(AOM_ask_value_string(tPrimaryObjects[iCount], ATTR_ITEM_REV_ID, &szPrimaryRevId));
				szPriObjStr = (char *)MEM_alloc(tc_strlen(szPrimaryItemID) + tc_strlen(szPrimaryRevId) + tc_strlen("/")+ 1);


				tc_strcpy(szPriObjStr,szPrimaryItemID);
				tc_strcat(szPriObjStr,"/");

				tc_strcat(szPriObjStr,szPrimaryRevId);


				if(ptMirrorHandedPrimaryTags[ii]==tSecondaryPartRev)
				{
					TC_write_syslog("\n Cyclic relation is being created..");
					ifail = ErrorCodeForMHPrimary;
					EMH_store_error_s2(EMH_severity_error, ifail,szPriObjStr,szSecObjStr);
					NG5_MEM_TCFREE(szPriObjStr);
					NG5_MEM_TCFREE(szSecObjStr);
					NG5_MEM_TCFREE(szPrimaryItemID);
					NG5_MEM_TCFREE(szPrimaryRevId);
					NG5_MEM_TCFREE(cSecItemId);
					NG5_MEM_TCFREE(cSecItemRevId);
					return ifail;
				}
			}
		}
		tag_t tMirroredHandedReln = NULLTAG;
		ITK( GRM_find_relation_type(MIRRORED_HANDED, &tMirroredHandedReln) );
		if((NULLTAG != tMirroredHandedReln))
		{


			int		iDst		=	0;
			tag_t		*tpCatDst	=	NULL;
			int		iSecEngPrt	=	0;
			tag_t		*tpSecEngPrt	=	NULL;

			//Getting the secondary (Engineered Part Revision) of above CATPart with relation catiaV5_MML - If exists

			ITK( GRM_list_secondary_objects_only(tSecondaryPartRev, tMirroredHandedReln, &iSecEngPrt, &tpSecEngPrt) );

			if(NULL != tpSecEngPrt)
			{

				for(int iPrt=0; iPrt<iSecEngPrt; iPrt++)
				{
					//Check if cyclic relationship is getting created for mirrored handed relation
					for(int iCount=0;iCount<iNoOfPrimObjects;iCount++)
					{
						if(tpSecEngPrt[iPrt] == tPrimaryObjects[iCount])
						{
							char* szPrimaryItemID = NULL;
							char* szPrimaryRevId= NULL;
							char * szSecItemID = NULL;
							char * szSecItemRevID = NULL;
							char* szPriObjStr= NULL;
							ITK(AOM_ask_value_string(tPrimaryObjects[iCount], ATTR_ITEM_ID, &szPrimaryItemID));
							ITK(AOM_ask_value_string(tPrimaryObjects[iCount], ATTR_ITEM_REV_ID, &szPrimaryRevId));
							szPriObjStr = (char *)MEM_alloc(tc_strlen(szPrimaryItemID) + tc_strlen(szPrimaryRevId) + tc_strlen("/")+ 1);

							tc_strcpy(szPriObjStr,szPrimaryItemID);
							tc_strcat(szPriObjStr,"/");
							tc_strcat(szPriObjStr,szPrimaryRevId);

							TC_write_syslog("\n Cyclic relation is being created..");
							ifail = ErrorCodeForMHPrimary;


							EMH_store_error_s2(EMH_severity_error, ifail,szPriObjStr,szSecObjStr);
							NG5_MEM_TCFREE(szPriObjStr);
							NG5_MEM_TCFREE(szPrimaryItemID);
							NG5_MEM_TCFREE(szPrimaryRevId);
							break;
						}
					}
				}

				NG5_MEM_TCFREE(tpSecEngPrt);

			}
		}
		NG5_MEM_TCFREE(cSecItemId);
		NG5_MEM_TCFREE(cSecItemRevId);
		NG5_MEM_TCFREE(szSecObjStr);
		NG5_MEM_TCFREE(ptMirrorHandedPrimaryTags);
		NG5_MEM_TCFREE(caSecondaryType);

	}

	TC_write_syslog("Exitining method Ng5_Validate_mirrored_handed_primary_preCondition \n");
	return ifail;

}
