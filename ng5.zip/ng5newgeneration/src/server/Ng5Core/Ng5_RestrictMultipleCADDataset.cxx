/*==========================================================================================

                    Copyright (c) 2017 - Adient

============================================================================================
File description:

    Ng5_RestrictMultipleCADDataset.cxx


Teamcenter-CAD Integration Multiple Dataset Restriction
   

=============================================================================================
   Date			Name                    Description of Change
  22-Nov-2021	Sahida Khatun              Initial creation
  
==================================================================================================*/
 
#include <Ng5Core/Ng5_RestrictMultipleCADDataset.hxx>
#include <Ng5Core/Ng5_EngPartRevRevisePrecondition.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <tccore/grm.h>
#include <tc/emh.h>
#include <tccore/item.h>
#include <Ng5Core/Ng5Core_Std_Defines.h>


using namespace ng5newgeneration;
//-----------------------------------------------------------------------------------------------------
// int Ng5_EngPartRevRevisePrecondition( METHOD_message_t * msg, va_list args )
// implementation for the extension on precondition of Item_Copy_rev operation of Eng part revision
// and check whether previous revision is part of proposed changes of Change Notice
//------------------------------------------------------------------------------------------------------
int Ng5_RestrictMultipleCADDataset( METHOD_message_t * msg, va_list args)
{
        int retCode				=	ITK_ok;
		int n_args				=	0;
		
		//tag_t tPrimaryObj 		   = msg->;
		//tag_t tSecObj              =NULLTAG;
		
		tag_t tRelation			   = NULLTAG;
		tag_t primaryType          = NULLTAG;
		tag_t secondaryType        = NULLTAG;
		char* primaryClass         = NULL;
		char* secondaryClass       = NULL;
		int   secCount             = 0;
		int   secIndx              = 0;
		tag_t relationType         = NULLTAG;
		tag_t* secondObjs          = NULL;
		tag_t  secObjType          = NULLTAG;
		tag_t  dsType              = NULLTAG;
		tag_t  dsType1             = NULLTAG;
		char*  dsName              = NULL;
		char*  dsName1             = NULL;
		char*  secClass            = NULL;
		//char** pszobjectStringVals = NULL;
		
         tag_t tPrimaryObj  = va_arg(args, tag_t);
         tag_t tSecObj      = va_arg(args, tag_t);
         TC_write_syslog("\nInsideRestrictMultipleCADDataset");
         
         if(tPrimaryObj!=NULLTAG)
         {
           TCTYPE_ask_object_type(tPrimaryObj,&primaryType);
           TCTYPE_ask_class_name2	(primaryType,&primaryClass);	
           TC_write_syslog("\n\n The Primary Class %s",primaryClass);
         }
         if(tSecObj!=NULLTAG)
         {
           TCTYPE_ask_object_type	(tSecObj ,&secondaryType);	
           TCTYPE_ask_class_name2	(secondaryType,&secondaryClass);	
           TC_write_syslog("\n\n The new Secondary Class %s",secondaryClass);
         }
         
         
         GRM_find_relation_type	(REL_SPECIFICATION,&relationType);

         
         if(tc_strcmp(secondaryClass,DATASET)==0)
         {
           //AE_ask_dataset_tool(tSecObj,&dsTool);
           AE_ask_dataset_datasettype(tSecObj,&dsType); 
           AE_ask_datasettype_name2	(dsType,&dsName);			
           
           TC_write_syslog("\n\n The Dataset Type is %s",dsName );	
           if(tc_strcmp(dsName,DATASET_CATPART)==0 ||tc_strcmp(dsName,DATASET_CATPRODUCT)==0 ||tc_strcmp(dsName,DATASET_CATDRAWING)==0)
           {
             GRM_list_secondary_objects_only(tPrimaryObj,relationType,&secCount,&secondObjs);
             for(secIndx=0; secIndx<secCount;secIndx++)
              {
                TCTYPE_ask_object_type	(secondObjs[secIndx] ,&secObjType );
                TCTYPE_ask_class_name2	(secObjType ,&secClass);
                TC_write_syslog("\n\n The existing Secondary Class %s",secClass);
                if(tc_strcmp(secClass,DATASET)==0)
                {
                 AE_ask_dataset_datasettype(secondObjs[secIndx],&dsType1);	
                 AE_ask_datasettype_name2(dsType1,&dsName1);
                   TC_write_syslog("\n\n The  existing Dataset Type is %s",dsName1 );
                   if(tc_strcmp(dsName1,DATASET_UGMASTER)==0 ||tc_strcmp(dsName1,DATASET_UGPART)==0)
                   {
                     TC_write_syslog("\nCatia Dataset is already existing,NX dataset Can't be attached\n");
                     EMH_store_error(EMH_severity_error, ErrorMultipleCADTool);
					 return ErrorMultipleCADTool;
					}
                }
                
              
              }
              	}
              	
             else if(tc_strcmp(dsName,DATASET_UGMASTER)==0 ||tc_strcmp(dsName,DATASET_UGPART)==0)
             {
             GRM_list_secondary_objects_only(tPrimaryObj,relationType,&secCount,&secondObjs);
             for(secIndx=0; secIndx<secCount;secIndx++)
              {
                TCTYPE_ask_object_type(secondObjs[secIndx],&secObjType);
                TCTYPE_ask_class_name2(secObjType ,&secClass);
                TC_write_syslog("\n\n The existing Secondary Class %s",secClass);
                if(tc_strcmp(secClass,DATASET)==0)
                {
                   AE_ask_dataset_datasettype(secondObjs[secIndx],&dsType1);	
                   AE_ask_datasettype_name2(dsType1,&dsName1);
                   TC_write_syslog("\n\n The  existing Dataset Type is %s",dsName1 );
                   if(tc_strcmp(dsName1,DATASET_CATPART)==0 ||tc_strcmp(dsName1,DATASET_CATPRODUCT)==0 ||tc_strcmp(dsName1,DATASET_CATDRAWING)==0)
                   {
                      TC_write_syslog("\n\n NX Dataset is already existing,Catia dataset Can't be attached\n");
                      EMH_store_error(EMH_severity_error, ErrorMultipleCADTool);
					  return ErrorMultipleCADTool ;
					}
                }
               
              }
              }
           
           
           }
           
         NG5_MEM_TCFREE (secClass);
         NG5_MEM_TCFREE (dsName1);
         NG5_MEM_TCFREE (dsName);
         
              
         
         NG5_MEM_TCFREE (secondaryClass);
         
         
  return retCode ;
}