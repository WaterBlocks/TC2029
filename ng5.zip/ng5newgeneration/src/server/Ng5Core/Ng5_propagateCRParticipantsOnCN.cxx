//@<COPYRIGHT>@
//==================================================
//Copyright $2021.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_propagateCRParticipantsOnCN
 *
 */
#include <Ng5Core/Ng5_propagateCRParticipantsOnCN.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>
#include "Ng5_CommonUtils.hxx"

using namespace ng5newgeneration;
/*----------------------------------------------------------------------------------------------

* Operation-Attachment : IMAN_SAVE - Post Action

Currently used on rHasChange Relation Objects

Change History
Date		Name					Comments
									 
06/30/2021  Balaji 			  		Modified function Ng5_propagateCRParticipantsOnCN shifted the logic to propagate participants details   
									from CR to CN and PRG to CN to Ng5_propagateInfoOnRelate
**************************************************************************************/
int Ng5_propagateCRParticipantsOnCN( METHOD_message_t * /*msg*/, va_list args )
{

	
	int iFail = ITK_ok;

	scoped_smptr<char> chTargetObjectType;
	scoped_smptr<char> chMasterPrgObjectType;


	tag_t tChangeNotice	   = NULLTAG;
	tag_t tMasterProgram   = NULLTAG;

	string szPreferenceName 		  = "";
	


TC_write_syslog("\n -----------Ng5_propagateCRParticipantsOnCN ENTRY - IMAN SAVE ------\n" );

 va_list largs;
 va_copy(largs,args);
 tag_t  tCMImplementsRel = va_arg (largs,tag_t);
 int    isNew        	= va_arg (largs,int);
 TC_write_syslog("\n -----------isNew - %d ------\n",isNew );

if(isNew == 1)
	{
		// Modified by Balaji for TC 12 Upgrade 
		NG5_ITK_CALL(GRM_ask_primary(tCMImplementsRel,&tMasterProgram));
		NG5_ITK_CALL(GRM_ask_secondary(tCMImplementsRel,&tChangeNotice));

		if(tChangeNotice == NULLTAG || tMasterProgram == NULLTAG)
		{
			return iFail;
		}
		NG5_ITK_CALL(AOM_ask_value_string(tMasterProgram, ATTR_OBJECT_TYPE, &chMasterPrgObjectType));
	    TC_write_syslog("\n -----------chMasterPrgObjectType %s \n",string(chMasterPrgObjectType.getString()).c_str());
		
		NG5_ITK_CALL(AOM_ask_value_string(tChangeNotice,ATTR_OBJECT_TYPE, &chTargetObjectType));
		TC_write_syslog("\n -----------chTargetObjectType %s \n",string(chTargetObjectType.getString()).c_str());
		
		szPreferenceName = string(chTargetObjectType.getString()) + "_" + string(chMasterPrgObjectType.getString()) + "_ParticipantsMap";
		// Added by Ckoku for CMImprovments
		char* chrChangeType = NULL;
		NG5_ITK_CALL(AOM_ask_value_string(tChangeNotice,"ng5_change_type", &chrChangeType));
		TC_write_syslog("\n -----------chrChangeTypev %s \n",chrChangeType);
		if (chrChangeType != NULL && tc_strcmp(chrChangeType,"Drawing Only Change")!=0 && tc_strcmp(chrChangeType,"Typical Change")!=0)
		{
			TC_write_syslog("\n -----------chrChangeTypev - Indisde ifffff loooooop \n");
			NG5_ITK_CALL(ng5_copyParticipant2(tMasterProgram,tChangeNotice,szPreferenceName));

		} else {
			// Do nothing
			TC_write_syslog("\n -----------chrChangeTypev - Indisde else loooooop \n");
		}

		
		// END of Modifications   by Balaji for TC 12 Upgrade 
	}

	
	TC_write_syslog("\n -----------Ng5_propagateCRParticipantsOnCN Exit Error With %d-\n",iFail );
	return iFail;

}

int ng5_copyParticipant2(tag_t sourceObject,tag_t targetObject,string strPrefValue)
{
	int iFail = ITK_ok;

	tag_t participant_type = NULLTAG;
	tag_t tParticipant = NULLTAG;
	tag_t tRelation_type = NULLTAG;
	tag_t tRelation = NULLTAG;
	tag_t tParticipantUserValue = NULLTAG;
	tag_t tUser = NULLTAG;

	bool isGrpMemberActive = false;
	bool isUserActive = false;
	logical is_deactivated;
	int iUserStatus = 0;
	char* cpUserId = NULL;

	map<string,string> MapPrefValues;
	MapPrefValues.clear();


	TC_write_syslog("\n ng5_copyParticipant2 - Entry \n");

	Ng5_CommonUtils::loadAllPreferencesIntoMap(strPrefValue, MapPrefValues);
	for(map<string, string>::iterator itr = MapPrefValues.begin() ; itr != MapPrefValues.end() ; ++itr)
	{
		NG5_ITK_CALL(AOM_ask_value_tag(sourceObject, itr->second.c_str(), &tParticipantUserValue));
		NG5_ITK_CALL(TCTYPE_find_type(itr->first.c_str(), itr->first.c_str(), &participant_type));
	if(tParticipantUserValue != NULLTAG && participant_type != NULLTAG)
		{
		/*Check Group member status*/
		NG5_ITK_CALL(SA_ask_groupmember_inactive(tParticipantUserValue, &is_deactivated));
		if(is_deactivated)
			{
			//Group member is inactive
			TC_write_syslog("\n Ng5_addParticipantRelationCreatePost --> Group member is inactive");
			
			isGrpMemberActive = false;
			
			}
			else
			{
				//Group member is ACTIVE
				TC_write_syslog ("\n Ng5_addParticipantRelationCreatePost --> Group member is ACTIVE");
				isGrpMemberActive = true;
			}
		/*Check User status*/
		NG5_ITK_CALL(SA_ask_groupmember_user(tParticipantUserValue, &tUser));
		NG5_ITK_CALL(SA_get_user_status(tUser, &iUserStatus));
		NG5_ITK_CALL(POM_ask_user_id(tUser, &cpUserId));
		if(iUserStatus == 1)
		  {
			//User is inactive
			TC_write_syslog ("\n Ng5_addParticipantRelationCreatePost --> cpUserId <%s> is inactive" , cpUserId );
			
			isUserActive = false;
		  }
		else
			{
			//User is ACTIVE
			TC_write_syslog ("\n Ng5_addParticipantRelationCreatePost --> cpUserId <%s> is ACTIVE" , cpUserId );
			isUserActive = true;
			}
		NG5_MEM_TCFREE(cpUserId);
		if((isGrpMemberActive == true) && (isUserActive == true))
		{
			TC_write_syslog("\n  - Both Group member and User id are active \n");
			NG5_ITK_CALL(AOM_refresh(targetObject, true));
			if(iFail == ITK_ok)
			{
				tag_t tRelationExist = NULLTAG;
				NG5_ITK_CALL(EPM_create_participant(tParticipantUserValue, participant_type, &tParticipant));
				NG5_ITK_CALL(GRM_find_relation_type(HAS_PARTICIPANTS_TYPE, &tRelation_type));
				NG5_ITK_CALL(GRM_find_relation(targetObject, tParticipant, tRelation_type, &tRelationExist));
				if(tRelationExist == NULLTAG)
				{
				  NG5_ITK_CALL(GRM_create_relation(targetObject, tParticipant, tRelation_type, NULLTAG, &tRelation));
				  NG5_ITK_CALL(GRM_save_relation(tRelation));
				  NG5_ITK_CALL(AOM_save_with_extensions(targetObject));//TC 12 Upgrade
				}
				NG5_ITK_CALL(AOM_refresh(targetObject, false));
			}
		}
		else
			{

			TC_write_syslog ("\n Ng5_addParticipantRelationCreatePost --> Either Group member or User is inactive, skipping it in Participants");
			}

}
	}
	TC_write_syslog("\n ng5_copyParticipant2 - Exit \n");
			return iFail;
}

