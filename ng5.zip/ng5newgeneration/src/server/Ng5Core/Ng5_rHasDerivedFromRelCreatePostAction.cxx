//@<COPYRIGHT>@
//==================================================
//Copyright $2018.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasDerivedFromRelCreatePostAction
 *   Function will get called whenever the Relationship is created between Engineered Part Rev
 *   and Engineered Part Rev with the Relation 'Has Derived From'.
 *   It checks for the Engineering Part Rev attached to Engineering Part Rev (where it is derived from) & the typed
 *   reference property ng5_derived_from_parts gets updated by adding the Engineered Part Rev
 *    to this property.
 *    Similarly, it will work  whenever the Relationship is created between Raw Material Rev
 *   and Raw Material Rev with the Relation 'Has Derived From'.
 *   History:
 *   mm/dd/yyyy  Name              Comments
 *   ----------  ----------------  -------------------------
 *   05/31/2018  Meenakshi Shenoy  Initial Version
 *   07/05/2021  Balaji            TC12 Upgrade
 */
#include <Ng5Core/Ng5_rHasDerivedFromRelCreatePostAction.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_rHasDerivedFromRelCreatePostAction(METHOD_message_t *msg,
		va_list args) {

	int iFail = ITK_ok;

	tag_t tPartRev = NULLTAG;
	tag_t tEngRev = NULLTAG;
	tag_t tRelationType = NULLTAG;

	TC_write_syslog("\n Entering Ng5_rHasDerivedFromRelCreatePostAction \n");
	tPartRev = va_arg(args, tag_t);
	tEngRev = va_arg(args, tag_t);
	tRelationType = va_arg(args, tag_t);

	if (NULLTAG != tPartRev && NULLTAG != tEngRev && NULLTAG != tRelationType) {
		int numofEngPrt = 0;

		tag_t *tagPrtValues = NULLTAG;

		logical engPartExist = false;

		logical lPriVerdict = false;

		NG5_ITK_CALL(AOM_ask_value_tags(tEngRev,DERIVED_FROM_PARTS,&numofEngPrt,&tagPrtValues));

		//Checking if the Part count is more than 0
		if (numofEngPrt > 0 && tagPrtValues != NULL) {
			for (int indxEngPrt = 0; indxEngPrt < numofEngPrt; indxEngPrt++) {

				//Checking if the Engineered Part is already attached to ng5_derived_from_parts Property
				if (tagPrtValues[indxEngPrt] == tPartRev) {
					engPartExist = true;
				}
			}

		}

		//Setting the ng5_derived_from_parts Property by adding the Eng Part rev to it

		NG5_ITK_CALL( AM_check_privilege (tEngRev, ACCESS_WRITE, &lPriVerdict));

		//Allow only if the logged in user has write access to Primary object
		if (true == lPriVerdict) {
			//If the Part Does not exist or Property value count is 0
			if (engPartExist == false || numofEngPrt == 0) {
				NG5_ITK_CALL(AOM_refresh(tEngRev,TRUE));
				NG5_ITK_CALL(AOM_set_value_tag_at(tEngRev,DERIVED_FROM_PARTS,numofEngPrt, tPartRev));
				TC_write_syslog("\n Setting Property ng5_derived_from_parts \n");
				NG5_ITK_CALL(AOM_save_with_extensions(tEngRev));//TC 12 Upgrade
				NG5_ITK_CALL(AOM_refresh(tEngRev,FALSE));
				if (iFail != ITK_ok) {
					return iFail;
				}
			}
		} else {
			logical lPriVerdict1 = false;
			// if the part is released, bypass is set to update the property
			AM__set_application_bypass(true);
			NG5_ITK_CALL( AM_check_privilege (tEngRev, ACCESS_WRITE, &lPriVerdict1));
			if (lPriVerdict1) {
				TC_write_syslog("\n access obtained \n");
				NG5_ITK_CALL(AOM_refresh(tEngRev,TRUE));
				NG5_ITK_CALL(AOM_set_value_tag_at(tEngRev,DERIVED_FROM_PARTS,numofEngPrt, tPartRev));
				TC_write_syslog("\n Setting Property ng5_derived_from_parts \n");
				NG5_ITK_CALL(AOM_save_with_extensions(tEngRev));//TC 12 Upgrade
				NG5_ITK_CALL(AOM_refresh(tEngRev,FALSE));
			} else {
				TC_write_syslog("\n access not obtained \n");
			}

			AM__set_application_bypass(false);

		}

		TC_write_syslog("\n Leaving Ng5_rHasDerivedFromRelCreatePostAction \n");
		MEM_free(tagPrtValues);

	}
	return iFail;

}
