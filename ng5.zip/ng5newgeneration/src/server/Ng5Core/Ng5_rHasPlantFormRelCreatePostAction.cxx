//@<COPYRIGHT>@
//==================================================
//Copyright $2020.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_rHasPlantFormRelCreatePostAction
 *
 */
#include <Ng5Core/Ng5_rHasPlantFormRelCreatePostAction.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

#include <math.h>
#include <iomanip>
#include <cxpom/attributeaccessor.hxx>
#include <metaframework/BusinessObjectRef.hxx>
#include <sa/sa_errors.h>
#include <ug_va_copy.h>
#include <ce/ce.h>
#include <constants/constants.h>
#include <base_utils/ScopedSmPtr.hxx>
#include <stdarg.h>
#include <string>
#include <sstream>
#include <fclasses/tc_string.h>

#include "Ng5_CommonUtils.hxx"

using namespace std;
using namespace ng5newgeneration;
/**********************************************************************************
 **  Function Name: Ng5_rHasPlantFormRelCreatePostAction
 **  Parameters:
 **     METHOD_message_t*  msg (I)
 **     va_list  args         (I)
 **
 **  Description:
 **    Post Action to create ICE Part form and attach to the parent Object.
 **    If there is existing  ICE Part Form then it will not create, if it doesnt
 **    exists, then creates ICE Part Form and attach it to the Parent Object.
 **
 **
***********************************************************************************/
int Ng5_rHasPlantFormRelCreatePostAction( METHOD_message_t * msg, va_list args )
{

	int iFail           = ITK_ok;
	int nForms          = 0;

	tag_t tMatlMaster   = NULLTAG;
	tag_t tPltForm      = NULLTAG;
	tag_t tRelationType = NULLTAG;
	tag_t* ttForms      = NULLTAG;

	tMatlMaster         = va_arg(args, tag_t);
	tPltForm            = va_arg(args, tag_t);
	tRelationType       = va_arg(args, tag_t);

	TC_write_syslog("\n Entering Ng5_rHasPlantFormRelCreatePostAction\n");

	if (NULLTAG != tPltForm && NULLTAG != tMatlMaster && NULLTAG != tRelationType)
	{
		char* 	cObjectType    	= NULL;
		char*  	cItemID		 	= NULL;
		char*  	cPlantCode	 	= NULL;
		char*   cPlantFormName  = NULL;
		tag_t  	tICEform      	= NULLTAG;
		tag_t  	tPlantform    	= NULLTAG;
		tag_t 	tRelMM 		 	= NULLTAG;
		tag_t  	tRelICEtype   	= NULLTAG;
		tag_t  	tRelPlanttype 	= NULLTAG;
		tag_t  	trelation     	= NULLTAG;
		double 	value		 	= 0.0;
		int 	iEngCnt 	 	= 0;
		tag_t 	*tPrimEngPart 	= NULL;

		NG5_ITK_CALL (AOM_ask_value_string (tMatlMaster,ATTR_OBJECT_TYPE, &cObjectType));
		//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction:object_type %s\n", cObjectType);

		NG5_ITK_CALL (AOM_ask_value_string (tMatlMaster,ATTR_ITEM_ID, &cItemID));
		//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction:cItemID %s\n", cItemID);
		
		NG5_ITK_CALL (AOM_ask_value_string (tPltForm, ATTR_PLANT_CODE, &cPlantCode));
		//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction:cPlantCode %s\n", cPlantCode);
		
		cPlantFormName = (char*)MEM_alloc(sizeof(char)*(tc_strlen(cItemID) + tc_strlen(ROLE_TOKEN) + tc_strlen(cPlantCode)+ 10));
		tc_strcpy(cPlantFormName, cItemID);				
		tc_strcat(cPlantFormName, ROLE_TOKEN);
		tc_strcat(cPlantFormName, cPlantCode);
		
		NG5_ITK_CALL (AOM_refresh(tPltForm, TRUE));
		NG5_ITK_CALL (AOM_set_value_string (tPltForm, OBJECT_NAME, cPlantFormName));
		//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction:cPlantFormName %s\n", cPlantFormName);
		NG5_ITK_CALL (AOM_save(tPltForm));
		NG5_ITK_CALL (AOM_refresh(tPltForm, FALSE));

		//get the relation type for the Eng Part and MM
		NG5_ITK_CALL (GRM_find_relation_type(REL_MATLMSTR, &tRelMM));
		//Get Eng part
		NG5_ITK_CALL(GRM_list_primary_objects_only(tMatlMaster, tRelMM, &iEngCnt, &tPrimEngPart));
		//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction:iEngCnt %d\n", iEngCnt);

		if(iEngCnt > 0 && tPrimEngPart != NULL)
		{
			tag_t 	trelIPFType = NULLTAG;
			int 	iIPFCnt 	= 0;
			tag_t 	*tPrimIPF 	= NULL;

			//get the relation type for the ICE Part form and Eng Part
			NG5_ITK_CALL (GRM_find_relation_type(REL_ICEPARTFORM, &trelIPFType));
			//Get ICE Part Form of Eng Part
			NG5_ITK_CALL(GRM_list_secondary_objects_only(tPrimEngPart[0], trelIPFType, &iIPFCnt, &tPrimIPF));
			//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction:iIPFCnt %d\n", iIPFCnt);
			if(iIPFCnt > 0 && tPrimIPF != NULL)
			{
				char* cObjIPFType = NULL;
				AOM_ask_value_string(tPrimIPF[0], ATTR_OBJECT_TYPE, &cObjIPFType);
				//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction:Object Type = %s \n",cObjIPFType);

				//Get SAP Net Weight
				double 	dSAPwt 		= 0.0;
				char*	cSAPUom 	= NULL;
				char*	cPlantUOM 	= NULL;

				AOM_ask_value_string(tPrimIPF[0], ATTR_SAP_UOM, &cSAPUom);
				//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction:cSAPUom=%s \n",cSAPUom);
				AOM_ask_value_double(tPrimIPF[0], ATTR_SAP_WT, &dSAPwt);
				//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction: SAP Net Weight=%f\n",dSAPwt);

				//Get Plant Weight UOM
				AOM_ask_value_string(tPltForm, ATTR_PLANT_UOM, &cPlantUOM);
				//TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction:cPlantUOM=%s \n",cPlantUOM);

				double	dPlantWt = 0.0;
				NG5_ITK_CALL (Ng5_CommonUtils::getConvertedWeight (cSAPUom, cPlantUOM, dSAPwt, &dPlantWt));

				TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction : ConvertedWeight: Plant Weight=%f\n",dPlantWt);

				NG5_ITK_CALL (AOM_refresh(tPltForm, TRUE));
				NG5_ITK_CALL (AOM_set_value_double (tPltForm, ATTR_PLANT_WT, dPlantWt));
				NG5_ITK_CALL (AOM_save(tPltForm));
				NG5_ITK_CALL (AOM_refresh(tPltForm, FALSE));
				NG5_MEM_TCFREE (cSAPUom);
				NG5_MEM_TCFREE (cPlantUOM);
				NG5_MEM_TCFREE (cObjIPFType);
				NG5_MEM_TCFREE (cObjectType);
				NG5_MEM_TCFREE (cItemID);
				NG5_MEM_TCFREE (tPrimEngPart);
				NG5_MEM_TCFREE (cPlantCode);
				NG5_MEM_TCFREE (cPlantFormName);
			}
			NG5_MEM_TCFREE (tPrimIPF);
		}
	}
	// Cleanup and exit the function.
	TC_write_syslog("\n Ng5_rHasPlantFormRelCreatePostAction exited \n");
	return iFail;
}
