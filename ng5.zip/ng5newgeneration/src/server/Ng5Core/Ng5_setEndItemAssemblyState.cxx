//@<COPYRIGHT>@
//==================================================
//Copyright $2022.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the implementation for the Extension Ng5_setEndItemAssemblyState
 *
 */
#include <Ng5Core/Ng5_setEndItemAssemblyState.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

int Ng5_setEndItemAssemblyState( METHOD_message_t *msg, va_list args)
{
 
	int ifail = 0;
	char *chTypeName = NULL;
	tag_t     tBOMLine         = NULLTAG;
	tag_t 	  tObjType   	   = NULLTAG;

	TC_write_syslog("\n Entering Ng5_setEndItemAssemblyState");

	va_list largs;
	va_copy(largs,args);
	tBOMLine =  msg->object_tag;
	va_end( largs );
	int ienditemstate = 0, enditemstatevalue=0, blIsIpa=0;

	TC_write_syslog("\n LTag of BOM Line = %d \n ", tBOMLine);
	if (NULLTAG != tBOMLine)
	{

        TCTYPE_ask_object_type(tBOMLine,&tObjType);
		TC_write_syslog("\n Type tag of BOM Line = %d \n ", tObjType);
        TCTYPE_ask_name2 (tObjType,&chTypeName);
		TC_write_syslog("\n Object Type = %s \n ", chTypeName);
		BOM_line_look_up_attribute("fnd0bl_is_mono_override",&ienditemstate);
		TC_write_syslog("\n ienditemstate = %d \n ", ienditemstate);
	    BOM_line_ask_attribute_int(tBOMLine,ienditemstate,&enditemstatevalue);
	    TC_write_syslog("\n enditemstatevalue = %d \n ", enditemstatevalue);
	    BOM_line_look_up_attribute("Ng5_Is_Ipa",&blIsIpa);
	    if(enditemstatevalue)
	    {

	        BOM_line_set_attribute_string(tBOMLine,blIsIpa,"Yes");
	    }
	    else
	    {
	    	BOM_line_set_attribute_string(tBOMLine,blIsIpa,"");
	    }

	}

	NG5_MEM_TCFREE(chTypeName);
	TC_write_syslog("\n Existing Ng5_setEndItemAssemblyState");
	return ifail;
}
