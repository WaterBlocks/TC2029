/*********************************************************************************************
** File Name:         Ng5_EngPartRevisionRevisePostAction.hxx
**
** File Description:
	This file contains the implementation to post action on revise and create new revision operation
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- -------------------------
**   2/27/2017  Shibabrata Jena      Initial Version

*********************************************************************************************/
 
#ifndef NG5_ENGPARTREVISIONSAVEPOSTACTION_HXX
#define NG5_ENGPARTREVISIONSAVEPOSTACTION_HXX
#include <tccore/method.h>
#include <Ng5Core/libng5core_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif

//-----------------------------------------------------------------------------------------------------
// int Ng5_EngPartRevisionRevisePostAction( METHOD_message_t * msg, va_list args )
// implementation for the extension on post action of Item_Copy_rev operation of Eng part revision
// and update the custom properties ng5_rev_type and ng5_is_initial_rev
//------------------------------------------------------------------------------------------------------
extern NG5CORE_API int Ng5_EngPartRevisionSavePostAction(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5Core/libng5core_undef.h>
                
#endif  // NG5_ENGPARTREVISIONREVISEPOSTACTION_HXX
