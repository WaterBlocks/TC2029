/*********************************************************************************************
** File Name:        Ng5_absItemRevisionDeletePre.cxx

**
** File Description: This file contains implementation of extension Ng5_absItemRevisionDeletePre. This extension is added on Pre action of Delete operation of Abstract Item
**						Revision. This is extension implementation for Item revision (Eng Part, ext Part etc) when delete operation is performed.
**						Latest revision overlay icon will be set only for major and minor previsous revisions while delete operation is performed on any of the revision 
**						This extension set ng5_status_indicator attribute on previous Major or Minor revision in order show them latest after deletion
**						of current revision.
**
**
** History:
** mm/dd/yyyy     		Name                  Comments
** ----------          -------               -------------------------
** 12/21/2016  			Atish Misal      	Initial Creation (AGM ID : 3860	Status Indicator - Differenciate latest and non-latest revisions)
** 1/08/2018  		Pradnya Hingankar		Added COnstant for Owning site attribute
** 05/07/2021           Sahida              TC12 Upgrade

*********************************************************************************************/

#include <Ng5Core/Ng5_absItemRevisionDeletePre.hxx>
#include <Ng5Core/Ng5_CommonUtils.hxx>
#include <Ng5Core/Ng5Core_Std_Defines.h>

using namespace std;
using namespace ng5newgeneration;


/* This is extension implementation for Item revision (Eng Part, ext Part etc) when delete operation is performed.
*  Latest revision overlay icon will be set only for major and minor previsous revisions while delete operation is performed on any of the revision
*/
int Ng5_absItemRevisionDeletePre( METHOD_message_t *msg, va_list args )
{
 
	TC_write_syslog("\n Entering Ng5_absItemRevisionDeletePre \n");

		int iFail = ITK_ok;
		tag_t tNewRevision = va_arg(args, tag_t); // New  Revision tag
		tag_t tItemTag = NULLTAG;
		tag_t tLatestRevProcess = NULLTAG;
		char *pcOverlyStatus=NULL;
		tag_t tOwningSite = NULLTAG;

try
{
		ITK(AOM_ask_value_tag(tNewRevision,ATTR_OWNING_SITE,&tOwningSite));
		if(tOwningSite == NULLTAG)
		{

			// This function retuen latest revision from all availble revision of the item.
			tLatestRevProcess=Ng5_CommonUtils::getLatestRevisionOverlay(tNewRevision);


		   if (tLatestRevProcess != NULLTAG)
			{

			   // This API will not change last modified date even thought business object is modified
			   ITK(POM_set_env_info(POM_bypass_attr_update,false,0,0.0,NULLTAG,NULL));


			   ITK(AOM_ask_value_string(tLatestRevProcess,ATTR_STATUS_INDICATOR,&pcOverlyStatus));

			   if (tc_strcmp(pcOverlyStatus, "") == 0)
			   {

					AM__set_application_bypass(true);

					//Business logic to set the property value

					ITK(AOM_refresh(tLatestRevProcess,true));

					ITK(AOM_set_value_string(tLatestRevProcess, ATTR_STATUS_INDICATOR, ATTR_VALUE_STATUS_INDICATOR));

					ITK(AOM_save_with_extensions(tLatestRevProcess));//TC12 Upgrade

					ITK(AOM_refresh(tLatestRevProcess,false));

					//set the bypass rule to false again
					AM__set_application_bypass(false);

			     }


			}
		}
		else{
			TC_write_syslog("\n Skipping Replica object \n");
		}

			MEM_TCFREE(pcOverlyStatus);

}
catch(...)
{
	MEM_TCFREE(pcOverlyStatus);
}

TC_write_syslog("\n Exiting Ng5_absItemRevisionDeletePre \n");
		return iFail;

}
