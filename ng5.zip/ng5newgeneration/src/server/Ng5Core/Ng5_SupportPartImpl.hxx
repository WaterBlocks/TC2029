/*********************************************************************************************
** File Name:         Ng5_SupportpartImpl.hxx
**
** File Description:
** This file contains declaration for overriding finalizecreateinput method
**
** History:
**   mm/dd/yyyy  Name          Comments
**   ----------  ------------- ------------------------
**   12/28/2016	 Shibabrata 	declaration for overriding finalizecreateinput method
*********************************************************************************************/

#ifndef NG5NEWGENERATION__NG5_SUPPORTPARTIMPL_HXX
#define NG5NEWGENERATION__NG5_SUPPORTPARTIMPL_HXX

#include <Ng5Core/Ng5_SupportPartGenImpl.hxx>

#include <Ng5Core/libng5core_exports.h>


namespace ng5newgeneration
{
    class Ng5_SupportPartImpl; 
    class Ng5_SupportPartDelegate;
}

class  NG5CORE_API ng5newgeneration::Ng5_SupportPartImpl
    : public ng5newgeneration::Ng5_SupportPartGenImpl
{
public:


    ///
    /// Description for the Finalize Create Input
    /// @param creInput - desc for  creInput parameter
    /// @return - Return desc for Initialize for Create
    ///
    int  finalizeCreateInputBase( ::Teamcenter::CreateInput *creInput );

protected:
    ///
    /// Constructor for a Ng5_SupportPart
    explicit Ng5_SupportPartImpl( Ng5_SupportPart& busObj );

    ///
    /// Destructor
    virtual ~Ng5_SupportPartImpl();

private:
    ///
    /// Default Constructor for the class
    Ng5_SupportPartImpl();
    
    ///
    /// Private default constructor. We do not want this class instantiated without the business object passed in.
    Ng5_SupportPartImpl( const Ng5_SupportPartImpl& );

    ///
    /// Copy constructor
    Ng5_SupportPartImpl& operator=( const Ng5_SupportPartImpl& );

    ///
    /// Method to initialize this Class
    static int initializeClass();

    ///
    ///static data
    friend class ng5newgeneration::Ng5_SupportPartDelegate;

};

#include <Ng5Core/libng5core_undef.h>
#endif // NG5NEWGENERATION__NG5_SUPPORTPARTIMPL_HXX
