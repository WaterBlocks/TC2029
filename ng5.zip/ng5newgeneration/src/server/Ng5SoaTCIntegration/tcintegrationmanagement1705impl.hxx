/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#ifndef TEAMCENTER_SERVICES_TCINTEGRATION_2017_05_TCINTEGRATIONMANAGEMENT_IMPL_HXX 
#define TEAMCENTER_SERVICES_TCINTEGRATION_2017_05_TCINTEGRATIONMANAGEMENT_IMPL_HXX


//SOA File
#include <tcintegrationmanagement1705.hxx>
#include <TCIntegration_exports.h>


namespace Ng5
{
    namespace Soa
    {
        namespace TCIntegration
        {
            namespace _2017_05
            {
                class TCIntegrationManagementImpl;
            }
        }
    }
}


class SOATCINTEGRATION_API Ng5::Soa::TCIntegration::_2017_05::TCIntegrationManagementImpl : public Ng5::Soa::TCIntegration::_2017_05::TCIntegrationManagement

{
public:

    virtual TCIntegrationManagementImpl::SoaResponse executeOperation ( const InputStructure& input );


};


/**/
#include <TCIntegration_undef.h>
#endif
