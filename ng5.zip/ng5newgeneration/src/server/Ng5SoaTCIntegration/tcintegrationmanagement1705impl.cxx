/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif


#include <string>
#include <fstream>
#include <iostream>

//SOA INCLUDES
#include <tcintegrationmanagement1705impl.hxx>
#include <Ng5_operationsdefs.h>
//SOA File
using namespace std;
using namespace Teamcenter;
using namespace Ng5::Soa::TCIntegration::_2017_05;
using namespace Teamcenter::Soa::Server;


/*SOA Starts*/

TCIntegrationManagementImpl::SoaResponse TCIntegrationManagementImpl::executeOperation ( const InputStructure& input )
{
	int ifail = ITK_ok;
	SoaResponse response;
	TC_write_syslog("\n+++TCOPUtils Debug Message : Entered into SOA code\n");


	int iInputCode = input.inputCode;
    string sInputString = input.inputString;
	std::string outputStringInfo = "";
	Teamcenter::Soa::Server::ServiceData serviceData;
	string userId = (input.userInfo).c_str();

	TC_write_syslog("\n\t+++TCOPUtils Debug Message From SOA: inputCode is %d\n", iInputCode);
	TC_write_syslog("\n\t+++TCOPUtils Debug Message From SOA: inputString is %s\n", (sInputString).c_str());
	TC_write_syslog("\n\t+++TCOPUtils Debug Message From SOA: userInfo is %s\n", (input.userInfo).c_str());

	try
	{
		ifail = TCOPUtils_call_operation(iInputCode, sInputString, userId, outputStringInfo);
		TC_write_syslog("\n\t+++TCOPUtils Debug Message From SOA: Back from _call_operation outputStringInfo is %s\n", (outputStringInfo).c_str());
	}
	catch (const IFail& ex)
	{
		if (ifail == ITK_ok)
		{
			ifail = 919999;
		}
		response.outputCode = ifail;
	    response.outputString = ex.getMessage();
		response.serviceData = serviceData;

		TC_write_syslog("\n\t+++TCOPUtils Debug Message From SOA: Exception caught %s\n",( ex.getMessage()).c_str());
		return response;
	}
	
	response.outputCode = ifail;
	response.outputString = outputStringInfo;
	response.serviceData = serviceData;


	TC_write_syslog("\n\t+++TCOPUtils Debug Message From SOA: response.outputCode is %d\n", response.outputCode);
	TC_write_syslog("\n\t+++TCOPUtils Debug Message From SOA: response.outputStringInfo is %s\n", (response.outputString).c_str());
	TC_write_syslog("\n\t+++TCOPUtils Debug Message From SOA: Before response.serviceData\n");
	return response;

}

/*SOA Ends*/
