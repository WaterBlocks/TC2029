/* 
 @<COPYRIGHT>@
 ==================================================
 Copyright 2012
 Siemens Product Lifecycle Management Software Inc.
 All Rights Reserved.
 ==================================================
 @<COPYRIGHT>@
*/

#include <unidefs.h>
#if defined(SUN)
#include <unistd.h>
#endif

#include <mbomdataservice2012impl.hxx>
#include<tc/tc_macros.h>
#include<me/me.h>
#include<bom/bom.h>
#include<tccore/aom.h>
#include<tccore/aom_prop.h>
#include<iostream>
#include<algorithm>


#define BL_SUFFIX "ng5_bl_suffix"
#define BL_ITEMID "bl_item_item_id"
#define BL_MFGDESC "ng5_bl_ice_mfg_desc1"
#define CUSTOMER  "ng5_customer"//EBOM2MBOM
#define HASCUSTPARTFORM  "Ng5_rPartHasCustomerPrtForm" //EBOM2MBOM


using namespace Ng5::Soa::MBOMManagement::_2020_12;
using namespace Teamcenter::Soa::Server;


static int totalBomLineCount = 0;

std::vector<std::string> getProcessBOMChild (tag_t tBOMLine, std::vector<std::string> vsuffix)
{
	std::vector<std::string> rvsuffix = vsuffix;
	int ibchild =0;
	char* enditemstatevalue= NULL;
	tag_t* tbchild= NULL;

	ITKCALL(AOM_UIF_ask_value(tBOMLine,"Ng5_Is_Ipa",&enditemstatevalue));
	TC_write_syslog("\n enditemstatevalue = %s \n ", enditemstatevalue);

	if(tc_strcmp(enditemstatevalue,"Yes")!=0)
	{
		ITKCALL(BOM_line_ask_child_lines(tBOMLine,&ibchild,&tbchild));
		for(int bcount =0 ;bcount <ibchild; bcount++)
		{
			char* cpSuffix = NULL;
			AOM_ask_value_string (tbchild[bcount],BL_SUFFIX,&cpSuffix );
			char* cpItemId = NULL;
			AOM_ask_value_string (tbchild[bcount],BL_ITEMID,&cpItemId );
			char* cpMfgDec = NULL;
			AOM_ask_value_string (tbchild[bcount],BL_MFGDESC,&cpMfgDec );
			if(cpSuffix != NULL && tc_strlen(cpSuffix)>0)
			{
				std::string tempstr (cpSuffix);
				tempstr.append("|");
				tempstr.append(cpItemId);
				tempstr.append("|");
				if(cpMfgDec != NULL)
				{
					tempstr.append(cpMfgDec);
					tempstr.append("|");
				}
				if (std::find(vsuffix.begin(), vsuffix.end(), tempstr) == vsuffix.end())
				{
					TC_write_syslog("\n adding cpSuffix = %s \n ", cpSuffix);
					rvsuffix.push_back(tempstr.c_str());
				}
				NG5_MEM_TCFREE(cpSuffix);
			}
			rvsuffix = getProcessBOMChild (tbchild[bcount], rvsuffix);
		}


	}
	NG5_MEM_TCFREE(enditemstatevalue);
	NG5_MEM_TCFREE(tbchild);
	return rvsuffix;
}

MBOMDataServiceImpl::GetCustomerNames MBOMDataServiceImpl::getAssociatedOEMNames( const std::string revUid )
{
    tag_t tparent = NULLTAG;

    TC_write_syslog("revUid : %s\n",revUid.c_str());

    ITK__convert_uid_to_tag(revUid.c_str(), &tparent);
    TC_write_syslog("tparent : %d\n",tparent);
    std::vector<std::string> oemNames;
    int	nMatMstrLinks	    =	0;
	tag_t tRelation         =   NULLTAG;
	tag_t *tpMatMstrLinks	=	NULL;

	ITKCALL( GRM_find_relation_type(HASCUSTPARTFORM, &tRelation) );

    if(tparent != NULLTAG && tRelation!=NULLTAG)
    {
		// check if the relationship exist in EngPart / Raw Material
    	ITKCALL( GRM_list_secondary_objects_only(tparent, tRelation, &nMatMstrLinks, &tpMatMstrLinks) );
		for(int i=0;i<nMatMstrLinks;i++)
		{
			char *OEMName_mf= NULL;
			ITKCALL(AOM_ask_value_string(tpMatMstrLinks[i], CUSTOMER ,&OEMName_mf ));

			if(OEMName_mf !=NULL)
			{
				oemNames.push_back(OEMName_mf);
				 NG5_MEM_TCFREE(OEMName_mf);
			}

		}
	}else oemNames.push_back("");
    MBOMDataServiceImpl::GetCustomerNames sOEMSet;
    sOEMSet.oemnames = oemNames;
    NG5_MEM_TCFREE(tpMatMstrLinks);
    return sOEMSet;
}

MBOMDataServiceImpl::GetMBOMLines MBOMDataServiceImpl::getMBOMColorCodes ( const std::string bomTopLine )
{
    tag_t tparent = NULLTAG,twindow= NULLTAG,twintopLine;

    TC_write_syslog("bomTopLine : %s\n",bomTopLine.c_str());

    ITK__convert_uid_to_tag(bomTopLine.c_str(), &tparent);
    std::vector<std::string> vsuffix;
    ITKCALL(BOM_create_window(&twindow));
    if(tparent != NULLTAG)
    {
    	
        BOM_set_window_top_line(twindow,tparent,NULLTAG,NULLTAG,&twintopLine);
		if(twintopLine != NULLTAG)
		{
			 vsuffix = getProcessBOMChild (twintopLine, vsuffix);
		}
    }else vsuffix.push_back("");
	ITKCALL(BOM_close_window(twindow));
    MBOMDataServiceImpl::GetMBOMLines suffixdet;
    suffixdet.bomLineDetails = vsuffix;
    return suffixdet;
}
std::string MBOMDataServiceImpl::getEBOMSizeForCloningType ( const BusinessObjectRef<Teamcenter::ItemRevision>& ebomTopline )
{
    // TODO implement operation

	char 		*cpRevRule      		= NULL;

	tag_t 		rule                    = NULLTAG,
				window                  = NULLTAG,
		        bvr                     = NULLTAG,
				tEbomItemRev			= NULLTAG,
				tEBOMWindowTopline		= NULLTAG,
		        ebomToplineRev          = NULLTAG;

	bool 		isBackGroundFlag 		= false;
	std::string isBackGroundFlagStr;

	//ITKCALL(Ng5_getRev2CopyFrom(ebomTopline,&tEbomItemRev));

	ITKCALL(BOM_create_window (&window));
	ITKCALL(PREF_ask_char_value	(MFGREVRULEPREF,0,&cpRevRule));
	ITKCALL(CFM_find(cpRevRule, &rule));
	ITKCALL(BOM_set_window_config_rule(window, rule));
	ITKCALL(BOM_set_window_pack_all(window, TRUE));
	ITKCALL(BOM_set_window_top_line(window, NULLTAG, ebomTopline, bvr, &tEBOMWindowTopline));
	isBackGroundFlag = Ng5_getEBOMLineCount1(tEBOMWindowTopline);

	if (isBackGroundFlag)
	{
		isBackGroundFlagStr = "Yes";
	}
	else
	{

		isBackGroundFlagStr = "No";
	}

	ITKCALL(BOM_close_window(window));

	NG5_MEM_TCFREE(cpRevRule);

	return isBackGroundFlagStr;
}


bool Ng5_getEBOMLineCount1(tag_t line)
{
    int 		blChildCount 		= 0;
    int			iItemID				= 0;
    int			iLevelAttr			= 0;
    int 		iLevel				= 0;
    int 		iBackGroundLimit	= 0;

    bool 		isBackGround 		= false;
    tag_t		item_revision 		= NULLTAG;
    tag_t		*tChildren 			= NULL;



	TC_write_syslog("\n \nEntering Ng5_TraverseMfgNodes");


    ITKCALL(BOM_line_ask_child_lines(line, &blChildCount, &tChildren));
    ITKCALL(BOM_line_look_up_attribute("bl_level_starting_0", &iLevelAttr));
    ITKCALL(BOM_line_ask_attribute_int(line, iLevelAttr, &iLevel));
	ITKCALL(PREF_ask_int_value	(MFGCLONINGBGLIMIT,0,&iBackGroundLimit));



    if (iLevel == 0)
    {
    	totalBomLineCount = 0;
    }


	for (int ii = 0; ii < blChildCount; ii++)
	{
		if (totalBomLineCount < iBackGroundLimit)
		{

			totalBomLineCount = totalBomLineCount + 1;

			isBackGround = Ng5_getEBOMLineCount1(tChildren[ii]);
		}
		else
		{
			isBackGround = true;
			break;
		}
	}
	NG5_MEM_TCFREE(tChildren);
	return isBackGround;

}
