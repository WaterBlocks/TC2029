//@<COPYRIGHT>@
//==================================================
//Copyright $2019.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@


#include <common/library_indicators.h>

#if !defined(EXPORTLIBRARY)
#   error EXPORTLIBRARY is not defined
#endif

#undef EXPORTLIBRARY

#if !defined(LIBNG5SOAEQUBESERVICES) && !defined(IPLIB)
#   error IPLIB or LIBNG5SOAEQUBESERVICES is not defined
#endif

#undef NG5SOAEQUBESERVICES_API
#undef NG5SOAEQUBESERVICESEXPORT
#undef NG5SOAEQUBESERVICESGLOBAL
#undef NG5SOAEQUBESERVICESPRIVATE
