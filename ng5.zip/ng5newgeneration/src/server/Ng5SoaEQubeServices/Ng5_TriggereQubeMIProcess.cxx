
//@<COPYRIGHT>@
//==================================================
//Copyright $2019.
//eQ Technologic Private Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   FILENAME : Ng5_TriggereQubeMIProcess.cxx
 *   DESCRIPTION : This extension can be used to trigger an url on operations like IMAN_save, IMAN_delete, IMAN_refresh etc. UID of an object is appended to the url.
 *
 *
 *	 FUNCTIONS :	int 	Ng5_TriggereQubeMIProcess( METHOD_message_t * , va_list )
 * 					char*	getErrorMessage( int )
 *	 				int 	getTCPreferenceValue( const char* , char ** )
 *	 				char* 	escapeCharsForHTTP( char * )
 *	 				char* 	appendURLParam( char * ,char * )
 *	 				int 	processHTTPResponse(int , char *)
 *
 *	 AUTHOR : Mangesh Dabhade	START DATE : 23 Aug 2019
 */

#include <Ng5SoaEQubeServices/Ng5_TriggereQubeMIProcess.hxx>
#include<stdio.h>
#include <ug_va_copy.h>
#include<curl/curl.h>
#include<tccore/item.h>
#include <curl/easy.h>
#include <tc/preferences.h>
#include <string.h>


//Extended Error Codes
#define CUSTOM_ERROR_BASE EMH_USER_error_base + 500
#define HOSTNAME_INVALID_ERROR CUSTOM_ERROR_BASE + 1
#define INVALID_URL_ERROR CUSTOM_ERROR_BASE + 2
#define PAGE_NOT_FOUND_ERROR CUSTOM_ERROR_BASE + 3
#define	INVALID_PORT_IN_HTTP_URL_ERROR CUSTOM_ERROR_BASE + 4
#define	REQUEST_SENDING_ERROR CUSTOM_ERROR_BASE + 5
#define	RESPONSE_READ_ERROR CUSTOM_ERROR_BASE + 6
#define SSL_CONNECT_ERROR CUSTOM_ERROR_BASE + 7
#define UNSUPPORTED_PROTOCOL_ERROR CUSTOM_ERROR_BASE + 8
#define COULDNT_RESOLVE_PROXY_ERROR CUSTOM_ERROR_BASE + 9
#define GENERIC_HTTP_ERROR CUSTOM_ERROR_BASE + 10

#define HTTP_RESPONSE_SUCCESS 200
#define HTTP_RESPONSE_ERROR_404 404

#define HTTP_URL_PREF "HTTP_TRIGGER_URL"

#define HTTP_TRIGGER_URL_FAIL_ON_ERROR "HTTP_TRIGGER_URL_FAIL_ON_ERROR"
#define REPORT_CURL_ERROR(x) if(x != CURLE_OK) TC_write_syslog("\nNg5_TriggereQubeMIProcess : Curl Error Code : %d\t Error Message : %s\n", x, curl_easy_strerror(x));


/**
 	Function : getErrorMessage
 	--------------------------
	Gets the error message corresponding to the Extended Error Code

	ifail : Extended Error Code (I)

    @returns Error message corresponding to the Extended Error Code
*/
char * getErrorMessage(int ifail)
{
	char *errorMessage;

	switch(ifail)
	{
		case HOSTNAME_INVALID_ERROR:
				errorMessage = MEM_string_copy("Hostname invalid in HTTP_URL");
				break;
		case INVALID_URL_ERROR:
				errorMessage = MEM_string_copy("HTTP_URL is invalid");
				break;
		case PAGE_NOT_FOUND_ERROR:
				errorMessage = MEM_string_copy("Page Not Found Error");
				break;
		case INVALID_PORT_IN_HTTP_URL_ERROR:
				errorMessage = MEM_string_copy("Invalid port in HTTP_URL");
				break;
		case REQUEST_SENDING_ERROR:
				errorMessage = MEM_string_copy("Error sending HTTP request");
				break;
		case RESPONSE_READ_ERROR:
				errorMessage = MEM_string_copy("Error reading HTTP response");
				break;
		case SSL_CONNECT_ERROR:
				errorMessage = MEM_string_copy("SSL connect error");
				break;
		case UNSUPPORTED_PROTOCOL_ERROR:
				errorMessage = MEM_string_copy("Unsupported protocol error");
				break;
		case COULDNT_RESOLVE_PROXY_ERROR:
				errorMessage = MEM_string_copy("Couldn't resolve proxy error");
				break;
		case GENERIC_HTTP_ERROR:
				errorMessage = MEM_string_copy("Generic HTTP error");
				break;
		default :
				errorMessage = MEM_string_copy("Internal error");
				break;
	}

	return errorMessage;
}


/**
 	Function : getTCPreferenceValue
 	-------------------------------
	Gets the value of a TC Preference having data type String

	prefName  : Name of the preference (I)
	prefValue : Value of the preference (OF)

    @returns ITK_ok on success

*/
int getTCPreferenceValue(const char *prefName, char **prefValue)
{
    int ifail =  PREF_ask_char_value(prefName, 0, prefValue);

    if(ifail != ITK_ok)
    {
        TC_write_syslog("\nNg5_TriggereQubeMIProcess : TC Preference value for %s is not found\n", prefName);
    }
    else if(*prefValue != NULL && strlen(*prefValue) > 0)
	{
		TC_write_syslog("\nNg5_TriggereQubeMIProcess : TC Preference value for %s  found as %s\n", prefName, *prefValue);
	}

    return ifail;

}



/**
 	Function : appendURLParam
 	--------------------------
	Appends parameter in the URL

	url		: HTTP URL (I)
	param	: parameter to append (OF)

    @returns URL with appended parameter

*/
char * appendURLParam(char *url,char *param)
{
	char *crlValue = NULL;

	TC_write_syslog("\nNg5_TriggereQubeMIProcess : Appending %s in HTTP_URL\n", param);

	crlValue = curl_escape(param,0);
	url = MEM_string_append(url, crlValue);
	curl_free(crlValue);

	return url;
}


/**
 	Function : Ng5_TriggereQubeMIProcess
 	---------------------------------
	Triggers HTTP URL obtained from HTTP_TRIGGER_URL preference

	Contextual information passed with a message.

    @returns
    ITK_ok on success
    Extended Error Code in case of failure

*/
int Ng5_TriggereQubeMIProcess( METHOD_message_t *msg, va_list args )
{

	char *tempURL  = NULL;
	char *finalURL  = NULL;
	char *errorMessage = NULL;
	char *uid = NULL;
	char *failOnError = NULL;

	int httpRespCode = 0;
	int ifail = ITK_ok;
	int onErrorIfail = ITK_ok;
	bool bArgUrlFound = TRUE;
	tag_t object = NULLTAG;
	va_list largs;

	CURL *cCurl = NULL;
	CURLcode cRes = CURLE_OK;
	char *curlResponse = NULL;

	TC_write_syslog("\n\n*********************Start Ng5_TriggereQubeMIProcess*********************\n");

	TC_write_syslog("\nNg5_TriggereQubeMIProcess : Reading TC Preference variable value for: %s\n", HTTP_URL_PREF );
		ifail = getTCPreferenceValue((const char *) HTTP_URL_PREF, &tempURL);


	if(ifail == ITK_ok && tempURL != NULL && strlen(tempURL) > 0)
	{

		va_copy( largs, args );
		object = va_arg(largs, tag_t);
		va_end( largs );

		ifail = POM_tag_to_uid(object,&uid);

		if(ifail != ITK_ok)
		{
			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Internal error while getting UID\n");
		}
		else
		{
			tempURL = MEM_string_append(tempURL,"uid=");
			tempURL = appendURLParam(tempURL,uid);

			finalURL = tempURL;

			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Final URL after appending UID : %s\n", finalURL);

			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Before curl_global_init\n");
			cRes = curl_global_init(CURL_GLOBAL_DEFAULT);
			REPORT_CURL_ERROR(cRes);

			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Before curl_easy_init\n");
			cCurl = curl_easy_init();
			REPORT_CURL_ERROR(cRes);


			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Before curl_easy_setopt CURLOPT_URL\n");
			cRes = curl_easy_setopt( cCurl, CURLOPT_URL, finalURL );
			REPORT_CURL_ERROR(cRes);

			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Before curl_easy_setopt CURLOPT_FOLLOWLOCATION\n");
			curl_easy_setopt(cCurl, CURLOPT_FOLLOWLOCATION, 1L);
			REPORT_CURL_ERROR(cRes);



			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Before curl_easy_setopt CURLOPT_SSLVERSION\n");
			curl_easy_setopt(cCurl, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1);
			REPORT_CURL_ERROR(cRes);


			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Before curl_easy_perform\n");
			cRes = curl_easy_perform( cCurl );
			REPORT_CURL_ERROR(cRes);

			if ( cRes != CURLE_OK )
			{
				if(cRes == CURLE_UNSUPPORTED_PROTOCOL)
				{
					ifail = UNSUPPORTED_PROTOCOL_ERROR;
				}
				else if( cRes == CURLE_URL_MALFORMAT )
				{
					ifail = INVALID_URL_ERROR;
				}
				else if( cRes == CURLE_COULDNT_RESOLVE_PROXY  )
				{
					ifail = COULDNT_RESOLVE_PROXY_ERROR;
				}
				else if( cRes == CURLE_SSL_CONNECT_ERROR  )
				{
					ifail = SSL_CONNECT_ERROR;
				}
				else if( cRes == CURLE_COULDNT_RESOLVE_HOST)
				{
					ifail = HOSTNAME_INVALID_ERROR;
				}
				else if( cRes == CURLE_COULDNT_CONNECT)
				{
					ifail = INVALID_PORT_IN_HTTP_URL_ERROR;
				}
				else
				{
					ifail = REQUEST_SENDING_ERROR;
				}

				errorMessage = getErrorMessage(ifail);

				TC_write_syslog("\nNg5_TriggereQubeMIProcess : Error while sending request to URL, %s\n", errorMessage);
			}
			else
			{
				cRes = curl_easy_getinfo(cCurl, CURLINFO_RESPONSE_CODE, &httpRespCode);

				ifail = ITK_ok;

				if ( cRes != CURLE_OK )
				{
					ifail = RESPONSE_READ_ERROR;
				}

				if( ifail != ITK_ok)
				{
					errorMessage = getErrorMessage(ifail);

					TC_write_syslog("\nNg5_TriggereQubeMIProcess : HTTP Response Error, %s\n", errorMessage);
				}
			}

			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Before curl_easy_cleanup\n");
			curl_easy_cleanup(cCurl);

			TC_write_syslog("\nNg5_TriggereQubeMIProcess : Before curl_global_cleanup\n");
			curl_global_cleanup();
		}

		if(finalURL != NULL)
		{
			MEM_free(finalURL);
		}
		if(curlResponse != NULL)
		{
			MEM_free(curlResponse);
		}
		if(uid != NULL)
		{
			MEM_free(uid);
		}
		if(errorMessage != NULL)
		{
			MEM_free(errorMessage);
		}
	}

	if(ifail != ITK_ok)
	{
		TC_write_syslog("\nNg5_TriggereQubeMIProcess : Reading TC Preference variable value for: %s\n", HTTP_TRIGGER_URL_FAIL_ON_ERROR );
		onErrorIfail = getTCPreferenceValue((const char *) HTTP_TRIGGER_URL_FAIL_ON_ERROR, &failOnError);

		if( onErrorIfail == ITK_ok && failOnError != NULL && strcmp(failOnError,"FALSE") == 0 )
		{
			TC_write_syslog("\nNg5_TriggereQubeMIProcess : HTTP_TRIGGER_URL_FAIL_ON_ERROR set to false so not failing an user action\n");
			ifail = ITK_ok;
		}

		if(failOnError != NULL)
		{
			MEM_free(failOnError);
		}
	}
	TC_write_syslog("\n*********************End Ng5_TriggereQubeMIProcess*********************\n\n");

	return ifail;

}
