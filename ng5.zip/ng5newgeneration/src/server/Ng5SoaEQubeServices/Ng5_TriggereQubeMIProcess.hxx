//@<COPYRIGHT>@
//==================================================
//Copyright $2019.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* 
 * @file 
 *
 *   This file contains the declaration for the Extension Ng5_TriggereQubeMIProcess
 *
 */
 
#ifndef NG5_TRIGGEREQUBEMIPROCESS_HXX
#define NG5_TRIGGEREQUBEMIPROCESS_HXX
#include <tccore/method.h>
#include <Ng5SoaEQubeServices/libng5soaequbeservices_exports.h>
#ifdef __cplusplus
         extern "C"{
#endif
                 
extern NG5SOAEQUBESERVICES_API int Ng5_TriggereQubeMIProcess(METHOD_message_t* msg, va_list args);
                 
#ifdef __cplusplus
                   }
#endif
                
#include <Ng5SoaEQubeServices/libng5soaequbeservices_undef.h>
                
#endif  // NG5_TRIGGEREQUBEMIPROCESS_HXX
